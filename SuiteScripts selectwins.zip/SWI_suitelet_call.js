/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/http','N/url','N/currentRecord','N/ui/dialog'],

function(http,url,currentrecord,dialog) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2 62528
     */
	var exports = {};
    function pageInit(scriptContext) {
    	console.log('suitelet');
      //suppressing leave page warning
     window.onbeforeunload = null;
      
      //disabling filter fields ones it have values
      var record = currentrecord.get();
      	var l=record.getValue({
      	 fieldId: 'custpage_ven_name'
      	 });
     	var sdate=record.getValue({
         	 fieldId: 'custpage_sdate'
         	 });
   	var edate=record.getValue({
        	 fieldId: 'custpage_edate'
        	 });
      	 if(l||sdate||edate){
      	
    	var field = record.getField({
    		fieldId: 'custpage_ven_name'
    	});
    	field.isDisabled = true;
    	var sdate = record.getField({
    		fieldId: 'custpage_sdate'
    	});
    	sdate.isDisabled = true;
    	var edate = record.getField({
    		fieldId: 'custpage_edate'
    	});
    	edate.isDisabled = true;
      	 }
    }
    function fieldChanged(scriptContext) {
    	return true

    }

   function vendorsuitelet(){
	   //var vid =context.request.parameters.custpage_ven_name;
	 
   
   	var record = currentrecord.get();
   	 var l=record.getValue({
   	 fieldId: 'custpage_ven_name'
   	 });
   	var sdate=record.getValue({
      	 fieldId: 'custpage_sdate'
      	 });
	var edate=record.getValue({
     	 fieldId: 'custpage_edate'
     	 });
   	 
	 
	 var output = url.resolveScript({
		   scriptId: 'customscript_rebate_prcoess_suitelet',
		   deploymentId: 'customdeploy_rebate_prcoess_suitelet',
		   //returnExternalUrl: true
		  });
	  
	 //11/5/2020 format needed
	 if(sdate){
	 var filterDate = new Date(sdate);
	 var fDate  = filterDate.getDate();
	 var fMonth  = filterDate.getMonth()+1;
	 var fYear  = filterDate.getFullYear();
	 var dateFilter  = fMonth+"/"+fDate+"/"+fYear;
   	 
 		   output=output+'&sdate='+dateFilter;
	 }
	 if(edate){
		 var filterDate = new Date(edate);
		 var fDate  = filterDate.getDate();
		 var fMonth  = filterDate.getMonth()+1;
		 var fYear  = filterDate.getFullYear();
		 var dateFilter  = fMonth+"/"+fDate+"/"+fYear;
	   	 
	 		   output=output+'&edate='+dateFilter; 
	 }
 	   output=output+'&vid='+l;
 	   console.log(output);
 	  location.replace(output);

  
	   
 
   }
   function resetfun(){
	   //var vid =context.request.parameters.custpage_ven_name;
	   console.log('calling');
	  
	
   	 var output = url.resolveScript({
 		   scriptId: 'customscript_rebate_prcoess_suitelet',
 		   deploymentId: 'customdeploy_rebate_prcoess_suitelet',
 		   //returnExternalUrl: true
 		  });
 	 
 	   console.log(output);
 	  location.replace(output);

   }
   function invoiceeror(){
	   //console.log('calling');
	  
	  
   	 var output = url.resolveScript({
 		   scriptId: 'customscript_rebate_prcoess_suitelet',
 		   deploymentId: 'customdeploy_rebate_prcoess_suitelet',
 		   //returnExternalUrl: true
 		  });
 	 
 	   log.debug(output)
 	  location.replace(output);

   }
   
   exports.vendorsuitelet = vendorsuitelet;
   exports.resetfun = resetfun;
   exports.pageInit = pageInit;
   exports.fieldChanged = fieldChanged;
   exports.invoiceeror = invoiceeror;
   return exports;
    
});