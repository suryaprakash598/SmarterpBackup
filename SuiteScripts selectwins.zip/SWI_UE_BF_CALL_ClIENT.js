function beforeLoadEntryFunction(type, form)
{
  form.setScript('customscript_swi_cli_hide_pricelevel');
}