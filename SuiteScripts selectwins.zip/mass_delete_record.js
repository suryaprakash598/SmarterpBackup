function findRelatedRecords(rec_type, rec_id)
{
	try{
		 
		var o_rec_obj = nlapiLoadRecord(rec_type, rec_id);
		var links=  o_rec_obj.getLineItemCount('links');
		for(var i=links;i >= 1; i--) 
		{
			var recId = o_rec_obj.getLineItemValue('links','id',i);
			var rectype = o_rec_obj.getLineItemValue('links','type',i);
			nlapiLogExecution('debug','recId'+recId,'rectype'+rectype);
			if(rectype=='Invoice')
			{
				nlapiDeleteRecord('invoice',recId);
			}
			if(rectype=='Delivered')
			{
				nlapiDeleteRecord('itemfulfillment',recId);
				
			}
			if(rectype=='Return Authorization')
			{
				nlapiDeleteRecord('returnauthorization',recId);
				
			}
			if(rectype=='Credit Memo')
			{
				nlapiDeleteRecord('creditmemo',recId);
				
			}
			if(rectype=='Item Receipt')
			{
				nlapiDeleteRecord('itemreceipt',recId);
				
			}
			if(rectype=='Payment')
			{
				nlapiDeleteRecord('customerpayment',recId);
				
			}if(rectype=='Bill')
			{
				nlapiDeleteRecord('vendorbill',recId);
				
			}
			//nlapiDeleteRecord(type,id);
		}
		var id= nlapiDeleteRecord(rec_type,rec_id);
		nlapiLogExecution('debug','so id',id);
	}catch(e)
	{
		nlapiLogExecution('debug','error',e.toString());
	}
}