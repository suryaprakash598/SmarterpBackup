function INV_RemoveBackOrderItems(type)
{
	try{
		if(type=='create'){ // || type=='edit'
			
			var recId = nlapiGetRecordId();
			var recType = nlapiGetRecordType();
			var o_invObj = nlapiLoadRecord(recType,recId);
			var lineCount = o_invObj.getLineItemCount('item');
			for(var i = lineCount; i >= 2; i--) {
			   var isAvail = o_invObj.getLineItemValue('item','quantityavailable',i);
			   
				if(isAvail==0){
				  o_invObj.removeLineItem('item', i);
				}
			}
			nlapiSubmitRecord(o_invObj,true,true);
		}
		
	}catch(e)
	{
		nlapiLogExecution('debug','Error',e.toString());
	}
}

/*
If all items are 0 avialble then we should not remove all items
other wise will get Code: USER_ERROR Details: You must enter at least one line item for this transaction.


*/