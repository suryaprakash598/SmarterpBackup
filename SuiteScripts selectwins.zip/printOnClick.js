function printPDF(id) {
	if(id)
	{
		//var suiteletURL = nlapiResolveURL('SUITELET', 'customscript_print_vendor_rma', 'customdeploy_print_vendor_rma')
		window.open("/app/site/hosting/scriptlet.nl?script=430&deploy=1&id="+id,"_blank");
	}
    
}
function printVCPDF(id) {
	if(id)
	{
		//var suiteletURL = nlapiResolveURL('SUITELET', 'customscript_print_vendor_rma', 'customdeploy_print_vendor_rma')
		window.open("/app/site/hosting/scriptlet.nl?script=433&deploy=1&id="+id,"_blank");
	}
    
}