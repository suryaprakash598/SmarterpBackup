function pageInitSetCustItems() {
	var window_url = window.location.href;

	var entity = getNS_url_param('entity', window_url);
	if (_logValidation(entity)) {
		var itemList = nlapiLookupField('customer', entity, 'custentity_swi_freqbtitems');
		if (_logValidation(itemList)) {
			var itemArray = itemList.split(",");
			var count = itemArray.length;
			for (var x = 1; x <= count; x++) {
				nlapiSelectNewLineItem('item');
				nlapiSetCurrentLineItemValue('item', 'item', itemArray[x - 1], true, true);
				nlapiSetCurrentLineItemValue('item', 'quantity', 0, true, true);
				nlapiCommitLineItem('item');
			}
		}
	}
}

function getNS_url_param(name, url) {

	name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
	var regexS = "[\\?&]" + name + "=([^&#]*)";
	var regex = new RegExp(regexS);
	var results = regex.exec(url);
	if (results == null)
		return "";
	else
		return results[1];
}

function fieldChangedSourceItems(type, name) {
	if (name == 'entity') {

		var entity = nlapiGetFieldValue('entity');
		//alert('entity==' + entity)
		/*if (entity != null) {
			var s_url = 'https://3497583.app.netsuite.com/app/accounting/transactions/salesord.nl?whence=&entity=' + entity;
			window.location.replace(s_url);

		}*/

		if (name == 'entity') {

			var entity = nlapiGetFieldValue('entity');

			if (entity != null) {
				/*	var iLineCount = nlapiGetLineItemCount('item');
					alert('iLineCount' + iLineCount)
					if (iLineCount > 0) {
						for (var i = iLineCount; i >= 1; i--) {
							alert('i' + i)

							nlapiRemoveLineItem('item', i);

						}
					}*/
				var itemList = nlapiLookupField('customer', entity, 'custentity_swi_freqbtitems');
				if (_logValidation(itemList)) {
					var itemArray = itemList.split(",");
					var count = itemArray.length;
					for (var x = 1; x <= count; x++) {
						nlapiSelectNewLineItem('item');
						nlapiSetCurrentLineItemValue('item', 'item', itemArray[x - 1], true, true);
						nlapiSetCurrentLineItemValue('item', 'quantity', 0, true, true);
						nlapiCommitLineItem('item');
					}
				}
				return true;
			}
		}
	}
}

function _logValidation(value) {
	if (value != null && value != '' && value != undefined && value.toString() != 'NaN' && value != NaN) {
		return true;
	} else {
		return false;
	}
}

/*function fieldChanged(type, name) {
	if (type == 'create') {
		if (name == 'entity') {
			alert('type==' + type)
			alert('name==' + name)
			var entity = nlapiGetFieldValue('entity');
			alert('entity==' + entity)
			if (entity != null) {
				var s_url = 'https://3497583.app.netsuite.com/app/accounting/transactions/salesord.nl?whence=&entity=' + entity;
				window.location.replace(s_url);
				var itemList = nlapiLookupField('customer', entity, 'custentity_swi_freqbtitems');
				var itemArray = itemList.split(",");
				var count = itemArray.length;
				for (var x = 0; x < count; x++) {
					nlapiSelectNewLineItem('item');
					nlapiSetCurrentLineItemValue('item', 'item', itemArray[x], true, true);
					nlapiSetCurrentLineItemValue('item', 'quantity', 0, true, true);
					nlapiCommitLineItem('item');	
				}
				return true;
			}
		}
	}
}
*/
function beforeLoadGetEntity(type, form, request) {
	if (type == 'create') {
		var i_entity = request.getParameter(entity);
		nlapiSetFieldValue('entity', entity);
		var itemList = nlapiLookupField('customer', entity, 'custentity_swi_freqbtitems');
		var itemArray = itemList.split(",");
		var count = itemArray.length;
		for (var x = 0; x < count; x++) {
			nlapiSelectNewLineItem('item');
			nlapiSetCurrentLineItemValue('item', 'item', itemArray[x], true, true);
			nlapiSetCurrentLineItemValue('item', 'quantity', 0, true, true);
			nlapiCommitLineItem('item');
		}
	}
}