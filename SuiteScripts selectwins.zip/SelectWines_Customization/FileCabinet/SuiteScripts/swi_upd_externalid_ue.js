/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/search'],
/**
 * @param {record} record
 */
function(record,search) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(context) {
    	

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(context) {
    	
    	var rec = context.newRecord;
    	log.debug("record ID is:", rec);
    	var internalid = rec.id;
    	log.debug('internalid'+internalid);
    	      //Step 2
    	       var SOnum = rec.getValue({
    	    		 fieldId: 'tranid'
    	    	 });
    	       log.debug('SOnum'+SOnum);
    	    	var fieldLookUp = search.lookupFields({
    					type: search.Type.INVOICE, //The intended record type
    					id: internalid, //Record ID
    					columns: ['tranid'] //Desired joined field referenced_record.desired_field
    				});
    				var tranid = fieldLookUp.tranid;
    				log.debug('tranid'+tranid);
    	if (rec) {
    	var invoice = rec.getValue({
    		fieldId: 'tranid'
    	});
    	
    	 record.submitFields({
             type: record.Type.INVOICE,
             id: internalid,
             values: {
                 'externalid': tranid
             },
    	 options: {
    	        enableSourcing: false,
    	        ignoreMandatoryFields : true
    	    }
    	 });
    	}
    	
    }

    return {
       // beforeLoad: beforeLoad,
    	//beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
    
});
