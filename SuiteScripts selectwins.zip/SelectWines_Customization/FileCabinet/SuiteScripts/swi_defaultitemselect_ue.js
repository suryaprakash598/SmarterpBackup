/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/error', 'N/record', 'N/search'],
/**
 * @param {error} error
 * @param {record} record
 * @param {search} search
 */
function(error, record, search) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(context) {
    	
    	if(context.type === context.UserEventType.CREATE){
    	
    		var salesOrder = context.newRecord;
    		
    		var entity = salesOrder.getValue('entity');
    		
    		if(entity){
    			
    			var itemList = search.lookupFields({
    						type: search.Type.CUSTOMER,
    						id: entity,
    						columns:['custentity_swi_freqbtitems']
    			});
    			
    			log.debug("Item List is:", itemList);
    			
    			
    			//var itemArray = context.value.split(",");
    			//var 
    			var count = itemList.length;
    			
    			//for (var x = 0; x < count; x++) {
    			
    			salesOrder.insertLine({
    				sublistId:'item',
    				line : 1
    			});
    			}
    			
    				salesOrder.setSublistValue({
    					sublistId: 'item',
    					fieldId: 'item',
    					line:1,
    					value: '1970'
    					});
    				
    				salesOrder.commitLine({
    					sublistId: 'item'
    					});
    			    
    		}
    		}
    	
    	

 

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {

    }

    return {
        beforeLoad: beforeLoad,
       // beforeSubmit: beforeSubmit,
        //afterSubmit: afterSubmit
    };
    
});
