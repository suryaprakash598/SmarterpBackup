/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 * @NModuleScope SameAccount
 */
define(['N/ui/serverWidget', 'N/redirect', 'N/runtime', 'N/record', 'N/ui/message', 'N/search', 'N/url', 'N/format','N/ui/dialog','N/email','N/file','N/task'],

function(serverWidget, redirect, runtime, record1, message, search, url,format,dialog,email,file,task) {
   
    /**
     * Definition of the Scheduled script trigger point.
     *
     * @param {Object} scriptContext
     * @param {string} scriptContext.type - The context in which the script is executed. It is one of the values from the scriptContext.InvocationType enum.
     * @Since 2015.2
     */
    function execute(scriptContext) {
    	
    	var scriptObj = runtime.getCurrentScript();
    	log.debug('Script parameter of custscript1:','');
    	  var fileObj = file.load({
        id: scriptObj.getParameter({
        name: 'custscript_rebatesource_fileid'
      })
      });
	  var contents = fileObj.getContents();
	  var groupResult = JSON.parse(contents);
    	 var postingDate= scriptObj.getParameter({name: 'custscript_postingdate'});
    	 //log.debug('data qsws',groupResult[0]);
    	 //log.debug('data',groupResult);
    	 if(!postingDate)
   	  {
   	  postingDate=new Date();
   	  }
    	 var keys = Object.keys(groupResult);
    	 log.debug('key',keys);
    	 for (var m = 0; m < keys.length; m++) {
             //creating invoice
             var result=createInvoice(groupResult[keys[m]],postingDate,keys[m]);
       	  
         }
    	
    }
    //custom functions
    function createInvoice(rebateData,pdate,vendor)
    {
    	
        var fields = search.lookupFields({
            type: 'vendor',
            id: vendor,
            columns: ['custentity_ns_relatedvendor']
        });
        log.debug('rebate data',rebateData);
        var vendorCustomer;
        try{
        vendorCustomer = fields.custentity_ns_relatedvendor[0].value;
        }
        catch(e){
        	log.debug('related vendor is not there');
        	return 'relatedvendor';
        }
        var updateRebateBilled = [];
        //creating BB invoice
        var rec = record1.create({
            type: 'invoice',
            isDynamic: true,
            
        });
		rec.setValue({
            fieldId: 'customform',
            value: 152
        });
		rec.setValue({
            fieldId: 'entity',
            value: vendorCustomer
        });
		
		log.debug('record',rec);
       	var initialFormattedDateString=format.parse({
    			value: pdate,
    			type: format.Type.DATE
    		});
    		var postingdate = format.format({
    			 value: initialFormattedDateString,
    			 type: format.Type.DATE
    			 });
    		postingdate=new Date(pdate);
    	
    	log.debug('formated date',postingdate);
       rec.setValue({
            fieldId: 'trandate',
            value: postingdate
        });
      
       var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
       var postingPeriod = months[postingdate.getMonth()] + ' ' + postingdate.getFullYear();
       log.debug('posting period',postingPeriod);
       
       rec.setText({
           fieldId: 'postingperiod',
           text: postingPeriod
       });
       rec.setValue({
           fieldId: 'location',
           value: 12
       });
               
        /* rec.setValue({
            fieldId: 'custbody1',
            value: true
        }); */

        var quantity=0;
        var amount=0;
        var rebateamount= 0;
        var items=[];
        //taking item data
        for (var j = 0; j <rebateData.length; j++) {
          var item={};
          item.quantity=rebateData[j].quantity;
          item.rebateAmount=rebateData[j].rebateAmount;
          item.Class=rebateData[j].Class;
          items.push(item);
          quantity= parseInt(rebateData[j].quantity)+quantity;
            amount = parseInt(rebateData[j].amount)+amount;
            rebateamount=format.parse({value:rebateData[j].rebateAmount, type: format.Type.FLOAT})+format.parse({value: rebateamount, type: format.Type.FLOAT});
            //rebateamount = parseFloat(rebateData[j].rebateAmount).toFixed(2) + parseFloat(rebateamount).toFixed(2);
            log.debug('rebateamount',rebateamount);
          
        }
        //item consolidating based on class
        var itemlist=items.reduce(function (acc,a) {
            
            if (!acc[a.Class]) {
              acc[a.Class] = []
            }
            acc[a.Class].push(a)
            return acc
          }, {});
          //log.debug('itemlist',itemlist);
          
          var listdata=itemlist['Keg Beer'];
          //log.debug('listdata',listdata);
           var keyslist = Object.keys(itemlist);
         log.debug('keylist',keyslist);
          //setting line values based on class
        for(var m=0;m<keyslist.length; m++)
            {
            var listdata=itemlist[keyslist[m]]
              
              var itemdata=totalitem(listdata);
              //log.debug('itemdatadfdfd',itemdata);

              rec.selectNewLine({
                  sublistId: 'item'
              });
			 
               if((itemdata.Class=="Keg Beer")||(itemdata.Class=="Package Beer"))
              {
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 23948
              });
              }
              else if(itemdata.Class=="Wine")
              {
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 23335
              });
              }
              else if(itemdata.Class=="Cider")
              {
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 25460
              });
              }
              else{ 
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 25461
              });
              }
              
              log.debug('itemdata.Class',itemdata.Class);
             rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'quantity',
                  value:itemdata.quantity
              });
             log.debug('itemdata.quantity',itemdata.quantity);
             rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'rate',
                  value: itemdata.rebateAmount
              });
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'custcol_ns_rebateamount',
                  value: itemdata.rebateAmount
              });
			  log.debug('itemdata.rebateAmount',itemdata.rebateAmount);
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'amount',
                  value: itemdata.rebateAmount
              });
             rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'location',
                  value: 12
              });
			  log.debug('item line level','location');
              
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'custcol_ns_rebatebilled',
                  value: true,
                  ignoreFieldChange: true
              });
            rec.commitLine({
                  sublistId: 'item'
              });
              
              
            }
        try {
        var recordId = rec.save();
		log.debug('recordId',recordId)
        }
        catch(e){
        	log.debug('error',e.toString());
        	//return 'creditmemo'; 
        }
		var contents='';
		var tranid;
        if (recordId) {
        //Gathering data for updating invoices
		loadobj = record1.load({
                    type: 'invoice',
                    id:recordId,
                    isDynamic: true,
                });
				tranid=loadobj.getValue({
    		 fieldId: 'tranid'
			});
			var sourceid=loadobj.getValue({
    		 fieldId: 'id'
			});
			contents = 'Item,Item ID,Invoice,Invoice ID,Period,Rebate Invoice,Rebate Invoice ID,Customer,Price,Quantity,Units,Rebate per Unit,Depletion Allowance,line' + '\n';
        for (var j = 0; j < rebateData.length; j++) {
          try {
               var obj = {};
            obj.tranid = rebateData[j].tranid;
            obj.item = rebateData[j].item;
            obj.itemid = rebateData[j].itemid;
            obj.rate = rebateData[j].amount / rebateData[j].quantity;
            obj.type = rebateData[j].Type;
            obj.docnumber = rebateData[j].docnumber;
            obj.Customer = rebateData[j].Customer;
            obj.amount = rebateData[j].amount;
            obj.quantity = rebateData[j].quantity;
            obj.Units = rebateData[j].Units;
            obj.rebateAmount = rebateData[j].rebateAmount;
			obj.rebateUnit = rebateData[j].rebateUnit;
			obj.line = rebateData[j].line;
			
            updateRebateBilled.push(obj)


            var item = '"' + obj.item + '"';
            var customer = '"' + obj.Customer + '"';
            contents += item + ',' + obj.itemid + ',' + obj.docnumber +',' + obj.tranid + ','+ postingPeriod +',' + tranid + ',' + sourceid + ',' + customer + 
			',' + obj.rate + ',' + obj.quantity + ',' + obj.Units + ','+ obj.rebateUnit+',' + obj.rebateAmount +',' + obj.line + '\n';

              //creating rebate source invoice record(custom record)
               
                

            } catch (e) {
                log.debug('error', e.toString())
            }
            
            
            
        }
        } else {
            var myMsg4 = message.create({
                title: "Record Creation Error",
                message: "Error in Invoice Creation",
                type: message.Type.ERROR
            });

            myMsg4.show(); // will stay up until hide is called.
        }
        //creating csv
			var fileObj = file.create({
							name: tranid+'.csv',
							fileType: file.Type.CSV,
							contents: contents,
							description: 'This is a plain text file.',
							encoding: file.Encoding.UTF8,
							folder: 81577,
							isOnline: true
							});

            var file_Id = fileObj.save();
			//updating file fieldId
			loadobj = record1.load({
                    type: 'invoice',
                    id:recordId,
                    isDynamic: true,
                });
			loadobj.setValue({
                    fieldId: 'custbody_rebate_source_document',
                    value:file_Id
                });
			var recordId1 = loadobj.save();		
			//csv import 149
			var scriptTask = task.create({taskType: task.TaskType.CSV_IMPORT});
scriptTask.mappingId =159;//sandbox 149;
var f = file.load(file_Id);
scriptTask.importFile = f;
//scriptTask.linkedFiles = {'addressbook': 'street,city\nval1,val2', 'purchases': file.load('SuiteScripts/other.csv')};
var csvImportTaskId = scriptTask.submit();

 var scriptTask = task.create({
        taskType: task.TaskType.CSV_IMPORT
      });
      scriptTask.mappingId = 166; //sandbox creditmemo;
      var f = file.load(file_Id);
      scriptTask.importFile = f;
      //scriptTask.linkedFiles = {'addressbook': 'street,city\nval1,val2', 'purchases': file.load('SuiteScripts/other.csv')};
      var csvImportTaskId = scriptTask.submit();
	  
      //nancy.sharp@selectwinesinc.com
       try{
         //sending mail
        
       var BB_record = record1.load({
            type: 'invoice',
            id: recordId,
            isDynamic: true,
        });
        var tranid = BB_record.getText({
   		 fieldId: 'tranid'
   	 });
	 var ebody;
	 while(true){
	 var csvTaskStatus = task.checkStatus({
                       taskId: csvImportTaskId 
                         });
		if (csvTaskStatus.status === task.TaskStatus.COMPLETE||csvTaskStatus.status === task.TaskStatus.FAILED)
		{
		break; 
		}
	
	}
        ebody=tranid+' is created for '+rebateData[0].vendor+'.'
        email.send({
            author: -5,
            recipients:"nancy.sharp@selectwinesinc.com",
            subject: tranid,
            body: ebody,
            RelatedRecords: {
            	 entityId: recordId}
            
        });
        log.debug("email sent");
      }
      catch(e){
        log.debug('error in sending mail');
      }

    }

    // Custom functions
    function checkNullRequired(value) {
    	var returnObj = true;
    	if (value == null || value == 'NaN' || value == undefined || value.toString().trim() == '' ) {
    		returnObj = false;
    	}
    	return returnObj;
    }
    
    
   
   
    function totalitem(listdata){
    var quantity=0;
    var rebateamount=0;

    for(var j=0; j<listdata.length; j++)
    {
    log.debug('',listdata[j]);
    quantity=parseInt(listdata[j].quantity)+quantity;
    rebateamount=format.parse({value:listdata[j].rebateAmount, type: format.Type.FLOAT})+format.parse({value: rebateamount, type: format.Type.FLOAT});
    }
    var itemdata={}
    itemdata.quantity = quantity
    itemdata.rebateAmount = rebateamount
    itemdata.Class = listdata[0].Class

    return itemdata;
    }

    return {
        execute: execute
    };
    
});