/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 */
define(['N/search','N/file','./savedsearchs'],

function(search,file,ssObj) {
   
	//Load saved search
    function execute(scriptContext) 
	{
		 var searchid = ssObj.SavedSearches.MonthEndReports;
		for(var k=0;k<searchid.length;k++){
			var objj = searchid[k];
			var id=Object.keys(searchid[k]);
			log.debug('id',id);
			var fileName = objj[id[0]];
    	var mySearch = search.load({
    		id: id[0]
    	})
    	
		//Run saved search
    	var mySearchResultSet = mySearch.run();
    	var columns = mySearch.columns;
		log.debug('mySearchResultSet',mySearchResultSet);
		//Headers of CSV File separated by commas and ends with a new line (\r\n)
		var csvFile = '';
		for(var i=0; i< columns.length; i++){
			  csvFile = csvFile+columns[i].label+',';
			} 
		
		csvFile =csvFile.slice(0, -1)+'\r\n';
			 var currentRange = mySearchResultSet.getRange({
            start : 0,
            end : 1000
		});
    
		var i = 0;  // iterator for all search results
		var j = 0;  // iterator for current result range 0..999

		while ( j < currentRange.length ) {
			
			// take the result row
			var resultObject = currentRange[j];
			// and use it like this....
			 var tempString = '';
				 for(var y=0; y< columns.length; y++){
					  var searchResult = resultObject.getValue(mySearch.columns[y]);
					 // tempString = tempString+searchResult.replace(',','&') +',';
					 tempString = tempString+'"'+searchResult+'",';
					 } 
				//log.debug('tempString...',tempString)
				tempString = tempString.slice(0, -1);
				//Add each result as a new line on CSV
				csvFile += tempString+'\r\n';
			// finally:
			i++; j++;
			if( j==1000 ) {   // check if it reaches 1000
				j=0;          // reset j an reload the next portion
				currentRange = mySearchResultSet.getRange({
					start : i,
					end : i+1000
				});
			}
		}
		 
		
		//Variable for datetime
		var date = new Date();
					var day = date.getDate(),
					month = date.getMonth()+1;
					month=month<=9 ? '0'+month:month;
					day=day<=9 ? '0'+day:day;
		//Creation of file
    		var fileObj = file.create({
			//To make each file unique and avoid overwriting, append date on the title
			// name: searchid[k]+ month+""+day+'.csv',
			name: fileName+ month+""+day+'.csv',
			fileType: file.Type.CSV,
			contents: csvFile,
			description: 'This is a CSV file.',
			encoding: file.Encoding.UTF8,
			folder: 29849//-20
    		});
		
		//Save the CSV file
		var fileId = fileObj.save()
    		log.debug('File ID...',fileId)
	}
    }
 
    return {
        execute: execute
    };
    
});
