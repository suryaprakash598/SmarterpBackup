function getNS_url_param(name, url) {
	name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
	var regexS = "[\\?&]" + name + "=([^&#]*)";
	var regex = new RegExp(regexS);
	var results = regex.exec(url);
	if (results == null) return "";
	else return results[1];
}

function goBack() {
	var window_url = window.location.href;
	//alert('window_url' + window_url);
	var recid = getNS_url_param('recid', window_url);
	//alert('recid' + recid);
	var rec_url = nlapiResolveURL('RECORD', 'customrecordswi_bulk_order_processor', recid, 'view');
	window.location.href = rec_url;
	return true;
}