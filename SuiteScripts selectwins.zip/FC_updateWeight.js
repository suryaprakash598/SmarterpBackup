function FC_calcItemWeight(type, name) {
    try {
        if (type == 'item' && (name == 'quantity' || name == 'item' || name == 'units')) {
            var quantity = nlapiGetCurrentLineItemValue('item', 'quantity') || 1;
            var weight = nlapiGetCurrentLineItemValue('item', 'custcol_swi_item_weight') || 0;
            var units = nlapiGetCurrentLineItemValue('item', 'units');
            var unitsText = nlapiGetCurrentLineItemText('item', 'units');
            var itemId = nlapiGetCurrentLineItemValue('item', 'item');

            var l_btpc = nlapiGetCurrentLineItemValue('item', 'custcol_swi_item_btpc');
            var l_itemweight = nlapiGetCurrentLineItemValue('item', 'custcol_swi_item_weight_source');

            var btpc = Number(l_btpc) || 1;
            var itemOriginalWeight = (Number(l_itemweight) * btpc) || 0;
console.log('itemOriginalWeight',itemOriginalWeight);
            if (unitsText.includes('CS') && weight >= 0) // 14 :CS
            {
                nlapiSetCurrentLineItemValue('item', 'custcol_swi_item_weight', (Number(quantity) * Number(l_itemweight)).toFixed(2));
                nlapiSetCurrentLineItemValue('item', 'custcol_swi_no_of_cases', quantity);

            } else if (unitsText.includes('BTL') && weight >= 0) { // 13:BTL

                var cases = quantity / btpc;
              itemOriginalWeight=(Number(l_itemweight) / btpc) || 0;
              console.log('itemOriginalWeight bottle',itemOriginalWeight);
                nlapiSetCurrentLineItemValue('item', 'custcol_swi_no_of_cases', parseFloat(cases).toFixed(2));
                var caseValue = nlapiGetCurrentLineItemValue('item', 'custcol_swi_no_of_cases');
              console.log('case value',caseValue);
                var val = (Number(quantity) * itemOriginalWeight).toFixed(2);
                nlapiSetCurrentLineItemValue('item', 'custcol_swi_item_weight', val);
              console.log('val',val);
            }
        } else if (name == 'custbody_swi_validate_weight') {
            var itemCount = nlapiGetLineItemCount('item');
            for (var i = 0; i <= itemCount; i++) {
                var quantity = nlapiGetLineItemValue('item', 'quantity', (i + 1)) || 1;
				if(quantity){
                var weight = nlapiGetLineItemValue('item', 'custcol_swi_item_weight', (i + 1)) || 0;
                var units = nlapiGetLineItemValue('item', 'units', (i + 1));
                nlapiSelectLineItem('item', (i + 1));
                var unitsText = nlapiGetLineItemText('item', 'units', (i + 1));
                var itemId = nlapiGetLineItemValue('item', 'item', (i + 1));

                var l_btpc = nlapiGetLineItemValue('item', 'custcol_swi_item_btpc', (i + 1));
                var l_itemweight = nlapiGetLineItemValue('item', 'custcol_swi_item_weight_source', (i + 1));

                var btpc = Number(l_btpc) || 1;
                var itemOriginalWeight = (Number(l_itemweight) * btpc) || 0;

                if (unitsText.includes('CS') && weight >= 0) // 14 :CS
                {
                    nlapiSetLineItemValue('item', 'custcol_swi_item_weight', (i + 1), (Number(quantity) * itemOriginalWeight).toFixed(2));
                    nlapiSetLineItemValue('item', 'custcol_swi_no_of_cases', (i + 1), quantity);

                } else if (unitsText.includes('BTL') && weight >= 0) { // 13:BTL

                    var cases = quantity / btpc;
                    nlapiSetLineItemValue('item', 'custcol_swi_no_of_cases', (i + 1), parseFloat(cases).toFixed(2));
                    var caseValue = nlapiGetLineItemValue('item', 'custcol_swi_no_of_cases', (i + 1));
                    var val = (Number(caseValue) * itemOriginalWeight).toFixed(2);
                    nlapiSetLineItemValue('item', 'custcol_swi_item_weight', (i + 1), val);
                }
				//nlapiCommitLineItem('item');
            }
            
			}
            nlapiSetFieldValue('custbody_swi_validate_weight', 'F', false);
			
        }
        return true;
    } catch (e) {
        nlapiLogExecution('debug', 'Error', e.toString());
    }
}

function recalc_updateWeight() {
    try {
        debugger;
        var itemCount = nlapiGetLineItemCount('item');
        var totalCases = 0;
        var totalWeight = 0;
        for (var i = 0; i < itemCount; i++) {
            var cases = nlapiGetLineItemValue('item', 'custcol_swi_no_of_cases', (i + 1));
            var weight = nlapiGetLineItemValue('item', 'custcol_swi_item_weight', (i + 1));
            totalCases = Number(totalCases) + Number(cases);
            totalWeight = Number(totalWeight) + Number(weight);
        }

        nlapiSetFieldValue('custbody_swi_total_cases', totalCases);
        nlapiSetFieldValue('custbody_swi_total_weight', totalWeight);

        return true;

    } catch (e) {
        nlapiLogExecution('debug', 'Error', e.toString());
    }
}

function PS_updateWeight(type, name, line) {
    debugger;
    try {
        if (type == 'item' && (name == 'units' || name == 'item')) {
            var l_btpc = nlapiGetCurrentLineItemValue('item', 'custcol_swi_item_btpc');
            var l_itemweight = nlapiGetCurrentLineItemValue('item', 'custcol_swi_item_weight_source');
            if (l_btpc != '' && l_itemweight != '') {


                var quantity = nlapiGetCurrentLineItemValue('item', 'quantity') || 1;
                var unitsText = nlapiGetCurrentLineItemText('item', 'units');
                var btpc = Number(l_btpc) || 1;
                var itemOriginalWeight = (Number(l_itemweight) * btpc) || 0;

                if (unitsText.includes('CS')) // 14 :CS
                {
                    nlapiSetCurrentLineItemValue('item', 'custcol_swi_item_weight', (Number(quantity) * Number(l_itemweight)).toFixed(2));
                    nlapiSetCurrentLineItemValue('item', 'custcol_swi_no_of_cases', parseFloat(quantity).toFixed(2));

                } else if (unitsText.includes('BTL')) { // 13:BTL

                    var cases = quantity / btpc;
                    nlapiSetCurrentLineItemValue('item', 'custcol_swi_no_of_cases', parseFloat(cases).toFixed(2));
                    var caseValue = nlapiGetCurrentLineItemValue('item', 'custcol_swi_no_of_cases');
                  itemOriginalWeight = (Number(l_itemweight) / btpc) || 0;
                    var val = (Number(quantity) * itemOriginalWeight).toFixed(2);
                    nlapiSetCurrentLineItemValue('item', 'custcol_swi_item_weight', val);
                }
            }
        }
        return true;
    } catch (e) {
        nlapiLogExecution('debug', 'Error', e.toString());
    }
}

 