function BS_update_PDF_fields(argument) {
	try {

		var s_rec_type = nlapiGetRecordType();
		if (s_rec_type == 'purchaseorder') {
			var i_entity = nlapiGetFieldValue('entity');
			var s_compnay_name = nlapiLookupField('vendor', i_entity, ['companyname', 'phone']);
			nlapiSetFieldValue('custbody_swi_pdf_vendor_attention', s_compnay_name.companyname)
			nlapiSetFieldValue('custbody_swi_pdf_vendor_phone', s_compnay_name.phone)
		}
		var i_line_count = nlapiGetLineItemCount('item');

		for (var i = 1; i <= i_line_count; i++) {
			 if (nlapiGetLineItemValue('item', 'itemtype', i) != 'EndGroup') 
			 {
           
						var s_item_name = nlapiGetLineItemText('item', 'item', i);
						var i_item_id = nlapiGetLineItemValue('item', 'item', i)
						var btpc = nlapiLookupField('item', i_item_id, 'custitem_swi_btpc', true);
						var size = nlapiGetLineItemValue('item', 'custcol_swi_size', i);
						btpc = parseFloat(btpc);
						size = parseFloat(size);
						var s_item_number = s_item_name.split(' ')[0];
						nlapiSetLineItemValue('item', 'custcol_sw_pdf_item_number', i, s_item_number);
						var s_unit = nlapiGetLineItemValue('item', 'units_display', i);

						if (s_unit == 'BTL' && isNotNull(s_unit)) {
							var i_qty = nlapiGetLineItemValue('item', 'quantity', i);
							var no_of_cases = parseFloat(i_qty) / parseFloat(btpc)
							no_of_cases = parseFloat(no_of_cases)
							no_of_cases = no_of_cases.toFixed(3);
							nlapiSetLineItemValue('item', 'custcol_swi_pdf_no_of_cases', i, no_of_cases);
							nlapiSetLineItemValue('item', 'custcol_swi_pdf_no_of_bottles', i, i_qty);
							nlapiSetLineItemValue('item', 'custcol_swi_pdf_liter', i, parseFloat(i_qty) * parseFloat(size));

						} else {
							var i_qty = nlapiGetLineItemValue('item', 'quantity', i);
							var no_of_bottles = parseFloat(i_qty) * parseFloat(btpc)
							no_of_bottles = parseFloat(no_of_bottles)
							no_of_bottles = no_of_bottles.toFixed(3);
							nlapiSetLineItemValue('item', 'custcol_swi_pdf_no_of_bottles', i, no_of_bottles);
							nlapiSetLineItemValue('item', 'custcol_swi_pdf_no_of_cases', i, i_qty);
							nlapiSetLineItemValue('item', 'custcol_swi_pdf_liter', i, parseFloat(no_of_bottles) * parseFloat(size));

						}
			}
		}
	} catch (e) {
		nlapiLogExecution('debug', 'BS_update_PDF_fields', 'error ===== ' + e)

	}
}

function isNotNull(value) {
	var returnObj = false;
	if (value != null && value != '' && value != 'null' && value != undefined && value != 'undefined' && value != '@NONE@') returnObj = true;
	return returnObj;
}