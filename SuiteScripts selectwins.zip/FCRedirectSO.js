function fieldChangedRedirectSO1(type, name) {
    if (name == 'entity') {
        var entity = nlapiGetFieldValue('entity');
        var c_form = nlapiGetFieldValue('customform');
        if (entity != null && c_form == 142) {
            var href = window.location.href;
            var currentUrl = window.location.href;
            // regex pattern for detecting ? character
            var pattern = new RegExp(/\?.+=.*/g);
            var isUrlHaveQueryString = pattern.test(currentUrl);
            var s_url = '';
            if (isUrlHaveQueryString) {
                //IF URL HAS QUERY PARAMTER(IF WE CLICK ON NEW BUTTON WILL NOT HAVE QUERY PARAM)
                var pattern1 = new RegExp(/[?&]entity=/);
                var isEntityParamExists = pattern1.test(currentUrl);

                if (isEntityParamExists) {
                    // IF WE HAVE ALREADY ENTITY PARAM AND TRYING TO CHANGE CUSTOMER THEN IT SHOULD REPLACE
                    var newEntityValue = currentUrl.replace(/(entity=).*?(&)/, '$1' + entity + '$2');
                    s_url = newEntityValue;
                } else {
                    s_url = href + '&entity=' + entity + '&form=' + c_form;
                }

            } else {
                //FORM PARAM IS ADDED TO OVERCOME REGULAR EXPRESSION ISSUE IN ABOVE IF
                s_url = href + '?entity=' + entity + '&form=' + c_form;
            }

            //var s_url = 'https://3497583.app.netsuite.com/app/accounting/transactions/salesord.nl?whence=&entity=' + entity;
            window.location.replace(s_url);
            return true;
        }
    }
}