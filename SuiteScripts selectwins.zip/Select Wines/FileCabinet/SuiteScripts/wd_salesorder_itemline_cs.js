/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/search'],
/**
 * @param {search} search
 */
function(search) {
    
	//root record
    var salesOrder;
    
    //field Value
    var customer;
    
    
    function pageInit(context) {
    	salesOrder = context.currentRecord;
    	/*customerField = salesOrder.getField({
    		fieldId: 'entity'
    	});
    	
    	log.debug('customerField', customerField);
    	log.debug('customerField', customerField.id);*/
    	
    }

    
    function fieldChanged(context) {
    	
    	//If Customer Changed
    	if(context.fieldId === 'entity'){
    		window.location.reload();
    		return;
    		//Item Line Count
        	itemLineCount = salesOrder.getLineCount({
        		 sublistId: 'item'
        	});
        	
    		//remove item lines for previously selected customer
    		if(itemLineCount > 0){
    			for(var a=0; a<itemLineCount; a++){
    				salesOrder.removeLine({
    					 sublistId: 'item',
    					 line: a,
    					 ignoreRecalc: true
    				});
    			}
    		}
    		
    		//Get preferred items list for current selected customer
    		customer = salesOrder.getValue({
        		fieldId: 'entity'
        	});
    		
    		log.debug('customer', customer);
    		
    		search.lookupFields.promise({
    			 type: search.Type.CUSTOMER,
    			 id: customer,
    			 columns : 'custentity_swi_freqbtitems'
    		})
    		.then(function (result) {
    			var items = JSON.parse(JSON.stringify(result))["custentity_swi_freqbtitems"];
    			var itemCount = items.length;
    			
    			log.debug('Item COunt', itemCount);
    			
    			if(items !== undefined && itemCount >0){
    				for(var b=0; b<itemCount; b++){
    					log.debug('b', b);
    					/*var itemLine = salesOrder.selectLine({
    						 sublistId: 'item',
    						 line: b
    						});
    					
    					itemLine.setCurrentSublistValue({
    						 sublistId: 'item',
    						 fieldId: 'item',
    						 line: b,
    						 value: items[b]["value"]
    						});
    					
    					itemLine.setCurrentSublistValue({
	   						 sublistId: 'item',
	   						 fieldId: 'quantity',
	   						 line: b,
	   						 value: 1
   						});*/
    					
    					/*salesOrder.selectNewLine({
    						 sublistId: 'item'
    					});
    					
    					*/
    					
    					salesOrder.setCurrentSublistValue({
            				sublistId: 'item',
            				fieldId: 'item',
            				value : items[b]["value"],
            				ignoreFieldChange: false
            			});
    					salesOrder.setCurrentSublistValue({
            				sublistId: 'item',
            				fieldId: 'quantity',
            				value : 1,
            				ignoreFieldChange: false
            			});
    					salesOrder.commitLine({
    						 sublistId: 'item'
    					});
    					salesOrder.selectLine({
   						 sublistId: 'item',
   						 line: 0
   					});
    				}
    			}
    		})
    		.catch(function onRejected(reason) {
    			 log.error('ERROR in Item Load', reason);
    		});
    	}
    	
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     * @param {string} context.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(context) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(context) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(context) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     * @param {string} context.fieldId - Field name
     * @param {number} context.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} context.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(context) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(context) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(context) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(context) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(context) {

    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        //postSourcing: postSourcing,
        //sublistChanged: sublistChanged,
        //lineInit: lineInit,
        //validateField: validateField,
        //validateLine: validateLine,
        //validateInsert: validateInsert,
        //validateDelete: validateDelete,
        //saveRecord: saveRecord
    };
    
});
