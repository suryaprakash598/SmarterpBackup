function beforeLoadGetEntity(type, form, request) {
	var s_rec_type = nlapiGetRecordType();
	if (s_rec_type == 'salesorder') {
		if (type == 'create') {
			var entity = request.getParameter('entity');
			if (entity) {
				//Look for Preferred Item Search
				nlapiSetFieldValue('entity', entity);
				var itemList = nlapiLookupField('customer', entity, 'custentity_swi_freqbtitems');
				if (itemList) {
					var itemArray = itemList.split(",");
					// If Preferred Items are available for the customer
					if (itemArray[0]) {
						//Item Search for Details
						var itemSearch = nlapiSearchRecord("item", null, [
							["internalid", "anyof"].concat(itemArray)
						], [
							new nlobjSearchColumn("internalid"),
							new nlobjSearchColumn("custitem_swi_btpc"),
							new nlobjSearchColumn("custitem_swi_size"),
							new nlobjSearchColumn("quantityavailable"),
							new nlobjSearchColumn("unitstype"),
							new nlobjSearchColumn("baseprice")
						]);
						//Set Items details to items lines
						for (var s = 0; s < itemSearch.length; s++) {
							var itemId = itemSearch[s].getValue('internalid');
							var btpc = itemSearch[s].getText('custitem_swi_btpc');
							var size = itemSearch[s].getValue('custitem_swi_size');
							var unit = itemSearch[s].getValue('saleunit');
							var basePrice = itemSearch[s].getValue('baseprice');
							var quantityAvailable = itemSearch[s].getValue('quantityavailable');
							/*nlapiLogExecution ( 'debug' , 'id' , itemId);
							nlapiLogExecution ( 'debug' , 'btpc' , btpc);
							nlapiLogExecution ( 'debug' , 'size' , size);
							nlapiLogExecution ( 'debug' , 'units' , unit);
							nlapiLogExecution ( 'debug' , 'price' , basePrice);*/
							//Set Item Line Values
							nlapiSelectNewLineItem('item');
							//Item
							nlapiSetCurrentLineItemValue('item', 'item', itemId, true);
							//Quantity
							nlapiSetCurrentLineItemValue('item', 'quantity', 0, true);
							//Quantity Available
							if (quantityAvailable) {
								nlapiSetCurrentLineItemValue('item', 'quantityavailable', quantityAvailable, true);
							}
							//BTPC
							if (btpc) {
								nlapiSetCurrentLineItemValue('item', 'custcol_swi_bottlepcs', btpc, true);
							}
							//SIZE
							if (size) {
								nlapiSetCurrentLineItemValue('item', 'custcol_swi_size', parseFloat(size), true);
							}
							//UNIT
							if (unit) {
								nlapiSetCurrentLineItemValue('item', 'units', unit, true);
							}
							//BASE PRICE
							// if(basePrice){
							nlapiSetCurrentLineItemValue('item', 'rate', basePrice, true);
							//}
							nlapiSetCurrentLineItemValue('item', 'amount', '0', true);
							nlapiCommitLineItem('item');
						}
					}
				}
			}
		}

	/*	if (type == 'create' || type == 'edit' || type == 'view') {
			try {
				form.getField('subsidiary').setDisplayType('hidden');
				form.getField('opportunity').setDisplayType('hidden');
				form.getField('discountitem').setDisplayType('hidden');
				form.getField('discountrate').setDisplayType('hidden');
				form.getField('automaticallyapplypromotions').setDisplayType('hidden');
				if (type == 'view') {
					var o_item_sublist = form.getSubList('item')
					o_item_sublist.getField('options').setDisplayType('hidden');
					o_item_sublist.getField('isclosed').setDisplayType('hidden');
				}
			} catch (e) {}
			//form.getSubList('promotion').setDisplayType('hidden')
		}*/
	}
}