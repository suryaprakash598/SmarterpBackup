/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/https'],
/**
 * @param {search} search
 */
function(search, https) {
   
    function beforeLoad(context) {
    	var salesOrder = context.newRecord;
    	
    	var i_entity = context.request.getParameter('entity');
    	log.debug(i_entity);
    	
    	var customer = salesOrder.getValue({
    		fieldId: 'entity'
    	});
    	
    	
    	log.debug('customer', customer);
    	log.debug('mode1', context.Type);
    	
    	//If Customer and record mode is CREATE
    	if(customer && context.Type === context.UserEventType.CREATE){
    		
    		log.debug('mode2', context.Type);
    		//Get all preferred items for this customers
    		var preferredItems = search.lookupFields({
    			 type: search.Type.CUSTOMER,
    			 id: customer,
    			 columns: ['custentity_swi_freqbtitems']
    			});
    		
    		log.debug('preferredItems', preferredItems);
    	}
    }

    
    function beforeSubmit(context) {
    }
    function afterSubmit(context) {
    }
    
    return {
        beforeLoad: beforeLoad,
        //beforeSubmit: beforeSubmit,
        //afterSubmit: afterSubmit
    };
    
});
