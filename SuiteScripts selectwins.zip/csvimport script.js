/**
  * @NApiVersion 2.x
  * @NScriptType ScheduledScript
  * @NModuleScope SameAccount
  */
define(['N/ui/serverWidget', 'N/redirect', 'N/runtime', 'N/record', 'N/ui/message', 'N/search', 'N/url', 'N/format', 'N/ui/dialog', 'N/email', 'N/file', 'N/task'],

  function(serverWidget, redirect, runtime, record1, message, search, url, format, dialog, email, file, task) {

    /**
      * Definition of the Scheduled script trigger point.
      *
      * @param {Object} scriptContext
      * @param {string} scriptContext.type - The context in which the script is executed. It is one of the values from the scriptContext.InvocationType enum.
      * @Since 2015.2
      */
    function execute(scriptContext) {

      var scriptObj = runtime.getCurrentScript();
	  var fileSearchObj = search.create({
   type: "file",
   filters:
   [
      ["folder","anyof","170551"]//sandbox "161477"
   ],
   columns:
   [search.createColumn({name: "internalid", label: "Internal ID"})
   ]
});
var searchResultCount = fileSearchObj.runPaged().count;
log.debug("fileSearchObj result count",searchResultCount);
fileSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
    var file_Id = result.getValue({name: "internalid"});
	//log.debug(file_Id);
	var s=csvImport(file_Id);
  if (runtime.getCurrentScript().getRemainingUsage() < 400) {
                var taskId = rescheduleCurrentScript();
                log.debug("Rescheduling status: " + task.checkStatus(taskId));
                return;
            }
   return true;
});


    }
    //custom functions
    function csvImport(file_Id) {

     
      //csv import 149
      var scriptTask = task.create({
        taskType: task.TaskType.CSV_IMPORT
      });
      scriptTask.mappingId = 159; //sandbox 149;
      var f = file.load(file_Id);
      scriptTask.importFile = f;
      var csvImportTaskId = scriptTask.submit();
      //nancy.sharp@selectwinesinc.com
     
        while (true) {
          var csvTaskStatus = task.checkStatus({
            taskId: csvImportTaskId
          });
          if (csvTaskStatus.status === task.TaskStatus.COMPLETE || csvTaskStatus.status === task.TaskStatus.FAILED) {
            break;
          }
		  //log.debug(csvTaskStatus.status);
        }
      var scriptTask = task.create({
        taskType: task.TaskType.CSV_IMPORT
      });
      scriptTask.mappingId = 166; //sandbox creditmemo;
      var f = file.load(file_Id);
      scriptTask.importFile = f;
     var csvImportTaskId = scriptTask.submit();
      
       while (true) {
          var csvTaskStatus = task.checkStatus({
            taskId: csvImportTaskId
          });
          if (csvTaskStatus.status === task.TaskStatus.COMPLETE || csvTaskStatus.status === task.TaskStatus.FAILED) {
            break;
          }
		  //log.debug(csvTaskStatus.status);
        }
		f.folder = 81577;
		var fileId = f.save(); 

        return true;
    }
/**
     * Reschedules the current script and returns the ID of the reschedule task
     */
    function rescheduleCurrentScript() {
        var scheduledScriptTask = task.create({
            taskType: task.TaskType.SCHEDULED_SCRIPT
        });
        scheduledScriptTask.scriptId = runtime.getCurrentScript().id;
        scheduledScriptTask.deploymentId = runtime.getCurrentScript().deploymentId;
        return scheduledScriptTask.submit();
    }
    

    return {
      execute: execute
    };

  });