function printItemReceipt()
{
	var internalid = request.getParameter('id');
	nlapiLogExecution('debug','internalid',internalid);
	if(internalid)
	{
		try{
				var record = nlapiLoadRecord('itemreceipt', internalid);
				var renderer = nlapiCreateTemplateRenderer(); 
				var getFile = nlapiLoadFile('9152');
				var file = getFile.getValue();
				renderer.setTemplate(file);
				renderer.addRecord('record', record);

				var xml = renderer.renderToString();
				var PDFfile = nlapiXMLToPDF(xml);
				nlapiLogExecution('debug','PDFfile',PDFfile);
				response.setContentType('PDF','PRINT.pdf','INLINE');
				 response.write(PDFfile.getValue());
				 

		}
		catch(e)
		{
			nlapiLogExecution('debug','Error',e.toString());
		}
	}
	
}