//Create Item Purchased Button
function BeforeLoadAddButton(type,form){
	try{
		if(type == 'create')
		{
		   form.setScript('customscript_open_popup');
		   var list = form.getSubList('item');
		   list.addButton('custpage_customconfigurebutton', 'Frequent Items', 'validate');
		   
		}
	}catch(e)
	{
		nlapiLogExecution('debug','Error',e.toString());
	}
 
}