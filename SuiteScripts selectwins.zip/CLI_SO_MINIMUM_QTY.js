/*	
Script Name	:	CLI_SO_MINIMUM_QTY
Author		:	 
Company		:	  
Date		:	11 Apr 2020
Description	:	 
*/
function fieldChangedMinQTY(type, name) {
	var o_context = nlapiGetContext();
	var i_role = o_context.getRole();
	if (i_role != 3) {
		//alert('i_role' + i_role)
		if (type == 'item' && name == 'quantity') {
			var i_item = nlapiGetCurrentLineItemValue('item', 'item');
			//alert('i_item' + i_item)
			if (_logValidation(i_item)) {
				var i_min_qty = nlapiLookupField('inventoryitem', i_item, 'minimumquantity');
				if (_logValidation(i_min_qty)) {
					var i_qty = nlapiGetCurrentLineItemValue('item', 'quantity');
					//alert('i_qty' + i_qty);
					if (parseInt(i_qty) < parseInt(i_min_qty)) {
						alert('Minimum quantity of this item is ' + i_min_qty);
						return false;
					}
				}
			}
		}
	}
	return true;
}

function validateLineMinQTY(type, name) {
	//alert('i_role' + i_role)
	if (type == 'item') {
		var o_context = nlapiGetContext();
		var i_role = o_context.getRole();
		if (i_role != 3) {
			var i_item = nlapiGetCurrentLineItemValue('item', 'item');
			//alert('i_item' + i_item)
			if (_logValidation(i_item)) {
				var i_min_qty = nlapiLookupField('inventoryitem', i_item, 'minimumquantity');
				//alert('i_min_qty' + i_min_qty);
				if (_logValidation(i_min_qty)) {
					var i_qty = nlapiGetCurrentLineItemValue('item', 'quantity');
					//alert('i_qty' + i_qty);
					if (parseInt(i_qty) < parseInt(i_min_qty)) {
						alert('Minimum quantity of this item is ' + i_min_qty);
						return false;
					}
				}
			}
		}
	}
	return true;
}

function _logValidation(value) {
	if (value != 'null' && value != '' && value != undefined && value != 'NaN') {
		return true;
	} else {
		return false;
	}
}