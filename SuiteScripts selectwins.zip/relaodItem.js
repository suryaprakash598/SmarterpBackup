function reloadItemNew(type,name){
	try{
		debugger; 
		if(type=='item' && name=='custcol_swi_sel_item') //&& name=='custcol_swi_sel_item'
		{
			var ischecked = nlapiGetCurrentLineItemValue('item','custcol_swi_sel_item');
			if(ischecked=='T')
			{
				
				var itemId  = nlapiGetCurrentLineItemValue('item','item');
				var rate  = nlapiGetCurrentLineItemValue('item','rate');
				var qty  = nlapiGetCurrentLineItemValue('item','quantity');
				var amount  = nlapiGetCurrentLineItemValue('item','amount');
				var quantityAvailable  = nlapiGetCurrentLineItemValue('item','quantityavailable');
				var units  = nlapiGetCurrentLineItemText('item','units');
				
				
				var qtyAvail = parseFloat(quantityAvailable).toFixed(2);
				nlapiSetCurrentLineItemValue('item','item',itemId);
				nlapiSetCurrentLineItemValue('item','quantity',qty);//PREVIOUSLY QTY WAS SETTING TO 1
				nlapiSetCurrentLineItemValue('item','rate',rate);
				nlapiSetCurrentLineItemValue('item','amount',amount);
				if(quantityAvailable){
				nlapiSetCurrentLineItemValue('item','quantityavailable',qtyAvail);
				}
				
				 
				//nlapiCommitLineItem('item',true);
				
			}else{
              
				// nlapiSetCurrentLineItemValue('item','quantity',0);              
              return true;
            }
		}
		return true;
	}catch(e){
		nlapiLogExecution('debug','error',e.toString());
	}
}


 