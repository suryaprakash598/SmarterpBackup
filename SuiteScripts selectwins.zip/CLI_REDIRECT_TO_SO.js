function fieldChangedRedirectSO(type, name) {
	if (name == 'entity') {
		var entity = nlapiGetFieldValue('entity')
		if (entity != null) {
			var s_url = 'https://3497583.app.netsuite.com/app/accounting/transactions/salesord.nl?whence=&entity=' + entity;
			window.location.replace(s_url);
			return true;
		}
	}
}

 