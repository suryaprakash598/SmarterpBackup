var i_total_cust_records = 0;
var distributor_srs = 'o54228';

function VIPReportRetailOutletFile(request, response) {
	try {
		var s_file_current_number = nlapiLookupField('customrecord_swi_vip_file_naming', 1, 'custrecord_swi_vip_current_number');
		s_file_current_number = parseInt(s_file_current_number) + 1;
		s_file_current_number = threeDigits(s_file_current_number);
		var s_file_data = '';
		var s_cust_data = generateCustData()
		var a_filter = [];
		var a_column = [];
		a_filter.push(new nlobjSearchFilter('custentity_swi_vip_supplier_id', null, 'isnotempty'))
		a_filter.push(new nlobjSearchFilter('custentity_swi_vip_distributor_id', null, 'isnotempty'))
		a_column.push(new nlobjSearchColumn('custentity_swi_vip_supplier_id'))
		a_column.push(new nlobjSearchColumn('custentity_swi_vip_distributor_id'))
		var o_vendor_search = nlapiSearchRecord('vendor', null, a_filter, a_column);
		if (isNotNull(o_vendor_search)) {
			var divideVendor =0; var counter=0; 
			var condition =10;
			//nlapiLogExecution('debug','condition',condition);
			for (var v = 0; v < o_vendor_search.length; v++) {
				
				divideVendor=divideVendor+1;
			//nlapiLogExecution('debug','conditionvalue'+condition,'divideVendor'+divideVendor);
				reScheduleScript();
				var s_footer_data = '99';
				i_total_cust_records = i_total_cust_records.toString();

				var vendor_SUPPID = o_vendor_search[v].getValue('custentity_swi_vip_supplier_id');
				var vendor_DISTID = o_vendor_search[v].getValue('custentity_swi_vip_distributor_id');
				s_footer_data = s_footer_data + vendor_SUPPID + addSpeace(8, vendor_DISTID) + vendor_DISTGLN + '0188' + vendor_FILEVER + addPrefixZero(7, i_total_cust_records)
				var s_cust_starting = '20' + vendor_SUPPID + addSpeace(8, vendor_DISTID)
				var temp_s_cust_data = s_cust_data;
				temp_s_cust_data = temp_s_cust_data.replace(/1234567890/gi, s_cust_starting)
				temp_s_cust_data = temp_s_cust_data.replace(/98765432/gi, addSpeace(8, vendor_DISTID))
				s_file_data = s_file_data + vendor_RECID + vendor_SUPPID + addSpeace(8, vendor_DISTID) + vendor_DISTGLN + '0188' + vendor_FILEVER + vendor_FILETYPE + getTimeDate() + '\r\n' + temp_s_cust_data + '\r\n' + s_footer_data + '\r\n'
				if(divideVendor==condition){
					var o_file = nlapiCreateFile(distributor_srs + s_file_current_number +"_"+counter+ '.out', 'PLAINTEXT', s_file_data);
					o_file.setFolder(1138);
					var i_file_id = nlapiSubmitFile(o_file);
					if (s_file_current_number == 1000)
					{
						nlapiSubmitField('customrecord_swi_vip_file_naming', 1, 'custrecord_swi_vip_current_number', 0);
					}
					else{
						nlapiSubmitField('customrecord_swi_vip_file_naming', 1, 'custrecord_swi_vip_current_number', s_file_current_number);
					}
					counter=counter+1;
					var checkPoint=o_vendor_search.length-condition;
					
					if(checkPoint>=20)
					{
						condition =20;
					}else{
						condition =checkPoint;
					}
					s_file_data='';
					nlapiLogExecution('debug','condition AtLast'+condition,'checkPoint'+checkPoint);
					divideVendor=0;
					try{
						sendEmail(i_file_id);
					}catch(e)
					{
						nlapiLogExecution('debug','Error',e);
					}
				}
				reScheduleScript();
			}
		}

		
	} catch (e) {
		nlapiLogExecution('error', 'e', e);
	}
}

function generateCustData() {

	var s_cust_data = '';
	var o_customer_search1 = customerSearch();
	if (isNotNull(o_customer_search1)) {
		 var completeResultSet = o_customer_search1; //copy the result
		while(o_customer_search1.length == 1000){ //if there are more than 1000 records
			 var lastId = o_customer_search1[999].getValue('internalid'); //note the last record retrieved
			  o_customer_search1 = customerSearch(lastId);
			 completeResultSet = completeResultSet.concat(o_customer_search1); //add the result to the complete result set
		} 
		var o_customer_search = completeResultSet;
		i_total_cust_records = o_customer_search.length;
		nlapiLogExecution('debug','o_customer_search',i_total_cust_records);
		for (var c = 0; c < o_customer_search.length; c++) {
			reScheduleScript()
				//for (var c = 0; c < 22; c++) {
				//nlapiLogExecution('debug', 'generateCustData', c + "   rec id +=== " + o_customer_search[c].getId())
			var entityid = o_customer_search[c].getValue('entityid');
			var companyname = o_customer_search[c].getValue('companyname');
			var storename = o_customer_search[c].getValue('custentity_swi_storename');
			var address1 = o_customer_search[c].getValue('address1');
			var address2 = o_customer_search[c].getValue('address2');
			var licenno = o_customer_search[c].getValue('custentity_swi_cust_licenno');
			var city = o_customer_search[c].getValue('city');
			var state = o_customer_search[c].getValue('state');
			var zipcode = o_customer_search[c].getValue('zipcode');
			var country = o_customer_search[c].getValue('country');
			var phone = o_customer_search[c].getValue('phone');
			var chaincode = o_customer_search[c].getValue('custentity_swi_vip_chaincode');
			//nlapiLogExecution('debug', 'chaincode', chaincode)
			var rocot = o_customer_search[c].getValue("custentity_swi_viip_rocot");
			var rocsts = o_customer_search[c].getValue("custentity_swi_vip_rocsts");
			var roivol = o_customer_search[c].getValue("custentity_swi_vip_roivol");
			var rosm1 = o_customer_search[c].getValue("custentity_swi_vip_rosm1");
			var rosts = o_customer_search[c].getValue("custentity_swi_vip_rosts");
			if (!isNotNull(roivol))
				roivol = '0';
			s_cust_data = s_cust_data + '1234567890' + customer_DISTGLN + addSpeace(15, entityid) + addSpeace(35, companyname) + addSpeace(35, storename) + addSpeace(35, address1) + addSpeace(20) + addSpeace(15) + addSpeace(30, city) + addSpeace(2, state) + addSpeace(9, zipcode) + addSpeace(3) + '00000000000000000000' + addSpeace(10, chaincode) + addSpeace(10) + addSpeace(2, rocot) + ' ' + ' ' + '  ' + '00' + addSpeace(1, roivol) + ' ' + '  ' + '  ' + ' ' + '  ' + '  ' + '  ' + ' ' + addSpeace(5, rosm1) + '     ' + '          ' + addSpeace(1, rosts) + ' ' + addSpeace(35) + '98765432' + 'X'
			reScheduleScript()
			if (c != o_customer_search.length - 1) {

				s_cust_data = s_cust_data + '\r\n'
			}
			//nlapiLogExecution('debug', 'generateCustData', 'Customer data ===> ' + s_cust_data)
		}
		reScheduleScript()
	}
	return s_cust_data
}
function customerSearch(internalid)
{
	nlapiLogExecution('debug','internalid',internalid);
		if(internalid){
			var a_filters = [
						["stage", "anyof", "CUSTOMER"],
						"AND", ["isinactive", "is", "F"], 
						   "AND", 
						   ["internalidnumber","greaterthan",internalid]
					];
		}else{
			var a_filters = [
						["stage", "anyof", "CUSTOMER"],
						"AND", ["isinactive", "is", "F"]
					];
		}
		nlapiLogExecution('debug','a_filters',JSON.stringify(a_filters));
	var o_customer_search = nlapiSearchRecord("customer", null,a_filters, [
		new nlobjSearchColumn("internalid").setSort(false),
		new nlobjSearchColumn("entityid"),
		new nlobjSearchColumn("companyname"),
		new nlobjSearchColumn("custentity_swi_storename"),
		new nlobjSearchColumn("address1"),
		new nlobjSearchColumn("address2"),
		new nlobjSearchColumn("custentity_swi_cust_licenno"),
		new nlobjSearchColumn("city"),
		new nlobjSearchColumn("state"),
		new nlobjSearchColumn("zipcode"),
		new nlobjSearchColumn("country"),
		new nlobjSearchColumn("phone"),
		new nlobjSearchColumn("custentity_swi_vip_chaincode"),
		new nlobjSearchColumn("custentity_swi_viip_rocot"),
		new nlobjSearchColumn("custentity_swi_vip_rocsts"),
		new nlobjSearchColumn("custentity_swi_vip_roivol"),
		new nlobjSearchColumn("custentity_swi_vip_rosm1"),
		new nlobjSearchColumn("custentity_swi_vip_rosts")
	]);
	return o_customer_search;
}