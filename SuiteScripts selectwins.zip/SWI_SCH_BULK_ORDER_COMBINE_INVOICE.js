/*
Author 			: Surya prakash
Modifications	: 7/2/2020 | added customform id:149 while creating invoice instead of preferred form



*/


var o_context = nlapiGetContext();

function bulkOrderCombineInvoice(request, response) {
	try {
		var param_po_id = o_context.getSetting('SCRIPT', 'custscript_po_id');
		var param_bulk_rec_id = o_context.getSetting('SCRIPT', 'custscript_bulk_order_record_id');
		var POIds = JSON.parse(param_po_id);
		nlapiLogExecution('debug','POIds'+POIds.length,JSON.stringify(POIds));
		
		var items =[];
		var itemDetails = [];
		var bodyFields = [];
		if(POIds.length>0)
		{
			for(var j=0;j<POIds.length;j++)
			{
				//nlapiLogExecution('debug','POIds[j]',POIds[j]);
				var o_po_rec = nlapiLoadRecord('purchaseorder', POIds[j].id);
				var b_bulk_orede = o_po_rec.getFieldValue('custbody_swi_bulkorderprocess');
				
				if (b_bulk_orede == 'T') {
					var linksCount = o_po_rec.getLineItemCount('links');
					var index = o_po_rec.findLineItemValue('links','type','Item Receipt');
					//nlapiLogExecution('debug','Item receipt index',index);
					if(j==0)
					{
					
						var s_po_cust_id = o_po_rec.getFieldValue('custbody_swi_tw_custid');
						var s_truck_number = o_po_rec.getFieldValue('custbody_swi_truckno');
						var s_inv_date = o_po_rec.getFieldValue('custbody_swi_inv_date');
						var s_inv_due_date = o_po_rec.getFieldValue('custbody_swi_vip_inv_due_date');
						var i_po_location = o_po_rec.getFieldValue('location');
						var s_memo =  o_po_rec.getFieldValue('memo');
						bodyFields.push({
							"s_po_cust_id":s_po_cust_id,
							"s_truck_number":s_truck_number,
							"s_inv_date":s_inv_date,
							"s_inv_due_date":s_inv_due_date,
							"i_po_location":i_po_location,
							"s_memo":s_memo,
							"POIds":POIds,
							"POId":POIds[j]
						})
					}
					var i_line_count = o_po_rec.getLineItemCount('item');
					
					for (var i = 1; i <= i_line_count; i++) {
						var obj ={};
						var i_po_item = o_po_rec.getLineItemValue('item', 'item', i);
						var i_po_item_text = o_po_rec.getLineItemText('item', 'item', i);
						var i_po_item_qty = o_po_rec.getLineItemValue('item', 'quantity', i);
						var i_po_item_unit = o_po_rec.getLineItemValue('item', 'units', i);
						var i_po_item_class = o_po_rec.getLineItemValue('item', 'class', i);
						obj.item = i_po_item;
						obj.itemtext = i_po_item_text;
						obj.itemQty = i_po_item_qty;
						obj.itemUnit = i_po_item_unit;
						obj.itemClass = i_po_item_class;
						
					 itemDetails.push(obj);
					}
					 
				}
				
			}
			
		}
		createInvoice(itemDetails,bodyFields,param_bulk_rec_id);
		//nlapiLogExecution('debug','itemDetails',JSON.stringify(itemDetails));
	}
	catch(e)
	{
		nlapiLogExecution('debug','Error',e.toString());
	}
}
function createInvoice(itemDetails,bodyFields,param_bulk_rec_id)
{
	try{
		var sortedItems =_.sortBy(itemDetails,'itemtext');
		var itemData = itemSearch(sortedItems);
		var classGroupedItems = _.groupBy(itemData,'itemclass');
		//nlapiLogExecution('debug','sortedItems',JSON.stringify(sortedItems));
		//nlapiLogExecution('debug','classGroupedItems',JSON.stringify(classGroupedItems));
		var a_bodyFields = bodyFields;
		var CGIKeys = Object.keys(classGroupedItems);
			for(var c=0;c<CGIKeys.length;c++)
			{
				
			
				var o_inv_rec = nlapiCreateRecord('invoice');
				o_inv_rec.setFieldValue('customform',149); //Custom Service Invoice
					o_inv_rec.setFieldValue('entity', a_bodyFields[0]["s_po_cust_id"])
					o_inv_rec.setFieldValue('trandate', a_bodyFields[0]["s_inv_date"])
					o_inv_rec.setFieldValue('location', a_bodyFields[0]["i_po_location"])
					o_inv_rec.setFieldValue('duedate', a_bodyFields[0]["s_inv_due_date"])
					//o_inv_rec.setFieldValues('custbody_swi_po_number', a_bodyFields[0]["POIds"])
					o_inv_rec.setFieldValue('custbody_swi_bulkorderprocess', 'T')
					o_inv_rec.setFieldValue('custbody_swi_truckno', a_bodyFields[0]["s_truck_number"])
					o_inv_rec.setFieldValue('memo', a_bodyFields[0]["s_memo"]);
					
						var CGIItems = classGroupedItems[CGIKeys[c]];
						//var sortedItems =_.sortBy(CGIItems,'itemName');
						nlapiLogExecution('debug','CGIItems',JSON.stringify(CGIItems));
					for (var i = 0; i <CGIItems.length; i++) {
						var item = CGIItems[i]["itemId"];
						var o_itemData=_.findWhere(sortedItems,{item:item});
						nlapiLogExecution('debug','o_itemData'+item,JSON.stringify(o_itemData));
						 
						o_inv_rec.selectNewLineItem('item');
						o_inv_rec.setCurrentLineItemValue('item', 'item', o_itemData.item);
						o_inv_rec.setCurrentLineItemValue('item', 'quantity', o_itemData.itemQty);
						//o_inv_rec.setCurrentLineItemValue('item', 'custcol_swi_caseprice', o_itemData.rate);
						o_inv_rec.setCurrentLineItemValue('item', 'units', o_itemData.itemUnit);
						o_inv_rec.setCurrentLineItemValue('item', 'location', a_bodyFields[0]["i_po_location"]);
						o_inv_rec.commitLineItem('item');
					}
					var i_saved_inv_id = nlapiSubmitRecord(o_inv_rec);
					//nlapiLogExecution('debug','i_saved_inv_id'+CGIKeys[c],i_saved_inv_id);
					var a_poids =a_bodyFields[0]["POIds"];
					//nlapiLogExecution('debug','a_poids',JSON.stringify(a_poids));
					var poid ='';
					if(CGIKeys[c]==1)
					{
						var obj = _.where(a_poids,{class: "beer"});
						for(var cl=0;cl<obj.length;cl++)
						{
							poid  = obj[cl].id;
							nlapiSubmitField('purchaseorder',poid,'custbody_swi_bop_invoice_numer',i_saved_inv_id);
						}
							
					}else if (CGIKeys[c]==5){
						var obj = _.where(a_poids,{class: "cider"})
						for(var cl=0;cl<obj.length;cl++)
						{
							poid  = obj[cl].id;
							nlapiSubmitField('purchaseorder',poid,'custbody_swi_bop_invoice_numer',i_saved_inv_id);
						}
					}else if(CGIKeys[c] == 4){
						var obj = _.where(a_poids,{class: "wine"})
						for(var cl=0;cl<obj.length;cl++)
						{
							poid  = obj[cl].id;
							nlapiSubmitField('purchaseorder',poid,'custbody_swi_bop_invoice_numer',i_saved_inv_id);
						}
					}
					
			}
					/* for(var j=0;j<a_poids.length;j++)
					{
						nlapiSubmitField('purchaseorder',a_poids[j],'custbody_swi_bop_invoice_numer',i_saved_inv_id);
					} */
					
					
					
					
					nlapiSubmitField('customrecordswi_bulk_order_processor', param_bulk_rec_id, 'custrecord_swi_bop_status', 4)
					 
	}catch(e)
	{
		nlapiLogExecution('debug','Error',e.toString());
	}
}
function itemSearch(sortedItems)
{
	try{
		var a_ItemData=[];
		var itemArray  = _.pluck(sortedItems,'item');
		//nlapiLogExecution('debug','itemArray',JSON.stringify(itemArray));
		var itemSearch = nlapiSearchRecord("item", null, [
	
			["internalid", "anyof"].concat(itemArray),
			  
		],
		[
			  new nlobjSearchColumn("internalid",null,"GROUP"), 
			  new nlobjSearchColumn("itemid",null,"GROUP"), 
			   new nlobjSearchColumn("quantityavailable",null,"MAX"), 
			   new nlobjSearchColumn("saleunit",null,"GROUP"), 
			   new nlobjSearchColumn("class",null,"GROUP"), 
			   new nlobjSearchColumn("unitprice","pricing","MAX").setSort(false), 
			   new nlobjSearchColumn("custitem_swi_btpc",null,"MAX"), 
			   new nlobjSearchColumn("custitem_swi_size",null,"MAX"),
			   new nlobjSearchColumn("custitem_swi_sell_price",null,"MAX"),
			   new nlobjSearchColumn("type",null,"GROUP")
			
			
			   
		]);
		
		for (var s = 0; s <  itemSearch.length; s++) {
			var obj ={};
			var itemId = itemSearch[s].getValue('internalid',null,"GROUP");
			var itemName = itemSearch[s].getValue('itemid',null,"GROUP");
			var btpc = itemSearch[s].getText('custitem_swi_btpc',null,"MAX");
			var size = itemSearch[s].getValue('custitem_swi_size',null,"MAX");
			var unit = itemSearch[s].getValue('saleunit',null,"GROUP");
			var rate = itemSearch[s].getValue('unitprice','pricing',"MAX");
			var quantityAvailable = itemSearch[s].getValue('quantityavailable',null,"MAX");
			var itemType = itemSearch[s].getValue('type',null,"GROUP");
			var itemclass = itemSearch[s].getValue('class',null,"GROUP");
			obj.itemId = itemId;
			obj.itemName = itemName;
			obj.itemclass = itemclass;
			obj.rate = rate;
			a_ItemData.push(obj);
							
		}
		return a_ItemData;
	}catch(e)
	{
		nlapiLogExecution('debug','Error',e.toString());
	}
}