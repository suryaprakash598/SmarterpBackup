/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord','N/url','N/record','N/search','N/ui/serverWidget'],
/**
 * @param {currentRecord} currentRecord
 */
function(currentrecord,url,record,search,serverWidget) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) { 
    	if (scriptContext.type == 'view')
    	{ 
    	 var record1 = scriptContext.newRecord;
    	 log.debug('',record1);
         var recId  = record1.getValue({
             fieldId: 'id'
         });
        var invrec = record.load({
            type: "invoice",
            id:recId,
            isDynamic: true
        });
        var bbinvoice=invrec.getValue({fieldId:'location'});
        pattern = /INVBB/;
        if(bbinvoice==12){
    	var scripturl  = url.resolveScript({scriptId:'customscript_print_invoice1_o',
       	 deploymentId: 'customdeploy_print_invoice1_o'});
      var createPdfUrl =scripturl+ '&id=' + recId;
      var RebateprintUrl=createPdfUrl+'&rebate='+'True'
       
 
        scriptContext.form.addButton({
            id: "custpage_mybutton",
            label: "Print",
            functionName: "window.open('" + createPdfUrl + "');"
        });
      /* scriptContext.form.addButton({
          id: "custpage_mybutton",
          label: "Generate Rebate Source CSV",
          functionName: "window.open('" + RebateprintUrl + "');"
      }); */
        }
        
    	}	

    }
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {

    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit,
       
    };
    
});