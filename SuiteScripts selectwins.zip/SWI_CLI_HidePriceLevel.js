function lockOtherFields(type, form) {
	var validationPass = authCheck(type)
		nlapiLogExecution('ERROR', 'val', validationPass);
	if (validationPass) {
		disable()
	}
}

function postSource() {
	var validationPass = authCheck(type)
		nlapiLogExecution('ERROR', 'val', validationPass);
		var line = nlapiGetCurrentLineItemIndex('item');
	console.log('line',line);
	 nlapiSetLineItemDisabled('item','pricelevel',true,line)
	if (validationPass) {
		disable()
	}
}

function lockOtherFields_lineInit(type, form) {
	var validationPass = authCheck(type)
		nlapiLogExecution('ERROR', 'val', validationPass);
		nlapiLogExecution('ERROR', 'type', type);
	var line = nlapiGetCurrentLineItemIndex('item');
	console.log('line',line);
	 nlapiSetLineItemDisabled('item','pricelevel',true,line)

	if (validationPass) {
		disable()
	}
}

function disable() {
	 
	nlapiLogExecution('DEBUG', 'x', 4);
	//item fields
 
	//nlapiDisableLineItemField('item', 'pricelevel', true);
	var line = nlapiGetCurrentLineItemIndex('item');
	console.log('line',line);
	 nlapiSetLineItemDisabled('item','pricelevel',true,line)
}

function authCheck(type) {
	var role = nlapiGetRole();
	console.log('type',type);
	if ((type == 'edit' || type == 'item')  ) {
		return true
	}
	return false
}

 

 