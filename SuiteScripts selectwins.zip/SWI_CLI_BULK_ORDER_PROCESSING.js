function onSaveValidation(type) {
	var i_file = nlapiGetFieldText('custrecord_swi_bop_file');
	i_file = i_file.toString()
	var s_type = i_file.slice(i_file.length - 4, i_file.length);
	if (s_type != '.csv') {
		alert('Please upload .csv file only.');
		return false;
	}
	if (type == 'create') {
		nlapiSetFieldValue('custrecord_swi_bop_status', 1)
	}
	return true;
}