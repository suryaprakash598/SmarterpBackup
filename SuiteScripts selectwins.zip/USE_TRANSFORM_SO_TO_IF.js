function transformSOtoIF(type) {
	//try {
	var i_rec_id = nlapiGetRecordId();
	var s_rec_type = nlapiGetRecordType();
	var o_so_rec = nlapiLoadRecord(s_rec_type, i_rec_id);
	var trandate = o_so_rec.getFieldValue('trandate');
	if (s_rec_type == 'salesorder' && type == 'create') {
		var i_payment_method = o_so_rec.getFieldValue('custbody_sh_payment_method');
		var s_payment_method = o_so_rec.getFieldText('custbody_sh_payment_method');
		var itemFulfillment = nlapiTransformRecord(s_rec_type, i_rec_id, 'itemfulfillment', {
			recordmode: 'dynamic'
		});
		itemFulfillment.setFieldValue('trandate', trandate)
		itemFulfillment.setFieldValue('location', 3)
		var i_line_count = itemFulfillment.getLineItemCount('item');
		for (var i = 1; i <= i_line_count; i++) {
			itemFulfillment.selectLineItem('item', i);
			var i_so_qty = itemFulfillment.getCurrentLineItemValue('item', 'quantity')
			itemFulfillment.setCurrentLineItemValue('item', 'quantity', i_so_qty);
			itemFulfillment.setCurrentLineItemValue('item', 'location', 3);
			itemFulfillment.commitLineItem('item');
		}
		itemFulfillment.setFieldValue('shipstatus', 'C')
		var fulfillmentId = nlapiSubmitRecord(itemFulfillment, true, true);
		nlapiLogExecution('debug', 'transformSOtoIF', ' Record Tranformed so id = ' + i_rec_id + ' Item fulfillment id= ' + fulfillmentId);
	}
	/*} catch (e) {}*/
}