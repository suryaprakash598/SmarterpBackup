/*var jj = scanFiletoCreatePO();
var kk = 0*/
var yyyy = null;
var o_context = nlapiGetContext();

function scanFiletoCreatePO(request, response) {
	try {
		var param_rec_id = o_context.getSetting('SCRIPT', 'custscript_rec_id');
		var param_file_id = o_context.getSetting('SCRIPT', 'custscript_file_id');
		var i_rec_process_status = nlapiLookupField('customrecordswi_bulk_order_processor', param_rec_id, 'custrecord_swi_bop_status');
		nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Process Stared ===> ' + i_rec_process_status)
		if (i_rec_process_status == 2) {
			nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Process Stared 1111')

			var a_vendor_mapping = mapVendorWithExternalId()
			var a_item_mapping = mapItemWithExternalId()
			var a_item_class = mapItemWithClass()
			var a_cust_mapping = mapCustWithExternalId()
			var i_flat_file_id = param_file_id;
			var o_file = nlapiLoadFile(i_flat_file_id);
			var s_file_data = o_file.getValue();
			var jsonData = csvJson(s_file_data);
			jsonData = JSON.parse(jsonData);
			var groupedData = _.groupBy(jsonData,'Vendor');
			//nlapiLogExecution('debug','groupedData',JSON.stringify(groupedData));
			var keys = Object.keys(groupedData);
			var a_temp = []
			var s_tran_date = null;
			var s_inv_date = null;
			//response.write(s_file_data)
			var a_data = s_file_data.split(/\n|\n\r/);
			var a_final_data = []
				var counter = 0;
				var POIds = [];
			for (var i = 0; i < keys.length; i++) {
				if(keys[i]!='')
				{
					var b_wine_item_found = false;
					var b_beer_item_found = false;
					var b_cider_item_found = false;
			
					//CREATING PO OBJECTS
					var o_wine_po = nlapiCreateRecord('purchaseorder');
					var o_beer_po = nlapiCreateRecord('purchaseorder');
					var o_cider_po = nlapiCreateRecord('purchaseorder');
					o_wine_po.setFieldValue('customform',156);
					o_beer_po.setFieldValue('customform',156);
					o_cider_po.setFieldValue('customform',156);
					var  a_data = groupedData[keys[i]];
					var i_vendor_id;
					for(var j=0;j<a_data.length;j++)
					{
						//LOOPING LINES
						//nlapiLogExecution('debug', 'a_data', JSON.stringify(a_data[j]));
						i_vendor_id = a_vendor_mapping[a_data[j].Vendor];
						if (isNotNull(i_vendor_id)) 
						{
							reScheduleScript();
							var s_truck_number = a_data[j]["How Shipped"];
							var s_cust_code = a_cust_mapping[a_data[j]["Cust ID"]];
							s_tran_date = poCreationDate(a_data[j]["PO Create Date"])
							s_inv_date = invoiceCreationDate(a_data[j]["Invoice Date"])
							s_inv_due_date = convertInvoieDueDate(a_data[j]["Payment Date"]);
							var poReceiveDate = po_ReceiveDate(a_data[j]["PO Received Date"]);
							
							//nlapiLogExecution('debug','duedate'+a_data[j]["Payment Date"],s_inv_due_date);
							var s_memo = 	a_data[j]["PO #"]+""+
											a_data[j]["Trans #"]+""+
											a_data[j]["Store #"]+""+
											a_data[j]["Del Date"]+""+
											a_data[j]["UF PO #"];
											
							
							
							
							//SETTING BODY FIELDS
							// Wine PO
							o_wine_po.setFieldValue('entity', i_vendor_id)
							o_wine_po.setFieldValue('location', 3)
							o_wine_po.setFieldValue('custbody_swi_truckno', s_truck_number)
							o_wine_po.setFieldValue('custbody_swi_tw_custid', s_cust_code)
							o_wine_po.setFieldValue('custbody_swi_bop_processing_record', param_rec_id)
							o_wine_po.setFieldValue('custbody_swi_inv_date', s_inv_date)
							o_wine_po.setFieldValue('custbody_po_receive_date', poReceiveDate)
							try {
								
								o_wine_po.setFieldValue('custbody_swi_vip_inv_due_date', s_inv_due_date)
							} catch (e) {
								var s_error_message = 'Header provided in the file is not in the correct format, Please check line number ' + (j + 1).toString();
								var err = nlapiCreateError('404', s_error_message);
								nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, ['custrecord_swi_bop_status', 'custrecord_swi_bop_error_message'], [5, s_error_message])
								throw err;
							}
							o_wine_po.setFieldValue('trandate', s_tran_date)
							o_wine_po.setFieldValue('custbody_swi_bulkorderprocess', 'T')
							o_wine_po.setFieldValue('memo', s_memo)
								// Beer PO
							o_beer_po.setFieldValue('entity', i_vendor_id)
							o_beer_po.setFieldValue('location', 3)
							o_beer_po.setFieldValue('custbody_swi_truckno', s_truck_number)
							o_beer_po.setFieldValue('custbody_swi_tw_custid', s_cust_code)
							o_beer_po.setFieldValue('custbody_swi_inv_date', s_inv_date)
							o_beer_po.setFieldValue('custbody_po_receive_date', poReceiveDate)
							try {
								o_beer_po.setFieldValue('custbody_swi_vip_inv_due_date', s_inv_due_date)

							} catch (e) {
								var s_error_message = 'Header provided in the file is not in the correct format, Please check line number ' + (j + 1).toString();
								var err = nlapiCreateError('404', s_error_message);
								nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, ['custrecord_swi_bop_status', 'custrecord_swi_bop_error_message'], [5, s_error_message])
								throw err;
							}
							o_beer_po.setFieldValue('custbody_swi_bop_processing_record', param_rec_id)
							o_beer_po.setFieldValue('trandate', s_tran_date)
							o_beer_po.setFieldValue('custbody_swi_bulkorderprocess', 'T')
							o_beer_po.setFieldValue('memo', s_memo)
								// Cider PO
							o_cider_po.setFieldValue('entity', i_vendor_id)
							o_cider_po.setFieldValue('location', 3)
							o_cider_po.setFieldValue('trandate', s_tran_date)
							o_cider_po.setFieldValue('custbody_swi_truckno', s_truck_number)
							o_cider_po.setFieldValue('custbody_swi_tw_custid', s_cust_code)
							o_cider_po.setFieldValue('custbody_swi_inv_date', s_inv_date)
							o_cider_po.setFieldValue('custbody_po_receive_date', poReceiveDate)
							try {

								o_cider_po.setFieldValue('custbody_swi_vip_inv_due_date', s_inv_due_date)
							} catch (e) {
								var s_error_message = 'Header provided in the file is not in the correct format, Please check line number ' + (j + 1).toString();
								var err = nlapiCreateError('404', s_error_message);
								nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, ['custrecord_swi_bop_status', 'custrecord_swi_bop_error_message'], [5, s_error_message])
								throw err;
							}
							o_cider_po.setFieldValue('custbody_swi_bop_processing_record', param_rec_id)
							o_cider_po.setFieldValue('custbody_swi_bulkorderprocess', 'T')
							o_cider_po.setFieldValue('memo', s_memo);
						}//VENDOR VALIDATION ENDS
						else {
							var s_error_message = 'Either The Vendor with ' + a_data[j]["Vendor"] + ' is not present in the system or not valid vendor id is provided. Please check line number ' + (j + 1).toString();
							var err = nlapiCreateError('404', s_error_message);
							nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, ['custrecord_swi_bop_status', 'custrecord_swi_bop_error_message'], [5, s_error_message])
							throw err;
						}
						
						// ADDING LINE ITEMS TO PO'S
					
						// Cider = 5
						// Cage beer = 2
						// Package Beer = 1
						// Wine = 4
							
							var i_item =a_item_mapping[a_data[j]["Item #"]];
							//nlapiLogExecution('debug', 'i_item'+a_data[j]["Item #"], i_item);
							if (isNotNull(i_item)) {
								var s_item_class = a_item_class[i_item];
								
								var i_uom = a_data[j]["UOM"];
								
								var b_unit_change = false;
								var i_qty = 0;
								var i_unit = null;
								if (i_uom == 'C') {
									i_qty = a_data[j]["Qty"];
								} else if (i_uom == 'B') {
									i_qty = a_data[j]["Qty"];
									i_unit = 23;
									b_unit_change = true;
								}
								
								if (s_item_class == "4") {
									b_wine_item_found = true
									 
										o_wine_po.selectNewLineItem('item');
										o_wine_po.setCurrentLineItemValue('item', 'item', i_item);
										o_wine_po.setCurrentLineItemValue('item', 'quantity', i_qty);
										if (b_unit_change == true) {
											o_wine_po.setCurrentLineItemText('item', 'units', 'BTL');
										}
										o_wine_po.commitLineItem('item');
									 
								}
								if (s_item_class == "5") {
									
									b_cider_item_found = true
									o_cider_po.selectNewLineItem('item');
									o_cider_po.setCurrentLineItemValue('item', 'item', i_item);
									o_cider_po.setCurrentLineItemValue('item', 'quantity', i_qty);
									if (b_unit_change == true) {
										o_cider_po.setCurrentLineItemText('item', 'units', 'BTL');
									}
									o_cider_po.commitLineItem('item');
									
								}
								if (s_item_class == "1") {
									b_beer_item_found = true
									o_beer_po.selectNewLineItem('item');
									o_beer_po.setCurrentLineItemValue('item', 'item', i_item);
									o_beer_po.setCurrentLineItemValue('item', 'quantity', i_qty);
									if (b_unit_change == true) {
										o_beer_po.setCurrentLineItemText('item', 'units', 'BTL');
									}
									o_beer_po.commitLineItem('item');
								}
								
								
							}//ITEM VALIDATION ENDS
							else 
							{
								var s_error_message = 'Either The item with ' + a_data[j]["Item #"] + ' is not present in the system or not valid item id is provided. Please check line number ' + (j + 1).toString();
								var err = nlapiCreateError('404', s_error_message);
								nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, ['custrecord_swi_bop_status', 'custrecord_swi_bop_error_message'], [5, s_error_message])
								throw err;
							}
					
					
					} // GROUPED LOOP ENDS
				
			
				 
				try {
					reScheduleScript();
					
							if (isNotNull(i_vendor_id)) {
								if (b_beer_item_found == true) {
									
									var i_saved_beer_id = nlapiSubmitRecord(o_beer_po)
									nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Beer PO Saved===> ' + i_saved_beer_id)
									POIds.push({'class':'beer','id':i_saved_beer_id});
								}
								if (b_cider_item_found == true) {
									
									var i_saved_cider_id = nlapiSubmitRecord(o_cider_po)
									nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Cide PO Saved===> ' + i_saved_cider_id)
								POIds.push({'class':'cider','id':i_saved_cider_id});
								}
								if (b_wine_item_found == true) {
									
									var i_saved_wine_id = nlapiSubmitRecord(o_wine_po);
									var st = nlapiLookupField('purchaseorder',i_saved_wine_id,'status',true);
									nlapiLogExecution('debug', 'scanFiletoCreatePO'+st, 'Wine PO Saved===> ' + i_saved_wine_id)
									POIds.push({'class':'wine','id':i_saved_wine_id});
								}
							}
							reScheduleScript();
					
				} catch (e) {
					reScheduleScript();
					nlapiLogExecution('error', 'scanFiletoCreatePO', 'ERROR ===> ' + e)
					nlapiLogExecution('debug','b_beer_item_found'+b_beer_item_found,'b_cider_item_found'+b_cider_item_found+"/b_wine_item_found"+b_wine_item_found);
					if (b_beer_item_found == true) {
						var i_saved_beer_id = nlapiSubmitRecord(o_beer_po);
						POIds.push({'class':'beer','id':i_saved_beer_id});
						nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Beer PO Saved===> ' + i_saved_beer_id)
					}
					if (b_cider_item_found == true) {
						var i_saved_cider_id = nlapiSubmitRecord(o_cider_po);
						POIds.push({'class':'cider','id':i_saved_cider_id});
						nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Cide PO Saved===> ' + i_saved_cider_id)
					}
					if (b_wine_item_found == true) {
						var i_saved_wine_id = nlapiSubmitRecord(o_wine_po);
						POIds.push({'class':'wine','id':i_saved_wine_id});
						nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Wine PO Saved===> ' + i_saved_wine_id)
					}
					nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, 'custrecord_swi_bop_status', 5)
				}
			}
			//nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, 'custrecord_swi_bop_status', 4)
			//THIS WILL UPDATE AFTER COMBINED INVOICE GENERATED
		}
		
		}
		if (isNotNull(i_vendor_id)) {
			if (b_beer_item_found == true) {
				//var i_saved_beer_id = nlapiSubmitRecord(o_beer_po)
				nlapiLogExecution('debug', 'scanFiletoCreatePO1', 'Beer PO Saved===> ' + i_saved_beer_id)
			}
			if (b_cider_item_found == true) {
				//var i_saved_cider_id = nlapiSubmitRecord(o_cider_po)
				nlapiLogExecution('debug', 'scanFiletoCreatePO1', 'Cide PO Saved===> ' + i_saved_cider_id)
			}
			if (b_wine_item_found == true) {
				//var i_saved_wine_id = nlapiSubmitRecord(o_wine_po)
				nlapiLogExecution('debug', 'scanFiletoCreatePO1', 'Wine PO Saved===> ' + i_saved_wine_id)
			}
		}
		nlapiLogExecution('debug', 'POIds', POIds);
		nlapiLogExecution('debug', 'scanFiletoCreatePO', 'Process Ended');
		var params = {
				custscript_po_id: JSON.stringify(POIds),
				custscript_bulk_order_record_id:param_rec_id
			}
		nlapiScheduleScript('customscript_bulk_order_combine_invoice','customdeploy_bulk_order_combine_invoice',params);
		
	} catch (e) {
		nlapiLogExecution('debug', 'Error', e.toString());
		nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, ['custrecord_swi_bop_status', 'custrecord_swi_bop_error_message'], [5, e])

	}
}

function poCreationDate(a) {
	yyyy = a.split('/')[2]
	var mm = a.split('/')[0]
	var dd = a.split('/')[1]
	var o_date = nlapiStringToDate(mm + '/' + dd + '/' + yyyy)
	// return nlapiAddDays(o_date)
	return o_date
}

function invoiceCreationDate(a) {
	yyyy = a.split('/')[2]
	var mm = a.split('/')[0]
	var dd = a.split('/')[1]
	return mm + '/' + dd + '/' + yyyy

}
function po_ReceiveDate(a) {
	yyyy = a.split('/')[2]
	var mm = a.split('/')[0]
	var dd = a.split('/')[1]
	return mm + '/' + dd + '/' + yyyy

}

function convertInvoieDueDate(a) {
	if (isNotNull(a)) {
		var dd = a.split('/')[1]
		var mm = a.split('/')[0]
		return mm + '/' + dd + '/' + yyyy
	} else return null
}

function mapCustWithExternalId() {
	var filters = [];
	var columns = [];
	var o_mapData = {};
	var a_externalIds = Object.keys(o_mapData);
	filters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'))
	filters.push(new nlobjSearchFilter('entityid', null, 'isnotempty'))
	columns.push(new nlobjSearchColumn('entityid'))
	columns.push(new nlobjSearchColumn('internalid'))
	var results = [];
	var savedsearch = nlapiCreateSearch('customer', filters, columns);
	var resultset = savedsearch.runSearch();
	var searchid = 0;
	do {
		var resultslice = resultset.getResults(searchid, searchid + 1000);
		for (var rs in resultslice) {
			results.push(resultslice[rs]);
			searchid++;
		}
	} while (resultslice.length >= 1000);
	if (results) {
		for (var pp_res = 0; pp_res < results.length; pp_res++) {
			var externalid = results[pp_res].getValue('entityid');
			o_mapData[externalid] = results[pp_res].getValue('internalid');
		}
	}
	return o_mapData;
}

function mapVendorWithExternalId() {
	var filters = [];
	var columns = [];
	var o_mapData = {};
	var a_externalIds = Object.keys(o_mapData);
	filters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'))
	filters.push(new nlobjSearchFilter('entityid', null, 'isnotempty'))
	columns.push(new nlobjSearchColumn('entityid'))
	columns.push(new nlobjSearchColumn('internalid'))
	var results = [];
	var savedsearch = nlapiCreateSearch('vendor', filters, columns);
	var resultset = savedsearch.runSearch();
	var searchid = 0;
	do {
		var resultslice = resultset.getResults(searchid, searchid + 1000);
		for (var rs in resultslice) {
			results.push(resultslice[rs]);
			searchid++;
		}
	} while (resultslice.length >= 1000);
	if (results) {
		for (var pp_res = 0; pp_res < results.length; pp_res++) {
			var externalid = results[pp_res].getValue('entityid');
			o_mapData[externalid] = results[pp_res].getValue('internalid');
		}
	}
	return o_mapData;
}

function mapItemWithExternalId() {
	var filters = [];
	var columns = [];
	var o_mapData = {};
	var a_externalIds = Object.keys(o_mapData);
	filters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'))
	filters.push(new nlobjSearchFilter('itemid', null, 'isnotempty'))
	columns.push(new nlobjSearchColumn('itemid'))
	columns.push(new nlobjSearchColumn('displayname'))
	columns.push(new nlobjSearchColumn('internalid'))
	var results = [];
	var savedsearch = nlapiCreateSearch('item', filters, columns);
	var resultset = savedsearch.runSearch();
	var searchid = 0;
	do {
		var resultslice = resultset.getResults(searchid, searchid + 1000);
		for (var rs in resultslice) {
			results.push(resultslice[rs]);
			searchid++;
		}
	} while (resultslice.length >= 1000);
	if (results) {
		for (var pp_res = 0; pp_res < results.length; pp_res++) {
			//var externalid = results[pp_res].getValue('itemid');
			var externalid = results[pp_res].getValue('displayname');
			o_mapData[externalid] = results[pp_res].getValue('internalid');
		}
	}
	return o_mapData;
}

function mapItemWithClass() {
	var filters = [];
	var columns = [];
	var o_mapData = {};
	var a_externalIds = Object.keys(o_mapData);
	filters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'))
	filters.push(new nlobjSearchFilter('class', null, 'isnotempty'))
	columns.push(new nlobjSearchColumn('class'))
	columns.push(new nlobjSearchColumn('internalid'))
	var results = [];
	var savedsearch = nlapiCreateSearch('item', filters, columns);
	var resultset = savedsearch.runSearch();
	var searchid = 0;
	do {
		var resultslice = resultset.getResults(searchid, searchid + 1000);
		for (var rs in resultslice) {
			results.push(resultslice[rs]);
			searchid++;
		}
	} while (resultslice.length >= 1000);
	if (results) {
		for (var pp_res = 0; pp_res < results.length; pp_res++) {
			var internalid = results[pp_res].getValue('internalid');
			o_mapData[internalid] = results[pp_res].getValue('class');
		}
	}
	return o_mapData;
}

function isNotNull(value) {
	var returnObj = false;
	if (value != null && value != '' && value != 'null' && value != undefined && value != 'undefined' && value != '@NONE@') returnObj = true;
	return returnObj;
}

function reScheduleScript() {
	//Check in governance of script 
	if (nlapiGetContext().getRemainingUsage() < 500) {
		//Rescheduled the script
		var stateMain = nlapiYieldScript();
		if (stateMain.status == 'FAILURE') {
			nlapiLogExecution("Debug", "Failed to yield script, exiting: Reason = " + stateMain.reason + " / Size = " + stateMain.size);
			throw "Failed to yield script";
		} else if (stateMain.status == 'RESUME') {
			nlapiLogExecution("Debug", "Resuming script because of " + stateMain.reason + ". Size = " + stateMain.size);
		}
	}
}
function csvJson(csv)
{
 
  var lines=csv.split(/\n|\n\r|\r/);
  var result = [];
  var headers=lines[0].split(",");
  for(var i=1;i<lines.length;i++){

	  var obj = {};
	  var currentline=lines[i].split(",");

	  for(var j=0;j<headers.length;j++){
		  obj[headers[j]] = currentline[j];
	  }

	  result.push(obj);

  }
  return JSON.stringify(result); //JSON
 
}