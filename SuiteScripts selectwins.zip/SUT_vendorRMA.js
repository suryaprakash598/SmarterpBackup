function printVendorRMA()
{
	var internalid = request.getParameter('id');
	//nlapiLogExecution('debug','internalid',internalid);
	if(internalid)
	{
		try{
				var record = nlapiLoadRecord('vendorreturnauthorization', internalid);
				var renderer = nlapiCreateTemplateRenderer(); 
				var getFile = nlapiLoadFile('6243');
				var file = getFile.getValue();
				//nlapiLogExecution('debug','file',file);
				renderer.setTemplate(file);
				renderer.addRecord('record', record);

				var xml = renderer.renderToString();
				var PDFfile = nlapiXMLToPDF(xml);
				//nlapiLogExecution('debug','PDFfile',PDFfile);
				response.setContentType('PDF','PRINT.pdf','INLINE');
				 response.write(PDFfile.getValue());
				 

		}
		catch(e)
		{
			nlapiLogExecution('debug','Error',e.toString());
		}
	}
	
}