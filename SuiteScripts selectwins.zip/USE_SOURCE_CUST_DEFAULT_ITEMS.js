function beforeLoadSetItem(type, form, request) {
	var s_rec_type = nlapiGetRecordType();
	if (s_rec_type == 'salesorder') {
		if (type == 'create') {
			var entity = request.getParameter('entity');
			if (entity) {
				//Look for Preferred Item Search
				nlapiSetFieldValue('entity', entity);
				var itemList = nlapiLookupField('customer', entity, 'custentity_swi_freqbtitems');
				var pricelevel = nlapiLookupField('customer', entity, 'pricelevel');
				if(pricelevel)
				{
					
				}else{
					pricelevel = 9;
				}
				if (itemList) {
					var itemArray = itemList.split(",");
					// If Preferred Items are available for the customer
					if (itemArray[0]) {
						//Item Search for Details
						var itemSearch = nlapiSearchRecord("item", null, [
							
							["internalid", "anyof"].concat(itemArray),
							"AND", 
							[
								["type","anyof","Group"],
								"OR",
								["pricing.pricelevel","anyof",pricelevel]
							],
   							
                          	
						],
                        [
							  new nlobjSearchColumn("internalid",null,"GROUP"), 
							   new nlobjSearchColumn("quantityavailable",null,"MAX"), 
							   new nlobjSearchColumn("saleunit",null,"GROUP"), 
							   new nlobjSearchColumn("unitprice","pricing","MAX"), 
							   new nlobjSearchColumn("custitem_swi_btpc",null,"MAX"), 
							   new nlobjSearchColumn("custitem_swi_size",null,"MAX"),
							   new nlobjSearchColumn("type",null,"GROUP"),
							   new nlobjSearchColumn("itemid",null,"GROUP").setSort(false)
							
							
							   
						]);
						if(itemSearch && itemSearch.length)
						{
						//Set Items details to items lines
						for (var s = 0; s <  itemSearch.length; s++) {
							var itemId = itemSearch[s].getValue('internalid',null,"GROUP");
							var btpc = itemSearch[s].getText('custitem_swi_btpc',null,"MAX");
							var size = itemSearch[s].getValue('custitem_swi_size',null,"MAX");
							var unit = itemSearch[s].getValue('saleunit',null,"GROUP");
							var rate = itemSearch[s].getValue('unitprice','pricing',"MAX");
							var quantityAvailable = itemSearch[s].getValue('quantityavailable',null,"MAX");
							var itemType = itemSearch[s].getValue('type',null,"GROUP");
							
							//Set Item Line Values
							nlapiSelectNewLineItem('item');
							if(itemType =='Group'){
								var group_Item_num = Number(nlapiGetCurrentLineItemIndex('item'));
								var lineNumbers = nlapiGetFieldValue('custbody_item_group_lines');
								lineNumbers = lineNumbers!=0 ?Number(lineNumbers) + ","+ Number(group_Item_num) : Number(group_Item_num);
								nlapiSetFieldValue('custbody_item_group_lines',lineNumbers);
							}
							
							//Item
							nlapiSetCurrentLineItemValue('item', 'item', itemId, true,true);
							 
							 //BTPC
							if (btpc) {
								  
								nlapiSetCurrentLineItemText('item', 'custcol_swi_bottlepcs', btpc);
							}
							//Quantity Available
							if (quantityAvailable) {
								var qtyAvail = parseFloat(quantityAvailable).toFixed(2);
								//nlapiLogExecution('debug','qtyAvail',qtyAvail);
								nlapiSetCurrentLineItemValue('item', 'quantityavailable', qtyAvail, true);
							}
							
							//SIZE
							if (size) {
								nlapiSetCurrentLineItemValue('item', 'custcol_swi_size', size, true);
							}
							nlapiSetCurrentLineItemValue('item', 'units', unit, true);
							nlapiSetCurrentLineItemValue('item', 'custcol_swi_caseprice', rate, true);
							nlapiSetCurrentLineItemValue('item', 'quantity', 0, true,true);
							if(itemType !='Group'){
							nlapiSetCurrentLineItemValue('item', 'rate', rate, true);
                          	nlapiSetCurrentLineItemValue('item', 'amount', 0, true);
							}
							nlapiCommitLineItem('item');
						}
						}
					}
				}
			}
		}

	}
}
function removeSOLineItems() {
	try{
		 var id = nlapiGetRecordId();
		   var soRecord = nlapiLoadRecord('salesorder', id);
		   var soItemCount = soRecord.getLineItemCount('item');
			var isGroupFlag='F';
		   for(var i = 1; i <= soRecord.getLineItemCount('item'); i++) {
				var itemtype = soRecord.getLineItemValue('item','itemtype',i);
				var isChecked = soRecord.getLineItemValue('item','custcol_swi_sel_item',i);
				var quantity = soRecord.getLineItemValue('item','quantity',i);
				var units = soRecord.getLineItemValue('item','units',i);
							
					if(itemtype=='Group')
						{
							isGroupFlag='T';
							if((isChecked!='T')||(quantity<1))  { 
								soRecord.removeLineItem('item', i); 
								i--;
							}
							
						}else if(itemtype=='EndGroup'){
							isGroupFlag='F';
							continue; // escape the end of group line
						}
						if(isGroupFlag=='F')
						{
							
							if((isChecked!='T')||(quantity<1) && (units!=''))  {  //&& is replaced by || in first cond.
							  soRecord.removeLineItem('item', i);
							  i--;
							}
						}
				
		   }
	 
		nlapiSubmitRecord(soRecord, true, true);
	   }catch(e)
	   {
		  nlapiLogExecution('debug','Error',e.toString()); 
	   }
}