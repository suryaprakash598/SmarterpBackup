function sendEmail(fileid)
{
	try{
		 nlapiLogExecution('debug','fileId'+fileid);
		 
			var emails = ['nancy.sharp@selectwinesinc.com','chantha.thoeun@selectwinesinc.com']; 
			var subject  = 'VIP File Alert';
			var body = 'VIP file is generated. Please do process it.';
			if(fileid){
				//IF FILE EXISTS THEN SEND EMAIL
				var attachment = nlapiLoadFile(fileid);
				
				nlapiSendEmail(5,emails,subject,body,null,null,null,attachment);
			}else{
				nlapiSendEmail(5,emails,subject,body);
			}
		 
	}catch(e)
	{
		nlapiLogExecution('debug','Error in sending email',e.toString());
	}
}