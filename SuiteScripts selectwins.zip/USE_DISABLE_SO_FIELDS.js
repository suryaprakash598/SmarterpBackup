function beforeLoadDisableFields(type, form, request) {
	var s_rec_type = nlapiGetRecordType();
	if (s_rec_type == 'salesorder') {

		if (type == 'create' || type == 'edit' || type == 'view') {
			try {
				form.getField('subsidiary').setDisplayType('hidden');
				form.getField('opportunity').setDisplayType('hidden');
				form.getField('discountitem').setDisplayType('hidden');
				form.getField('discountrate').setDisplayType('hidden');
				form.getField('automaticallyapplypromotions').setDisplayType('hidden');
				if (type == 'view') {
					var o_item_sublist = form.getSubList('item')
					o_item_sublist.getField('options').setDisplayType('hidden');
					o_item_sublist.getField('isclosed').setDisplayType('hidden');
				}
			} catch (e) {}
			//form.getSubList('promotion').setDisplayType('hidden')
		}
	}
}