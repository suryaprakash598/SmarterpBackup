/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define([],

function() {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
	
	var exports = {};
    function beforeLoad(scriptContext) {
    	if(scriptContext.type == scriptContext.UserEventType.VIEW){
    	scriptContext.form.addButton({
            id: "custpage_mybutton",
            label: "Calculate Weight",
            functionName: "onButtonClick"
        });
    	//scriptContext.form.clientScriptModulePath = "SuiteScripts/Adding_Button.js";
    	scriptContext.form.clientScriptFileId=113362;
    	}
      else
        {
          scriptContext.form.addButton({
            id: "custpage_mybutton1",
            label: "Calculate Weight",
            functionName: "onButtonClickEdit"
        });
    	//scriptContext.form.clientScriptModulePath = "SuiteScripts/Adding_Button.js";
    	scriptContext.form.clientScriptFileId=113362;
        }

    }

   
    exports.beforeLoad = beforeLoad;
    return exports;
    
});
