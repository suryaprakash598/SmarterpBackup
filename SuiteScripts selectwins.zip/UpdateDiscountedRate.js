function FC_applyDiscounts(type, name) {
    try {

        //ON CLICK OF APPLY DISCOUNTS CHECKBOX
        //GET ALL LINE ITEMS AND THOSE QUANTITIES
        // SEND ALL ITEMS TO SAVED SEARCH
        // FETCH MIN QTY , RATE, MAIN AND SUB GROUPS
        if (name == 'custbody_swi_apply_discount') {
            var chekboxvalue = nlapiGetFieldValue('custbody_swi_apply_discount');
            if (chekboxvalue == 'T') {
                var isGroupFlag = 'F';
                var items = [];
                var itemQty = [];
                 var lineItemCount = nlapiGetLineItemCount('item');
                for (var i = 0; i < lineItemCount; i++) {
                    var obj = {};

                    var itemtype = nlapiGetLineItemValue('item', 'itemtype', (i + 1));
                    if (itemtype == 'Group') {
                        isGroupFlag = 'T';
                    } else if (itemtype == 'EndGroup') {
                        isGroupFlag = 'F';
                        continue; // escape the end of group line
                    }
                    if (isGroupFlag == 'F') {
                        if (nlapiGetLineItemValue('item', 'itemtype', (i + 1)) != 'EndGroup') {

                            console.log('apply discount checked', (i + 1));
                            nlapiSelectLineItem('item', (i + 1));
                            var isItemSelected = nlapiGetLineItemValue('item', 'custcol_swi_sel_item', (i + 1));
                            var qty = nlapiGetLineItemValue('item', 'quantity', (i + 1));
                            if (isItemSelected == 'T' && qty >= 1) { //IF ITEMS ARE NOT SELECTED THEN NO NEED TO CALCULATE DISCOUNTS
                                var units = nlapiGetCurrentLineItemText('item', 'units');
                                var btpc = nlapiGetCurrentLineItemText('item', 'custcol_swi_bottlepcs');
                                var itemid = nlapiGetLineItemValue('item', 'item', (i + 1));
                                var rate = nlapiGetLineItemValue('item', 'rate', (i + 1));
                                nlapiCommitLineItem('item');

                                if (units.includes('CS')) {
                                    qty = Number(btpc) * Number(qty);
                                }
                                items.push(itemid);
                                obj.itemid = itemid;
                                obj.qty = qty;
                                obj.rate = rate;
                                itemQty.push(obj)
                            }
                        }
                    }
                }
                
                if (items.length > 0) {
                    
                    var itemRates = searchData(items, itemQty);
                    console.log('itemRates', itemRates);
                    if (itemRates.length != 0) {
                        for (var k = 0; k < itemRates.length; k++) {
                            var itemLine = nlapiFindLineItemValue('item', 'item', itemRates[k].itemid);
                            nlapiSelectLineItem('item', itemLine);
                            var units = nlapiGetCurrentLineItemText('item', 'units');
                            var currentRate = nlapiGetCurrentLineItemValue('item', 'rate');
                            var btpc = nlapiGetCurrentLineItemText('item', 'custcol_swi_bottlepcs');
                            if (units.includes('CS')) {
                                itemRates[k].itemqty = Number(itemRates[k].itemqty) / Number(btpc);
                            } else if (units.includes('BTL')) {
                                itemRates[k].itemRate = itemRates[k].itemRate / btpc; // generally price will be given for case then 
                                //if units are converted to BTL then that price should be converted to bottles
                            }
                            if (Number(itemRates[k].itemRate) <= Number(currentRate)) { //if discounted rate is less than current rate
                                nlapiSetCurrentLineItemValue('item', 'price', -1);
                                nlapiSetCurrentLineItemValue('item', 'rate', itemRates[k].itemRate);
                                nlapiSetCurrentLineItemValue('item', 'amount', itemRates[k].itemRate * itemRates[k].itemqty);
                            }
                            //nlapiRefreshLineItems('item');
                            nlapiCommitLineItem('item');

                        }


                    }

                } else {
                    //IF ITEM RATE IS 0 THEN CASE PRICE SHOULD UPDATE INTO RATE FIELD

                }
            } else if (chekboxvalue == 'F') {
                var isGroupFlag = 'F';
                var lineItemCount = nlapiGetLineItemCount('item');
                for (var i = 0; i < lineItemCount; i++) {
                    debugger;

                    var itemtype = nlapiGetLineItemValue('item', 'itemtype', (i + 1));
                    if (itemtype == 'Group') {
                        isGroupFlag = 'T';
                    } else if (itemtype == 'EndGroup') {
                        isGroupFlag = 'F';
                        continue;
                    }
                    if (isGroupFlag == 'F') {
                        nlapiSelectLineItem('item', (i + 1));
                        var isItemSelected = nlapiGetLineItemValue('item', 'custcol_swi_sel_item', (i + 1));
                        var qty = nlapiGetLineItemValue('item', 'quantity', (i + 1));
                        if (isItemSelected == 'T' && qty >= 1) {
                            var itemid = nlapiGetLineItemValue('item', 'item', (i + 1));
                            var units = nlapiGetLineItemValue('item', 'units', (i + 1));
                            nlapiSetCurrentLineItemValue('item', 'item', itemid, true, true);
                            nlapiSetCurrentLineItemValue('item', 'quantity', qty, true, true);
                            nlapiSetCurrentLineItemValue('item', 'units', units, true, true);
                            nlapiCommitLineItem('item');
                        }
                    }

                }
            }
        }
		nlapiLogExecution('debug','_mode',_mode);
        if (name == 'quantity' && type == 'item'&&_mode=='create') {
            var isDiscountChecked = nlapiGetFieldValue('custbody_swi_apply_discount');
            if (isDiscountChecked == 'T') {
                alert('Please uncheck Apply Discount to modify line items. Reapply Discounts once line modified');

            }
        }
        return true;
    } catch (e) {
        nlapiLogExecution('debug', 'Error', e.toString());
    }
}

function recalcSetLineCheckBox() {
    debugger;
    try {
        /* var count = nlapiGetLineItemCount('item');
        for(var i=0;i<count;i++){
        	   nlapiSetLineItemValue('item','custcol_swi_sel_item',(i+1),'T');
        	   nlapiFireLineItemOnChange('item','custcol_swi_sel_item',(i+1));
        	   
        } */

    } catch (e) {
        nlapiLogExecution('debug', 'Error', e.toString());
    }

}

function save_validateApplyDiscount() {
    var applyDiscount = nlapiGetFieldValue('custbody_swi_apply_discount');
    if (applyDiscount == 'F') {
        alert('Please Check Apply Discount Checkbox');
        return false;
    }
    return true;
}
var _mode;
function PI_SourceGroupComponents(type) {
    try {
        debugger;
		_mode = type;
        var groupItems = nlapiGetFieldValue('custbody_item_group_lines');
        var a_groupItem = groupItems.split(',');
        var lineItemCount = nlapiGetLineItemCount('item');
        if (lineItemCount > 0) {

            for (var i = 0; i < a_groupItem.length; i++) {
                try {
                    if (Number(a_groupItem[i]) != 0) {
						nlapiLogExecution('debug','Number(a_groupItem['+i+'])',Number(a_groupItem[i]))
                        nlapiSelectLineItem('item', Number(a_groupItem[i]));
                        nlapiSetCurrentLineItemValue('item', 'custcol_swi_sel_item', 'T', true, true);
                        nlapiSetCurrentLineItemValue('item', 'custcol_swi_sel_item', 'F');
                        nlapiCommitLineItem('item');

                    }
                } catch (e) {
                    nlapiLogExecution('debug', 'Error in PI_SourceGroupComponents loop', e.toString());
					nlapiCancelLineItem('item')
                }
            }
        }
    } catch (e) {
        nlapiLogExecution('debug', 'Error in PI_SourceGroupComponents', e.toString());
    }
}

function VL_storeSelectedLines() {
    try {
        debugger;
        var isSelected = nlapiGetCurrentLineItemValue('item', 'custcol_swi_sel_item');
        if (isSelected == 'T') {
            var lineNum = nlapiGetCurrentLineItemIndex('item');
            var selectedLines = nlapiGetFieldValue('custbody_selected_lines');
            if (selectedLines == '') {
                nlapiSetFieldValue('custbody_selected_lines', lineNum);
            } else {
                nlapiSetFieldValue('custbody_selected_lines', selectedLines + "," + lineNum);
            }
        }
        var qty = nlapiGetCurrentLineItemValue('item', 'quantity');
        var itemType = nlapiGetCurrentLineItemValue('item', 'itemtype');
        var itemId = nlapiGetCurrentLineItemValue('item', 'item');
        var quantityAvailable = nlapiGetCurrentLineItemValue('item', 'quantityavailable');
        var itemName = nlapiGetCurrentLineItemText('item', 'item');
        var isKegItem = itemName.search('KEG');
        var isDepostItem = itemName.search('Deposit');
        if (isSelected == 'F' && qty > 0 && itemType != 'Group' && isKegItem == -1 && isDepostItem == -1&&_mode=='create') {
            alert('Please select the checkbox');
			//nlapiCancelLineItem('item');
            return false;
        }
        var qtyAvail = parseFloat(quantityAvailable).toFixed(2);
        if (isSelected == 'T' && qty > 0 && (quantityAvailable > 0 && quantityAvailable != '')) {
            nlapiSetCurrentLineItemValue('item', 'quantityavailable', qtyAvail);

        }
        var chekboxvalue = nlapiGetFieldValue('custbody_swi_apply_discount');
        var customer = nlapiGetFieldValue('entity');
        var pricelevel = nlapiLookupField('customer', customer, 'pricelevel');
         var arr = [1, 10, 6, 12]; // 1:Restaurant 10:Military
        if (chekboxvalue != 'T' && !arr.includes(Number(pricelevel))) {
            var units = nlapiGetCurrentLineItemText('item', 'units');
            var btpc = nlapiGetCurrentLineItemText('item', 'custcol_swi_bottlepcs')
            if (units.includes('CS')) {
                var unitValue = nlapiGetCurrentLineItemValue('item', 'units');
                //SETTING PRICELEVEL TO FULLPRICE IF UNITS ARE IN CASE
                var rateObj = readItemPriceData(itemType, itemId, qty, customer, 3, unitValue);
                var rate = rateObj;
                //var rate = rateObj[rateObj.length-1]["qtyFullpriceLineRate"];
                nlapiSetCurrentLineItemValue('item', 'price', 3, true, true);
                nlapiSetCurrentLineItemValue('item', 'rate', rate);
                nlapiSetCurrentLineItemValue('item', 'amount', rate * qty);

            } else if (units.includes('BTL')) {
                var unitValue = nlapiGetCurrentLineItemValue('item', 'units');
                //SETTING PRICELEVEL TO EDLP IF UNITS ARE IN BTL
                var rateObj = readItemPriceData(itemType, itemId, qty, customer, 11, unitValue);
                var rate = rateObj;
                //var rate = rateObj[rateObj.length-1].qtyEdlpLineRate/Number(btpc);
                nlapiSetCurrentLineItemValue('item', 'price', 11, true, true);
                nlapiSetCurrentLineItemValue('item', 'rate', rate);
                nlapiSetCurrentLineItemValue('item', 'amount', rate * qty);

            }
        } 
        return true;
    } catch (e) {
        nlapiLogExecution('debug', 'Error in VL_storeSelectedLines', e.toString());
    }
}

function readItemPriceData(itemType, itemId, qty, customer, price, unitValue) {
    var obj = {};
    obj.itemId = itemId;
    obj.qty = qty;
    obj.customer = customer;
    obj.price = price;
    obj.unitValue = unitValue;
    var obj1 = JSON.stringify(obj);
    debugger;
    var url = 'https://3497583.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=452&deploy=1&compid=3497583&h=27e873b8fbb66afbf311&data=' + obj1;
    var resp = nlapiRequestURL(url);
    var res = resp.getBody();
    if (res) {
        return res;
    } else {
        return 0;
    }


}

function VD_updateSelectedLines() {
    try {
        debugger;
        /* var isSelected = nlapiGetCurrentLineItemValue('item','custcol_swi_sel_item');
        if(isSelected=='T')
        { */
        var lineNum = nlapiGetCurrentLineItemIndex('item');
        var selectedLines = nlapiGetFieldValue('custbody_selected_lines');
        var selLineArray = selectedLines.split(',').sort();
        if (selLineArray.indexOf(lineNum) > -1) {
            var index = selLineArray.indexOf(lineNum);
            for (var i = index; i < selLineArray.length; i++) {
                selLineArray[index] = selLineArray[index] - 1;
            }
            selLineArray.splice(index, 1);
        }
        nlapiSetFieldValue('custbody_selected_lines', selectedLines + "," + lineNum);
        /* } */
        return true;
    } catch (e) {
        nlapiLogExecution('debug', 'Error in VD_updateSelectedLines', e.toString());
    }
}



function searchData(items, itemQty) {
    var customrecord_swi_item_lineSearch = nlapiSearchRecord("customrecord_swi_item_line", null,
        [
            ["custrecord_swi_item_sel", "anyof", items],
            "AND",
            ["custrecord_swi_q_grp_parent", "noneof", "@NONE@"],
            "AND",
            ["isinactive", "is", "F"],
      "AND",
      ["custrecord_swi_q_grp_parent.isinactive","is","F"]
        ],
        [
            new nlobjSearchColumn("custrecord_swi_item_sel"),
            new nlobjSearchColumn("custrecord_swi_item_price"),
            new nlobjSearchColumn("custrecord_swi_btpc"),
            new nlobjSearchColumn("custrecord_swi_units"),
            new nlobjSearchColumn("custrecord_swi_q_grp_parent"),
            new nlobjSearchColumn("custrecord_swi_minqty", "CUSTRECORD_SWI_Q_GRP_PARENT", null),
            new nlobjSearchColumn("custrecord_swi_quan_disc_grp", "CUSTRECORD_SWI_Q_GRP_PARENT", null)
        ]
    );
    var searchObj = customrecord_swi_item_lineSearch;
    if (searchObj && searchObj.length > 0) {
        var rate = 0;
        var itemRates = [];
        var sumofSameGroupItemQty = 0;
        var subgrpqty = 0;
        var SearchDetails = [];
        for (var j = 0; j < searchObj.length; j++) {
            var obj = {};
            var itemObj = {};
            var item = searchObj[j].getValue('custrecord_swi_item_sel');
            var itemRate = searchObj[j].getValue('custrecord_swi_item_price');
            var subGrp = searchObj[j].getText('custrecord_swi_q_grp_parent');
            var minQty = searchObj[j].getValue('custrecord_swi_minqty', 'CUSTRECORD_SWI_Q_GRP_PARENT');
            var mainGrp = searchObj[j].getText('custrecord_swi_quan_disc_grp', 'CUSTRECORD_SWI_Q_GRP_PARENT');
            obj.item = item;
            obj.itemRate = itemRate;
            obj.subGrp = subGrp;
            obj.mainGrp = mainGrp;
            obj.minQty = minQty;
            var qty = _.findWhere(itemQty, {
                itemid: item
            }) || 1;
            obj.itmqty = qty && qty.qty;
            obj.itmrate = qty && qty.rate;

            SearchDetails.push(obj);
            //SINGLE ITEM SCENARIO
            /*   var itemqty =itemQty[j].qty;
              var itemid =itemQty[j].itemid;
            if(itemid == item && itemqty >= minQty)
            {
            	itemObj.itemid = itemid;
            	itemObj.itemRate= itemRate;
            	itemObj.itemqty= itemqty;
            	itemRates.push(itemObj);
            } */
        }
        var groupBySubGrp = _.groupBy(SearchDetails, 'subGrp');
        for (var l = 0; l < Object.keys(groupBySubGrp).length; l++) {
            var key = Object.keys(groupBySubGrp)[l];
            var subgrpLen = groupBySubGrp[key].length;
            var subgrp = groupBySubGrp[key];
            var sumOfQty = 0;
            var subGrpMinQty = 0;
            for (var m = 0; m < subgrpLen; m++) {
                var itemObj = {};
                sumOfQty = Number(sumOfQty) + Number(subgrp[m].itmqty);
                subGrpMinQty = subgrp[m].minQty;

            }

            for (var m = 0; m < subgrpLen; m++) {
                var itemObj = {};
                if (sumOfQty >= subGrpMinQty) //36>=36 || 36>=60
                {
                    itemObj.itemid = subgrp[m].item;
                    itemObj.itemRate = subgrp[m].itemRate;
                    itemObj.itemqty = subgrp[m].itmqty;
                    itemRates.push(itemObj);
                    flag = 'T';
                }
                /* else if(sumOfQty<subGrpMinQty ){ //36<60
                	itemObj.itemid = subgrp[m].item;
                	itemObj.itemRate= subgrp[m].itmrate;
                	itemObj.itemqty= subgrp[m].itmqty;
                	itemRates.push(itemObj);
                } */

            }

        }


        return itemRates;
    }

}