/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
define(['N/ui/serverWidget','N/search','N/task', 'N/redirect','N/record'],

function(serverWidget,search,task,redirect,record) {
   
    /**
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} context
     * @param {ServerRequest} context.request - Encapsulation of the incoming request
     * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
     * @Since 2015.2
     */
    function onRequest(context) {
    	
    	var request = context.request;
    	var response = context.response;
    	var internalid={};
    	
    	if(request.method == 'GET'){
    		
        	
        	
        	var form = serverWidget.createForm({
        		title : 'VIP Sales File Filters',
        		//hideNavBar : true
        	});
        	
        	var vendorName = form.addField({
        		id : 'custpage_ven_name',
        		type : serverWidget.FieldType.SELECT,
        		label : 'Vendor Name'
        	});
        	vendorName.isMandatory = true;
        	vendorName.addSelectOption({
        		 value : '',
        		 text : ''
        		});
        	
            	var vendorSearchObj = search.create({
            		   type: "vendor",
            		   filters:
            		   [
                         ["custentity_swi_vip_supplier_id","isnotempty",""], 
                          "AND", 
                          ["custentity_swi_vip_distributor_id","isnotempty",""]
            		   ],
            		   columns:
            		   [
            		      search.createColumn({
            		         name: "entityid",
            		         sort: search.Sort.ASC,
            		         label: "Name"
            		      }),
            		      search.createColumn({name: "internalid", label: "Internal ID"})
            		   ]
            		});
            	var myResultSet = vendorSearchObj.run();
            	var resultRange = myResultSet.getRange({
            		 start: 0,
            		 end: 1000
            		 });
            	for (var i = 0; i < resultRange.length; i++) {
            		 
            		 var entity = resultRange[i].getValue({
            			 name: 'entityid'
            			 });
            		 internalid.entity=resultRange[i].getValue({
            			 name: 'internalid'
        			 });
					 var Vinternalid=resultRange[i].getValue({
            			 name: 'internalid'
        			 });
            		 vendorName.addSelectOption({
                		 value : Vinternalid,
                		 text : entity
                		});
            		 
            		 }
            	
            	//vendorName.updateBreakType = serverWidget.FieldBreakType.STARTCOL;	


        	var startDate = form.addField({
        		id : 'custpage_start_date',
        		type : serverWidget.FieldType.DATE,
        		label : 'Start Date'
        	});
        	startDate.isMandatory = true;
        	startDate.updateBreakType = serverWidget.FieldBreakType.STARTROW;
        	/*startDate.updateLayoutType({
        		layoutType: serverWidget.FieldLayoutType.STARTROW
        	})*/
        	var endDate = form.addField({
        		id : 'custpage_end_date',
        		type : serverWidget.FieldType.DATE,
        		label : 'End Date'
        	});
        	endDate.isMandatory = true;

        	endDate.updateBreakType = serverWidget.FieldBreakType.STARTROW;
        	/*endDate.updateLayoutType({
        		layoutType: serverWidget.FieldLayoutType.STARTROW
        	})*/
        	        	

        	
        	form.addSubmitButton('Submit');  // this also return a field object
        	log.debug('all ids',internalid);
        	response.writePage(form);
        	
        }
    	else
    		{
    		var vendorName= context.request.parameters.custpage_ven_name;
    		var startDate= context.request.parameters.custpage_start_date;
    		var endDate= context.request.parameters.custpage_end_date;
    		
    		var id=internalid.vendorName;
    		log.debug('internal id',id);
    		var scheduletask = task.create({
    			 taskType: task.TaskType.SCHEDULED_SCRIPT,
    			 scriptId: 'customscript_swi_salesfiles',
    			 deploymentId: 'customdeploy_swi_salesfiles',
    			});
    		scheduletask.params = {custscriptcustscript_vendorname: vendorName,custscriptcustscript_startdate: startDate, custscriptcustscript_enddate: endDate };
    		var mrTaskId = scheduletask.submit();
    		log.debug('mrTaskId',mrTaskId);
    		log.debug('jay');
    		redirect.redirect({
    			 url: 'https://3497583.app.netsuite.com/app/common/scripting/scriptstatus.nl?sortcol=dcreated&sortdir=DESC&date=TODAY&datefrom=10/16/2020&dateto=10/16/2020&scripttype=458&primarykey=1804',
    			
    			});

    		/*redirect.toRecord({
    			 type: record.Type.SCRIPT_DEPLOYMENT,
    			 id: mrTaskId
    			 });*/
    		}
    	
    	

    }

    return {
        onRequest: onRequest
    };
    
});
