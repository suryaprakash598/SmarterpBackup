function transformPOtoInv(type) {
	nlapiLogExecution('debug', 'transformPOtoInv', 'Script Executed')
	if (type == 'create') {
		nlapiLogExecution('debug', 'transformPOtoInv', 'Context ===> scheduled ')
		var i_ir_rec_id = nlapiGetRecordId();
		var i_po_rec_id = nlapiLookupField('itemreceipt', i_ir_rec_id, 'createdfrom');
		var o_po_rec = nlapiLoadRecord('purchaseorder', i_po_rec_id);
		var b_bulk_orede = o_po_rec.getFieldValue('custbody_swi_bulkorderprocess');
		if (b_bulk_orede == 'T') {
			var s_po_cust_id = o_po_rec.getFieldValue('custbody_swi_tw_custid');
			var s_truck_number = o_po_rec.getFieldValue('custbody_swi_truckno');
			var s_inv_date = o_po_rec.getFieldValue('custbody_swi_inv_date');
			var s_inv_due_date = o_po_rec.getFieldValue('custbody_swi_vip_inv_due_date');
			var i_po_location = o_po_rec.getFieldValue('location');
			var i_line_count = o_po_rec.getLineItemCount('item');
			var s_memo =  o_po_rec.getFieldValue('memo');
			var o_inv_rec = nlapiCreateRecord('invoice');
			o_inv_rec.setFieldValue('entity', s_po_cust_id)
			o_inv_rec.setFieldValue('trandate', s_inv_date)
			o_inv_rec.setFieldValue('location', i_po_location)
			o_inv_rec.setFieldValue('duedate', s_inv_due_date)
			o_inv_rec.setFieldValue('custbody_swi_po_number', i_po_rec_id)
			o_inv_rec.setFieldValue('custbody_swi_bulkorderprocess', 'T')
			o_inv_rec.setFieldValue('custbody_swi_truckno', s_truck_number)
			o_inv_rec.setFieldValue('memo', s_memo)
			for (var i = 1; i <= i_line_count; i++) {
				var i_po_item = o_po_rec.getLineItemValue('item', 'item', i);
				var i_po_item_qty = o_po_rec.getLineItemValue('item', 'quantity', i);
				var i_po_item_unit = o_po_rec.getLineItemValue('item', 'units', i);
				o_inv_rec.selectNewLineItem('item');
				o_inv_rec.setCurrentLineItemValue('item', 'item', i_po_item);
				o_inv_rec.setCurrentLineItemValue('item', 'quantity', i_po_item_qty);
				o_inv_rec.setCurrentLineItemValue('item', 'units', i_po_item_unit);
				o_inv_rec.commitLineItem('item');
			}
			var i_saved_inv_id = nlapiSubmitRecord(o_inv_rec)
			nlapiLogExecution('debug', 'transformPOtoInv', 'Invoie Created ===> ' + i_saved_inv_id)
			o_po_rec.setFieldValue('custbody_swi_bop_invoice_numer', i_saved_inv_id)
			var i_saved_po_id = nlapiSubmitRecord(o_po_rec)
			nlapiLogExecution('debug', 'transformPOtoInv', 'PO Updated ===> ' + i_saved_po_id)
		}
	}
}

function mapVendorWithExternalId() {
	var filters = [];
	var columns = [];
	var o_mapData = {};
	var a_externalIds = Object.keys(o_mapData);
	filters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'))
	filters.push(new nlobjSearchFilter('entityid', null, 'isnotempty'))
	columns.push(new nlobjSearchColumn('entityid'))
	columns.push(new nlobjSearchColumn('internalid'))
	var results = [];
	var savedsearch = nlapiCreateSearch('vendor', filters, columns);
	var resultset = savedsearch.runSearch();
	var searchid = 0;
	do {
		var resultslice = resultset.getResults(searchid, searchid + 1000);
		for (var rs in resultslice) {
			results.push(resultslice[rs]);
			searchid++;
		}
	} while (resultslice.length >= 1000);
	if (results) {
		for (var pp_res = 0; pp_res < results.length; pp_res++) {
			var externalid = results[pp_res].getValue('entityid');
			o_mapData[externalid] = results[pp_res].getValue('internalid');
		}
	}
	return o_mapData;
}