function getRate(request, response)
{
	try{
			var data = request.getParameter('data');
			nlapiLogExecution('debug','data',data);
			var obj =JSON.parse(data);
		 
			 var portalSO = nlapiCreateRecord('salesorder', {
					recordmode: 'dynamic'
				});
			 	portalSO.setFieldValue('entity', obj.customer);
				portalSO.selectNewLineItem('item');
                portalSO.setCurrentLineItemValue('item', 'item', obj.itemId);
                portalSO.setCurrentLineItemValue('item', 'quantity', obj.qty);
                portalSO.setCurrentLineItemValue('item', 'price', obj.price);
                portalSO.setCurrentLineItemValue('item', 'units', obj.unitValue);
				portalSO.commitLineItem('item');
				
				var rate = portalSO.getLineItemValue('item', 'rate',1);
				if(rate!='' &&rate!=null&&rate!='null'&&rate!='undefined'&&rate!=undefined)
				{
					response.write(rate);
				}else{
					var rate = 0;
					response.write(rate);
				}
	}catch(e)
	{
		var rate = 0;
		response.write(rate);
		nlapiLogExecution('debug','Error',e.toString());
	}
}