function pageInit(type){
       var entity = nlapiGetFieldValue('entity');
	   if (type == 'create') {
            if(entity){
                var itemList = nlapiLookupField('customer', entity, 'custentitysw_defaultitems');		
                var itemArray = itemList.split(",");
                var count = itemArray.length;
                    for (var x = 0; x < count; x++){		  
                        nlapiSelectNewLineItem('item');
                        nlapiSetCurrentLineItemValue('item', 'item',itemArray[x], true, true);
						nlapiSetCurrentLineItemValue('item', 'quantity',0, true, true);
                        nlapiCommitLineItem('item');
				}
			}
       }
}

function fieldChange(type, name){
      if (name == 'entity'){
            var entity = nlapiGetFieldValue('entity');
			if (type == 'create') {
                  if (entity){
                       var itemList = nlapiLookupField('customer', entity, 'custentity_sw_defaultitems');		
                        var itemArray = itemList.split(",");
                         var count = itemArray.length;
                              for (var x = 0; x < count; x++){		  
                                  nlapiSelectNewLineItem('item');
                                  nlapiSetCurrentLineItemValue('item', 'item', itemArray[x], true, true);
								  nlapiSetCurrentLineItemValue('item', 'quantity',0, true, true);
                                  nlapiCommitLineItem('item');
                                }
                      }
			}
          }
		  
}
