// Vendor Header data
var vendor_RECID = '01';
var vendor_DISTGLN = '0000000000000'
var vendor_ISVID = '0188'
var vendor_FILEVER = '030'
var vendor_FILETYPE = 'A'
var distributor_DISTGLN = '0000000000000';//0 removed

// Customer body data
var customer_RECID = '20';
var customer_DISTGLN = '0000000000000';
var customer_ROCHN2 = '          ';
var customer_ROFWN = ' ';
var customer_ROCSTS = ' ';
var customer_RODISP = '  ';
var customer_ROETHN = '  ';
var customer_ROLIFE = ' ';
var customer_ROOCC = '  ';
var customer_ROPAGE = '  ';
var customer_ROPTYPE = ' ';
var customer_ROWMVT = '  ';
var customer_ROSMVT = '  ';
var customer_ROMMVT = '  ';
var customer_ROSELL = ' ';
var customer_ROSM2 = '     ';
var customer_ROLICTYPE = ' ';
var customer_ROBUYER = '                                   ';
var customer_ROWHSE = '        ';
var customer_ROEND = ' ';

// Footer data
var trailer_RECID = '99';
var trailer_DISTGLN = '0000000000000';
var trailer_ISVID = '0188';
var trailer_FILEVER = '030';

var libClassCodesType = 1;
var libChainCodesType = 2;
var libSRSCodesType = 3;
var libClassCodesField = 'custrecord_swi_vip_class_code';
var libChainCodesField = 'custrecord_swi_vip_chain_codes';
var libSRSCodesField = 'custrecord_swi_vip_srs_code';

var sales_RECID = '02';
var sales_DISTGLN = '0000000000000'
var sales_ISVID = '0188'
var sales_FILEVER = '051'
var sales_IPFLAG = 'I'
var sales_FILETYPE = 'A'

var inventory_RECID = '03';
var inventory_DISTGLN = '0000000000000'
var inventory_ISVID = '0188'
var sales_FILEVER = '030'

function isNotNull(value) {
	var returnObj = false;
	if (value != null && value != '' && value != 'null' && value != undefined && value != 'undefined' && value != '@NONE@') returnObj = true;
	return returnObj;
}

function mapVIPReportCodes(i_codeType, s_field) {
	var o_mapData = {};

	var o_codeRecSearch = nlapiSearchRecord("customrecord_swi_vip_report_codes", null, [
		["custrecord_swi_code_type", "anyof", i_codeType]
	], [

		new nlobjSearchColumn("internalid"),
		new nlobjSearchColumn(s_field)
	]);
	if (isNotNull(o_codeRecSearch)) {
		var a_externalIds = Object.keys(o_mapData);
		for (var i = 0; i < o_codeRecSearch.length; i++) {
			var id = o_codeRecSearch[i].getValue('internalid');
			o_mapData[id] = o_codeRecSearch[i].getText(s_field);
		}
	}
	return o_mapData;
}

function getTimeDate() {
	var o_date = getCompanyCurrentDateTime();
	return o_date.getFullYear() + twoDigits(o_date.getMonth() + 1) + twoDigits(o_date.getDate()) + twoDigits(o_date.getHours()) + twoDigits(o_date.getMinutes()) + twoDigits(o_date.getSeconds())

}

function getDate() {
	var o_date = getCompanyCurrentDateTime();
	return o_date.getFullYear() + twoDigits(o_date.getMonth() + 1) + twoDigits(o_date.getDate());

}

function twoDigits(n) {
	return n > 9 ? "" + n : "0" + n;
}

function threeDigits(n) {
	return n > 10 ? "" + n : "00" + n;
}
function threeDigits1(n) {
	return n > 10 ? "0" + n : "00" + n;
}
function getCompanyCurrentDateTime() {

	var currentDateTime = new Date();
	//var companyTimeZone = nlapiLoadConfiguration('companyinformation').getFieldText('timezone');
	var companyTimeZone = '(GMT-05:00) Eastern Time (US & Canada)';
	var timeZoneOffSet = (companyTimeZone.indexOf('(GMT)') == 0) ? 0 : new Number(companyTimeZone.substr(4, 6).replace(/\+|:00/gi, '').replace(/:30/gi, '.5'));
	var UTC = currentDateTime.getTime() + (currentDateTime.getTimezoneOffset() * 60000);
	var companyDateTime = UTC + (timeZoneOffSet * 60 * 60 * 1000);

	return new Date(companyDateTime);
}

function addPrefixZero(no, a) {
	if (isNotNull(a)) {
		var s_zero = ''
		a = a.toString();
		if (a.length == no)
			return a;
		if (no > a.length) {
			var no_of_zero = no - a.length;
			for (var k = 0; k < no_of_zero; k++) {

				s_zero = '0' + s_zero;

			}
			return s_zero + a;
		}
	}else{
		//By Surya
		return '';
	}
}

function addSpeace(no, text) {
	if (isNotNull(text)) {
		text = text.toString();
		var textLength = text.length;
		if (textLength > no) {
			return text.slice(0, no);
		}
		if (textLength == no)
			return text;

		no = no - textLength;
		var space = '';
		for (var ss = 0; ss < no; ss++) {
			space = space + ' ';
		}
		return text + space
	} else {
		var space = '';
		for (var ss = 0; ss < no; ss++) {
			space = space + ' ';
		}
		return space
	}
}

function reScheduleScript() {

	if (nlapiGetContext().getRemainingUsage() < 500) {

		var stateMain = nlapiYieldScript();
		if (stateMain.status == 'FAILURE') {
			nlapiLogExecution("Debug", "Failed to yield script, exiting: Reason = " + stateMain.reason + " / Size = " + stateMain.size);
			throw "Failed to yield script";
		} else if (stateMain.status == 'RESUME') {
			nlapiLogExecution("Debug", "Resuming script because of " + stateMain.reason + ". Size = " + stateMain.size);
		}
	}
}

function getAllResult(filters, columns, type) {

	var results = [];
	var savedsearch = nlapiCreateSearch(type, filters, columns);
	var resultset = savedsearch.runSearch();
	var searchid = 0;
	do {
		var resultslice = resultset.getResults(searchid, searchid + 1000);
		reScheduleScript()
		for (var rs in resultslice) {
			results.push(resultslice[rs]);
			searchid++;
		}
	} while (resultslice.length >= 1000);

	return results;
}

function convertTrandateToFomrat(a) {
	if (isNotNull(a)) {
		var o_date = nlapiStringToDate(a);
		return o_date.getFullYear() + twoDigits(o_date.getMonth() + 1) + twoDigits(o_date.getDate());
	} else
		return '        '
}