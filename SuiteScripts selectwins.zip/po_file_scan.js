function callScheduledScript_CreatePO(request, response) {
	if (request.getMethod() == 'GET') {
		var param_rec_id = request.getParameter('recid');
		var param_file_id = request.getParameter('fileid');
		if (_logValidation(param_rec_id) && _logValidation(param_file_id)) {
			nlapiSubmitField('customrecordswi_bulk_order_processor', param_rec_id, 'custrecord_swi_bop_status', 2)
			nlapiLogExecution('debug', 'param_rec_id', param_rec_id)
			nlapiLogExecution('debug', 'param_file_id', param_file_id)
			var params = {
				custscript_rec_id: param_rec_id,
				custscript_file_id: param_file_id,
			}
			nlapiScheduleScript('customscriptswi_sch_bulk_order_processin', 'customdeploy1', params);
			//Create a form.
			var form = nlapiCreateForm('The system is processing bulk orders, please wait.');
			//var form = nlapiCreateForm('');
			form.setScript('customscript407');
			var url = '/app/common/scripting/scriptstatus.nl?sortcol=dcreated&sortdir=DESC&date=TODAY&datefrom=4/17/2020&dateto=4/17/2020&scripttype=406&primarykey=1056&ifrmcntnr=T';
			var content = '<iframe src="' + url + '"align="center" style="width: 1000px; height: 600px; margin:0; border:0; padding:0"></iframe>';
			var iFrame = form.addField('custpage_sso', 'inlinehtml', 'SSO');
			iFrame.setDefaultValue(content);
			iFrame.setLayoutType('outsidebelow', 'startcol');
			response.writePage(form);
		}
	}
}

function _logValidation(value) {
	if (value != 'null' && value != '' && value != undefined && value != 'NaN' && value != 'undefined') {
		return true;
	} else {
		return false;
	}
}