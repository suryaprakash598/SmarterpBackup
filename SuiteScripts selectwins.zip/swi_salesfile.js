var i_total_so_records = 0;
var i_toal_qty = 0;
var distributor_srs = 's54228';
var totalrecords=0;
function VIPReportSalesFile(request, response) {
  
 var context = nlapiGetContext();
  var vname= context.getSetting('SCRIPT','custscriptcustscript_vendorname');
  var sdate= context.getSetting('SCRIPT','custscriptcustscript_startdate');
  var edate= context.getSetting('SCRIPT','custscriptcustscript_enddate');
  
 nlapiLogExecution('debug','vname varible', vname);
 nlapiLogExecution('debug','sdate', context.getSetting('SCRIPT', 'custscriptcustscript_startdate')); 
 nlapiLogExecution('debug','edate', context.getSetting('SCRIPT', 'custscriptcustscript_enddate')); 
	try {
		var s_file_current_number = nlapiLookupField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number');
		s_file_current_number = parseInt(s_file_current_number) + 1;
		s_file_current_number = threeDigits(s_file_current_number);
		var s_file_data = '';
		var s_sales_data = "";
		var a_filter = [];
		var a_column = [];
		a_filter.push(new nlobjSearchFilter('custentity_swi_vip_supplier_id', null, 'isnotempty'))
		a_filter.push(new nlobjSearchFilter('custentity_swi_vip_distributor_id', null, 'isnotempty'))
		a_filter.push(new nlobjSearchFilter('internalid', null, 'anyof',vname))//internalid
		a_column.push(new nlobjSearchColumn('custentity_swi_vip_supplier_id'))
		a_column.push(new nlobjSearchColumn('custentity_swi_vip_distributor_id'))
		a_column.push(new nlobjSearchColumn('internalid'))
		var o_vendor_search = nlapiSearchRecord('vendor', null, a_filter, a_column);
		if (isNotNull(o_vendor_search)) {
			var divideVendor =0; var counter=0; 
			var condition =10;
			nlapiLogExecution('debug','o_vendor_search.length',o_vendor_search.length);
			for (var v = 0; v < o_vendor_search.length; v++) {
				i_toal_qty=0;
				divideVendor=divideVendor+1;
				reScheduleScript()

				var vendor_SUPPID = o_vendor_search[v].getValue('custentity_swi_vip_supplier_id');
				var vendor_DISTID = o_vendor_search[v].getValue('custentity_swi_vip_distributor_id');
				var vendor_internalid = o_vendor_search[v].getValue('internalid');
				var temp_s_sales_dataObj = generateSalesData(vendor_internalid,vendor_DISTID,sdate,edate); //s_sales_data;
				var s_footer_data = '98';
				s_footer_data = s_footer_data +
					vendor_SUPPID +
					addSpeace(8, vendor_DISTID) +
					vendor_DISTGLN +
					vendor_ISVID + '030' ;
					
				var s_sales_start = '21' + vendor_SUPPID + addSpeace(8, vendor_DISTID);
				 
				temp_s_sales_data = temp_s_sales_dataObj.s_sales_data;
				if ( temp_s_sales_data!= '') 
				{
					var o_salesData = temp_s_sales_dataObj.a_dataObj;
					
					if(o_salesData.length>0)
					{
						var o_salesData_grp = _.groupBy(o_salesData,'trandate');
						
						var o_salesData_keys=Object.keys(o_salesData_grp);
						nlapiLogExecution('debug','o_salesData_keys.length',o_salesData_keys.length);
						for(var k=0;k<o_salesData_keys.length;k++)
						{
							var qtyToFooter='';
							var totRecordsToFooter='';
							var i_qty_total=0;
							s_file_data = s_file_data +
							'02' +
							vendor_SUPPID +
							addSpeace(8, vendor_DISTID) +
							'0000000000000' +
							'0188' +
							'030' +
							sales_IPFLAG +
							o_salesData_keys[k]+
							//getDate() +
							getTimeDate() + '\r\n';
							var a_obj = o_salesData_grp[o_salesData_keys[k]];
							
							for(var l=0;l<a_obj.length;l++)
							{
								var temp_s_sales_data1=a_obj[l].salesData;
								temp_s_sales_data = temp_s_sales_data1.replace(/1234567890/gi, s_sales_start);
								s_file_data=s_file_data+temp_s_sales_data+ '\r\n';
								i_qty_total = Number(i_qty_total)+Number(a_obj[l].quantity_delivered);
							}
							 
							totRecordsToFooter=	addPrefixZero(7, a_obj.length) //i_total_so_records
							qtyToFooter = addPrefixZero(11, i_qty_total);
							s_file_data=s_file_data+s_footer_data+totRecordsToFooter+qtyToFooter+ '\r\n';
							
						}
					 
					}
				}
				reScheduleScript()
					//nlapiLogExecution('debug','condition divideVendor'+divideVendor,'condition'+condition);
					
		/* if(divideVendor==condition){
					var o_file = nlapiCreateFile(distributor_srs + s_file_current_number + '.sls', 'PLAINTEXT', s_file_data);
					// o_file.setFolder(1138);
					o_file.setFolder(-20);
					var i_file_id = nlapiSubmitFile(o_file);
					if (s_file_current_number == 1000)
						nlapiSubmitField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number', 0);
					else
						nlapiSubmitField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number', s_file_current_number);
					
					counter=counter+1;
					var checkPoint=o_vendor_search.length-condition;
					
					if(checkPoint>=20)
					{
						condition =20;
					}else{
						condition =checkPoint;
					}
					s_file_data='';
					nlapiLogExecution('debug','condition AtLast'+condition,'checkPoint'+checkPoint);
					divideVendor=0;
					 
				} */
		 
			}
		}
		nlapiLogExecution('debug','condition AtLast'+totalrecords,s_file_data);
		var o_file = nlapiCreateFile(distributor_srs + s_file_current_number + '.sls', 'PLAINTEXT', s_file_data);
					// o_file.setFolder(1138);
					o_file.setFolder(39352);
					var i_file_id = nlapiSubmitFile(o_file);
					if (s_file_current_number == 1000)
						nlapiSubmitField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number', 0);
					else
						nlapiSubmitField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number', s_file_current_number);
					

	} catch (e) {
		nlapiLogExecution('error', 'error', e)

	}

}

function generateSalesData(vendorId, vendor_DISTID,sdate,edate) {

	var a_dataObj =[];
	var s_sales_data = '';
	var a_filter = [];
	var a_column = [];
	a_filter.push(new nlobjSearchFilter('cogs', null, 'is', 'F'))
	a_filter.push(new nlobjSearchFilter('taxline', null, 'is', 'F'))
	a_filter.push(new nlobjSearchFilter('quantity', null, 'greaterthan', 0));
	a_filter.push(new nlobjSearchFilter('vendor', "item", 'anyof', vendorId));
	a_filter.push(new nlobjSearchFilter('tranpackeddate', null, 'isnotempty'));// 03/09 for taking only shipped sales data
	a_filter.push(new nlobjSearchFilter('type', "applyingtransaction", 'anyof', "CustInvc"));
	// a_filter.push(new nlobjSearchFilter('status', "applyingtransaction", 'anyof', "CustInvc:B")); //REMOVING BASED ON DISCUSSION WITH NANCY ON 11/03/2021
	// a_filter.push(new nlobjSearchFilter('datecreated', "applyingtransaction", 'within', "7/6/2020 12:00 am","8/17/2020 11:59 pm"));
	a_filter.push(new nlobjSearchFilter('datecreated', "applyingtransaction", 'within', sdate,edate));

  
	a_column.push(new nlobjSearchColumn("transactionnumber"))
	a_column.push(new nlobjSearchColumn("tranid"))
	a_column.push(new nlobjSearchColumn("trandate"));
	a_column.push(new nlobjSearchColumn("entityid", "customer", null))
	a_column.push(new nlobjSearchColumn("externalid", "item", null))
	a_column.push(new nlobjSearchColumn("quantity"))
	a_column.push(new nlobjSearchColumn("unit"))
	a_column.push(new nlobjSearchColumn("rate"))
	a_column.push(new nlobjSearchColumn("amount"))
	a_column.push(new nlobjSearchColumn("linesequencenumber"))
	a_column.push(new nlobjSearchColumn("tranid", "applyingTransaction", null))
	a_column.push(new nlobjSearchColumn("quantityuom", "applyingTransaction", null))
	a_column.push(new nlobjSearchColumn("trandate","fulfillingTransaction",null) )
	
	
	var o_sales_order_search = getAllResult(a_filter, a_column, 'salesorder')

	if (isNotNull(o_sales_order_search)) {
		i_total_so_records = o_sales_order_search.length;
		totalrecords =totalrecords+i_total_so_records;
		//nlapiLogExecution('debug','o_sales_order_search.length',i_total_so_records);
		nlapiLogExecution('debug','o_sales_order_search.length',o_sales_order_search.length);
		for (var c = 0; c < o_sales_order_search.length; c++) {
			var obj={};
			var s_tempString='';
			var entityid = o_sales_order_search[c].getValue('entityid');
			var amount = o_sales_order_search[c].getValue('amount');
			/* var invoice_date = o_sales_order_search[c].getValue('trandate');
			invoice_date = convertTrandateToFomrat(invoice_date) */ // 8/17/2020 changed trandate to packed date
			var invoice_date = o_sales_order_search[c].getValue("trandate","fulfillingTransaction");
			nlapiLogExecution('debug','invoice_date',invoice_date);
			invoice_date = convertTrandateToFomrat(invoice_date)
			nlapiLogExecution('debug','invoice_date formateed',invoice_date);
			var invoice_number = o_sales_order_search[c].getValue("tranid", "applyingTransaction");
			var customer_id = o_sales_order_search[c].getValue("entityid", "customer", null);
			var supplier_item_code = o_sales_order_search[c].getValue("externalid", "item", null);
			var quantity_base = o_sales_order_search[c].getValue('quantity');
			var quantity_delivered = o_sales_order_search[c].getValue("quantityuom", "applyingTransaction");
			i_toal_qty = i_toal_qty + parseFloat(quantity_delivered)
			var quantity_unit_of_measure = o_sales_order_search[c].getValue('unit');
			quantity_unit_of_measure = quantity_unit_of_measure.toString();
			if (quantity_unit_of_measure.search('CS') > 0)
				quantity_unit_of_measure = 'C'
			else if (quantity_unit_of_measure.search('Bottle') >= 0)
				quantity_unit_of_measure = 'B'
			else
				quantity_unit_of_measure = ' '

			var Frontline_unit_price = o_sales_order_search[c].getValue('rate');
			Frontline_formula = (Frontline_unit_price*quantity_base)/quantity_delivered;
			var Net_unit_price = '';
			var Distributor_item_code = supplier_item_code; // coppied
			var Deposit_amount_per_unit = ''; // Not found
			var California_Redemption_Value = ''; // Not mandetory
			var Local_tax_per_unit = ''; // Not mandetory
			var Additional_charge_per_unit = ''; // Not mandetory
			var Distributor_Sales_Rep_ID = ''; // Not found
			var Repack_Flag = 'N'; // Not found
			var Depletion_Warehouse_ID = ''; // Not found
			var Extended_net_price = Number(amount).toFixed(4).replace('.','');//''; // Not found
			var Transaction_Type = ''; // Not mandetory
			var Distributors_internal_discount_id = '               '; // Not mandetory
			var Distributors_internal_discount_Group_ID = '               '; // Not mandetory
			var Suppliers_originated_promotion_ID = '               ';
			var Extended_Distributor_amount = '         '; // Not mandetory
			var Extended_Supplier_amount = '         '; // Not mandetory
			var Split_Case_charge_per_unit = '    '; // Not mandetory

			var Combo_Flag = ' '; // Not mandetory
			var Free_Good_Flag = ' '; // Not mandetory
			var Duty_Free_Flag = ' '; // Not mandetory
			var Order_Date = '        '; // Not mandetory
			var Order_Quantity = '       '; // Not mandetory
			var Order_Unit_of_Measure = ' '; // Not mandetory

			var Invoice_Line = o_sales_order_search[c].getValue('linesequencenumber');

			var Reference_invoice = '                         '; // Not mandetory
			var Extended_Front_Line_Price = '0000000000000'; // Not found
			var Depletion_Period = '000000'; // Not found
			var End_of_record_flag = 'X'; // Not found

			Frontline_unit_price = parseFloat(Frontline_formula).toFixed(2);
			Frontline_unit_price = Frontline_unit_price.toString();
			Frontline_unit_price = Frontline_unit_price.replace('.', '')
			if (!isNotNull(Frontline_unit_price))
				Frontline_unit_price = '000000000'
			Net_unit_price = Frontline_unit_price;
			
			s_tempString =s_tempString+'1234567890' +
				distributor_DISTGLN +
				addSpeace(8, invoice_date) +
				addSpeace(25, invoice_number) +
				addSpeace(15, customer_id) +
				addSpeace(10, '') + //supplier_item_code
				addPrefixZero(7, quantity_delivered) +
				quantity_unit_of_measure +
				addPrefixZero(9, Frontline_unit_price) +
				addPrefixZero(9, Net_unit_price) +
				addPrefixZero(6, Distributor_item_code) +
				'    '+
				'0000000' +
				'0000000' +
				'0000000' +
				'0000000' +
				'SRS99' +
				Repack_Flag+
				addSpeace(8, vendor_DISTID) +
				addPrefixZero(13, Extended_net_price) +End_of_record_flag;
				
			s_sales_data = s_sales_data +
				'1234567890' +
				distributor_DISTGLN +
				addSpeace(8, invoice_date) +
				addSpeace(25, invoice_number) +
				addSpeace(15, customer_id) +
				  addSpeace(10, '') + //supplier_item_code
				addPrefixZero(7, quantity_delivered) +
				quantity_unit_of_measure +
				addPrefixZero(9, Frontline_unit_price) +
				addPrefixZero(9, Net_unit_price) +
				addPrefixZero(6, Distributor_item_code) +
				'    '+
				'0000000' +
				'0000000' +
				'0000000' +
				'0000000' +
				'SRS99' +
				Repack_Flag+
				addSpeace(8, vendor_DISTID) +
				addPrefixZero(13, Extended_net_price) +
				End_of_record_flag;
			obj.trandate =invoice_date;
			obj.salesData = s_tempString;
			obj.vendor = vendorId;
			obj.quantity_delivered = quantity_delivered;
			a_dataObj.push(obj);
			if (c != o_sales_order_search.length - 1) {

				s_sales_data = s_sales_data + '\r\n'
			}
			reScheduleScript()

		}
	}
	var retObj ={};
	retObj.s_sales_data = s_sales_data;
	retObj.a_dataObj = a_dataObj;
	return retObj;
}