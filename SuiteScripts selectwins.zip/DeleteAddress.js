function deleteAddress(){
	var context = nlapiGetContext();
try{
	var customerSearch = nlapiCreateSearch("customer",
	[
	   ["isinactive","is","F"]
	], 
	[
	   new nlobjSearchColumn("internalid")
	]
	);
	var startResult = 0;

    var endResult = 1000;
     
    var resultSet = customerSearch .runSearch();

    var results = resultSet.getResults(startResult,endResult);
/* 
    if(results != null && results.length > 0){
 
       while(results.length == 1000){
			var resultLastId = results[results.length - 1].getValue('internalid');
			startResult = endResult;
			endResult += 1000;
			//results  =results+ resultSet.getResults(startResult,endResult);
		}

    } */
var arr=[];
var customers =[];
nlapiLogExecution('debug','results',results);
nlapiLogExecution('debug','results',results.length);
for(var i=0;i<results.length;i++){
	var record = nlapiLoadRecord('customer',results[i].getId() , {recordmode: 'dynamic'});
	var count = record.getLineItemCount('addressbook');
	if(count>1)
	{
		for(var j=0;j<count;j++)
		{
			var dbill = record.getLineItemValue('addressbook','defaultbilling',(j+1))
			var dship = record.getLineItemValue('addressbook','defaultshipping',(j+1))
			if(dbill=='F'&&dship=='F'){
				record.removeLineItem('addressbook',j+1);
				arr.push(results[i].getId());
				break;
			}
		}
		var x = nlapiSubmitRecord(record);
	}
	if (context.getRemainingUsage() <= 100){
            var stateMain = nlapiYieldScript(); 
            if( stateMain.status == 'FAILURE'){ 
                 // nlapiLogExecution("debug","Failed to yield script (do-while), exiting: Reason = "+ stateMain.reason + " / Size = "+ stateMain.size); 
                  throw "Failed to yield script"; 
            } 
            else if ( stateMain.status == 'RESUME' ){ 
                  nlapiLogExecution("debug", "Resuming script (do-while) because of " + stateMain.reason+". Size = "+ stateMain.size); 
            } 
      }
	customers.push(results[i].getId());
}
nlapiLogExecution('debug','arr',JSON.stringify(arr));
nlapiLogExecution('debug','arr customers',JSON.stringify(customers));
}catch(e)
{
	nlapiLogExecution('debug','Error',e.toString());
	if (context.getRemainingUsage() <= 100){
            var stateMain = nlapiYieldScript(); 
            if( stateMain.status == 'FAILURE'){ 
                 // nlapiLogExecution("debug","Failed to yield script (do-while), exiting: Reason = "+ stateMain.reason + " / Size = "+ stateMain.size); 
                  throw "Failed to yield script"; 
            } 
            else if ( stateMain.status == 'RESUME' ){ 
                  nlapiLogExecution("debug", "Resuming script (do-while) because of " + stateMain.reason+". Size = "+ stateMain.size); 
            } 
      }
}

}
