/**
 *@NApiVersion 2.0
 *@NScriptType Suitelet
 */

/**
     * get the parameters
     *
     * @param {number} vid(vendor internalid) - vendor internal id
     * @param {date} start Date - MM/DD/YYYY
     * @param {date} end Date - MM/DD/YYYY
     */

define(['N/ui/serverWidget', 'N/redirect', 'N/runtime', 'N/record', 'N/ui/message', 'N/search', 'N/url', 'N/format','N/ui/dialog','N/task','N/file'],
    function (serverWidget, redirect, runtime, record1, message, search, url,format,dialog,task,file) {

    function onRequest(context) {
      // Getting parameters
      var vid =  context.request.parameters.vid;
      var sdate=context.request.parameters.sdate;
      var edate=context.request.parameters.edate;
      var filterapplied=context.request.parameters.filter;
      log.debug('filterapplied',filterapplied);
      log.debug('edate',edate);
      var type = context.request.method;
      
        if (context.request.method === 'GET') {
        	try {
        		
                var form = serverWidget.createForm({
                    title: 'Rebate Invoice Process'
                });

                // adding start date field
                var startDate = form.addField({
                    id: 'custpage_sdate',
                    type: serverWidget.FieldType.DATE,
                    label: 'Start Date',

                });
				startDate.isMandatory = true;
                //adding end date field
                var endDate = form.addField({
                    id: 'custpage_edate',
                    type: serverWidget.FieldType.DATE,
                    label: 'End Date',

                });
				endDate.isMandatory = true;
                // adding vendor name field
                var vendorName = form.addField({
                    id: 'custpage_ven_name',
                    type: serverWidget.FieldType.SELECT,
                    label: 'Vendor Name'
                });
				vendorName.isMandatory = true;
                var postingDate = form.addField({
                    id: 'custpage_postingdate',
                    type: serverWidget.FieldType.DATE,
                    label: 'Please select Posting Date',

                });

                form.addSubmitButton({
                    label: 'Process Invoice'
                });

                // Attaching client script for button actions
                form.clientScriptFileId =120059; //production id 120059; sandbox 102532//
                //adding search button to filter based on vendor name and start date end date
                form.addButton({
                    id: 'custpage_buttonid',
                    label: 'Search',
                    functionName: 'vendorsuitelet()'
                });
                form.addButton({
                    id: 'custpage_resetbutton',
                    label: 'Reset',
                    functionName: 'resetfun()'
                });

                //log.debug('dcdc');
                vendorName.addSelectOption({
                    value: '',
                    text: ''
                });
                   // Getting all vendors Names and Internalid's
                var vendorSearchObj = search.create({
                type: "vendor",
                filters:
                [
                 ["isinactive", "is", "F"]
                ],
                columns:
                [
                search.createColumn({
                name: "entityid",
                sort: search.Sort.ASC,
                label: "Name"
                }),
                search.createColumn({name: "internalid", label: "Internal ID"})
                ]
                });
                var myResultSet = vendorSearchObj.run();
                var resultRange = myResultSet.getRange({
                start: 0,
                end: 1000
                });
                for (var i = 0; i < resultRange.length; i++) {

                var entity = resultRange[i].getValue({
                name: 'entityid'
                });
                var internalid=resultRange[i].getValue({
                name: 'internalid'
                });
                //adding vendor names to vendor filter
                vendorName.addSelectOption({
                value : internalid,
                text : entity
                });
                }

                //default values to fields
                startDate.updateDisplaySize({
                    height: 60,
                    width: 400
                });
                endDate.updateDisplaySize({
                    height: 60,
                    width: 200
                });
                postingDate.updateDisplaySize({
                    height: 60,
                    width: 200
                });
                
                	
                vendorName.defaultValue = vid;
                startDate.defaultValue = sdate;
                endDate.defaultValue = edate;
				
				
                log.debug(edate);
                
                if(filterapplied){
                endDate.updateDisplayType({
                	 displayType : serverWidget.FieldDisplayType.DISABLED
                });
            	startDate.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.DISABLED
                });
            	vendorName.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.DISABLED
                });
                }
                

              
                

                //adding Sublist

                var sublist = form.addSublist({
                    id: 'rebateprocess',
                    label: 'Rebate Invoices',
                    type: serverWidget.SublistType.LIST
                });
                sublist.addMarkAllButtons();
                var columns = DAO_sublistFields();

                var sublistHideFields = ["item_id", "_vendor_id", "_item_rate", "_class", "_amount", "_customer","_type","_lineid"];
                for (var i = 0; i < columns.length; i++) {
                    //log.debug(columns[i].id,'id');
                    //log.debug(columns[i].type,'type');

                    if (columns[i].type == 'checkbox') {
                        var sublistField = sublist.addField({
                            id: columns[i].id,
                            label: columns[i].label,
                            type: serverWidget.FieldType.CHECKBOX,
                            source: columns[i].source
                        });
                    } else {
                        var sublistField = sublist.addField({
                            id: columns[i].id,
                            label: columns[i].label,
                            type: serverWidget.FieldType.TEXT,
                            source: columns[i].source
                        });
                    }
                    //log.debug('sublistHideFields.indexOf(columns[i].id)', sublistHideFields.indexOf(columns[i].id));
                    if (sublistHideFields.indexOf(columns[i].id) != -1) {
                        sublistField.updateDisplayType({
                            displayType: serverWidget.FieldDisplayType.HIDDEN
                        });
                    }
                }
                var counter = 0;
                var invoiceSearchObj = searchData(sdate, edate, vid);
				var runtimeobj = runtime.getCurrentScript();
					//log.debug('.getRemainingUsage()',runtimeobj.getRemainingUsage());
					/* var results = invoiceSearchObj.getRange.promise({
					start: 0,
					end: 1000
					}); */
					 
                invoiceSearchObj.run().each(function (result, index) {
				try{
					
				//log.debug('result',result)
                    var valueObj = resultVaues(result);

                    sublist.setSublistValue({
                        id: '_tranid',
                        line: counter,
                        value: valueObj.traninternalid || 1
                    });
                    sublist.setSublistValue({
                        id: 'item',
                        line: counter,
                        value: valueObj.item
                    });
                    sublist.setSublistValue({
                        id: '_vendor',
                        line: counter,
                        value: valueObj.vendor || ''
                    });

                    sublist.setSublistValue({
                        id: 'item_id',
                        line: counter,
                        value: valueObj.itemid || ''
                    });
                    sublist.setSublistValue({
                        id: '_vendor_id',
                        line: counter,
                        value: valueObj.vendorid || ''
                    });
                    sublist.setSublistValue({
                        id: '_doc_number',
                        line: counter,
                        value: valueObj.docnumber || ''
                    });
                    sublist.setSublistValue({
                        id: '_date',
                        line: counter,
                        value: valueObj.trandate || ''
                    });
                    sublist.setSublistValue({
                        id: '_period',
                        line: counter,
                        value: valueObj.postingPeriod
                    });
                    sublist.setSublistValue({
                        id: '_item_rate',
                        line: counter,
                        value: valueObj.rate || 1
                    });
                    sublist.setSublistValue({
                        id: '_quantity',
                        line: counter,
                        value: valueObj.quantity || ''
                    });
                    sublist.setSublistValue({
                        id: '_amount',
                        line: counter,
                        value: valueObj.lineamount || ''
                    });
                   
					//log.debug('type',valueObj.type)
					if(valueObj.type=='Credit Memo'){
					sublist.setSublistValue({
                        id: '_rebate_amount',
                        line: counter,
                        // if it is credit memo append '-' rebate amount else add rebate amount
                        value:  - (valueObj.rebateamount) || ''
                    });
					if(valueObj.rebaterate)
					{
                    sublist.setSublistValue({
                        id: '_rebate_unit',
                        line: counter,
                        // if it is credit memo append '-' before rebate rate else add rebate rate
                        value:  - (valueObj.rebaterate) || ''
                    });	
					}
					}
					else{
						 sublist.setSublistValue({
                        id: '_rebate_amount',
                        line: counter,
                        // if it is credit memo append '-' rebate amount else add rebate amount
                        value:  valueObj.rebateamount
                    });
					if(valueObj.rebaterate){
                    sublist.setSublistValue({
                        id: '_rebate_unit',
                        line: counter,               
                        value: valueObj.rebaterate ||''
                    });
					}
					}

                   
                    
                    sublist.setSublistValue({
                        id: '_class',
                        line: counter,
                        value:valueObj.class1
                    });
                    sublist.setSublistValue({
                        id: '_customer',
                        line: counter,
                        value: valueObj.customer
                    });
                    if (valueObj.units == 'Bottle') {

                        sublist.setSublistValue({
                            id: '_units',
                            line: counter,
                            value: 'BTL'
                        });
                    } else {
                        sublist.setSublistValue({
                            id: '_units',
                            line: counter,
                            value: valueObj.units
                        });
                    }
                  sublist.setSublistValue({
                        id: '_type',
                        line: counter,
                        value: valueObj.type
                    });
					sublist.setSublistValue({
                        id: '_lineid',
                        line: counter,
                        value: valueObj.line
                    });
                  //log.debug('line id',valueObj.line)

                    counter++;
					if(counter==4000)
					{
						log.debug('.getRemainingUsage() after 900',runtimeobj.getRemainingUsage());
						return false;
					}
                    return true;
				}catch(e)
					{
						log.debug('Error in search Running',e.toString())
					}
                });

                context.response.writePage(form);

            } catch (e) {
                log.debug('error', e.toString())
            }
        }
        
      else  {
            log.debug('else block');
              var delimiter = /\u0002/;
              var delimiter1 = /\u0001/;
              var sublistData = context.request.parameters.rebateprocessdata.split(delimiter);
              var arrIndex = {
                  "Mark": 0,
                  "tranid": 1,
                  "Item": 2,
                  "Vendor": 3,
                  "itemid": 4,
                  "vendorid": 5,
                  "DocumentNumber": 6,
                  "Date": 7,
                  "Period": 8,
                  "Rate": 9,
                  "Quantity": 10,
                  "Amount": 12,
                  "RebateAmount": 14,
                  "RebateUnit": 13,
                  "Class": 15,
                  "Customer": 16,
                  "Units": 11,
                  "Type": 17,
                  "Line": 18

              };
             

              //log.debug('sublistData', sublistData);
              var mainArray = [];
              for (var i = 0; i < sublistData.length; i++) {
                  mainArray.push(sublistData[i].split(delimiter1));
              }
              var dataSource = mainArray.filter(function (data) {
                  if (data[0] == "F") {
                      return false; // skip
                  }
                  return true;
              }).map(function (data) {
                  var obj = {};
                  obj.tranid = data[arrIndex.tranid]
                      obj.vendor = data[arrIndex.Vendor]
                      obj.vendorid = data[arrIndex.vendorid]
                      obj.item = data[arrIndex.Item]
                      obj.itemid = data[arrIndex.itemid]
                      obj.docnumber = data[arrIndex.DocumentNumber]
                      obj.date = data[arrIndex.Date]
                      obj.period = data[arrIndex.Period]
                      obj.rate = data[arrIndex.Rate]
                      obj.quantity = data[arrIndex.Quantity]
                      obj.amount = data[arrIndex.Amount]
                      obj.rebateAmount = data[arrIndex.RebateAmount]
                      obj.rebateUnit = data[arrIndex.RebateUnit]
                      obj.Class = data[arrIndex.Class]
                  	  obj.Customer = data[arrIndex.Customer]
                  	  obj.Units = data[arrIndex.Units]
                	  obj.Type = data[arrIndex.Type]
					  obj.line = data[arrIndex.Line]
                  
                      return obj;
              });

              var groupResult = dataSource.reduce(function (r, a) {
                  r[a.vendorid] = r[a.vendorid] || [];
                  r[a.vendorid].push(a);
                  return r;
              }, Object.create(null));
              log.debug('groupResult', groupResult);
              var keys = Object.keys(groupResult);
              log.debug('keys', groupResult);
              // reading selected posting period
              var postingDate= context.request.parameters.custpage_postingdate;
              log.debug('posting date',postingDate);
          
              if(!postingDate)
            	  {
            	  var d=new Date(); // current date
					d.setDate(1); // going to 1st of the month
					d.setHours(-1);
                    
                    var filterDate = new Date(d);
	 var fDate  = filterDate.getDate();
	 var fMonth  = filterDate.getMonth()+1;
	 var fYear  = filterDate.getFullYear();
	 var dateFilter  = fMonth+"/"+fDate+"/"+fYear;
            	  postingDate=new Date(dateFilter);
            	  }
             
                  //creating invoice
                  //var result=createInvoice(groupResult[keys[m]],postingDate);
                  var fileObj = file.create({
								name: 'Rebate Source DND.txt',
								fileType: file.Type.PLAINTEXT,
								contents: JSON.stringify(groupResult),
								description: 'This is a plain text file.',
								encoding: file.Encoding.UTF8,
								folder: 81577,
								isOnline: true
							});
					var fileId = fileObj.save();
					log.debug('file id',fileId);
            	  var scheduletask = task.create({
         			 taskType: task.TaskType.SCHEDULED_SCRIPT,
         			 scriptId: 'customscript_swi_invoice_creation',
         			 deploymentId: 'customdeploy_swi_invoice_creation',
         			});
                  scheduletask.params = {custscript_postingdate: postingDate,custscript_rebatesource_fileid: fileId };
                  var mrTaskId = scheduletask.submit();
          		log.debug('mrTaskId',mrTaskId);
                 
              
              log.debug('finished','finished');
              redirect.redirect({
            	  //url: 'https://3497583-sb1.app.netsuite.com/app/common/scripting/scriptstatus.nl?daterange=TODAY',  // sandbox url
            	  url:'https://3497583.app.netsuite.com/app/common/scripting/scriptstatus.nl?daterange=TODAY'
            	 });

           }
    }
    
    // Custom functions
    function checkNullRequired(value) {
    	var returnObj = true;
    	if (value == null || value == 'NaN' || value == undefined || value.toString().trim() == '' ) {
    		returnObj = false;
    	}
    	return returnObj;
    }
    
    function resultVaues(result) {
        var obj = {};
        obj.id = result.id;
        obj.itemid = result.getValue({
            name: "item",
            summary: "GROUP"
        })
            obj.vendorid = result.getValue({
            name: "vendor",
            join: "item",
            summary: "GROUP"
        }) || 1,
        obj.item = result.getText({
            name: "item",
            summary: "GROUP"
        })
            obj.vendor = result.getText({
            name: "vendor",
            join: "item",
            summary: "GROUP"
        }) || 1,
        obj.docnumber = result.getValue({
            name: "tranid",
            summary: "GROUP"
        }),
        obj.traninternalid = result.getValue({
            name: "internalid",
            summary: "GROUP"
        }),
        obj.trandate = result.getValue({
            name: "trandate",
            summary: "GROUP"
        }),
        obj.postingPeriod = result.getText({
            name: "postingperiod",
            summary: "GROUP"
        }),
        obj.rate = result.getValue({
            name: "rate",
            summary: "SUM"
        }),
        obj.quantity = result.getValue({
            name: "quantityuom",
            summary: "SUM"
        }),
        obj.lineamount = result.getValue({
            name: "fxamount",
            summary: "SUM"
        }),
        obj.rebateamount = result.getValue({
            name: "custcol_ns_rebateamount",
            summary: "SUM"
        }),
        obj.rebaterate = result.getValue({
            name: "custcol_ns_rebateperunit",
            summary: "SUM"
        }),
        obj.class1 = result.getText({
            name: "class",
            join: "item",
            summary: "GROUP"
        }),
        obj.customer = result.getText({
            name: "entity",
            summary: "GROUP"
        }),
        obj.units = result.getText({
            name: "unit",
            summary: "GROUP"
        }),
        obj.type = result.getText({
            name: "type",
            summary: "GROUP"
        }),
        obj.line = result.getValue({
            name: "line",
            summary: "GROUP"
        })
       // log.debug('obj.line',obj.line);
        
            return obj;
    }
    
    function searchData(sdate,edate,vid) {
    var filter = [
            [["type", "anyof", "CustInvc"],
            "OR",["type", "anyof", "CustCred"]],
                      "AND",
                      ["shipping", "is", "F"],
                      "AND",
                      ["taxline", "is", "F"],
                      "AND",
                      ["mainline", "is", "F"],
                      "AND",
                      ["custcol_ns_rebateamount", "isnotempty", ""], 
                      "AND", 
                      ["custcol_ns_rebatebilled","is","F"],"AND",
                      ["custcol_swi_ignore_rebate","is","F" ], "AND",
                      ["customer.custentity_swi_chaincode","noneof","50","70"],"AND", 
                      ["customer.internalidnumber","notequalto","2330"]
                      
           ];
           if(sdate&&edate)
           {
            filter.push('AND'); 
            filter.push(["trandate","within",sdate,edate]); 
           }
           if(vid)
           {  
            filter.push('AND'); 
            filter.push(["item.vendor","anyof",vid]); 
            
           }
           
           
           
          
        var invoiceSearchObj = search.create({
            type: search.Type.TRANSACTION,
            filters: filter,
            columns:
            [
                search.createColumn({
                    name: "item",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "vendor",
                    join: "item",
                    summary: "GROUP",
                    sort: search.Sort.ASC
                }),
                search.createColumn({
                    name: "internalid",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "tranid",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "trandate",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "postingperiod",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "rate",
                    summary: "SUM"
                }),
                search.createColumn({
                  name: "quantityuom",
                    summary: "SUM"
                }),
                search.createColumn({
                    name: "fxamount",
                    summary: "SUM"
                }),
                search.createColumn({
                    name: "custcol_ns_rebateamount",
                    summary: "SUM"
                }),
                search.createColumn({
                    name: "custcol_ns_rebateperunit",
                    summary: "SUM"
                }),
      			search.createColumn({
        		 name: "class",
        		 join: "item",
       			  summary: "GROUP",
      				}),
                search.createColumn({
                    name: "entity",
                    summary: "GROUP"
                 }),
                 search.createColumn({
                     name: "unit",
                     summary: "GROUP"
                  }),
                  search.createColumn({
                      name: "type",
                      summary: "GROUP"
                   }),
				   search.createColumn({
					   name: "line",
					   summary: "GROUP"
				   })
               
            ]
        });
        var searchResultCount = invoiceSearchObj.runPaged().count;

        return invoiceSearchObj;
    }
    
    function DAO_sublistFields() {
        var columns = [
            {
                id: '_mark',
                label: 'MARK',
                type: 'checkbox'
            }, {
                id: '_tranid',
                label: 'ID',
                type: 'TEXT',
                source: ''
            }, {
                id: 'item',
                label: 'ITEM',
                type: 'TEXT',
                source: ''
            }, {
                id: '_vendor',
                label: 'Vendor',
                type: 'TEXT',
                source: ''
            }, {
                id: 'item_id',
                label: 'ITEM ID',
                type: 'TEXT',
                source: ''
            }, {
                id: '_vendor_id',
                label: 'Vendor ID',
                type: 'TEXT',
                source: ''
            }, {
                id: '_doc_number',
                label: 'DOCUMENT NUMBER',
                type: 'TEXT',
                source: ''
            }, {
                id: '_date',
                label: 'DATE',
                type: 'TEXT',
                source: ''
            }, {
                id: '_period',
                label: 'PERIOD',
                type: 'TEXT',
                source: ''
            }, {
                id: '_item_rate',
                label: 'Rate',
                type: 'TEXT',
                source: ''
            }, {
                id: '_quantity',
                label: 'QUANTITY',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_units',
                label: 'UNITS',
                type: 'TEXT',
                source: ''
            }, {
                id: '_amount',
                label: 'AMOUNT',
                type: 'TEXT',
                source: ''
            }, {
                id: '_rebate_unit',
                label: 'REBATE UNIT',
                type: 'TEXT',
                source: ''
            }, {
                id: '_rebate_amount',
                label: 'REBATE AMOUNT',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_class',
                label: 'CLASS',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_customer',
                label: 'CUSTOMER',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_type',
                label: 'Type',
                type: 'TEXT',
                source: ''
            },{
                id: '_lineid',
                label: 'Type',
                type: 'TEXT',
                source: ''
            }
            
            ];
        return columns;
    }
    
    return {
        onRequest: onRequest
    };
});
