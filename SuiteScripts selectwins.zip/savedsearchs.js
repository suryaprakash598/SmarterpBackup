/**
 * Copyright (c) 2017, 2018, Oracle and/or its affiliates.
 *
 * Version    Date            Author           Remarks
 * 1.00       28 Aug 2020    Surya
 *
 * @NApiVersion 2.x
 */
define([], function () {

    return {

        SavedSearches: {
            MonthEndReports: [
			               
			
								{'customsearch930':'Month End Liters Report (Non Alcohol Excl Bulk Order)'},
								{'customsearch918':'Month End Report Excluding Bulk Order (Beer)'}, 
								{'customsearch919':'Month End Report Excluding Bulk Order (Cider)'},
								{'customsearch929':'Month End Report Excluding Bulk Order (Non Alcohol)'},
								{'customsearch913':'Month End Report Excluding Bulk Order (Wine)'},
								{'customsearch920':'Month End Liters Report (Cider Excl Bulk Order)'},//Month End Liters Report (Cider, Excl. Bulk Order)
								{'customsearch916':'Month End Liters Report (Wine Excl Bulk Order)'},//Month End Liters Report (Wine , Excl. Bulk Order)
								{'customsearch926':'Month End Report Bulk Order (Package Beer)'},//Month End Report - Bulk Order (Package Beer)
								{'customsearch921':'Month End Report Bulk Order (Wine)'},//Month End Report - Bulk Order (Wine)
								{'customsearch927':'Month End Report Bulk Order (Wine) Liters'},//Month End Report - Bulk Order (Wine) -Liters
								// {'customsearch_atlas_open_pos_rpt_3_2_3':'SWI Detail Receiving Report'},				
								//{'customsearch_atlas_open_pos_rpt_3_2_2':'SWI Detail Receiing Report with Bulk order'},
								//{'customsearch_atlas_open_pos_rpt_3_2_2_2':'SWI Detail Receiving Report Bulk Order'},
								{'customsearch894':'Schedule A'},
								{'customsearch950':'Schedule B'},
								{'customsearch896':'SWI Wholesalers Report'},
								{'customsearch_swi_farm_report_2':'SWI Farm'},
								{'customsearch_swi_farm_report':'SWI Cider'},
								{'customsearch_swi_breakage_report':'SWI Breakage Report'},
								{'customsearch941':'VA ABC _ Beer Report'}
								  
							 ]
								 

        }

    };

});