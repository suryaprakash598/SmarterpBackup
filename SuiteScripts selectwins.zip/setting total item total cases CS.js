/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/ui/dialog','N/record','N/currentRecord','N/search','N/log'],
/**
 * @param {dialog} dialog
 */
function(dialog,record,currentrecord,search,log) {
   
	
	var exports = {};
    function pageInit(scriptContext) {
    	

    }
    
    function onButtonClick(scriptContext) {
    	var currRec = currentrecord.get();
    	if(currRec.id)//scriptContext.Type !== scriptContext.ClientScript.CREATE
    	{
    		//log.debug(scriptContext);
        //var currRec = currentrecord.get();
        //log.debug('currrec',currRec);
    		var id = currRec.getValue({
    			fieldId : 'id'
    			});
		//log.debug(id);

		var recObj = record.load({
		    type: record.Type.PURCHASE_ORDER, 
		    id:id,
		    isDynamic: true
		});
		var initial_weight=recObj.getValue({fieldId:'custbody_swi_total_weight'});
		var initial_cases=recObj.getValue({fieldId:'custbody_swi_total_cases'});

		var lineCount = recObj.getLineCount({
		    sublistId: 'item'
		});
      //log.debug('line count',lineCount);
		var weight=0;
		var no_of_cases=0;
		for( var i = 0; i < lineCount; i++)
		{
			
			//Getting Sublist Values
			var itemWeight = recObj.getSublistValue({
			    sublistId: 'item',
			    fieldId: 'custcol_swi_item_weight',
			    line: i
			});

			var item_no_of_cases = recObj.getSublistValue({
			    sublistId: 'item',
			    fieldId: 'custcol_swi_no_of_cases',
			    line: i
			});
			
			
			if(true)
				{
				var linelevelweight = recObj.getSublistValue({
				    sublistId: 'item',
				    fieldId: 'custcol_swi_item_weight_source',
				    line: i
				});
				
				//log.debug('linelevelweight before',linelevelweight);
				if (!linelevelweight)
					{
					linelevelweight=0;
					}
				//log.debug(linelevelweight,'linelevelweight');
				var btpc = recObj.getSublistValue({
				    sublistId: 'item',
				    fieldId: 'custcol_swi_item_btpc',
				    line: i
				});
				//log.debug(btpc,'btpc');
				
				var quantity=recObj.getSublistValue({
				    sublistId: 'item',
				    fieldId: 'quantity',
				    line: i
				});
				//log.debug('quantity',quantity)
				
				var unit =recObj.getSublistText({
				    sublistId: 'item',
				    fieldId: 'units',
				    line: i
				});
				log.debug('unit',unit)
				recObj.selectLine({
					sublistId: 'item',
					line:i
					});
				
				
				//recObj.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_item_weight',value:Weight*quantity});
				lineitemweight=0
				lineitemcases=0
				unit.toString();
				if(unit.includes('CS'))
					{
					log.debug('12 cs exce');
					lineitemweight=linelevelweight*quantity;
                      log.debug('line weight',lineitemweight);
					lineitemcases=quantity
					recObj.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_no_of_cases',value:quantity});
					recObj.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_item_weight',value:parseFloat(lineitemweight).toFixed(2)});
					}
				else
					{
					//log.debug('else exce');
					lineitemweight=(linelevelweight/btpc)*quantity;
					lineitemcases=(quantity/btpc);
					recObj.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_no_of_cases',value:lineitemcases});
					recObj.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_item_weight',value:parseFloat(lineitemweight).toFixed(2)});
					}
				
				
				recObj.commitLine({sublistId:'item'});
				
				weight=weight+lineitemweight;
				
				no_of_cases=no_of_cases+lineitemcases;
			}
			else
				{
				weight=weight+itemWeight;
				no_of_cases=no_of_cases+item_no_of_cases;
				
				}
				}
			log.debug('initial_weight',initial_weight);
          log.debug('calculated weight',weight)
          log.debug('initial_cases',initial_cases)
          log.debug('calculated cases',no_of_cases);
	if(initial_weight != parseFloat(weight).toFixed(2) || initial_cases != parseFloat(no_of_cases).toFixed(2))
	{
		recObj.setValue({fieldId:'custbody_swi_total_cases',value:parseFloat(no_of_cases).toFixed(2)});
		recObj.setValue({fieldId:'custbody_swi_total_weight',value:parseFloat(weight).toFixed(2)});
			
		      recObj.save({enableSourcing: true, ignoreMandatoryFields: true});
		      //log.debug('setting values');

				 window.location.reload();
		
	}
	else{
	      //log.debug(' no need the setting values');

		window.location.reload();
	}
	
     


    }
  }
    function onButtonClickEdit(scriptContext)
    {
    
    	var currRec = currentrecord.get();

    		
    		var entity = currRec.getValue({
        		fieldId: 'entity'
        	});
    		
    		var initial_weight=currRec.getValue({fieldId:'custbody_swi_total_weight'});
    		var initial_cases=currRec.getValue({fieldId:'custbody_swi_total_cases'});

    		var lineCount = currRec.getLineCount({
    		    sublistId: 'item'
    		});
    		
    		
    		
    		var weight=0;
    		var no_of_cases=0;
    		for( var i = 0; i < lineCount; i++)
    		{
    			
    			//Getting Sublist Values
    			var itemWeight = currRec.getSublistValue({
    			    sublistId: 'item',
    			    fieldId: 'custcol_swi_item_weight',
    			    line: i
    			});

    			var item_no_of_cases = currRec.getSublistValue({
    			    sublistId: 'item',
    			    fieldId: 'custcol_swi_no_of_cases',
    			    line: i
    			});
    			
    			
    			if(true)
    				{
    				var linelevelweight = currRec.getSublistValue({
    				    sublistId: 'item',
    				    fieldId: 'custcol_swi_item_weight_source',
    				    line: i
    				});
    				
    				
    				if (!linelevelweight)
    					{
    					linelevelweight=0;
    					}
    				
    				var btpc = currRec.getSublistValue({
    				    sublistId: 'item',
    				    fieldId: 'custcol_swi_item_btpc',
    				    line: i
    				});
    				
    				
    				var quantity=currRec.getSublistValue({
    				    sublistId: 'item',
    				    fieldId: 'quantity',
    				    line: i
    				});
    				
    				
    				var unit =currRec.getSublistText({
    				    sublistId: 'item',
    				    fieldId: 'units',
    				    line: i
    				});
    				
    				currRec.selectLine({
    					sublistId: 'item',
    					line:i
    					});
    				
    				
    				
    				lineitemweight=0
    				lineitemcases=0
					unit.toString();
    				if(unit.includes('CS'))
    					{
    					
    					lineitemweight=linelevelweight*quantity;
    					lineitemcases=quantity
    					currRec.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_no_of_cases',value:quantity});
    					currRec.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_item_weight',value:parseFloat(lineitemweight).toFixed(2)});
    					}
    				else
    					{
    					
    					lineitemweight=(linelevelweight/btpc)*quantity;
    					lineitemcases=(quantity/btpc);
    					currRec.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_no_of_cases',value:lineitemcases});
    					currRec.setCurrentSublistValue({ sublistId:'item',fieldId:'custcol_swi_item_weight',value:parseFloat(lineitemweight).toFixed(2)});
    					}
    				
    				
    				currRec.commitLine({sublistId:'item'});
    				
    				weight=weight+lineitemweight;
    				
    				no_of_cases=no_of_cases+lineitemcases;
    			}
    		}
    			
  
    

    	}
 
    
    
    
    
    exports.onButtonClick = onButtonClick;
    exports.onButtonClickEdit = onButtonClickEdit;
    exports.pageInit = pageInit;
    return exports;
});






