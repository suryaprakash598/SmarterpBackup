var i_total_so_records = 0;
var i_toal_qty = 0;
var item_cross_inv_RECID = '04';
var item_cross_inv_DISTGLN = '0000000000000'
var item_cross_inv_ISVID = '0188'
var item_cross_inv_FILEVER = '030';
var distributor_srs = 'c54228'; //m54228

function VIPReportItemCross() {
	var s_file_current_number = nlapiLookupField('customrecord_swi_vip_file_naming', 4, 'custrecord_swi_vip_current_number');
	s_file_current_number = parseInt(s_file_current_number) + 1;
	s_file_current_number = addPrefixZero(3, s_file_current_number);
	nlapiLogExecution('debug', 'script stared');
	var s_file_data = '';
	
	var a_filter = [];
	var a_column = [];
	a_filter.push(new nlobjSearchFilter('custentity_swi_vip_supplier_id', null, 'isnotempty'))
	a_filter.push(new nlobjSearchFilter('custentity_swi_vip_distributor_id', null, 'isnotempty'))
	a_filter.push(new nlobjSearchFilter('custentity_swi_vip_reg', null, 'is', 'T'))

	a_column.push(new nlobjSearchColumn('custentity_swi_vip_supplier_id'))
	a_column.push(new nlobjSearchColumn('custentity_swi_vip_distributor_id'))
	var o_vendor_search = nlapiSearchRecord('vendor', null, a_filter, a_column);
	if (isNotNull(o_vendor_search)) {
		for (var v = 0; v < o_vendor_search.length; v++) {
			//for (var v = 0; v < o_vendor_search.length / 2; v++) {
			reScheduleScript()
			var s_item_cross_inv_data = generateitem_cross_invData(o_vendor_search[v].getId())
			if(s_item_cross_inv_data!=''){
				var vendor_SUPPID = o_vendor_search[v].getValue('custentity_swi_vip_supplier_id');
				var vendor_DISTID = o_vendor_search[v].getValue('custentity_swi_vip_distributor_id');
				var s_footer_data = '96';
				s_footer_data = s_footer_data + vendor_SUPPID + addSpeace(8, vendor_DISTID) + item_cross_inv_DISTGLN + item_cross_inv_ISVID + '030' + addPrefixZero(7, i_total_so_records) + addSpeace(11, i_toal_qty)

				var s_item_cross_inv_start = '24' + vendor_SUPPID + addSpeace(8, vendor_DISTID)
				var temp_s_item_cross_inv_data = s_item_cross_inv_data;
				temp_s_item_cross_inv_data = temp_s_item_cross_inv_data.replace(/1234567890/gi, s_item_cross_inv_start)
					// s_file_data = s_file_data + item_cross_inv_RECID + vendor_SUPPID + addSpeace(8, vendor_DISTID) + item_cross_inv_DISTGLN + item_cross_inv_ISVID + getDate() + item_cross_inv_FILEVER + getDate() + getTimeDate() + '\n' + temp_s_item_cross_inv_data + '\n' + s_footer_data + '\n'
				s_file_data = s_file_data +
					item_cross_inv_RECID +
					vendor_SUPPID +
					addSpeace(8, vendor_DISTID) +
					item_cross_inv_DISTGLN +
					item_cross_inv_ISVID +
					item_cross_inv_FILEVER +
					getTimeDate() + '\n' +
					temp_s_item_cross_inv_data + '\n' +
					s_footer_data + '\n'
				reScheduleScript();
			}
		}
	}

	// var o_file = nlapiCreateFile(distributor_srs + s_file_current_number + '.slm', 'PLAINTEXT', s_file_data);
	var o_file = nlapiCreateFile(distributor_srs + s_file_current_number + '.ITM', 'PLAINTEXT', s_file_data);
	o_file.setFolder(1138);
	var i_file_id = nlapiSubmitFile(o_file);
	if (s_file_current_number == 1000)
		nlapiSubmitField('customrecord_swi_vip_file_naming', 4, 'custrecord_swi_vip_current_number', 0);
	else
		nlapiSubmitField('customrecord_swi_vip_file_naming', 4, 'custrecord_swi_vip_current_number', s_file_current_number);
	
	sendEmail(i_file_id);
}

function generateitem_cross_invData(vendor) {
	var s_item_cross_inv_data = '';
	var a_filter = [
		["type", "anyof", "InvtPart"],
		"AND", ["vendor", "anyof", vendor],
		"AND", ["vendor.custentity_swi_vip_reg", "is", "T"],
		"AND", ["isinactive", "is", "F"],
		/* "AND", 
		["lastmodifieddate", "within", "thismonthtodate"], */
		"AND", ["custitem_swi_tw_bulkorder_item", "is", "F"],
	]
	var a_column = [

		new nlobjSearchColumn("type"),
		new nlobjSearchColumn("salesdescription"),
		new nlobjSearchColumn("saleunit"),
		new nlobjSearchColumn("custitem_swi_btpc"),
		new nlobjSearchColumn("displayname")

	]

	var o_tran_inv_search = getAllResult(a_filter, a_column, 'item')

	if (isNotNull(o_tran_inv_search)) {
		i_total_so_records = o_tran_inv_search.length;
		nlapiLogExecution('debug', 'i_total_so_records', i_total_so_records)
		for (var c = 0; c < o_tran_inv_search.length; c++) {
			reScheduleScript()
			var INSITEM = '';
			var INDITEM = o_tran_inv_search[c].getValue("displayname");
			var INDDESC = o_tran_inv_search[c].getValue("salesdescription");
			var INGTIN = '              ';
			var INACT = 'A';
			// var SELLUNIT = '001';
			var SELLUNIT = o_tran_inv_search[c].getValue("saleunit");
			var UNIT = o_tran_inv_search[c].getText("custitem_swi_btpc");
			SELLUNIT = UNIT;
			nlapiLogExecution('debug', 'SELLUNIT', SELLUNIT);
			var IXDITMSIZ = '          ';
			var IXDITMALC = '     ';
			var IXVINTAGE = '    ';
			var IXGTINR = '              ';
			var IXREPACK = 'N';
			var IXEND = 'X'
			var INITMSTS = 'A'; // Unknown Value
			var INREPACK = 'N';
			var INEND = 'X';
			s_item_cross_inv_data = s_item_cross_inv_data +
				'1234567890' +
				distributor_DISTGLN +
				addSpeace(10, INSITEM) +
				// addSpeace(10, INDITEM) +
				addPrefixZero(6, INDITEM) +
				'    '+
				addSpeace(60, INDDESC) +
				INGTIN +
				INACT +
				threeDigits1(SELLUNIT) +
				threeDigits1(UNIT) +
				IXDITMSIZ +
				IXDITMALC +
				IXVINTAGE +
				IXGTINR +
				IXREPACK +
				IXEND;
			if (c != o_tran_inv_search.length - 1) {

				s_item_cross_inv_data = s_item_cross_inv_data + '\n'
			}
			reScheduleScript()

		}
	}
	return s_item_cross_inv_data
}

function convertTrandateToFomrat(a) {
	if (isNotNull(a)) {
		var o_date = nlapiStringToDate(a);
		return o_date.getFullYear() + twoDigits(o_date.getMonth() + 1) + twoDigits(o_date.getDate());
	} else
		return '        '
}