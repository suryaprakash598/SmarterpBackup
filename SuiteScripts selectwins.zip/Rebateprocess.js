/**
 *@NApiVersion 2.0
 *@NScriptType Suitelet
 */

/**
     * get the parameters
     *
     * @param {number} vid(vendor internalid) - vendor internal id
     * @param {date} start Date - MM/DD/YYYY
     * @param {date} end Date - MM/DD/YYYY
     */

define(['N/ui/serverWidget', 'N/redirect', 'N/runtime', 'N/record', 'N/ui/message', 'N/search', 'N/url', 'N/format','N/ui/dialog','SuiteScripts/suiteletcall'],
    function (serverWidget, redirect, runtime, record1, message, search, url,format,dialog,custfun) {

    function onRequest(context) {
      // Getting parameters
      var vid =  context.request.parameters.vid;
      var sdate=context.request.parameters.sdate;
      var edate=context.request.parameters.edate;
      var type = context.request.method;
        
        if (context.request.method === 'GET') {
            try {
              var form = serverWidget.createForm({
                    title: 'Rebate Invoice Process'
                });

               // adding start date field
                var startDate = form.addField({
                    id: 'custpage_sdate',
                    type: serverWidget.FieldType.DATE,
                    label: 'Start Date',
                    
                });
                //adding end date field
                var endDate = form.addField({
                    id: 'custpage_edate',
                    type: serverWidget.FieldType.DATE,
                    label: 'End Date',
                    
                });
                // adding vendor name field
                var vendorName = form.addField({
                    id : 'custpage_ven_name',
                    type : serverWidget.FieldType.SELECT,
                    label : 'Vendor Name'
                  });
                  var postingDate = form.addField({
                      id: 'custpage_postingdate',
                      type: serverWidget.FieldType.DATE,
                      label: 'Please select Posting Date',
                      
                  });
                 
               
                form.addSubmitButton({
                    label: 'Process Invoice'
                });
                
                // Attaching client script for button actions
                form.clientScriptFileId = 102532;
                //adding search button to filter based on vendor name and start date end date
                 form.addButton({
                     id: 'custpage_buttonid',
                     label: 'Search',
                     functionName: 'vendorsuitelet()'
                 });
                form.addButton({
                    id: 'custpage_resetbutton',
                    label: 'Reset',
                    functionName: 'resetfun()'
                });
              
             
             
              vendorName.addSelectOption({
             value : '',
             text : ''
            });
              // Getting all vendors Names and Internalid's
             var vendorSearchObj = search.create({
             type: "vendor",
             filters:
             [
             ],
             columns:
             [
                search.createColumn({
                   name: "entityid",
                   sort: search.Sort.ASC,
                   label: "Name"
                }),
                search.createColumn({name: "internalid", label: "Internal ID"})
             ]
          });
        var myResultSet = vendorSearchObj.run();
        var resultRange = myResultSet.getRange({
           start: 0,
           end: 1000
           });
        for (var i = 0; i < resultRange.length; i++) {
           
           var entity = resultRange[i].getValue({
             name: 'entityid'
             });
           var internalid=resultRange[i].getValue({
             name: 'internalid'
         });
           //adding vendor names to vendor filter
           vendorName.addSelectOption({
               value : internalid,
               text : entity
              });
           }
              

          //default values to fields    
         vendorName.defaultValue=vid;
        startDate.defaultValue=sdate;
        endDate.defaultValue=edate
        
        startDate.updateDisplaySize({
           height : 60,
           width : 400
          });
        endDate.updateDisplaySize({
         height : 60,
         width : 200
        });
        postingDate.updateDisplaySize({
            height : 60,
            width : 200
           });
        
        //adding Sublist
        
                var sublist = form.addSublist({
                    id: 'rebateprocess',
                    label: 'Rebate Invoices',
                    type: serverWidget.SublistType.LIST
                });
                sublist.addMarkAllButtons();
                var columns = DAO_sublistFields();
        
        var sublistHideFields=["item_id","_vendor_id","_item_rate","_class","_amount","_customer"];
                for (var i = 0; i < columns.length; i++) {
                    //log.debug(columns[i].id,'id');
                    log.debug(columns[i].type,'type');
          
                    if (columns[i].type == 'checkbox') {
                       var sublistField= sublist.addField({
                            id: columns[i].id,
                            label: columns[i].label,
                            type: serverWidget.FieldType.CHECKBOX,
                            source: columns[i].source
                        });
                    } else {
                       var sublistField= sublist.addField({
                            id: columns[i].id,
                            label: columns[i].label,
                            type: serverWidget.FieldType.TEXT,
                            source: columns[i].source
                        });
                    }
          //log.debug('sublistHideFields.indexOf(columns[i].id)',sublistHideFields.indexOf(columns[i].id));
          if(sublistHideFields.indexOf(columns[i].id)!=-1){
            sublistField.updateDisplayType({
              displayType : serverWidget.FieldDisplayType.HIDDEN
            });
          }
                }
                var counter = 0;
                var invoiceSearchObj = searchData(sdate,edate,vid);
                invoiceSearchObj.run().each(function (result, index) {
                    var valueObj = resultVaues(result);

                      sublist.setSublistValue({
                            id: '_tranid',
                            line: counter,
                            value: valueObj.traninternalid || 1
                        });
                        sublist.setSublistValue({
                            id: 'item',
                            line: counter,
                            value: valueObj.item
                        });
                        sublist.setSublistValue({
                            id: '_vendor',
                            line: counter,
                            value: valueObj.vendor || ''
                        });

                        sublist.setSublistValue({
                            id: 'item_id',
                            line: counter,
                            value: valueObj.itemid ||''
                        });
                        sublist.setSublistValue({
                            id: '_vendor_id',
                            line: counter,
                            value: valueObj.vendorid || ''
                        });
                        sublist.setSublistValue({
                            id: '_doc_number',
                            line: counter,
                            value: valueObj.docnumber || ''
                        });
                        sublist.setSublistValue({
                            id: '_date',
                            line: counter,
                            value: valueObj.trandate || ''
                        });
                        sublist.setSublistValue({
                            id: '_period',
                            line: counter,
                            value: valueObj.postingPeriod
                        });
                        sublist.setSublistValue({
                            id: '_item_rate',
                            line: counter,
                            value: valueObj.rate || 1
                        });
                        sublist.setSublistValue({
                            id: '_quantity',
                            line: counter,
                            value: valueObj.quantity || ''
                        });
                        sublist.setSublistValue({
                            id: '_amount',
                            line: counter,
                            value: valueObj.lineamount || ''
                        });
                        pattern = /INV/;
                        
                        sublist.setSublistValue({
                            id: '_rebate_amount',
                            line: counter,
                            // if it is credit memo append '-' rebate amount else add rebate amount 
                            value: (pattern.test(valueObj.docnumber)) ? valueObj.rebateamount : -(valueObj.rebateamount) || ''
                        });
                        sublist.setSublistValue({
                            id: '_rebate_unit',
                            line: counter,
                         // if it is credit memo append '-' before rebate rate else add rebate rate 
                            value: (pattern.test(valueObj.docnumber)) ? valueObj.rebaterate : -(valueObj.rebaterate) || ''
                        });
                        // getting class for item
                        var Class=search.lookupFields({
                            type: 'item',
                            id: valueObj.itemid,
                            columns: ['class']
                        });
                        sublist.setSublistValue({
                            id: '_class',
                            line: counter,
                            value: Class.class[0].text
                        });
                        sublist.setSublistValue({
                            id: '_customer',
                            line: counter,
                            value: valueObj.customer
                        });
                        if(valueObj.units=='Bottle'){
                        	
                        	sublist.setSublistValue({
                                id: '_units',
                                line: counter,
                                value: 'BTL'
                            });
                        }
                        else{
                        	sublist.setSublistValue({
                                id: '_units',
                                line: counter,
                                value: valueObj.units
                            });
                        }
                        
                        
                        counter++;                      
                    return true;                  
                });

                context.response.writePage(form);

            } catch (e) {
                log.debug('error', e.toString())
            }
        }
        
      else  {
            log.debug('else block');
              var delimiter = /\u0002/;
              var delimiter1 = /\u0001/;
              var sublistData = context.request.parameters.rebateprocessdata.split(delimiter);
              var arrIndex = {
                  "Mark": 0,
                  "tranid": 1,
                  "Item": 2,
                  "Vendor": 3,
                  "itemid": 4,
                  "vendorid": 5,
                  "DocumentNumber": 6,
                  "Date": 7,
                  "Period": 8,
                  "Rate": 9,
                  "Quantity": 10,
                  "Amount": 12,
                  "RebateAmount": 14,
                  "RebateUnit": 13,
                  "Class": 15,
                  "Customer": 16,
                  "Units": 11

              };
             

              //log.debug('sublistData', sublistData);
              var mainArray = [];
              for (var i = 0; i < sublistData.length; i++) {
                  mainArray.push(sublistData[i].split(delimiter1));
              }
              var dataSource = mainArray.filter(function (data) {
                  if (data[0] == "F") {
                      return false; // skip
                  }
                  return true;
              }).map(function (data) {
                  var obj = {};
                  obj.tranid = data[arrIndex.tranid]
                      obj.vendor = data[arrIndex.Vendor]
                      obj.vendorid = data[arrIndex.vendorid]
                      obj.item = data[arrIndex.Item]
                      obj.itemid = data[arrIndex.itemid]
                      obj.docnumber = data[arrIndex.DocumentNumber]
                      obj.date = data[arrIndex.Date]
                      obj.period = data[arrIndex.Period]
                      obj.rate = data[arrIndex.Rate]
                      obj.quantity = data[arrIndex.Quantity]
                      obj.amount = data[arrIndex.Amount]
                      obj.rebateAmount = data[arrIndex.RebateAmount]
                      obj.rebateUnit = data[arrIndex.RebateUnit]
                      obj.Class = data[arrIndex.Class]
                  	  obj.Customer = data[arrIndex.Customer]
                  	  obj.Units = data[arrIndex.Units]	
                  
                      return obj;
              });

              var groupResult = dataSource.reduce(function (r, a) {
                  r[a.vendor] = r[a.vendor] || [];
                  r[a.vendor].push(a);
                  return r;
              }, Object.create(null));
              log.debug('groupResult', groupResult);
              var keys = Object.keys(groupResult);
              //log.debug('keys', groupResult);
              // reading selected posting period
              var postingDate= context.request.parameters.custpage_postingdate;
              log.debug('posting date',postingDate);
          
              if(!postingDate)
            	  {
            	  postingDate=new Date();
            	  }
              for (var m = 0; m < keys.length; m++) {
                  //creating invoice
                  var result=createInvoice(groupResult[keys[m]],postingDate);
                
                 if(checkNullRequired(result))
                	 {
                	 var title1;
                	 var message;
                	 if(result=='relatedvendor')
                		 {
                		 
                		 title1='Related Customer is not available';
                		 message='Related Customer is not available';
                		 }
                	 else if(result=='creditmemo'){
                		
                		 title1='Please adjust credit memo against invoice';
                		 message='Please adjust credit memo against invoice';
                	 }
                	 
                	 //if any error while creating invoice this form show the message
                	 var form = serverWidget.createForm({
                         title: title1
                     });
                	 
                	 form.clientScriptFileId = 102532;
                	 var field = form.addField({
                		 id : 'custpage_text',
                		 type : serverWidget.FieldType.LABEL,
                		 label : message
                		});


                     form.addButton({
                         id: 'custpage_buttonid',
                         label: 'Click here to continue',
                         functionName: 'invoiceeror()'
                     });
                    
                	 context.response.writePage(form);

                	 }
              }
           }
    }
    
    // Custom functions
    function checkNullRequired(value) {
    	var returnObj = true;
    	if (value == null || value == 'NaN' || value == undefined || value.toString().trim() == '' ) {
    		returnObj = false;
    	}
    	return returnObj;
    }
    
    function resultVaues(result) {
        var obj = {};
        obj.id = result.id;
        obj.itemid = result.getValue({
            name: "item",
            summary: "GROUP"
        })
            obj.vendorid = result.getValue({
            name: "othervendor",
            join: "item",
            summary: "GROUP"
        }) || 1,
        obj.item = result.getText({
            name: "item",
            summary: "GROUP"
        })
            obj.vendor = result.getText({
            name: "othervendor",
            join: "item",
            summary: "GROUP"
        }) || 1,
        obj.docnumber = result.getValue({
            name: "tranid",
            summary: "GROUP"
        }),
        obj.traninternalid = result.getValue({
            name: "internalid",
            summary: "GROUP"
        }),
        obj.trandate = result.getValue({
            name: "trandate",
            summary: "GROUP"
        }),
        obj.postingPeriod = result.getText({
            name: "postingperiod",
            summary: "GROUP"
        }),
        obj.rate = result.getValue({
            name: "rate",
            summary: "SUM"
        }),
        obj.quantity = result.getValue({
            name: "quantityuom",
            summary: "SUM"
        }),
        obj.lineamount = result.getValue({
            name: "fxamount",
            summary: "SUM"
        }),
        obj.rebateamount = result.getValue({
            name: "custcol_ns_rebateamount",
            summary: "SUM"
        }),
        obj.rebaterate = result.getValue({
            name: "custcol_ns_rebateperunit",
            summary: "SUM"
        }),
        obj.class1 = result.getText({
            name: "Class",
            summary: "GROUP"
        }),
        obj.customer = result.getValue({
            name: "entity",
            summary: "GROUP"
        }),
        obj.units = result.getText({
            name: "unit",
            summary: "GROUP"
        })
        //log.debug('customer id',obj.customer);
        
            return obj;
    }
    
    function searchData(sdate,edate,vid) {
    var filter = [
            [["type", "anyof", "CustInvc"],
            "OR",["type", "anyof", "CustCred"]],
                      "AND",
                      ["shipping", "is", "F"],
                      "AND",
                      ["taxline", "is", "F"],
                      "AND",
                      ["mainline", "is", "F"],
                      "AND",
                      ["custcol_ns_rebateamount", "isnotempty", ""], 
                      "AND", 
                      ["custcol_ns_rebatebilled","is","F"]
                      
           ];
           if(sdate&&edate)
           {
            filter.push('AND'); 
            filter.push(["trandate","within",sdate,edate]); 
           }
           if(vid)
           {  
            filter.push('AND'); 
            filter.push(["item.vendor","anyof",vid]); 
            
           }
           
           
           
          
        var invoiceSearchObj = search.create({
            type: search.Type.TRANSACTION,
            filters: filter,
            columns:
            [
                search.createColumn({
                    name: "item",
                    summary: "GROUP",
                    sort: search.Sort.ASC
                }),
                search.createColumn({
                    name: "othervendor",
                    join: "item",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "internalid",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "tranid",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "trandate",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "postingperiod",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "rate",
                    summary: "SUM"
                }),
                search.createColumn({
                  name: "quantityuom",
                    summary: "SUM"
                }),
                search.createColumn({
                    name: "fxamount",
                    summary: "SUM"
                }),
                search.createColumn({
                    name: "custcol_ns_rebateamount",
                    summary: "SUM"
                }),
                search.createColumn({
                    name: "custcol_ns_rebateperunit",
                    summary: "SUM"
                }),
                search.createColumn({
                    name: "class",
                    summary: "GROUP"
                }),
                search.createColumn({
                    name: "entity",
                    summary: "GROUP"
                 }),
                 search.createColumn({
                     name: "unit",
                     summary: "GROUP"
                  })
               
            ]
        });
        var searchResultCount = invoiceSearchObj.runPaged().count;

        return invoiceSearchObj;
    }
    
    function DAO_sublistFields() {
        var columns = [
            {
                id: '_mark',
                label: 'MARK',
                type: 'checkbox'
            }, {
                id: '_tranid',
                label: 'ID',
                type: 'TEXT',
                source: ''
            }, {
                id: 'item',
                label: 'ITEM',
                type: 'TEXT',
                source: ''
            }, {
                id: '_vendor',
                label: 'Vendor',
                type: 'TEXT',
                source: ''
            }, {
                id: 'item_id',
                label: 'ITEM ID',
                type: 'TEXT',
                source: ''
            }, {
                id: '_vendor_id',
                label: 'Vendor ID',
                type: 'TEXT',
                source: ''
            }, {
                id: '_doc_number',
                label: 'DOCUMENT NUMBER',
                type: 'TEXT',
                source: ''
            }, {
                id: '_date',
                label: 'DATE',
                type: 'TEXT',
                source: ''
            }, {
                id: '_period',
                label: 'PERIOD',
                type: 'TEXT',
                source: ''
            }, {
                id: '_item_rate',
                label: 'Rate',
                type: 'TEXT',
                source: ''
            }, {
                id: '_quantity',
                label: 'QUANTITY',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_units',
                label: 'UNITS',
                type: 'TEXT',
                source: ''
            }, {
                id: '_amount',
                label: 'AMOUNT',
                type: 'TEXT',
                source: ''
            }, {
                id: '_rebate_unit',
                label: 'REBATE UNIT',
                type: 'TEXT',
                source: ''
            }, {
                id: '_rebate_amount',
                label: 'REBATE AMOUNT',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_class',
                label: 'CLASS',
                type: 'select',
                source: ''
            },
            {
                id: '_customer',
                label: 'CUSTOMER',
                type: 'TEXT',
                source: ''
            }
            
            ];
        return columns;
    }
   
    function totalitem(listdata){
    var quantity=0;
    var rebateamount=0;

    for(var j=0; j<listdata.length; j++)
    {
    log.debug('',listdata[j]);
    quantity=parseInt(listdata[j].quantity)+quantity;
    rebateamount=format.parse({value:listdata[j].rebateAmount, type: format.Type.FLOAT})+format.parse({value: rebateamount, type: format.Type.FLOAT});
    }
    var itemdata={}
    itemdata.quantity = quantity
    itemdata.rebateAmount = rebateamount
    itemdata.Class = listdata[0].Class

    return itemdata;
    }
    
    
    function createInvoice(rebateData,pdate) {
        var vendor = rebateData[0].vendorid;
        //checking related vendor is there or not
        var fields = search.lookupFields({
            type: 'vendor',
            id: vendor,
            columns: ['custentity_ns_relatedvendor']
        });
        log.debug('rebate data',rebateData);
        var vendorCustomer;
        try{
        vendorCustomer = fields.custentity_ns_relatedvendor[0].value;
        }
        catch(e){
        	log.debug('related vendor is not there');
        	return 'relatedvendor';
        }
        var updateRebateBilled = [];
        //creating BB invoice
        var rec = record1.create({
            type: 'invoice',
            isDynamic: true,
            defaultValues: {
                entity: vendorCustomer || 3460,
                customform: 152,
                
            }
        });
       	var initialFormattedDateString=format.parse({
    			value: pdate,
    			type: format.Type.DATE
    		});
    		var postingdate = format.format({
    			 value: initialFormattedDateString,
    			 type: format.Type.DATE
    			 });
    		postingdate=new Date(pdate);
    	
    	log.debug('formated date',postingdate);
       rec.setValue({
            fieldId: 'trandate',
            value: postingdate
        });
      
       var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
       var postingPeriod = months[postingdate.getMonth()] + ' ' + postingdate.getFullYear();
       log.debug('posting period',postingPeriod);
       
       rec.setText({
           fieldId: 'postingperiod',
           text: postingPeriod
       });
       rec.setValue({
           fieldId: 'location',
           value: 12
       });
               
        rec.setValue({
            fieldId: 'custbody1',
            value: true
        });

        var quantity=0;
        var amount=0;
        var rebateamount= 0;
        var items=[];
        //taking item data
        for (var j = 0; j < rebateData.length; j++) {
          var item={};
          item.quantity=rebateData[j].quantity;
          item.rebateAmount=rebateData[j].rebateAmount;
          item.Class=rebateData[j].Class;
          items.push(item);
          quantity= parseInt(rebateData[j].quantity)+quantity;
            amount = parseInt(rebateData[j].amount)+amount;
            log.debug('test',rebateData);
            rebateamount=format.parse({value:rebateData[j].rebateAmount, type: format.Type.FLOAT})+format.parse({value: rebateamount, type: format.Type.FLOAT});
            //rebateamount = parseFloat(rebateData[j].rebateAmount).toFixed(2) + parseFloat(rebateamount).toFixed(2);
            log.debug('rebateamount',rebateamount);
          
        }
        //item consolidating based on class
        var itemlist=items.reduce(function (acc,a) {
            
            if (!acc[a.Class]) {
              acc[a.Class] = []
            }
            acc[a.Class].push(a)
            return acc
          }, {});
          log.debug('itemlist',itemlist);
          
          var listdata=itemlist['Keg Beer'];
          log.debug('listdata',listdata);
           var keyslist = Object.keys(itemlist);
         
          //setting line values based on class
        for(var m=0;m<keyslist.length; m++)
            {
            var listdata=itemlist[keyslist[m]]
              
              var itemdata=totalitem(listdata);
             // log.debug('itemdatadfdfd',itemdata);

              rec.selectNewLine({
                  sublistId: 'item'
              });
              /*if(itemdata.Class=="Keg Beer")
              {
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 21260
              });
              }
              else*/ if(itemdata.Class=="Wine")
              {
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 23335
              });
              }
           /*   else if(itemdata.Class=="Package Beer")
              {
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 21261
              });
              }*/
              else{
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  value: 23948
              });
              }
              
              
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'quantity',
                  value: itemdata.quantity
              });
             
             
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'custcol_ns_rebateamount',
                  value: itemdata.rebateAmount
              });
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'amount',
                  value: itemdata.rebateAmount
              });
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'location',
                  value: 12
              });
              
              rec.setCurrentSublistValue({
                  sublistId: 'item',
                  fieldId: 'custcol_ns_rebatebilled',
                  value: true,
                  ignoreFieldChange: true
              });
              rec.commitLine({
                  sublistId: 'item'
              });
              
            }
        try {
        var recordId = rec.save();
        }
        catch(e){
        	log.debug('catch block');
        	return 'creditmemo'; 
        }
        if (recordId) {
        //Gathering data for updating invoices
        	for (var j = 0; j < rebateData.length; j++) {
            try {
                var obj = {};
                obj.tranid = rebateData[j].tranid;
                obj.itemid = rebateData[j].itemid;
                obj.rate = rebateData[j].amount/rebateData[j].quantity;
                obj.docnumber= rebateData[j].docnumber;
                updateRebateBilled.push(obj)
               /* quantity= parseInt(rebateData[j].quantity)+quantity;
                amount = parseInt(rebateData[j].amount)+amount;
                rebateamount=format.parse({value:rebateData[j].rebateAmount, type: format.Type.FLOAT})+format.parse({value: rebateamount, type: format.Type.FLOAT});
                //rebateamount = parseFloat(rebateData[j].rebateAmount).toFixed(2) + parseFloat(rebateamount).toFixed(2);
                log.debug('rebateamount',rebateamount);
                */
                
              //creating rebate source invoice record(custom record)
                
                rebatesource=record1.create({
                    type: 'customrecord_rebate_source_invoice',
                    isDynamic: true,
                    
                });
                
                rebatesource.setValue({
                    fieldId: 'custrecord_rebate_source_item',
                    value: rebateData[j].itemid
                });
                
                rebatesource.setValue({
                    fieldId: 'custrecord_rebate_source_vendor',
                    value: vendor
                });
                rebatesource.setValue({
                    fieldId: 'custrecord_customer',
                    value: rebateData[j].Customer
                });
                
                rebatesource.setValue({
                    fieldId: 'custrecord_rebateamount',
                    value: rebateData[j].rebateAmount
                });
                
                rebatesource.setValue({
                    fieldId: 'custrecord_rebate_source_doc_number',
                    value: recordId //obj.tranid
                });
                
                
                rebatesource.setValue({
                    fieldId: 'custrecord_rebate_source_rate',
                    value: rebateData[j].amount/rebateData[j].quantity
                });
                
                rebatesource.setValue({
                    fieldId: 'custrecord_rebate_source_qty',
                    value: rebateData[j].quantity
                });
                
                rebatesource.setValue({
                    fieldId: 'custrecord_invoice_number',
                    value: obj.tranid
                });
                
                rebatesource.setValue({
                    fieldId: 'custrecord_created_from',
                    value: obj.tranid
                });
                rebatesource.setValue({
                    fieldId: 'custrecord_units',
                    value: rebateData[j].Units
                });
                var rebatesourceid = rebatesource.save();
                

            } catch (e) {
                log.debug('error', e.toString())
            }
            
            
            
        }
            redirect.toRecord({
                type: 'invoice',
                id: recordId,
                isEditMode: false
            });

        } else {
            var myMsg4 = message.create({
                title: "Record Creation Error",
                message: "Error in Invoice Creation",
                type: message.Type.ERROR
            });

            myMsg4.show(); // will stay up until hide is called.
        }
        
        
        
        for (var rb = 0; rb < updateRebateBilled.length; rb++) {
            //update rebate billed checkbox
        	var loadobj;
        	pattern = /INV/;
            if(pattern.test(updateRebateBilled[rb].docnumber)==false){
            	log.debug('loading credit memo')
                 loadobj = record1.load({
                    type: 'creditmemo',
                    id: updateRebateBilled[rb].tranid,
                    isDynamic: true,
                });
            }
            else{
            	log.debug('loading invoice')
            	 loadobj = record1.load({
                    type: 'invoice',
                    id: updateRebateBilled[rb].tranid,
                    isDynamic: true,
                });
            }
                
                var lineNum = loadobj.findSublistLineWithValue({
                    sublistId: 'item',
                    fieldId: 'item',
                    value: updateRebateBilled[rb].itemid
                });
                
                var rateNum = loadobj.findSublistLineWithValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    value: updateRebateBilled[rb].rate
                });
                
                var lineCount = loadobj.getLineCount({
                sublistId: 'item'
            });
                for(var i=0;i<lineCount;i++){
                  var item = loadobj.getSublistValue({
                  sublistId: 'item',
                  fieldId: 'item',
                  line: i
              });

              var itemrate = loadobj.getSublistValue({
                  sublistId: 'item',
                  fieldId: 'rate',
                  line: i
              });
              if(item==updateRebateBilled[rb].itemid && itemrate==updateRebateBilled[rb].rate)
                {
                loadobj.selectLine({
                  sublistId: 'item',
                  line:i
                  });
                 loadobj.setCurrentSublistValue({
                              sublistId: 'item',
                              fieldId: 'custcol_ns_rebatebilled',
                              value: true,
                              ignoreFieldChange: true
                          });
                       loadobj.setCurrentSublistValue({
                              sublistId: 'item',
                              fieldId: 'custcol_ns_rebateinvoice',
                              value: recordId,
                              ignoreFieldChange: true
                          });
                       loadobj.commitLine({
                              sublistId: 'item'
                          });
                
                }
                }           
                var recordId1 = loadobj.save();
                log.debug('recordId1', recordId1)
            
      
        }

    }
    return {
        onRequest: onRequest
    };
});
