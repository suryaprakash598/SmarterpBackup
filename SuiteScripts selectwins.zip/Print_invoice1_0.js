function invoicePdfprint()
{
	//Read the Record ID and isRebateSource
	var internalid = request.getParameter('id');
	var isRebateSource = request.getParameter('rebate');
	nlapiLogExecution('debug','internalid',internalid);
	if(isRebateSource)
	{
		
		try{
			//Load the invoice record	
			var record = nlapiLoadRecord('invoice', internalid);
			var tranid = record.getFieldValue('tranid');
				/*var renderer = nlapiCreateTemplateRenderer();
				
			//Load the template file -- Rebate Source.html	
				var getFile = nlapiLoadFile('73040');
				var file = getFile.getValue();
				renderer.setTemplate(file);
			// Add record to template	
				renderer.addRecord('record', record);*/
				
				var customrecord_rebate_source_invoiceSearch = nlapiSearchRecord("customrecord_rebate_source_invoice",null,
						[
						   ["custrecord_rebate_source_doc_number","anyof",internalid]
						], 
						[
						   new nlobjSearchColumn("custrecord_rebate_source_item").setSort(false), 
						   new nlobjSearchColumn("custrecord_rebate_source_vendor"), 
						   new nlobjSearchColumn("custrecord_customer"), 
						   new nlobjSearchColumn("custrecord_rebate_source_doc_number"), 
						   new nlobjSearchColumn("custrecord_rebate_source_rate"), 
						   new nlobjSearchColumn("custrecord_rebate_source_qty"), 
						   new nlobjSearchColumn("custrecord_rebateamount"), 
						   new nlobjSearchColumn("created"),
						   new nlobjSearchColumn("custrecord_units"), 
						   new nlobjSearchColumn("custrecord_invoice_number"), 
						   new nlobjSearchColumn("custrecord_created_from")
						]
						);
				var contents='';
				contents='Item,Invoice,Customer,Price,Quantity,Units,Depletion Allowance'+'\n';
				if (customrecord_rebate_source_invoiceSearch.length) {
					for (var x = 0; x < customrecord_rebate_source_invoiceSearch.length; x++){		 
		                 var custrecord_rebate_source_item = customrecord_rebate_source_invoiceSearch[x].getText('custrecord_rebate_source_item');
		                 var custrecord_rebate_source_vendor = customrecord_rebate_source_invoiceSearch[x].getText('custrecord_rebate_source_vendor');
		                 var custrecord_customer = customrecord_rebate_source_invoiceSearch[x].getText('custrecord_customer');
		                 var custrecord_rebate_source_doc_number = customrecord_rebate_source_invoiceSearch[x].getValue('custrecord_rebate_source_doc_number');
		                 var custrecord_rebate_source_rate = customrecord_rebate_source_invoiceSearch[x].getValue('custrecord_rebate_source_rate');
		                 var custrecord_rebate_source_qty = customrecord_rebate_source_invoiceSearch[x].getValue('custrecord_rebate_source_qty');
		                 var custrecord_rebateamount = customrecord_rebate_source_invoiceSearch[x].getValue('custrecord_rebateamount');
		                 var created = customrecord_rebate_source_invoiceSearch[x].getValue('created');
		                 var custrecord_units = customrecord_rebate_source_invoiceSearch[x].getValue('custrecord_units');
		                 var custrecord_invoice_number = customrecord_rebate_source_invoiceSearch[x].getText('custrecord_invoice_number');
		                 var custrecord_created_from = customrecord_rebate_source_invoiceSearch[x].getValue('custrecord_created_from');
		                 custrecord_rebate_source_item='"'+custrecord_rebate_source_item+'"';
		                 custrecord_customer='"'+custrecord_customer+'"';
		                 contents += custrecord_rebate_source_item  +','+ custrecord_invoice_number + ','  + custrecord_customer +
		                 			',' +custrecord_rebate_source_rate +','+ custrecord_rebate_source_qty +
		                 			','+ custrecord_units +','+ custrecord_rebateamount +'\n';
					}
				}
				var amountremainingtotalbox = record.getFieldValue('amountremainingtotalbox');
				contents=contents+''+','+''+','+''+','+''+','+''+','+''+','+amountremainingtotalbox;
				var file = nlapiCreateFile(tranid+'.csv', 'CSV', contents);
				file.setFolder(81577);
				var i_file_id = nlapiSubmitFile(file);
				nlapiLogExecution('debug','i_file_id',i_file_id);
				//var form = nlapiCreateForm( 'Rebate Source CSV' );
				nlapiSetRedirectURL('EXTERNAL', 'https://3497583.app.netsuite.com/app/common/media/mediaitemfolders.nl?whence=');
				
				/*If search have values then add to template 
				if(customrecord_rebate_source_invoiceSearch){
				renderer.addSearchResults('rebateresults',customrecord_rebate_source_invoiceSearch);
				}*/
				/*var xml = renderer.renderToString();
				//convert xml to PDF
				var PDFfile = nlapiXMLToPDF(xml);
				nlapiLogExecution('debug','PDFfile',PDFfile);
				response.setContentType('PDF','PRINT.pdf','INLINE');
				 response.write(PDFfile.getValue());*/
				 

		}
		catch(e)
		{
			nlapiLogExecution('debug','Error',e.toString());
		}
	}
	else{
		try{
			//load the invoice record
			var record = nlapiLoadRecord('invoice', internalid);
			var renderer = nlapiCreateTemplateRenderer();
			//load the template file --  invoicePDF.html
			var getFile = nlapiLoadFile('120060');
			var file = getFile.getValue();
			renderer.setTemplate(file);
			renderer.addRecord('record', record);
			var xml = renderer.renderToString();
			//nlapiLogExecution('debug','xml',xml);
			// convert xml to PDF
			var PDFfile = nlapiXMLToPDF(xml);
			nlapiLogExecution('debug','PDFfile',PDFfile);
			response.setContentType('PDF','PRINT.pdf','INLINE');
			 response.write(PDFfile.getValue());
			 

	}
	catch(e)
	{
		nlapiLogExecution('debug','Error',e.toString());
	}
	}
	
}