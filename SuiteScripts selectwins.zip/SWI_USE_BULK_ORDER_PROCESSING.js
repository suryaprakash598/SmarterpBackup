 function beforeLoadAddButton(type, from) {
 	if (type == 'view') {
 		var i_status = nlapiGetFieldValue('custrecord_swi_bop_status');
 		if (i_status == 1) {
 			var i_file_id = nlapiGetFieldValue('custrecord_swi_bop_file')
 			var s_suit_url = nlapiResolveURL('SUITELET', 'customscript_swi_sut_bulk_order_processi', 'customdeploy1');
 			var s_final_url = "window.location.href= '" + s_suit_url + "&fileid=" + i_file_id + "&recid=" + nlapiGetRecordId() + "'";
 			form.addButton('custpage_process_bulk_order', "Start Bulk Order Process", s_final_url);
 		} /*else if (i_status == 5) {
 			var i_file_id = nlapiGetFieldValue('custrecord_swi_bop_file')
 			var s_suit_url = nlapiResolveURL('SUITELET', 'customscript_swi_sut_bulk_order_processi', 'customdeploy1');
 			var s_final_url = "window.location.href= '" + s_suit_url + "&operation=delete&recid=" + nlapiGetRecordId() + "'";
 			form.addButton('custpage_process_bulk_order', "Delete Processed Transactions", s_final_url);
 		}*/
 	}
 }

 function beforeSubmit(type) {
 	if (type == 'create') {
 		nlapiSetFieldValue('custrecord_swi_bop_status', 1)
 	}
 }