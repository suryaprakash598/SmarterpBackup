function lineInit()
{
	debugger;
}
function lineValidate()
{
	debugger;
}
function lineInsert()
{
	debugger;
}
 
function recalc(variable,var2)
{
	debugger;
	
		var count = nlapiGetLineItemCount('item');
		for(var i=0;i<count;i++){
			var select = nlapiGetLineItemValue('item','custcol_swi_sel_item',(i+1));
			var ApplyDiscount = nlapiGetFieldValue('custbody_swi_apply_discount');
			var rate = nlapiGetLineItemValue('item','rate',(i+1));
			if(select=='F' && ApplyDiscount == 'F')
			{
				nlapiSetLineItemValue('item','custcol_swi_caseprice',(i+1),rate);
			}
		}
		  
	return true;
}
function fieldchange()
{
	debugger;
}
function postsource(type,name)
{
	debugger;
}