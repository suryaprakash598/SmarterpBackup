function beforeLoad_addButton(type, form, request) {
	var recordId = nlapiGetRecordId();
	var recordType = nlapiGetRecordType();
	nlapiLogExecution('debug','recordType',recordType);
	if(recordId)
	{
		form.setScript('customscript432');
		if(recordType=='vendorreturnauthorization')
		{
			form.addButton('custpage_printbutton', 'Print', 'printPDF('+recordId+')' );
		}else if(recordType=='itemreceipt')
		{
			form.addButton('custpage_printbutton', 'Print', 'printVCPDF('+recordId+')' );
		}
	}
  }