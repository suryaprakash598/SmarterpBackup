//Open Pop Up
function validate()
{
	var customer_value = nlapiGetFieldValue('entity'); 
	if(!customer_value)
	{
		alert('Please select the customer first');
		return false;
	}
	else
	{ 
		var url = nlapiResolveURL('SUITELET', 'customscript_display_page', 'customdeploy_display_page');
		window.open(url+'&customer='+customer_value, 'Frequent Items', 'height=600,width=1200,status=no,toolbar=no,menubar=no,location=no,dialog=YES,modal=YES');
	}		
	return true;
}


function pageinit()
{
	return true;
}
