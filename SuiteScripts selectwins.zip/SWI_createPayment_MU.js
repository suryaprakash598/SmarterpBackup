function createPayment(rec_type,rec_id){
 	var payment = nlapiTransformRecord(rec_type,rec_id,'customerpayment');
 	var payment_id = nlapiSubmitRecord(payment,true);
 	nlapiLogExecution('DEBUG','Payment Id',payment_id);
	//one can modify the script according to the requirement
}