var i_total_so_records = 0;
var i_total_item_records = 0;
var i_toal_qty = 0;
var ItemTotalQty = 0;
var inventory_RECID = '03';
var inventory_DISTGLN = '0000000000000'
var inventory_ISVID = '0188'
var inventory_FILEVER = '030'
var distributor_srs = 'i54228';

function VIPReportInveTransaction() {
    var s_file_current_number = nlapiLookupField('customrecord_swi_vip_file_naming', 3, 'custrecord_swi_vip_current_number');
    s_file_current_number = parseInt(s_file_current_number) + 1;
    s_file_current_number = addPrefixZero(3, s_file_current_number);
    var s_file_data = '';
    var a_filter = [];
    var a_column = [];
    a_filter.push(new nlobjSearchFilter('custentity_swi_vip_supplier_id', null, 'isnotempty'))
    a_filter.push(new nlobjSearchFilter('custentity_swi_vip_distributor_id', null, 'isnotempty'))
    a_column.push(new nlobjSearchColumn('custentity_swi_vip_supplier_id'))
    a_column.push(new nlobjSearchColumn('custentity_swi_vip_distributor_id'))
    var o_vendor_search = nlapiSearchRecord('vendor', null, a_filter, a_column);
    if (isNotNull(o_vendor_search)) {
        for (var v = 0; v < o_vendor_search.length; v++) {
            i_toal_qty = 0;
            reScheduleScript();
            var vendor_SUPPID = o_vendor_search[v].getValue('custentity_swi_vip_supplier_id');
            var vendor_DISTID = o_vendor_search[v].getValue('custentity_swi_vip_distributor_id');
            var s_inventory_dataObj = generateInventoryData(o_vendor_search[v].getId(), vendor_SUPPID, vendor_DISTID);
            var itemData = generateItemData(o_vendor_search[v].getId(), vendor_SUPPID, vendor_DISTID);
            s_inventory_data = s_inventory_dataObj.search_inventory_data;

            var invenData = s_inventory_dataObj.invenData;
            var groupedInvenData = _.groupBy(invenData, 's_trantype');
            if (!isNotNull(s_inventory_data)) {
                i_total_so_records = '0000000';
                i_toal_qty = '00000000000000'
            }
            var s_footer_data = '97';
            i_toal_qty = Number(i_toal_qty) + Number(ItemTotalQty);

            i_total_so_records = Number(i_total_so_records) + Number(i_total_item_records);
            s_footer_data = s_footer_data +
                vendor_SUPPID +
                addSpeace(8, vendor_DISTID) +
                inventory_DISTGLN +
                inventory_ISVID + '030' +
                addPrefixZero(7, i_total_so_records) +
                addPrefixZero(14, i_toal_qty);

            if (isNotNull(s_inventory_data)) {

                s_file_data = s_file_data +
                    inventory_RECID +
                    vendor_SUPPID +
                    addSpeace(8, vendor_DISTID) +
                    inventory_DISTGLN +
                    inventory_ISVID +
                    getDate() +
                    inventory_FILEVER +
                    getTimeDate() + '\n';
                var keys = Object.keys(groupedInvenData);
                for (var m = 0; m < keys.length; m++) {
                    if (keys[m] == 'ItemRcpt') {
                        var data = groupedInvenData[keys[m]];
                        data = _.filter(data, 'i_temp_qty');
                        for (var n = 0; n < data.length; n++) {
                            s_file_data = s_file_data + data[n]["tempData"] + '\n';
                        }
                    }

                }
                for (var mm = 0; mm < keys.length; mm++) {
                    if (keys[mm] == 'InvAdjst') {
                        var data = groupedInvenData[keys[mm]];
                        for (var nn = 0; nn < data.length; nn++) {
                            s_file_data = s_file_data + data[nn]["tempData"] + '\n';
                        }
                    }

                }
                if (itemData.length > 0) {
                    for (var it = 0; it < itemData.length; it++) {
                        s_file_data = s_file_data + itemData[it]["dataString"] + '\n';
                    }
                }
                //s_file_data = s_file_data +s_inventory_data + '\n' ;
                s_file_data = s_file_data + s_footer_data + '\n';

            } else {

                s_file_data = s_file_data +
                    inventory_RECID +
                    vendor_SUPPID +
                    addSpeace(8, vendor_DISTID) +
                    inventory_DISTGLN +
                    inventory_ISVID +
                    getDate() +
                    inventory_FILEVER +
                    getTimeDate() + '\n';
                if (itemData.length > 0) {
                    for (var it = 0; it < itemData.length; it++) {
                        s_file_data = s_file_data + itemData[it]["dataString"] + '\n';
                    }
                }
                s_file_data = s_file_data + s_footer_data + '\n';
            }
            reScheduleScript();

        }
    }

    var o_file = nlapiCreateFile(distributor_srs + s_file_current_number + '.INV', 'PLAINTEXT', s_file_data);
    o_file.setFolder(1138);
    var i_file_id = nlapiSubmitFile(o_file);
    if (s_file_current_number == 1000)
        nlapiSubmitField('customrecord_swi_vip_file_naming', 3, 'custrecord_swi_vip_current_number', 0);
    else
        nlapiSubmitField('customrecord_swi_vip_file_naming', 3, 'custrecord_swi_vip_current_number', s_file_current_number);

    sendEmail(i_file_id);
    /*response.setContentType('PLAINTEXT', 'Retail Outlet File.txt');
    response.write(o_file.getValue());*/

}

function generateItemData(vendorid, vendor_SUPPID, vendor_DISTID) {
    var a_filter = [
        ["custitem_swi_tw_bulkorder_item", "is", "F"],
        "AND",
        ["type", "anyof", "InvtPart"],
        "AND",
        ["vendor.custentity_swi_vip_reg", "is", "T"],
        "AND",
        ["othervendor", "anyof", vendorid]
    ];
    var a_column = [
        new nlobjSearchColumn("displayname", null, "GROUP"),
        new nlobjSearchColumn("itemid", null, "GROUP").setSort(false),
        new nlobjSearchColumn("quantityonhand", null, "SUM"),
        //new nlobjSearchColumn("quantityonhandbase",null,"SUM"),
        new nlobjSearchColumn("unitstype", null, "GROUP"),
        new nlobjSearchColumn("class", null, "GROUP"),
        new nlobjSearchColumn("othervendor", null, "GROUP"),
        new nlobjSearchColumn("isinactive", null, "GROUP"),
        new nlobjSearchColumn("formulanumeric", null, "MAX").setFormula("TO_NUMBER({totalquantityonhand})*TO_NUMBER({custitem_swi_btpc})")
    ];

    var inventoryitemSearch = getAllResult(a_filter, a_column, 'inventoryitem')
    var itemData = [];
    ItemTotalQty = 0;
    if (isNotNull(inventoryitemSearch)) {
        i_total_item_records = inventoryitemSearch.length;
        for (var c = 0; c < inventoryitemSearch.length; c++) {
            var s_tempData = '';
            var obj = {};
            //var qtyOnHand = inventoryitemSearch[c].getValue('quantityonhand', null, "SUM");
            var disName = inventoryitemSearch[c].getValue('displayname', null, "GROUP");
            var itemId = inventoryitemSearch[c].getValue('itemid', null, "GROUP");
            var INDATE = getDate();
            var INUOM = inventoryitemSearch[c].getText('unitstype', null, "GROUP");
            var CLASS = inventoryitemSearch[c].getText('class', null, "GROUP");
            var qtyOnHand = inventoryitemSearch[c].getValue('formulanumeric', null, "MAX") || 0;
            qtyOnHand = Math.abs(Math.ceil(qtyOnHand));
            var qtyOnHandToAdd = qtyOnHand; //TO ADD WITH ItemTotalQty
            if (!isNotNull(qtyOnHand)) {
                qtyOnHand = '0000000000'
            }

            var date = new Date();
            var i_tran_last_day = date.getDate();
            var i_last_day = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
            var b_is_last_date = '';
            if (i_tran_last_day == i_last_day)
                b_is_last_date = 'Y';
            else
                b_is_last_date = 'N';

            INUOM = INUOM.toString();
            /* if (INUOM.search('CS') > 0)
            INUOM = 'C'
            else if (INUOM.search('Bottle') >= 0)
            INUOM = 'B'
            else
            INUOM = ' ' */
            if (CLASS != 'Package Beer' && CLASS != 'Keg Beer') {
                INUOM = 'B'
            } else {
                INUOM = 'C'
            }
            var INEOM = b_is_last_date;
            var i_is_active = inventoryitemSearch[c].getValue("isinactive", null, "GROUP");
            if (i_is_active == 'F')
                INITMSTS = 'A'
            else
                INITMSTS = 'N';
            var INEND = 'X';
            s_tempData = '22' +
                vendor_SUPPID +
                addSpeace(8, vendor_DISTID) +
                '0000000000000' +
                '          ' +
                10 +
                INDATE +
                addPrefixZero(10, qtyOnHand) +
                INUOM +
                INEOM +
                addSpeace(10, '') +
                addSpeace(35, '') +
                '  ' + //INDISTST +

                // addSpeace(10, disName) +
                addPrefixZero(6, disName) +
                '    ' +
                INITMSTS +
                ' ' + //INREPACK +
                INEND;
            // ItemTotalQty =ItemTotalQty+qtyOnHand;
            ItemTotalQty = ItemTotalQty + qtyOnHandToAdd;
            obj.qtyOnHand = qtyOnHand;
            obj.disName = disName;
            obj.itemId = itemId;
            obj.vendorid = vendorid;
            obj.dataString = s_tempData;
            obj.ItemTotalQty = ItemTotalQty;
            itemData.push(obj);
        }
    } else {
        ItemTotalQty = 0;
        i_total_item_records = 0;

    }
    return itemData;
}

function generateInventoryData(vendorid, vendor_SUPPID, vendor_DISTID) {
    var search_inventory_data = '';
    var invenData = [];
    var a_filter = [
        ["type", "anyof", "ItemRcpt", "InvAdjst"], //"ItemShip",
        "AND", ["mainline", "is", "F"],
        "AND", ["item.custitem_swi_tw_bulkorder_item", "is", "F"],
        // "AND", ["lastmodifieddate", "within", "thismonthtodate"],
        "AND", ["datecreated", "within", "thismonthtodate"], // 10/21/2020 : changing lastmodifieddate to datecreated by surya
        "AND", ["cogs", "is", "F"],
        "AND", ["taxline", "is", "F"],
        "AND", ["shipping", "is", "F"],
        "AND", ["item.othervendor", "anyof", vendorid],
        "AND", ["unit", "noneof", "@NONE@"]
    ]

    var a_column = [
        new nlobjSearchColumn("externalid", "item", "GROUP"),
        new nlobjSearchColumn("type", null, "GROUP"),
        new nlobjSearchColumn("trandate", null, "GROUP"),
        new nlobjSearchColumn("shiprecvstatusline", null, "GROUP"),
        new nlobjSearchColumn("unit", null, "GROUP"),
        new nlobjSearchColumn("internalid", "createdFrom", "GROUP"),
        new nlobjSearchColumn("entity", null, "GROUP"),
        new nlobjSearchColumn("shipstate", null, "GROUP"),
        new nlobjSearchColumn("billstate", null, "GROUP"),
        new nlobjSearchColumn("transactionnumber", "createdFrom", "GROUP"),
        new nlobjSearchColumn("tranid", "createdFrom", "GROUP"),
        new nlobjSearchColumn("tranid", null, "GROUP"),
        new nlobjSearchColumn("entity", "createdFrom", "GROUP"),
        new nlobjSearchColumn("isinactive", "item", "GROUP"),
        new nlobjSearchColumn("quantityshiprecv", null, "GROUP"),
        new nlobjSearchColumn("formulanumeric", null, "GROUP").setFormula("{quantity}/12"),
        new nlobjSearchColumn("quantity", null, "MIN"),
        new nlobjSearchColumn("totalquantityonhand", "item", "MAX"),
        new nlobjSearchColumn("item", null, "GROUP")
    ]

    var o_tran_inv_search = getAllResult(a_filter, a_column, 'transaction')
    if (isNotNull(o_tran_inv_search)) {
        var tempRecordsTotal = 0;
        var i_temp_qty = 0;
        for (var c = 0; c < o_tran_inv_search.length; c++) {
            var invenDataObj = {};
            var tempData = '';
            if (isNotNull(o_tran_inv_search[c].getValue('quantity', null, "MIN"))) {
                //ITEM RECEIPT / SHIPPED QTY/ADJUST
                /* i_temp_qty = parseFloat(o_tran_inv_search[c].getValue('quantity', null, "MIN")) + parseFloat(i_temp_qty)
                i_temp_qty =Math.abs(i_temp_qty);
                invenDataObj.i_temp_qty = i_temp_qty||0; */
            }
            reScheduleScript()
            var INITMSTS = null;
            var INITEM = '          ';
            var INTRANS = '' // Temporary value
            var INDATE = convertTrandateToFomrat(o_tran_inv_search[c].getValue('trandate', null, "GROUP"));
            var b_is_last_date = islastDay(o_tran_inv_search[c].getValue('trandate', null, "GROUP"));
            var INQTY = 0; // changed from '' to 0
            var INUOM = o_tran_inv_search[c].getText('unit', null, "GROUP");
            INUOM = INUOM.toString();

            var i_is_active = o_tran_inv_search[c].getValue("isinactive", "item", "GROUP");
            if (i_is_active == 'F')
                INITMSTS = 'A'
            else
                INITMSTS = 'N';

            if (INUOM.search('CS') > 0)
                INUOM = 'C'
            else if (INUOM.search('Bottle') >= 0)
                INUOM = 'B'
            else
                INUOM = ' '
            var INEOM = b_is_last_date
            var s_trantype = o_tran_inv_search[c].getValue('type', null, "GROUP");
            var INPOID = '';
            var INDISTNAME = ''
            var INDISTST = ''
            if (s_trantype == 'ItemRcpt') {
                INPOID = o_tran_inv_search[c].getValue("tranid", "createdFrom", "GROUP");
                INQTY = Math.abs(o_tran_inv_search[c].getValue('quantity', null, "MIN")) || 0;
                INDISTST = '  ';
                INTRANS = '20';
                invenDataObj.s_trantype = s_trantype;
                tempRecordsTotal = tempRecordsTotal + 1;

            } else if (s_trantype == 'ItemShip') {
                INDISTNAME = o_tran_inv_search[c].getText("entity", "createdFrom", "GROUP");
                INQTY = o_tran_inv_search[c].getValue('quantity', null, "MIN");
                INDISTST = o_tran_inv_search[c].getValue("shipstate", null, "GROUP");
                INTRANS = '99'; //30
                invenDataObj.s_trantype = s_trantype;
            } else if (s_trantype == 'InvAdjst') {
                INPOID = o_tran_inv_search[c].getValue("tranid", null, "GROUP");
                INQTY = o_tran_inv_search[c].getValue('quantity', null, "MIN");
                INQTY = Math.abs(INQTY);
                INDISTST = '  ';
                INTRANS = '99'; //40
                invenDataObj.s_trantype = s_trantype;
                tempRecordsTotal = tempRecordsTotal + 1;
            }

            /* if (b_is_last_date == 'Y') {
            INTRANS = '10';
            INQTY = o_tran_inv_search[c].getValue('quantity', null, "MIN");
            }
            var ItemOnHandQty = o_tran_inv_search[c].getValue('totalquantityonhand', null, "MAX");
             */
            if (!isNotNull(INQTY)) {
                INQTY = '0000000000'
            }
            var isDecimal = INQTY.toString().indexOf('.');
            if (isDecimal != -1) {
                nlapiLogExecution('debug', 'isDecimal' + isDecimal, INQTY);

                var INUOM = o_tran_inv_search[c].getText('unit', null, "GROUP");
                INUOM = INUOM.toString();

                if (INUOM.search('CS') > 0) {
                    //var a_inqty = INQTY.toString().split('.');
                    var NUnit = INUOM.split('/')[0];
                    INQTY = (Number(INQTY) * Number(NUnit)); //converting  to bottles
                    INUOM = 'B';
                    i_temp_qty = Math.abs(parseFloat(INQTY)) + Math.abs(parseFloat(i_temp_qty))
                    i_temp_qty = Math.abs(INQTY);

                } else {
                    i_temp_qty = Math.abs(parseFloat(INQTY)) + Math.abs(parseFloat(i_temp_qty))
                    i_temp_qty = Math.abs(INQTY);
                }
                nlapiLogExecution('debug', 'INQTY:' + INQTY, 'i_temp_qty' + i_temp_qty);
            } else {
                i_temp_qty = Math.abs(parseFloat(o_tran_inv_search[c].getValue('quantity', null, "MIN"))) + Math.abs(parseFloat(i_temp_qty))
                i_temp_qty = Math.abs(i_temp_qty);

            }
            invenDataObj.i_temp_qty = i_temp_qty || 0;
            var DISTITEM = o_tran_inv_search[c].getValue("externalid", "item", "GROUP");
            var INREPACK = 'N';
            var INEND = 'X';
            tempData =
                '22' +
                vendor_SUPPID +
                addSpeace(8, vendor_DISTID) +
                '0000000000000' +
                INITEM +
                INTRANS +
                INDATE +
                addPrefixZero(10, INQTY) +
                INUOM +
                INEOM +
                addSpeace(10, INPOID) +
                addSpeace(35, INDISTNAME) +
                INDISTST +
                // addSpeace(10, DISTITEM) +
                addPrefixZero(6, DISTITEM) +
                '    ' +
                INITMSTS +
                INREPACK +
                INEND;

            search_inventory_data = search_inventory_data +
                '22' +
                vendor_SUPPID +
                addSpeace(8, vendor_DISTID) +
                '0000000000000' +
                INITEM +
                INTRANS +
                INDATE +
                addPrefixZero(10, INQTY) +
                INUOM +
                INEOM +
                addSpeace(10, INPOID) +
                addSpeace(35, INDISTNAME) +
                INDISTST +
                // addSpeace(10, DISTITEM) +
                addPrefixZero(6, DISTITEM) +
                '    ' +
                INITMSTS +
                INREPACK +
                INEND;
            invenDataObj.vendorid = vendorid;
            invenDataObj.tempData = tempData;
            invenData.push(invenDataObj);

            if (c != o_tran_inv_search.length - 1) {

                search_inventory_data = search_inventory_data + '\n'
            }
            reScheduleScript()

        }
        i_toal_qty = i_temp_qty;
        i_total_so_records = tempRecordsTotal //;o_tran_inv_search.length;

    } else {
        i_total_so_records = '0000000';
        i_toal_qty = '00000000000000'
    }
    var retobj = {};
    retobj.search_inventory_data = search_inventory_data;
    retobj.invenData = invenData;
    return retobj;
}

function convertTrandateToFomrat(a) {
    if (isNotNull(a)) {
        var o_date = nlapiStringToDate(a);
        return o_date.getFullYear() + twoDigits(o_date.getMonth() + 1) + twoDigits(o_date.getDate());
    } else
        return '        '
}

function islastDay(a) {
    var o_date = new Date();
    var o_tran_date = nlapiStringToDate(a);
    var i_tran_last_day = o_tran_date.getDate();

    var i_last_day = new Date(o_date.getFullYear(), o_date.getMonth() + 1, 0).getDate();

    if (i_tran_last_day == i_last_day)
        return 'Y';
    else
        return 'N';
}