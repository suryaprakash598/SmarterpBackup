var globaltype;

function pageInit(type) {
	itemsLineCount = nlapiGetLineItemCount('item');
	for (var line = 0; line <= itemsLineCount; line++) {
		nlapiSetLineItemValue('item', 'item', line, nlapiGetLineItemValue('item', 'item', line));
	}
}

function fieldChanged(type, name) {
	if (name == 'entity' ) {
		var entity = nlapiGetFieldValue('entity');
		/*if (entity != null) {
			var s_url = 'https://3497583.app.netsuite.com/app/accounting/transactions/salesord.nl?whence=&entity=' + entity;
			window.location.replace(s_url);
			return true;
		}*/
	}
	/*if (type == 'item' && name == 'quantity') {
		var i_item = nlapiGetCurrentLineItemValue('item', 'item');
		//alert('i_item' + i_item)
		var i_qty = nlapiGetCurrentLineItemValue('item', 'quantity');
		//alert('i_qty' + i_qty)
		if (isNotNull(i_item)) {
			var i_item_size = nlapiLookupField('inventoryitem', i_item, 'custitem_swi_size');
			//alert('i_item_size' + i_item_size)
			if (isNotNull(i_item_size)) {
				var i_new_qty = parseFloat(i_item_size) * parseFloat(i_qty);
				//alert('i_new_qty' + i_new_qty)
				i_new_qty = parseFloat(i_new_qty).toFixed(3)
				nlapiSetCurrentLineItemValue('item', 'custcol_swi_size', i_new_qty)
			}
		}
	}*/
	/*if (type == 'item' && name == 'item') {
		var i_item = nlapiGetCurrentLineItemValue('item', 'item');
		alert(i_item)
		nlapiSetCurrentLineItemValue('item', 'item', i_item);
	}*/
}

function postSourcinSetCasePrice(type, name) {
	debugger;
	if (type == 'item' && name == 'item') {
		var i_rate = nlapiGetCurrentLineItemValue('item', 'rate');
		//alert('i_rate' + i_rate)
		nlapiSetCurrentLineItemValue('item', 'custcol_swi_caseprice', i_rate)
	}
}

function isNotNull(value) {
	var returnObj = false;
	if (value != null && value != '' && value != 'null' && value != undefined && value != 'undefined' && value != '@NONE@') returnObj = true;
	return returnObj;
}

function pageInitLoadItem(type) {
	if (type == 'create') {
		var i_line_count = nlapiGetLineItemCount('item');
		alert('i_line_count==' + i_line_count)
		for (var i = 1; i <= i_line_count; i++) {
			var i_item = nlapiGetLineItemValue('item', 'item', i)
			alert('item==' + i_item)
			nlapiRemoveLineItem('item', i)
			nlapiInsertLineItem('item', i)
			nlapiSetLineItemValue('item', 'item', i, i_item)
		}
	}
}

function reCalcItem() {
	if (nlapiGetRecordType() == 'salesorder') {
		alert('fu callw')
		var currentLine = nlapiGetCurrentLineItemIndex('item');
		alert('currentLine' + currentLine)
		var cFlag = nlapiGetLineItemValue('item', 'custcol_item_flag', currentLine);
		alert('cFlag' + cFlag)

		if (cFlag == 'F') {
			var currentItem = nlapiGetLineItemValue('item', 'item', currentLine);
			var currentRate = nlapiGetLineItemValue('item', 'rate', currentLine);
			alert('currentItem' + currentItem)

			alert('currentRate' + currentRate)

			nlapiSetCurrentLineItemValue('item', 'item', currentItem, false, true);
			nlapiSetCurrentLineItemValue('item', 'rate', currentRate, false, true);
			nlapiSetCurrentLineItemValue('item', 'custcol_item_flag', 'T', false, true);
			nlapiCommitLineItem('item');
		}
	}
}

function postSourcing(type, name) {
	if (type == 'item' && name == 'item') {
		var i_item = nlapiGetCurrentLineItemValue('item', 'item');
		alert(i_item)
		nlapiSetCurrentLineItemValue('item', 'item', i_item);
	}
}

function pageInitHideField(type) {
	var field = nlapiGetLineItemField('item', 'options', 1).setDisplayType('hidden');
	var field = nlapiGetLineItemField('item', 'isclosed', 1).setDisplayType('hidden');
}

function pageInitSourceItem(type) {
	if (type == 'create') {
		var a_item_array = []
		if (nlapiGetRecordType() == 'salesorder') {
			alert('function called');
			var i_line_count = nlapiGetLineItemCount('item')
			for (var i = 1; i <= i_line_count; i++) {
				var i_item = nlapiGetLineItemValue('item', 'item', i);
				a_item_array.push(i_item)

			}
			alert('a_item_array' + a_item_array)

			for (var i = 1; i <= i_line_count; i++) {
				nlapiRemoveLineItem('item', i)
			}
			for (var i = 0; i < a_item_array.length; i++) {
				nlapiSelectNewLineItem('item');

				alert('seetin item' + a_item_array[i])
				nlapiSetCurrentLineItemValue('item', 'item', a_item_array[i])
				nlapiCommitLineItem('item');

			}
		}
	}
}