/*** Copyright @ 2020-2020 
 
** Description: This is HTMl Suitelet
** @libraries used:
** @client:	
** @author: 
** @dated: 	
** @version: 1.0
//******************************************************************************************/
function suitelet(request, response)
{
	try
	{	 
	var customerId = request.getParameter('customer');
	var fileContent = nlapiLoadFile(28170).getValue();
	var itemsArray  = nlapiLookupField('customer',customerId,'custentity_swi_freqbtitems',true);
		fileContent = fileContent+'<script>var fdata=['+JSON.stringify(itemsArray)+']</script>'
		
		response.write(fileContent);	
		
	}
		catch(e)
		{
			nlapiLogExecution('Debug', 'Errors', e);
		}
}

	