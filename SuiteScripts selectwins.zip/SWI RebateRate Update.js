/*******************************************************************************{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 *
 ******************************************************************************/

define(['N/runtime', 'N/record', 'N/search', 'N/log'], function (
        /** @type {import('N/runtime')} **/
        runtime,
        /** @type {import('N/record')}  **/
        record,
        /** @type {import('N/search')}  **/
        search,
        /** @type {import('N/log')}     **/
        log) {

    /**
     * context.newRecord
     * context.oldRecord
     * context.type
     *
     * @type {import('N/types').EntryPoints.UserEvent.afterSubmit}
     */
    function afterSubmit(context) {
        try {
			var items=[];var arr=[];
            var rec = context.newRecord; //create mode
			if(!rec){
				rec=context.oldRecord;
			}
            var rectype = rec.type;
            var recId = rec.id;
            var recObj = record.load({
                type: rectype,
                id: recId 
            });
          
          //excluding customers who has Supplier and VAWholesaler chain code and Select Wines employee
          var customer=recObj.getValue({fieldId:'entity'});
            
            var fields = search.lookupFields({
                type: 'customer',
                id: customer,
                columns: ['custentity_swi_chaincode']
            });
            var chaincode;
            var c_id;
            try{
                 chaincode = fields.custentity_swi_chaincode[0].value;
                
                
                }
                catch(e){
                	log.debug('customer chain is not there');
                	//return 'relatedvendor';
                }
                if(chaincode==70||chaincode==50||customer==2330){
                	log.debug('Customer chain code');
                	return false
                }
            var date=recObj.getValue({fieldId:'trandate'});
            date=new Date(date);
            log.debug(date);
			var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
			  for (var i = 0; i < lineCount; i++) {
				  var obj={};
				var item = recObj.getSublistValue({
				  sublistId: 'item',
				  fieldId: 'item',
				  line: i
				});
				var qty = recObj.getSublistValue({
				  sublistId: 'item',
				  fieldId: 'quantity',
				  line: i
				});
				var rate = recObj.getSublistValue({
				  sublistId: 'item',
				  fieldId: 'rate',
				  line: i
				});
				var units = recObj.getSublistText({
					  sublistId: 'item',
					  fieldId: 'units',
					  line: i
					});
				var units_display = recObj.getSublistText({
					  sublistId: 'item',
					  fieldId: 'units_display',
					  line: i
					});
                log.debug('units display',units_display);
				var bpc = recObj.getSublistText({
					  sublistId: 'item',
					  fieldId: 'custcol_swi_bottlepcs',
					  line: i
					});
				
				obj.item=item;
				obj.qty=qty;
				obj.rate=rate;
				obj.units=units;
				obj.bpc=bpc;
				obj.units_display=units_display;
				arr.push(obj);
				items.push(item);
			  }
			  log.debug('arr',arr);
			  var rebateDataObj = rebateRateSearch(items);
			  log.debug('rebateDataObj',rebateDataObj);
			  if(rebateDataObj.length>0)
			  {
				  for(var m=0;m<arr.length;m++)
				  {
					  
					  var dateselector={};
                    	dateselector.givendate=0;
                      
					  
					  for(var l=0;l<rebateDataObj.length;l++)
					  {
						  var item = arr[m].item;
						  var rate = arr[m].rate;
						  var qty = arr[m].qty;
						  var bpc = arr[m].bpc;
						  var units = arr[m].units;
						  var unitsCheck = units.split('/');
						  
						  var rebateItem = rebateDataObj[l].item;
						  var rebateItemRate = rebateDataObj[l].rate;
						  var rebateRate = rebateDataObj[l].rebaterate;
						  log.debug('rebate rate',rebateRate);
						  if(units=='BTL')
							  {
							  rebateRate=rebateRate/bpc;
							  log.debug('rebate rate for bottle',rebateRate);
							  rate=rate*bpc;
							  log.debug('rate for bottle',rate);
							 
							  }
						  /*if(unitsCheck[1]!='CS')
						  {
							  rebateRate=rebateRate/bpc
						  log.debug('bottle',rebateRate)
						  }*/
						  var startDate = rebateDataObj[l].startDate;
						  var rebateRateRange = rebateItemRate.split('-');
						  var startrange=rebateRateRange[0];
						  var endrange=rebateRateRange[1];
						  if(!endrange)
						  {
							  endrange=startrange; 
						  }
						  var GivenDate = startDate;
							var CurrentDate = new Date();
							GivenDate = new Date(GivenDate);
							
							
						  if(item==rebateItem && ((rate>=endrange) && (rate<=startrange))&&(GivenDate<=date)){
							  
                            if(dateselector.givendate==0)
								  {
                            	log.debug('GivenDate<date',GivenDate<date);
								  dateselector.rebaterate=rebateRate;
								  dateselector.rebateamount=rebateRate*qty;
								  dateselector.givendate=GivenDate;
								  log.debug('if condition',dateselector)
								  
								  }
							  else if((GivenDate<=date)&&(dateselector.givendate<=GivenDate))
								  {
								  log.debug('(dateselector.givendate<GivenDate)&&(GivenDate>date)',(dateselector.givendate<GivenDate)&&(GivenDate>date));
								  dateselector.rebaterate=rebateRate;
								  dateselector.rebateamount=rebateRate*qty;
								  dateselector.givendate=GivenDate;
								  log.debug('if else condition',dateselector)
								  }
							  
							  
							  
							 
						  }
						  
					  }
					  log.debug('dateselector',dateselector)
					  recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'custcol_ns_rebateperunit',
						  line: m,
						  value: dateselector.rebaterate
						});
					  log.debug(dateselector.rebaterate)
						recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'custcol_ns_rebateamount',
						  line: m,
						  value: dateselector.rebateamount
						});
					  log.debug(dateselector.rebateamount)
				  }
			  }
				 
              var id = recObj.save({
                enableSourcing: true,
                ignoreMandatoryFields: true
            }); 
            log.debug('Id', id);

        } catch (e) {
            log.debug('Error', e.toString());
        }
    }
    
    
       
    

    function rebateRateSearch(items) {
        try {
			  var rebateData = [];
            var customrecord_rebate_price_tableSearchObj = search.create({
                type: "customrecord_rebate_price_table",
                filters:
                [
                    ["custrecord4", "anyof", items]
                ],
                columns:
                [
                    search.createColumn({
                        name: "custrecord4",
                        sort: search.Sort.ASC,
                        label: "Rebate Link"
                    }),
                    search.createColumn({
                        name: "custrecord5",
                        label: "Level"
                    }),
                    search.createColumn({
                        name: "custrecord6",
                        label: "Rate"
                    }),
                    search.createColumn({
                        name: "custrecord7",
                        label: "Rebate"
                    }),
					search.createColumn({
                        name: "custrecord_start_date",
                        label: "Start Date"
                    })
                ]
            });
            var searchResultCount = customrecord_rebate_price_tableSearchObj.runPaged().count;
            customrecord_rebate_price_tableSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
				var obj = {};
				
                var item = result.getValue({
                    name: "custrecord4" 
                });
				var rate = result.getValue({
                    name: "custrecord6" 
                });
                var rebate = result.getValue({
                    name: "custrecord7" 
                });
				var startDate = result.getValue({
                    name: "custrecord_start_date" 
                });
				obj.item=item;
				obj.rate=rate;
				obj.rebaterate=rebate;
				obj.startDate=startDate;
				
				rebateData.push(obj);
                return true;
            });
			return rebateData;
        } catch (e) {
            log.debug('Error in rebateRateSearch', e.toString());
        }
    }

    return {
        'afterSubmit': afterSubmit
    };

});