var i_total_so_records = 0;
var i_toal_qty = 0;
var distributor_srs = 's54228';

function VIPReportSalesFile(request, response) {
	try {
		var s_file_current_number = nlapiLookupField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number');
		s_file_current_number = parseInt(s_file_current_number) + 1;
		s_file_current_number = threeDigits(s_file_current_number);
		var s_file_data = '';
		// var s_sales_data = generateSalesData();
		var s_sales_data = "";

		var a_filter = [];
		var a_column = [];
		a_filter.push(new nlobjSearchFilter('custentity_swi_vip_supplier_id', null, 'isnotempty'))
		a_filter.push(new nlobjSearchFilter('custentity_swi_vip_distributor_id', null, 'isnotempty'))
		a_column.push(new nlobjSearchColumn('custentity_swi_vip_supplier_id'))
		a_column.push(new nlobjSearchColumn('custentity_swi_vip_distributor_id'))
		a_column.push(new nlobjSearchColumn('internalid'))
		var o_vendor_search = nlapiSearchRecord('vendor', null, a_filter, a_column);
		if (isNotNull(o_vendor_search)) {
			//nlapiLogExecution('debug','o_vendor_search',o_vendor_search.length);
			for (var v = 0; v < o_vendor_search.length; v++) {
				reScheduleScript()

				var vendor_SUPPID = o_vendor_search[v].getValue('custentity_swi_vip_supplier_id');
				var vendor_DISTID = o_vendor_search[v].getValue('custentity_swi_vip_distributor_id');
				var vendor_internalid = o_vendor_search[v].getValue('internalid');
				var temp_s_sales_data = generateSalesData(vendor_internalid,vendor_DISTID); //s_sales_data;
				var s_footer_data = '98';
				//nlapiLogExecution('debug','i_total_so_records'+i_total_so_records,addPrefixZero(7, i_total_so_records));
				s_footer_data = s_footer_data +
					vendor_SUPPID +
					addSpeace(8, vendor_DISTID) +
					vendor_DISTGLN +
					vendor_ISVID + '051' +
					addPrefixZero(7, i_total_so_records) +
					addPrefixZero(11, i_toal_qty)

				var s_sales_start = '21' + vendor_SUPPID + addSpeace(8, vendor_DISTID)
				if (temp_s_sales_data != '') {
					temp_s_sales_data = temp_s_sales_data.replace(/1234567890/gi, s_sales_start)
					
					s_file_data = s_file_data +
						'02' +
						vendor_SUPPID +
						addSpeace(8, vendor_DISTID) +
						'0000000000000' + 
						'0188' +
						'051' + 
						sales_IPFLAG +
						getDate() +					 
						getTimeDate() + '\n' +
						temp_s_sales_data + '\n' +
						s_footer_data + '\n'
				}
				reScheduleScript()

			}
		}
		var o_file = nlapiCreateFile(distributor_srs + s_file_current_number + '.sls', 'PLAINTEXT', s_file_data);
		o_file.setFolder(1138);
		var i_file_id = nlapiSubmitFile(o_file);
		if (s_file_current_number == 1000)
			nlapiSubmitField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number', 0);
		else
			nlapiSubmitField('customrecord_swi_vip_file_naming', 2, 'custrecord_swi_vip_current_number', s_file_current_number);
	response.setContentType('PLAINTEXT', 'Retail Outlet File.txt');
	response.write(o_file.getValue());

	} catch (e) {
		nlapiLogExecution('error', 'error', e)

	}

}

function generateSalesData(vendorId,vendor_DISTID) {

	var s_sales_data = '';
	var a_filter = [];
	var a_column = [];
	a_filter.push(new nlobjSearchFilter('cogs', null, 'is', 'F'))
	a_filter.push(new nlobjSearchFilter('taxline', null, 'is', 'F'))
	a_filter.push(new nlobjSearchFilter('quantity', null, 'greaterthan', 0));
	a_filter.push(new nlobjSearchFilter('vendor', "item", 'anyof', vendorId));
	a_filter.push(new nlobjSearchFilter('type', "applyingtransaction", 'anyof', "CustInvc"));
	a_filter.push(new nlobjSearchFilter('status', "applyingtransaction", 'anyof', "CustInvc:B"));
	a_filter.push(new nlobjSearchFilter('lastmodifieddate', "applyingtransaction", 'within', "lastmonthtodate"));

	a_column.push(new nlobjSearchColumn("transactionnumber"))
	a_column.push(new nlobjSearchColumn("tranid"))
	a_column.push(new nlobjSearchColumn("trandate"));
	a_column.push(new nlobjSearchColumn("entityid", "customer", null))
	a_column.push(new nlobjSearchColumn("externalid", "item", null))
	a_column.push(new nlobjSearchColumn("quantity"))
	a_column.push(new nlobjSearchColumn("unit"))
	a_column.push(new nlobjSearchColumn("rate"))
	a_column.push(new nlobjSearchColumn("linesequencenumber"))
	a_column.push(new nlobjSearchColumn("tranid", "applyingTransaction", null))
	a_column.push(new nlobjSearchColumn("quantityuom", "applyingTransaction", null))
	a_column.push(new nlobjSearchColumn("formulanumeric").setFormula("({rate}*{quantity})/{applyingtransaction.quantityuom}"))
	var o_sales_order_search = getAllResult(a_filter, a_column, 'salesorder')
 
	if (isNotNull(o_sales_order_search)) {
		i_total_so_records = o_sales_order_search.length;
		for (var c = 0; c < o_sales_order_search.length; c++) {
			var entityid = o_sales_order_search[c].getValue('entityid');
			var invoice_date = o_sales_order_search[c].getValue('trandate');
			invoice_date = convertTrandateToFomrat(invoice_date)
				// var invoice_number = o_sales_order_search[c].getValue('tranid');
			var invoice_number = o_sales_order_search[c].getValue("tranid", "applyingTransaction");
			var customer_id = o_sales_order_search[c].getValue("entityid", "customer", null);
			var supplier_item_code = o_sales_order_search[c].getValue("externalid", "item", null);
			var quantity_base = o_sales_order_search[c].getValue('quantity');
			var quantity_delivered = o_sales_order_search[c].getValue("quantityuom", "applyingTransaction");
			i_toal_qty = i_toal_qty + parseFloat(quantity_delivered)
			var quantity_unit_of_measure = o_sales_order_search[c].getValue('unit');
			quantity_unit_of_measure = quantity_unit_of_measure.toString();
			//nlapiLogExecution('debug','quantity_unit_of_measure'+quantity_unit_of_measure.search('Bottle'),quantity_unit_of_measure);
			if (quantity_unit_of_measure.search('CS') > 0)
				quantity_unit_of_measure = 'C'
			else if (quantity_unit_of_measure.search('Bottle') >= 0)
				quantity_unit_of_measure = 'B'
			else
				quantity_unit_of_measure = ' '

			var Frontline_unit_price = o_sales_order_search[c].getValue('rate');
			var Frontline_formula = o_sales_order_search[c].getValue('formulanumeric');
			nlapiLogExecution('debug', 'Frontline_formula' + Frontline_unit_price, Frontline_formula);
			// TO SHOW RATE PER UNIT
			//Frontline_unit_price = (Frontline_unit_price*quantity_base)/quantity_delivered;
			var Net_unit_price = '';
			var Distributor_item_code = supplier_item_code; // coppied
			var Deposit_amount_per_unit = ''; // Not found
			var California_Redemption_Value = ''; // Not mandetory
			var Local_tax_per_unit = ''; // Not mandetory
			var Additional_charge_per_unit = ''; // Not mandetory
			var Distributor_Sales_Rep_ID = ''; // Not found
			var Repack_Flag = 'N'; // Not found
			var Depletion_Warehouse_ID = ''; // Not found
			var Extended_net_price = ''; // Not found
			var Transaction_Type = ''; // Not mandetory
			var Distributors_internal_discount_id = '               '; // Not mandetory
			var Distributors_internal_discount_Group_ID = '               '; // Not mandetory
			var Suppliers_originated_promotion_ID = '               ';
			var Extended_Distributor_amount = '         '; // Not mandetory
			var Extended_Supplier_amount = '         '; // Not mandetory
			var Split_Case_charge_per_unit = '    '; // Not mandetory

			var Combo_Flag = ' '; // Not mandetory
			var Free_Good_Flag = ' '; // Not mandetory
			var Duty_Free_Flag = ' '; // Not mandetory
			var Order_Date = '        '; // Not mandetory
			var Order_Quantity = '       '; // Not mandetory
			var Order_Unit_of_Measure = ' '; // Not mandetory

			var Invoice_Line = o_sales_order_search[c].getValue('linesequencenumber');

			var Reference_invoice = '                         '; // Not mandetory
			var Extended_Front_Line_Price = '0000000000000'; // Not found
			var Depletion_Period = '000000'; // Not found
			var End_of_record_flag = 'X'; // Not found

			Frontline_unit_price = Frontline_formula;
			Frontline_unit_price = Frontline_unit_price.toString();
			Frontline_unit_price = Frontline_unit_price.replace('.', '')
			if (!isNotNull(Frontline_unit_price))
				Frontline_unit_price = '000000000'
			Net_unit_price = Frontline_unit_price
			s_sales_data = s_sales_data + 
			'1234567890' +
				distributor_DISTGLN +
				addSpeace(8, invoice_date) +
				addSpeace(25, invoice_number) +
				addSpeace(15, customer_id) +
				addSpeace(10, supplier_item_code) +
				addPrefixZero(7, quantity_delivered) +
				quantity_unit_of_measure +
				addPrefixZero(9, Frontline_unit_price) +
				addPrefixZero(9, Net_unit_price) +
				addSpeace(10, Distributor_item_code) +
 
				'0000000' +
				'0000000' +
				'0000000' +
				'0000000' +
				'SRS99' + 
addSpeace(8, vendor_DISTID) +
				addPrefixZero(13, Extended_net_price) + 

				/*addSpeace(10, Distributor_Sales_Rep_ID) + 
				 addSpeace(10, Repack_Flag) + 
				addSpeace(10, Depletion_Warehouse_ID) +
				addSpeace(10, Extended_net_price) + 
				addSpeace(10, Transaction_Type) + 
				Distributors_internal_discount_id +
				Distributors_internal_discount_Group_ID + 
				Suppliers_originated_promotion_ID + 
				Extended_Distributor_amount + 
				Extended_Supplier_amount + 
				Split_Case_charge_per_unit +
				Combo_Flag + 
				Free_Good_Flag +
				Duty_Free_Flag +
				Order_Date + 
				Order_Quantity +
				Order_Unit_of_Measure + 
				addPrefixZero(6, Invoice_Line) +
				Reference_invoice + 
				Extended_Front_Line_Price +
				Depletion_Period +  */
				End_of_record_flag;

			if (c != o_sales_order_search.length - 1) {

				s_sales_data = s_sales_data + '\n'
			}
			reScheduleScript()

		}
	}
	//nlapiLogExecution('debug','s_sales_data',s_sales_data);
	return s_sales_data
}