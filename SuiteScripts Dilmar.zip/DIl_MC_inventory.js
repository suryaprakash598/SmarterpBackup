/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json

Owner			Date		Description
Surya			24/05/2021	Location is limited to 5 characters
Surya			24/05/2021	Removed decimals on Onhand qty and qty
Surya			14/09/2021	Changed Name of the file storing in filecabinet due to overriding the file daily
Surya			15/09/2021	Date created to Date in filter
Surya			22/09/2021	Changes the saved search from invoice to item(Made inventory file as individual not depends on invoices)
 */
define(['N/search', 'N/file', 'underscore', 'N/encode', 'N/record', 'N/email', 'SuiteScripts/SFTPConnectionEstablish'],

    function (search, file, underscore, encode, record, email, _SFTPObj) {

    //Load saved search
    function execute(scriptContext) {
        var connectionObj = _SFTPObj.executeSFTP();
        log.debug('connectionObj', connectionObj);

        var _mcInvHeader = savedSearchInventory();
        var textFile = '';
        for (var i = 0; i < _mcInvHeader.length; i++) {
            textFile += headerRecord(_mcInvHeader[i]);
        }
        // log.debug('textFile',textFile);
        var fileObj = file.create({
            name: 'inventory' + new Date(),
            fileType: file.Type.PLAINTEXT,
            contents: textFile,
            description: '',
            encoding: file.Encoding.UTF8,
            folder: 1250 //1086
        });

        //Save the CSV file
        var fileId = fileObj.save();
        var fileData = file.load({
            id: fileId
        });
        if (connectionObj) {
             connectionObj.upload({
            directory: '/',
            filename: 'inventory.txt',
            file: fileData,
            replaceExisting: false
            }); 
        }
    }
    function savedSearchInventory() {
        try {
            var arr = [];
            var itemSearchObj = search.create({
                type: "item",
                filters:
                [
                    ["custitem_dilmar_brand", "anyof", "52"],
                    "AND",
                    ["locationquantityonhand", "isnotempty", ""],
                    "AND",
                    ["formulanumeric: CASE WHEN (NVL({locationquantityonhand},0) + NVL({locationquantityonorder},0)) > 0 THEN 1 ELSE 0 END", "equalto", "1"]
                ],
                columns:
                [
                    search.createColumn({
                        name: "custrecord_5826_loc_branch_id",
                        join: "inventoryLocation",
                        summary: "GROUP",
                        label: "Branch ID"
                    }),
                    search.createColumn({
                        name: "itemid",
                        summary: "GROUP",
                        sort: search.Sort.ASC,
                        label: "Part Number"
                    }),
                    search.createColumn({
                        name: "formulanumeric1",
                        summary: "MAX",
                        formula: "NVL({locationquantityonhand},0)",
                        label: "Qty On Hand"
                    }),
                    search.createColumn({
                        name: "formulanumeric2",
                        summary: "SUM",
                        formula: "NVL(Case When ({transaction.type}='Purchase Order') and ({transaction.locationnohierarchy}={inventorylocation.namenohierarchy}) and ({transaction.quantity}-{transaction.quantityshiprecv})>0 and {transaction.status}!='Closed' then ({transaction.quantity}-{transaction.quantityshiprecv}) end,0)",
                        label: "Qty on PO"
                    })

                ]
            });
            var searchResultCount = itemSearchObj.runPaged().count;
            log.debug("itemSearchObj result count", searchResultCount);
            itemSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                var obj = {};

                obj.locationCode = result.getValue({
                    name: "custrecord_5826_loc_branch_id",
                    join: "inventoryLocation",
                    summary: "GROUP"
                });

                obj.partnumber = result.getValue({
                    name: "itemid",
                    summary: "GROUP"
                });
                obj.quantityOnHand = result.getValue({
                    name: "formulanumeric1",
                    summary: "MAX",
                    formula: "NVL({locationquantityonhand},0)"
                });
                obj.quantityOnOrder = result.getValue({
                    name: "formulanumeric2",
                    summary: "SUM",
                    formula: "NVL(Case When ({transaction.type}='Purchase Order') and ({transaction.locationnohierarchy}={inventorylocation.namenohierarchy}) and ({transaction.quantity}-{transaction.quantityshiprecv})>0 and {transaction.status}!='Closed' then ({transaction.quantity}-{transaction.quantityshiprecv}) end,0)"

                });

                arr.push(obj);
                return true;
            });
            return arr;
        } catch (e) {
            log.debug('Error in savedSearchList', e.toString());
        }
    }

    function headerRecord(data) {
        log.debug('_data', data);
        var tempString = '';
        var _data = Object.keys(data);
        if (_data.length) {
            //LocationID , PartNumber,VendorCode, QtyOnHand,QtyOnOrder
            var vendorcode = 'MOT';
            /* if(data.location){ */
            var locationName = data.locationCode;
            // locationName = locationName.match(/.{1,5}/g)[0]||'';
            tempString += locationName + "\t" +
            data.partnumber + "\t" +
            vendorcode + "\t" +
            (data.quantityOnHand | 0) + "\t" +
            (data.quantityOnOrder | 0) + "\r\n";
            // }
        }
        return tempString;
    }

    return {
        execute: execute
    };

});