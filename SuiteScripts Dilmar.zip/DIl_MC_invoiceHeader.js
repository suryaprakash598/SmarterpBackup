/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 
 Owner			Date		Description
 Surya			15/09/2021	Date created to Date in filter
 Surya			15/09/2021	Datecreated of createdfrom changed to date of createdfrom
 */
 define(['N/search', 'N/file', 'underscore','N/encode', 'N/record', 'N/email','SuiteScripts/SFTPConnectionEstablish'],

 function (search, file, underscore, encode, record, email,_SFTPObj) {

 //Load saved search
 function execute(scriptContext) {
     var _mcInvHeader = savedSearchInvoiceHeader();
      log.debug('_mcInvHeader',_mcInvHeader);
      //log.debug('_mcInvHeader.len',_mcInvHeader.length);
	  var textFile = '';
     for(var i=0;i<_mcInvHeader.length;i++)
	 {
		textFile+= headerRecord(_mcInvHeader[i]);
	 }
	// log.debug('textFile',textFile);
	 var fileObj = file.create({
                 name: 'invoiceHeader'+new Date(),
                 fileType: file.Type.PLAINTEXT,
                 contents: textFile,
                 description: '',
                 encoding: file.Encoding.UTF8,
                 folder: 1250//1086
             });
		
             //Save the CSV file
             var fileId = fileObj.save()
			 
			 var fileData = file.load({id:fileId});
			 var connectionObj =  _SFTPObj.executeSFTP();
			log.debug('connectionObj',connectionObj);
			 if(connectionObj)
			 {
				 try{
					 connectionObj.upload({
					directory: '/',
					filename: 'InvoiceHeader.txt',
					file: fileData,
					replaceExisting: false
					}); 
				 }catch(e)
				 {
					 log.debug('error in upload',e.toString())
				 }
			 }
 }
 function savedSearchInvoiceHeader() {
     try {
         var arr = [];
         var invoiceSearchObj = search.create({
		   type: "invoice",
		   filters:
		   [
			  ["type","anyof","CustInvc"], 
			   "AND", 
				 ["trandate","within","thismonth"], 
				//["trandate","within","6/01/2021","9/17/2021"], 				
				"AND", 
				["item.custitem_dilmar_brand","anyof","52"], 
			  "AND", 
			  ["mainline","is","F"], 
			  "AND", 
			  ["taxline","is","F"], 
			  "AND", 
			  ["shipping","is","F"], 
			  "AND", 
			  ["cogs","is","F"], 
				"AND", 
			["customer.isdefaultshipping","is","T"]
		   ],
		   columns:
		   [
			   search.createColumn({
					 name: "tranid",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "location",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "custrecord_5826_loc_branch_id",
					 join: "location",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "trandate",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "custbody_bizspeed_ship_date",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "taxamount",
					 summary: "AVG"
				  }),
				  search.createColumn({
					 name: "discountamount",
					 summary: "AVG"
				  }),
				  search.createColumn({
					 name: "shipaddress",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "billaddress",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "internalid",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "entity",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "trandate",
					 join: "createdFrom",
					 summary: "GROUP"
				  }),
				  search.createColumn({
					 name: "accountnumber",
					 join: "customer",
					 summary: "GROUP"
				  }),
				   search.createColumn({
				 name: "internalid",
				 join: "shippingAddress",
				 summary: "GROUP" 
			  }), search.createColumn({
				 name: "internalid",
				 join: "billingAddress",
				 summary: "GROUP" 
			  }),
			  search.createColumn({
         name: "formulanumeric",
         summary: "GROUP",
         formula: "NVL({shippingaddress.internalid}, {customer.addressinternalid})",
         label: "Formula (Numeric)"
      })
		   ]
		});
		var searchResultCount = invoiceSearchObj.runPaged().count;
		//log.debug("invoiceSearchObj result count",searchResultCount);
 
         invoiceSearchObj.run().each(function(result){
            // .run().each has a limit of 4,000 results
            var obj ={};
            obj.location = result.getText({name:'location',summary: "GROUP"});
            obj.locationCode = result.getValue({  name: "custrecord_5826_loc_branch_id",  join: "location",  summary: "GROUP" });
            obj.docNumber = result.getValue({name:'tranid',summary: "GROUP"});
            obj.traninternalid = result.getValue({name:'internalid',summary: "GROUP"});
            obj.trandate = result.getValue({name:'trandate',summary: "GROUP"});
            obj.bizShipDate = result.getValue({name:'custbody_bizspeed_ship_date',summary: "GROUP"});
            obj.taxamount = result.getValue({name:'taxamount',summary: "AVG"});
            obj.discountamount = result.getValue({name:'discountamount',summary: "AVG"});
            obj.shipaddress = result.getValue({name:'shipaddress',summary: "GROUP"});
            obj.billaddress = result.getValue({name:'billaddress',summary: "GROUP"});
            obj.entity = result.getValue({name:'entity',summary: "GROUP"});
			obj.customerAc = result.getValue({name: "accountnumber",join: "customer",summary: "GROUP"});
			obj.orderDate = result.getValue({name: "trandate",join: "createdFrom",summary: "GROUP"});
			obj._billingAddress = result.getValue({name: "internalid",join: "billingAddress",summary: "GROUP"});
			// obj._shippingAddress = result.getValue({name: "internalid",join: "shippingAddress",summary: "GROUP"});
			obj._shippingAddress = result.getValue({
				 name: "formulanumeric",
				 summary: "GROUP",
				 formula: "NVL({shippingaddress.internalid}, {customer.addressinternalid})" 
			  });
            arr.push(obj);
            return true;
         });
         return arr;
     } catch (e) {
         log.debug('Error in savedSearchList', e.toString());
     }
 }
  
 function headerRecord(data) {
	 log.debug('_data',data);
     var tempString = '';
	var _data =  Object.keys(data);
	 var time = '000000';
     if (_data.length) {
		 //LocationID , InvoiceNumber,InvoiceDate,OrderDate,OrderTime,DeliveryDate,DeliveryTime,
		 //OrderType,SalesTaxOnInvoice,DiscountAmountOnInvoice,MiscChargesOnInvoice,BillToCustomerID,ShipToCustomerID
		var shipdate ='';
		var orderDate ='';
		var OrderType='M';
		if(data.bizShipDate)
		{
			shipdate= data.bizShipDate.split(' ')[0];
			log.debug('shipdate',shipdate);
			shipdate = formatDate(shipdate);
		}if(data.orderDate)
		{
			orderDate= data.orderDate.split(' ')[0];
			orderDate = formatDate(orderDate);
			//log.debug('orderDate',orderDate);
		}if(data.trandate)
		{
			trandate= data.trandate.split(' ')[0];
			trandate = formatDate(trandate);
			//log.debug('trandate',trandate);
		}
		if(data.locationCode)
		{
			var locationName = data.locationCode;
		  //locationName = locationName.match(/.{1,5}/g)[0]||'';
         tempString +=  locationName + "\t" +
						data.docNumber + "\t" +
						trandate+ "\t" +
						orderDate + "\t" +
						time + "\t" +
						shipdate + "\t" +
						time + "\t"+
						OrderType + "\t"+
						0 + "\t"+
						0 + "\t" +
						0 + "\t" +
						data._billingAddress + "\t" +
						data._shippingAddress + "\r\n";
		}
     }
     return tempString;
 }
 function formatDate(date) {
	 if(date)
	 {
		 var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

		if (month.length < 2) 
			month = '0' + month;
		if (day.length < 2) 
			day = '0' + day;

		return [year, month, day].join('');
	 }else{
		 return '        ';
	 }
    
}
 
  function units() {
     var obj = {
         'Bulk': 'GAL',
         '1 Gal': 'GAL',
         'Carton': 'CT',
         'Case': 'CT',
         'Drum': 'EA',
         'Each': 'EA',
         'Ecobox': 'CT',
         'Keg': 'EA',
         'Pail': 'EA',
         'Tote': 'EA'
     };
     return obj;
 }
 
 return {
     execute: execute
 };

});