/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/email'],
/**
 * @param {record} record
 */
function(record,email) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
    	
    	
    	
    	

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
    	
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {
		 var recObj = scriptContext.newRecord; 
         var transferorder_id=recObj.getValue({fieldId:'createdfrom'});
		 var transferorder_text=recObj.getText({fieldId:'createdfrom'});//Transfer Order #TO473
		transferorder_text=JSON.stringify(transferorder_text);
          
  if((transferorder_text.indexOf("Transfer Order")==-1))
  {
    return true;
  }
		if(transferorder_id){
		 transferorder = record.load({
                    type: 'transferorder',
                    id: transferorder_id,
                    isDynamic: false,
                });
    	for (var i = 0; i < transferorder.getLineCount({sublistId: 'item'}); i++) {
			var item = transferorder.getSublistValue({
				sublistId: 'item',
				fieldId: 'item',
				line:i
				});			
              	var quantity = transferorder.getSublistValue({
				sublistId: 'item',
				fieldId: 'quantity',
				line:i
				});
				var quantityfullfilled = transferorder.getSublistValue({
				sublistId: 'item',
				fieldId: 'quantityfulfilled',
				line:i
				});
				var quantityreceived = transferorder.getSublistValue({
				sublistId: 'item',
				fieldId: 'quantityreceived',
				line:i
				});
				
				
              if(quantityreceived==quantityfullfilled){
			transferorder.setSublistValue({
			sublistId: 'item',
			fieldId: 'isclosed',
			line: i,
			value: true
			});
			}
			
	}
	transferorder.save({ ignoreMandatoryFields: true });
		}
}
    return {
       // beforeLoad: beforeLoad,
       // beforeSubmit: beforeSubmit,
      afterSubmit: afterSubmit
    };
    
});
