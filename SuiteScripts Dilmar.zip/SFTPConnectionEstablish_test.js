	/**
	 * @NApiVersion 2.0
	 * @NScriptType ScheduledScript
	 */
	define(['N/sftp','N/error','N/file'],
		function (sftp,error,file) {
		function execute(context) { 
			var connection;
			
				//Estblish a connection between NS and SFTP
			var myPwdGuid = "58bdddb0368c4b7b8aaeefdb93820655";
			var myHostKey = "AAAAB3NzaC1yc2EAAAADAQABAAAAgQDCh9qdcv1i9Y6nDwpspLaW1OosdrrtOl0t7uiof2/QYs0RTmT1DVRz0D0SNweNjtB/5069pFaNMthEh591gNrnipxy2FA2Zz7x5fv0v/AbTjmTujK14GYDBvMQTA58jGf1NWRn0+CkJvhCqY4eylkYgXdn4Y5QgGQYoEvN9P6zdQ==";
			try {
				connection = sftp.createConnection({
					username: 'dilmar',
					passwordGuid: myPwdGuid, // references var myPwdGuid
					url: 'dstftp2.dstinc.com',
					directory: 'sftp://dilmar:DOpass08!@dstftp2.dstinc.com/',
					hostKey: myHostKey // references var myHostKey
				});
				log.debug('connection',connection)
				  var csvFile = file.load({id:34066});
				connection.upload({
					directory: 'sftp://dilmar:DOpass08!@dstftp2.dstinc.com/',
					filename: 'testInv.txt',
					file: csvFile,
					replaceExisting: false
					});  
			} catch (e) {
				//incase any error in creating connection
				log.debug('creating connection', e.toString());
				return false;
			}
			
		 return connection;
	}
		return {
		execute: execute
			};
		});