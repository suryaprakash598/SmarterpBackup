/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 */
 /**
 Owner			Date			Modification
 Surya			28/04/2021		Changed delivery_date format in headerRecord function
 Surya			28/04/2021		Added filter to restrict NTD orders
 Surya			08/06/2021		Excluded Memorized transaction
 */
define(['N/search', 'N/file', 'underscore', 'N/encode', 'N/record', 'N/email'],

    function (search, file, underscore, encode, record, email) {

    //Load saved search
    function execute(scriptContext) {
		//SEARCH FOR RFD FILES
        var _rfd = savedSearchRFD();
		//GROUP RESULTS BY DOCUMENT NUMBER KEY
        var _groupRfd = underscore.groupBy(_rfd, 'documentNumber');
        var keys = Object.keys(_groupRfd);
        var arr = [];
        for (var k = 0; k < keys.length; k++) {
            try {
                var csvFile = '';
                var data = _groupRfd[keys[k]];
                var headerObj = headerRecord(_groupRfd[keys[k]]);
                var lineObj = lineItemRecord(_groupRfd[keys[k]]);
                var controlObj = controlRecord(_groupRfd[keys[k]]);
                var TrailerObj = trailerRecord(_groupRfd[keys[k]]);
                csvFile += controlObj + headerObj + lineObj + TrailerObj;
                //CREATION OF FILE
                var fileObj = file.create({
                    //To make each file unique and avoid overwriting, append date on the title
                    name: 'RFD_' + data[0].documentNumber,
                    fileType: file.Type.CSV,
                    contents: csvFile,
                    description: 'This is a CSV file.',
                    encoding: file.Encoding.UTF8,
                    folder: 1239 //1086
                });

                //Save the CSV file
                var fileId = fileObj.save()
				//log.debug('File ID...', fileId)
				arr.push({
				'fileId': fileId,
				'docnumber': data[0].documentNumber,
				'traninternalid': data[0].traninternalid
				});
				
                encodetobase64(fileId)
            } catch (e) {
                log.debug('Error in Main', e.toString());
            }
        }
        if (arr.length) {
            createCustomRecord(arr);
           // sendEmail(arr);
            updateFileGeneratedInfo(arr);
        }
    }
    function savedSearchRFD() {
        try {
            var arr = [];
            var salesorderSearchObj = search.create({
                type: "salesorder",
                filters:
                [
                    ["type", "anyof", "SalesOrd"],
                    "AND",
                    ["datecreated", "on", "today"],
                    "AND",
                    ["status", "anyof", "SalesOrd:A"],
                    "AND",
                    ["taxline", "is", "F"],
                    "AND",
                    ["cogs", "is", "F"],
                    "AND",
                    ["shipping", "is", "F"],
                    "AND",
                    ["mainline", "is", "F"],
                    "AND",
                    ["customer.custentity_dil_customer_nation_yn", "is", "T"],
                    "AND",
                    ["customer.custentity_dil_cust_buyback_vid", "anyof", "1"],
                    "AND",
                    ["custbody_is_sent_to_shell", "is", "F"],
                    "AND",
                    ["custbody_is_file_generated", "is", "F"],
					"AND",
					["custbody_is_from_ntd","is","F"],
					  "AND", 
					["number","isnotempty",""], 
					"AND", 
					["memorized","is","F"],
                    "AND",
                    ["item.type", "noneof", "OthCharge", "Discount"]
                ],
                columns:
                [
                    search.createColumn({
                        name: "otherrefnum",
                        summary: "GROUP"
                    }),
                    search.createColumn({
                        name: "internalid",
                        summary: "GROUP"
                    }),
                    search.createColumn({
                        name: "trandate",
                        summary: "GROUP"
                    }), 
					search.createColumn({
                        name: "custbody_dil_so_order_delivery_date",
                        summary: "GROUP"
                    }),
                    search.createColumn({
                        name: "tranid",
                        summary: "GROUP"
                    }),
                    search.createColumn({
                        name: "quantity",
                        summary: "GROUP"
                    }),
                    search.createColumn({
                        name: "item",
                        summary: "GROUP"
                    }),
                    /*  search.createColumn({
                    name: "custentity_dil_cust_plant_id",
                    join: "customer",
                    summary: "GROUP"
                    }) ,*/
                    search.createColumn({
                        name: "custentity_dil_cust_ext_sold_to",
                        join: "customer",
                        summary: "GROUP"
                    }),
                    search.createColumn({
                        name: "custentity_dil_cust_ext_ship_to",
                        join: "customer",
                        summary: "GROUP"
                    }),
                    search.createColumn({
                        name: "custrecord_dil_plant_id",
                        join: "location",
                        summary: "GROUP",
                        label: "Plant ID"
                    }),
                    search.createColumn({
                        name: "custrecord_dil_dist_ship_from_num",
                        join: "location",
                        summary: "GROUP",
                        label: "Distributor Ship From Number"
                    }),
                    search.createColumn({
                        name: "itemid",
                        join: "item",
                        summary: "GROUP",
                        label: "Item Name"
                    }),
                    search.createColumn({
                        name: "custentity_dil_cust_vmi_flag",
                        join: "customer",
                        summary: "GROUP",
                        label: "Vendor Managed Inventory"
                    })
                ]
            });
            var searchResultCount = salesorderSearchObj.runPaged().count;
            log.debug("salesorderSearchObj result count", searchResultCount);
            salesorderSearchObj.run().each(function (result) {
				log.debug('result',result);
                var obj = {};
                obj.traninternalid = result.getValue({
                    name: "internalid",
                    summary: "GROUP"
                });
                log.debug('result.id', result.id);
                obj.documentNumber = result.getValue({
                    name: "tranid",
                    summary: "GROUP"
                });
				obj.custbody_dil_so_order_delivery_date = result.getValue({
                    name: "custbody_dil_so_order_delivery_date",
                    summary: "GROUP"
                });
                obj.otherrefnum = result.getValue({
                    name: "otherrefnum",
                    summary: "GROUP"
                });
                obj.trandate = result.getValue({
                    name: "trandate",
                    summary: "GROUP"
                });
                obj.quantity = result.getValue({
                    name: "quantity",
                    summary: "GROUP"
                });
                obj.item = result.getText({
                    name: "item",
                    summary: "GROUP"
                });
                obj.plantid = result.getValue({
                    name: "custrecord_dil_plant_id",
                    join: "location",
                    summary: "GROUP"
                });
                obj.soldto = result.getValue({
                    name: "custentity_dil_cust_ext_sold_to",
                    join: "customer",
                    summary: "GROUP"
                });
                obj.shipto = result.getValue({
                    name: "custentity_dil_cust_ext_ship_to",
                    join: "customer",
                    summary: "GROUP"
                });
                //partner item code
                obj.vendorname = result.getValue({
                    name: "itemid",
                    join: "item",
                    summary: "GROUP"
                });
                obj.isvmi = result.getValue({
                    name: "custentity_dil_cust_vmi_flag",
                    join: "customer",
                    summary: "GROUP",
                    label: "Vendor Managed Inventory"
                });

                arr.push(obj);
                return true;
            });
            return arr;
        } catch (e) {
            log.debug('Error in savedSearchList', e.toString());
        }
    }
    function controlRecord() {
        var tempString = '';
		//TagID,SenderID,SenderQualifer,ReceiverID,ReceiverQualifier,SenderInterchangeNo,MessageReferenceNo,MessageType,SMDVersion,TestFlag
        tempString += "CTL,11243268,,SOPUS,,,,REQUEST_FOR_DELIVERY,," + "\r\n";
        return tempString;
    }

    function trailerRecord(data) {

        var tempString = '';
        tempString += "TRL" + "," + data[0].documentNumber + "\r\n";
        return tempString;
    }
    function headerRecord(data) {
        var tempString = '';
        if (data.length) {
            var isvmiordfoa = 'DFOA';
            if (data[0].isvmi) {
                isvmiordfoa = 'VMI';
            }
			var trandate='';
			var delivery_date='';
			if(data[0].trandate)
			{
				trandate = formatDate(data[0].trandate);
			}
			if(data[0].custbody_dil_so_order_delivery_date)
			{
				delivery_date = formatDate(data[0].custbody_dil_so_order_delivery_date);
			}
			var CarrierNotesText='';
			var DistributorShipFromID='';
			//TagID,CustomerPONumber,PurchaseOrderDate,TransactionType,DistributorPONumber,CustomerSoldToID,CustomerShipToID,DistributorShipFromID(o),PlantID,CarrierNotesText(o),DistributorDeliveryDate
            tempString += "HDR" + "," + data[0].otherrefnum + "," +
			trandate + "," + isvmiordfoa + "," + data[0].documentNumber + "," + 
			data[0].soldto + "," + data[0].shipto + "," + DistributorShipFromID + "," +
			data[0].plantid +"," + CarrierNotesText+ "," +
			delivery_date+ "\r\n";
        }
        return tempString;
    }
    function lineItemRecord(data) {
        var tempString = '';
        var lineNumber = 0;
        for (var i = 0; i < data.length; i++) {
            lineNumber = lineNumber + 10;
			//TagID,LineItemNumber,ShellProductNumber,Quantity
            tempString += "LIN" + "," + (lineNumber) + "," + data[i].item + "," + data[i].quantity + "\r\n";
        }
        return tempString;
    }
    function encodetobase64(fileid) {
        try {
            var fileObj = file.load({
                id: fileid
            });
            var base64EncodedString = encode.convert({
                string: fileObj.getContents(),
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });
            log.debug('base64EncodedString', base64EncodedString);
        } catch (e) {
            log.debug('error', e.toString());
        }
    }
    function createCustomRecord(arr) {
        try {

            //redirect.toSuitelet({scriptId:1909,deploymentId:1,parameters:{'fileid':1}});
            log.debug('arr', arr);
            var customRecObj = record.create({
                type: 'customrecord_edi_rfd',
                isDynamic: !0
            });
            var salesorderids = [];
            for (var i = 0; i < arr.length; i++) {
                salesorderids.push(arr[i].traninternalid);
            }
            customRecObj.setValue({
                fieldId: 'custrecord_rfd_document_number',
                value: salesorderids
            });
            /* customRecObj.setValue({
            fieldId: 'mediaitem',
            value: 7562
            }); */

            var id = customRecObj.save();
            for (var i = 0; i < arr.length; i++) {
                record.attach({
                    record: {
                        type: 'file',
                        id: arr[i].fileId,
                    },
                    to: {
                        type: 'customrecord_edi_rfd',
                        id: id
                    }
                })
            }
        } catch (e) {
            log.debug('error', e.toString());
        }

    }
    function sendEmail(arr) {
        try {
            var senderId = -5;
            log.debug('arr', arr);
            var recipientId = ['amber@dilmar.com'];
            var subject = 'EDI RFD Files';
            var body = 'Hi, EDI RFD processed files';
            body += '<table><tr><th>Document Number</th><th>File</th></tr>';
            for (var i = 0; i < arr.length; i++) {
                body += '<tr>';
                body += '<td>' + arr[i].docnumber + '</td><td>' + arr[i].fileId + '</td>';
                body += '</tr>';
            }
            body += '</table>';
            email.send({
                author: senderId,
                recipients: recipientId,
                /* cc: cclist,
                bcc: bcclist, */
                subject: subject,
                body: body
            });

        } catch (e) {
            log.debug('error', e.toString());
        }
    }
    function updateFileGeneratedInfo(arr) {
        try {
            for (var i = 0; i < arr.length; i++) {
				
                /* record.submitFields({
                    type: 'salesorder',
                    id: arr[i].traninternalid,
                    values: {
                        custbody_is_file_generated: true,
						custbody_is_sent_to_shell:true
                    },
                    options: {
                        enableSourcing: !1,
                        ignoreMandatoryFields: !0
                    }
                }); */
				var recObj = record.load({
                    type: record.Type.SALES_ORDER,
                    id: arr[i].traninternalid
                });
				
				recObj.setValue({
                        fieldId: 'custbody_is_file_generated',
                        value: true,
                        ignoreFieldChange: true
                    });
				recObj.setValue({
                        fieldId: 'custbody_is_sent_to_shell',
                        value: true,
                        ignoreFieldChange: true
                    });
				var id = recObj.save();
            }
        } catch (e) {
            log.debug('error', e.toString())
        }
    }
	function formatDate(date) {
	  
		 var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

		if (month.length < 2) 
			month = '0' + month;
		if (day.length < 2) 
			day = '0' + day;

		return [year, month, day].join('');
	 
    
}
    return {
        execute: execute
    };

});