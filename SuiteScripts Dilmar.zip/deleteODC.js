/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 */
  
define(['N/search', 'N/runtime','N/file','N/record'],

    function (search, runtime,file) {

    //Load saved search
    function execute(scriptContext) {
		try{
			var s = [  
    29201,
29314,
29313,
29312,
29311,
29207,
29310,
29206,
29309,
29205,
29308,
29204,
29307,
29203,
29326,
29325,
29306,
29202,
29324,
29323,
29322,
29321,
29320,
29319,
29318,
29317,
29316,
29315,
29305
];
 var fileArr = s;
        for (var i = 0; i < fileArr.length; i++) {
            var proceefile = file.load({
                id: fileArr[i]
            });
            if (proceefile.fileType == 'CSV') {
                var newFileName = 'visual' + proceefile.name;
                proceefile.name = newFileName;
                proceefile.folder = 4562;
                //submit the file so that the new file name would be saved
                var id = proceefile.save();

            }
        }
			
		}catch(e)
		{
			log.debug('Error in creating Error Record',e.toString());
		}
	}
    return {
        execute: execute
    };
	
});