/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/search'],
/**
 * @param {record} record
 */
function(record,search) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
    	
    	

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
		//log.debug('before submit');
    	
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {
	log.debug('after submit');	
	try{
		//if(scriptContext.type == scriptContext.UserEventType.CREATE){
		 var rec = scriptContext.newRecord; 
    	var is_national_cust;
		var handling_Fee_quantity=0;
		var PO_ID = rec.getValue({
				fieldId: 'id',
				});
      var type = scriptContext.newRecord.type;
		var	recObj=record.load({
                    type: type,
                    id: PO_ID,
                    isDynamic: false,
                });
		var customer = recObj.getSublistValue({
				sublistId: 'item',
				fieldId: 'customer',
				line:0
				});
          
		if(customer){
		try {		
		var fields = search.lookupFields({
        type: 'customer',
        id: customer,
        columns: ['custentity_drop_ship_customer']
      });
      
          
        is_national_cust = fields.custentity_drop_ship_customer;
		//log.debug('is_national_cust',is_national_cust);
      } catch (e) {
        log.debug('error',e);
        
      }
 if(is_national_cust){
		  
    	for (var i = 0; i < recObj.getLineCount({sublistId: 'item'}); i++) {
			var quantity = recObj.getSublistValue({
				sublistId: 'item',
				fieldId: 'quantity',
				line:i
				});
			var gallon_conversion = recObj.getSublistValue({
				sublistId: 'item',
				fieldId: 'custcol_ns_gallonconversionfactor',
				line:i
				});	
			handling_Fee_quantity=Number(handling_Fee_quantity)+(Number(quantity)*Number(gallon_conversion))
			//log.debug('handling_Fee_quantity',handling_Fee_quantity);
	}
	
	var lineCount=recObj.getLineCount({sublistId: 'item'});
	var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3024 //''
            });
            //log.debug('Environment fee line number',lineNumber);
       
           
                // if Environment fee is not available at the item list then add the line to the item list with environment fee value
               
                    if (lineNumber == -1)
                    {
                        recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3024 //'Handling fee'
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:Number(handling_Fee_quantity) //'Handling fee'
						})	
                        }catch(e)
                        {
                            log.error(' error adding handling fee line',e.message());
                        }
                    }
					else{
						log.debug('handling_Fee_quantity',handling_Fee_quantity);
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:Number(handling_Fee_quantity) //'Handling fee'
						})	
					}
	
	
	
	/*  var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
                        recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        var item=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3021 //'Handling fee'
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:parseInt(handling_Fee_quantity) //'Handling fee'
                            });	
                        }catch(e)
                        {
                            log.error(' error adding handling fee line',e.message());
                        } */
         recObj.save({
    ignoreMandatoryFields: true
		});           
	  }
	  
		}
		
//}
		}
catch(e){
	log.error('error',e)
}
	}	


    	
    
    
    	


    return {
       // beforeLoad: beforeLoad,
        //beforeSubmit: beforeSubmit,
      afterSubmit: afterSubmit
    };
    
});
