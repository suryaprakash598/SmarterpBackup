/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 */
define(['N/record','N/search','N/runtime'], function(record,search,runtime) {
		
	function checkitem(items,item)
	{
		for (var i = 0; i < items.length; i++) {
		  if (items[i] === item) {
			return true;
		  }
		}
		return false;
	}


	function getHandlingCharges(buyback_vendor,itemqty,item_type)
	{
		var total_charges =0 ;
		var customrecord_dil_handling_fee_charge_hdrSearchObj = search.create({
				   type: "customrecord_dil_handling_fee_charge_hdr",
				   filters:
				   [
					  ["custrecord_dil_handling_fee_buyback_vid","anyof",buyback_vendor], 
					  "AND", 
					  ["custrecord_dil_handling_dtl_buyback_vid.custrecord_dil_handling_qty_gte","lessthanorequalto",itemqty], 
					  "AND", 
					  ["custrecord_dil_handling_dtl_buyback_vid.custrecord_dil_handling_qty_lte","greaterthanorequalto",itemqty], 
					  "AND", 
					  ["custrecord_dil_handling_dtl_buyback_vid.custrecord_dil_handling_item_process_grp","anyof",item_type]
				   ],
				   columns:
				   [
					  search.createColumn({
						 name: "custrecord_dil_handling_fee_buyback_vid",
						 sort: search.Sort.ASC
					  }),
					  search.createColumn({
						 name: "custrecord_dil_handling_rate",
						 join: "CUSTRECORD_DIL_HANDLING_DTL_BUYBACK_VID"
					  })
				   ]
				});

				customrecord_dil_handling_fee_charge_hdrSearchObj.run().each(function(result){
				   total_charges = result.getValue({name: "custrecord_dil_handling_rate",join: "CUSTRECORD_DIL_HANDLING_DTL_BUYBACK_VID"});
				   return true;
				});
				return total_charges;
	}
	
		// Search for the contacts associated with Customers and Vendors
		function findEmailList(entity){
			var contactSearchObj = search.create({
			   type: "contact",
			   filters:
			   [
				  ["isinactive","is","F"], 
				  "AND", 
				  ["email","isnotempty",""], 
				  "AND", 
				  ["company.internalid","anyof",entity],
				  "AND",
				  ["custentity_dil_contact_inv_notify","is","T"]
			   ],
			   columns:
			   [
				  search.createColumn({
				  name: "email"})
				  
			   ]
			});
			var emails = [];
            var curr_emailaddress,all_emailaddresses;
			contactSearchObj.run().each(function(result){
              if (emails.length <= 10)
              {
                 curr_emailaddress = result.getValue("email");
                 var existing_email = emails.indexOf(curr_emailaddress);
                 if (existing_email == -1)
                    { 
                      all_emailaddresses = all_emailaddresses+curr_emailaddress+";";
                      if (all_emailaddresses.length <= 254)
                      {emails.push(result.getValue("email"));}
                    }
              }
			   return true;
			});
			return emails;
		}
		
	function beforeSubmit(context)
	{	var newRecord = context.newRecord;
	   
		var is_national_cust = newRecord.getValue('custbody_dil_is_national_customer');
	     log.debug('ue type',context.type);
		 if (is_national_cust)
			  {
				var buyback_vendor = newRecord.getValue('custbody_dil_so_buyback_vendor');
				var qty_synthetic =0, qty_nonsynthetic=0, handlingcharge_syn =0,handingcharge_nonsyn=0,total_handling_charge=0,total_qty = 0;
				
				var itemCount = newRecord.getLineCount({
						sublistId: 'item'
					});
				  
					for (var i = 0; i < itemCount; i++){
						try{
										
							var item_type = newRecord.getSublistValue({
								sublistId: 'item',
								fieldId: 'custcol_dil_item_process_group',
								line: i
							});
							var qty = Number(newRecord.getSublistValue({sublistId: 'item',fieldId: 'quantity', line: i}));
							var gallon_units = Number(newRecord.getSublistValue({sublistId:'item', fieldId: 'custcol_ns_gallonconversionfactor',line: i}));
						   var units_line = newRecord.getSublistValue({
								sublistId: 'item',
								fieldId: 'units',
								line: i
							}).toString();
							var gallon_qty = 0;
						  // for items with unit BULK convert the quantity to the round of quantity for handling fee charges calculation
						  if (units_line.toUpperCase() === 'BULK') 
						  {
							gallon_qty = Math.round(qty * gallon_units);
						  } 
						  else
						  {
							gallon_qty = qty * gallon_units;
						  };
							
							if (buyback_vendor == '1'){
								if (item_type == '1' && item_type.length > 0)
								{
									qty_synthetic = qty_synthetic + gallon_qty;
								}
								else if(item_type == '2' && item_type.length > 0)
								{
									 qty_nonsynthetic = qty_nonsynthetic + gallon_qty;
								};
							}else if (buyback_vendor == '2')
								{
									total_qty = total_qty + gallon_qty;
								}
					
						
					//	newRecord.commitLine({sublistId: 'item'});
						} catch(e){
							 log.debug({
							title: 'error of Item ' + i,
							details: e.toString()
						});	
							//return 0;
						}
					}
					
					if (buyback_vendor == '1'){
						
						if (qty_synthetic > 0){
							 handlingcharge_syn = getHandlingCharges(buyback_vendor,qty_synthetic,"1");
						}
						if (qty_nonsynthetic > 0)
						{
							 handingcharge_nonsyn = getHandlingCharges(buyback_vendor,qty_nonsynthetic,"2");
						}
						 total_handling_charge = parseFloat(qty_synthetic * handlingcharge_syn) + parseFloat(qty_nonsynthetic * handingcharge_nonsyn);
					} else if (buyback_vendor == '2')
					{
						total_handling_charge = parseFloat(total_qty * getHandlingCharges(buyback_vendor,total_qty,"@NONE@"));
					}
					
					//find if the handling charges is already part of the sales order
					var lineNumber = newRecord.findSublistLineWithValue({
						sublistId: 'item',
						fieldId: 'item',
						value: 15 //'Handling Fees'
					});
					log.debug('handling fee line number',lineNumber +' v '+buyback_vendor+' s '+qty_synthetic +' n '+qty_nonsynthetic +' q '+total_qty+' h '+total_handling_charge);
				
					// if the handling fee charge is available
					
					if (parseFloat(total_handling_charge) > 0 )
						{
						// if handling fee is not available at the item list then add the line to the item list with handling fee value
						
							if (lineNumber == -1)
							{
								newRecord.insertLine
								({
									sublistId : 'item',
									line: itemCount
								});
								
								try {
								newRecord.setSublistValue({
										sublistId: 'item',
										fieldId: 'item',
										line: itemCount,
										value: 15 //'Handling Fees'
									});
								newRecord.setSublistValue({
										sublistId: 'item',
										fieldId: 'amount',
										line: itemCount,
										value: parseFloat(total_handling_charge)
									});
								}catch(e)
								{
									log.error(' error adding handling fee line',e.message());
								}
							}
							// else update the handling fee item with the proper handling charge
							else
							{
								try{
								newRecord.setSublistValue({
										sublistId: 'item',
										fieldId: 'amount',
										line: lineNumber,
										value: parseFloat(total_handling_charge)
									});
								} catch(e)
								{
									log.debug('error in updating handling fee',e.message());
								}
								
							}
						}
				}
				if (context.type !== context.UserEventType.CREATE)
				return;
				var newRecord = context.newRecord;
				var custid = newRecord.getValue('entity');
				var emaillist = [];
				emaillist = findEmailList(custid);
				if (emaillist.length > 0)
							{
								var email_addresses = emaillist.join(";");
								newRecord.setValue({
									fieldId: 'email',
									value : email_addresses
								});
							}
/*						newRecord.setValue({
							fieldId : 'tobeemailed',
							value: false
							});
 */   		// set the line location to header location by default if the location is empty
     var location_main = newRecord.getValue({fieldId: 'location'});
          try{
            	var numLines = newRecord.getLineCount({
                              sublistId: 'item'
                          });
            
              for (i = 0; i< numLines; i++)
              { 
                var location_line = newRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'location',
                                        line: i
                                      });
                var fulfilled_flag = newRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'custcol_dil_item_to_be_fulfilled',
                                        line: i
                                      });
                if (location_line.length == 0 && fulfilled_flag)
                  {
                   newRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'location',
                                    line: i,
                                    value: location_main
                                      });
			        log.debug('location line in save', i);
                  }
               }
          }catch(e)
            {
              log.error('error',e.toString());
             // return false;
            }
    
	}

	function afterSubmit(scriptContext){
         try{
		 var recObj = scriptContext.newRecord; 
    			
    			var lineCount = recObj.getLineCount({
    			    sublistId: 'item'
    			});
    	      log.debug('line count',lineCount);
    			var items=[];
    			
    			for( var i = 0; i < lineCount; i++)
    			{
    				
    				//Getting Sublist Values
    				var item = recObj.getSublistValue({
    				    sublistId: 'item',
    				    fieldId: 'item',
    				    line: i
    				});
					items.push(item)
				}
            var salesorder_id=recObj.getValue({fieldId:'createdfrom'});
		if(salesorder_id){
		 SaleOrder = record.load({
                    type: 'salesorder',
                    id: salesorder_id,
                    isDynamic: false,
                });
    	for (var i = 0; i < SaleOrder.getLineCount({sublistId: 'item'}); i++) {
			var unit = SaleOrder.getSublistValue({
				sublistId: 'item',
				fieldId: 'units_display',
				line:i
				});
			var item = SaleOrder.getSublistValue({
				sublistId: 'item',
				fieldId: 'item',
				line:i
				});
			var item_found=checkitem(items,item);
			log.debug('item_found',item_found);
			if(unit=='Bulk'&&item_found){
			
				var quantitybilled = SaleOrder.getSublistValue({
				sublistId: 'item',
				fieldId: 'quantitybilled',
				line:i
				});
              	var quantity = SaleOrder.getSublistValue({
				sublistId: 'item',
				fieldId: 'quantity',
				line:i
				});
              if(quantity>quantitybilled){
			SaleOrder.setSublistValue({
			sublistId: 'item',
			fieldId: 'isclosed',
			line: i,
			value: true
			});
			}
			}
	}
	SaleOrder.save({ ignoreMandatoryFields: true });
		}
      }
      catch(e){
        log.debug('error', e.toString());
      }
	}
    return {
        beforeSubmit: beforeSubmit,
		afterSubmit: afterSubmit
    }
});