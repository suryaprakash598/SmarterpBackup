/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 */
define(['N/search', 'N/file', 'underscore', 'SuiteScripts/RecurlyLib', 'N/record','N/email'],

    function (search, file, underscore, RECURLY_MODULE, record,email) {

    //Load saved search
    function execute(scriptContext) {
        var fileIds = getNotProcessedOCRMFiles();
        log.debug('fileIds', fileIds);
        var salesorderIds = [];
        for (var fi = 0; fi < fileIds.length; fi++) {

            var fileObj = file.load({
                id: fileIds[fi]
            });
            var dataArr = RECURLY_MODULE.csvToArr(fileObj.getContents());
            var shellSO = dataArr[1][1];
            var NSSO = dataArr[1][3];
			log.debug('NSSO',NSSO);
			log.debug('shellSO',shellSO);
            var _ocrm = savedSearchOCRM(shellSO, NSSO);
            log.debug('_ocrm', _ocrm);
            if (_ocrm != '') { 
			var obj={};
			obj.fileid=fileIds[fi];
			var arr=[]; arr.push(obj);
				sendEmail(arr);
            }
        }
		if (salesorderIds.length) {
            createCustomRecord(salesorderIds);
            sendEmail(salesorderIds);
		}

    }
    function savedSearchOCRM(shellSO, NSSO) {
        try {
            var salesorderSearchObj = search.create({
                type: "salesorder",
                filters:
                [
                    ["type", "anyof", "SalesOrd"],
                    "AND",
                    [
                        ["custbody_dil_so_shell_sales_order_num", "is", shellSO],
                        "OR",
                        ["numbertext", "haskeywords", NSSO]
                    ],
                    "AND",
                    ["status", "noneof", "SalesOrd:A"],
                    "AND",
                    ["mainline", "is", "T"],
                    "AND",
                    ["cogs", "is", "F"],
                    "AND",
                    ["taxline", "is", "F"],
                    "AND",
                    ["shipping", "is", "F"]
                ],
                columns:
                [
                    "tranid",
                    "internalid"
                ]
            });
            var searchResultCount = salesorderSearchObj.runPaged().count;
            log.debug("salesorderSearchObj result count", searchResultCount);
            var internalid = '';
            salesorderSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                internalid = result.getValue({
                    name: 'internalid'
                });
                return true;
            });
            return internalid;
        } catch (e) {
            log.debug('Error in savedSearchOCRM', e.toString());
        }
    }
    function getNotProcessedOCRMFiles() {
        try {
            var folderSearchObj = search.create({
                type: "folder",
                filters:
                [
                    ["internalid", "anyof", "1243"]
                ],
                columns:
                [
                    search.createColumn({
                        name: "name",
                        join: "file"
                    }),
                    search.createColumn({
                        name: "internalid",
                        join: "file"
                    })
                ]
            });
            var searchResultCount = folderSearchObj.runPaged().count;
            log.debug("folderSearchObj result count", searchResultCount);
            var fileIds = [];
            folderSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                fileIds.push(result.getValue({
                        name: "internalid",
                        join: "file"
                    }));
                return true;
            });
            return fileIds;
        } catch (e) {
            log.debug('Error in getNotProcessedOCRMFiles', e.toString());
        }
    }
    function createCustomRecord(arr) {
        try {

            //redirect.toSuitelet({scriptId:1909,deploymentId:1,parameters:{'fileid':1}});
            log.debug('arr', arr);
            var customRecObj = record.create({
                type: 'customrecord_edi_ocrm_salesorder',
                isDynamic: !0
            });
            var soids = [];

            for (var i = 0; i < arr.length; i++) {
                soids.push(arr[i].salesorderId);
            }
            log.debug('soids', soids);
            customRecObj.setValue({
                fieldId: 'custrecord_ocrm_document_number',
                value: soids
            });
            var id = customRecObj.save();
            for (var i = 0; i < arr.length; i++) {
                record.attach({
                    record: {
                        type: 'file',
                        id: arr[i].fileid,
                    },
                    to: {
                        type: 'customrecord_edi_ocrm_salesorder',
                        id: id
                    }
                })
            }
        } catch (e) {
            log.debug('error', e.toString());
        }

    }
    function sendEmail(arr) {
        try {
            var senderId = -5;
            log.debug('arr', arr);
            var recipientId = ['amber@dilmar.com'];
            var subject = 'EDI OCRM Files';
            var body = 'Hi, EDI OCRM processed files';
            body += '<table><tr><th>Document Number</th><th>File</th></tr>';
            var ids = moveFilesToProcessed(arr);
            /* for (var i = 0; i < arr.length; i++) {
                body += '<tr>';
                body += '<td>' + arr[i].docNumber + '</td><td>' + arr[i].fileid + '</td>';
                body += '</tr>';
            }
            body += '</table>';
            email.send({
                author: senderId,
                recipients: recipientId,
                  cc: cclist,
                bcc: bcclist,  
                subject: subject,
                body: body
            }); */

        } catch (e) {
            log.debug('error', e.toString());
        }
    }
	function moveFilesToProcessed(fileArr) {
	        try {
	            var arr = [];
	            for (var i = 0; i < fileArr.length; i++) {
	                var proceefile = file.load({
	                    id: fileArr[i].fileid
	                });
	                if (proceefile.fileType == 'CSV') {
	                    var newFileName = 'Processed_' + proceefile.name;
	                    proceefile.name = newFileName;
	                    proceefile.folder = 1244;
	                    //submit the file so that the new file name would be saved
	                    var id = proceefile.save();
	                    arr.push(id);
	                }
	            }
	            return arr;

	        } catch (e) {
	            log.debug('Error', e.toString())
	        }
	    }
    return {
        execute: execute
    };

});