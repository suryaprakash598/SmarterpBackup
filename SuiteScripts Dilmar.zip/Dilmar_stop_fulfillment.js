/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/email','N/search'],
/**
 * @param {record} record
 */
function(record,email,search) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
		try{
		var fulfillment = scriptContext.newRecord; 
    	
		var lineCount = fulfillment.getLineCount({
    sublistId: 'item'
});
//for each line set the "itemreceive" field to true
for (var i = 0; i < lineCount; i++) {
  var units=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'units',
	  line: i
  });//Bulk
  
	var first_fulfilment=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'custcol_first_itemfulfilment',
	  line: i
  });  
	  if(first_fulfilment&&units==6){
		  var setvalue=fulfillment.setSublistValue({
      sublistId: 'item',
      fieldId: 'itemreceive',
      value: false,
	  line: i
  });
   var fulfilment_check=fulfillment.setSublistValue({
      sublistId: 'item',
      fieldId: 'custcol_bulk_second_fulfiment_check',
      value: true,
	  line: i
  }); 
	  }
	  
}

//checking first fulfillment is there 
var so=fulfillment.getValue({
      fieldId: 'createdfrom'
  });
var so_str=fulfillment.getText({
      fieldId: 'createdfrom'
  });
  so_str=JSON.stringify(so_str);
          
  if((so_str.indexOf("Sales Order")==-1))//so_str.includes("Sales Order")
  {
    return true;
  }
  var SaleOrder = record.load({
                    type: 'salesorder',
                    id: so,
                    isDynamic: false,
                });
					var firstfulfilment=false;
				var id;
    	for (var i = 0; i < SaleOrder.getLineCount({sublistId: 'links'}); i++) {
			 type = SaleOrder.getSublistValue({
				sublistId: 'links',
				fieldId: 'type',
				line:i
				});
				if(type=='Item Fulfillment'){
			 firstfulfilment=true
			}
		}

//check customer accept back order or not
if(firstfulfilment){
var accept_backorder
var customer=fulfillment.getValue({
      fieldId: 'entity'
  });
   var fields = search.lookupFields({
                    type: 'customer',
                    id: customer,
                    columns: ['custentity_dil_cust_accept_backorders']
                });

                try {
                    accept_backorder = fields.custentity_dil_cust_accept_backorders;
                } catch (e) {
                    log.debug('not a Customer');
                }
				if(!accept_backorder){
					
					var setting_backorderflag=fulfillment.setValue({
							fieldId: 'custbody_accept_back_order_if',
							value:true
							});
					for (var i = 0; i < lineCount; i++) {
  
	
						var setvalue=fulfillment.setSublistValue({
								     sublistId: 'item',
									fieldId: 'itemreceive',
									value: false,
									line: i
									});	  
				}		
				}
		}
		}
		catch (e) {
        log.error('error',e);
        
      }
    	

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
		
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {
		if(scriptContext.type != scriptContext.UserEventType.DELETE){
		try{
		var IF = scriptContext.newRecord;
		var IF_ID = IF.getValue({
				fieldId: 'id',
				});
          log.debug('IF_ID',IF_ID);
	var fulfillment = record.load({
                    type: 'itemfulfillment',
                    id: IF_ID,
                    isDynamic: false,
                });
    	var so=fulfillment.getValue({
      fieldId: 'createdfrom'
  });
 var so_str=fulfillment.getText({
      fieldId: 'createdfrom'
  });
  so_str=JSON.stringify(so_str);
          
  if((so_str.indexOf("Sales Order")==-1))//so_str.includes("Sales Order")
  {
    return true;
  }
   var SaleOrder = record.load({
                    type: 'salesorder',
                    id: so,
                    isDynamic: false,
                });
log.debug('SO_ID',so);

		var lineCount = fulfillment.getLineCount({
    sublistId: 'item'
});
log.debug('lineCount',lineCount);
//for each line set the "itemreceive" field to true
for (var i = 0; i < lineCount; i++) {
	log.debug('i',i)
  var item=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'item',
	  line: i
  });
 /*  var lineNumber = SaleOrder.findSublistLineWithValue({
 sublistId: 'item',
 fieldId: 'item',
 value:item
}); */
/*var lineNumber=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'orderline',
	  line: i
  });
  lineNumber=Number(lineNumber)-1;*/
  var lineNumber=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'custcol_so_line_number',
	  line: i
  });
  if(!lineNumber){
	 lineNumber=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'orderline',
	  line: i
  });
   lineNumber=Number(lineNumber)-1;
  }
if(lineNumber>=0){
	var setvalue=SaleOrder.setSublistValue({
								     sublistId: 'item',
									fieldId: 'custcol_first_itemfulfilment',
      								line: lineNumber,
									value:IF_ID
									});
	log.debug('lineNumber',lineNumber);
}	
    }  
	SaleOrder.save({
 enableSourcing: true,
 ignoreMandatoryFields: true
});
		}
		catch(e){
			log.error('error',e);
		}
	}
    }
    	


    return {
        beforeLoad: beforeLoad,
       // beforeSubmit: beforeSubmit,
      afterSubmit: afterSubmit
    };
    
});
