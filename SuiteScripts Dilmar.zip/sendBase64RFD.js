/*******************************************************************************
{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType Restlet
 *
 ******************************************************************************/

define(['N/runtime', 'N/file', 'N/record', 'N/search', 'N/encode'], function(
  /** @type {import('N/runtime')} **/ runtime,
  /** @type {import('N/task')}    **/ file,
  /** @type {import('N/record')}  **/ record,
  /** @type {import('N/search')}  **/ search,
  /** @type {import('N/log')}     **/ encode
) {
 
  /**
   * @type {import('N/types').EntryPoints.RESTlet.post}
   */
  function onGet(requestParams) {
    // return string or object data
	try{
		 var arr = [];
		var rfdFileArray =  searchRfdFiles(arr);
		 var addedOdc_Rfd = searchOdcFiles(rfdFileArray);
		   return JSON.stringify(addedOdc_Rfd);
		  //return JSON.stringify(rfdFileArray);
	}catch(e)
	{
		log.debug('Error',e.toString());
	}
	/* var obj={};
	obj.csv=base64EncodedString; */
    return JSON.stringify(obj);
  }
  /**
   * @type {import('N/types').EntryPoints.RESTlet.post}
   */
  function onPost(requestParams) {
    // return string or object data
	log.debug('requestParams',requestParams);
	if(requestParams.length>0)
	{
		for(var i=0;i<requestParams.length;i++)
		{
			// [ {  uniqueID: "11136",  filename: "rfd_SO357" }, {  uniqueID: "11137",  filename: "rfd_SO361" } ]
			var fileArr = requestParams[i];
			moveFilesToProcessed(fileArr);
			
			
		}
	}
    return '1';
  }
	function searchRfdFiles(arr)
	{
		try{
			var fileSearchObj = search.create({
			   type: "file",
			   filters:
			   [
				  ["folder","anyof","1239"]
			   ],
			   columns:
			   [
				  search.createColumn({
					 name: "name",
					 sort: search.Sort.ASC
				  }),
				  "documentsize",
				  "internalid"
				   /*  "folder",
				    "url",
				    "filetype", */
			   ]
			});
			var searchResultCount = fileSearchObj.runPaged().count;
			log.debug("fileSearchObj result count",searchResultCount);
			
			fileSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
			   var obj={};
			   var name=result.getValue({name:'name'});
			   var internalid=result.getValue({name:'internalid'});
			   var base64Encoded = base64(internalid);
			   obj.name = name;
			   obj.uniqueID = internalid;
			   obj.base64Encoded = base64Encoded;
			    arr.push(obj);
			   return true;
			});
			return arr;
		}catch(e)
		{
			log.debug('error in searchRfdFiles',e.toString());
		}
	}
	function searchOdcFiles(arr)
	{
		try{
			var fileSearchObj = search.create({
			   type: "file",
			   filters:
			   [
				  ["folder","anyof","1567"]
			   ],
			   columns:
			   [
				  search.createColumn({
					 name: "name",
					 sort: search.Sort.ASC
				  }),
				  "internalid",
				  "documentsize"
				 /*  ,"folder",
				  "url",
				  "filetype" */
			   ]
			});
			var searchResultCount = fileSearchObj.runPaged().count;
			log.debug("fileSearchObj result count",searchResultCount);
			fileSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
			   var obj={};
			   var name=result.getValue({name:'name'});
			   var internalid=result.getValue({name:'internalid'});
			   var base64Encoded = base64(internalid);
			   obj.name = name;
			   obj.uniqueID = internalid;
			   obj.base64Encoded = base64Encoded;
			    arr.push(obj);
			   return true;
			});
			return arr;
		}catch(e)
		{
			log.debug('error in searchOdcFiles',e.toString());
		}
	}
   function base64(fileid)
   {
	   try{
		   var fileObj = file.load({id:fileid}); //8303
			var base64EncodedString = encode.convert({
				string: fileObj.getContents(),
				inputEncoding: encode.Encoding.UTF_8,
				outputEncoding: encode.Encoding.BASE_64
			});
			return base64EncodedString;
	   }catch(e)
	   {
		   log.debug('error in base64',e.toString());
	   }
   }
	function moveFilesToProcessed(fileArr)
	{
		try{
			/* var arr = [];
			for(var i=0;i<fileArr.length;i++)
			{ */
		var substring = "rfd";
		var substring1 = "odc";
		log.debug('fileArr',fileArr);
		var fileName = fileArr.filename;
		 fileName = fileName.toLowerCase();
 
		if(fileName.indexOf(substring) !== -1) //rfd
		{
			var proceefile = file.load({
                        id: fileArr.uniqueID
                    }); 
			var newFileName = 'Processed_' + proceefile.name;
			proceefile.name = newFileName;
			proceefile.folder = 1240;
			//submit the file so that the new file name would be saved
			var id = proceefile.save();
						 
		}else if(fileName.indexOf(substring1) !== -1) //odc
		{
			var proceefile = file.load({
                        id: fileArr.uniqueID
                    }); 
			var newFileName = 'Processed_' + proceefile.name;
			proceefile.name = newFileName;
			proceefile.folder = 1242;
			//submit the file so that the new file name would be saved
			var id = proceefile.save();
						 
		}
				
			/* }
			return arr; */
			 
		}catch(e)
		{
			log.debug('Error',e.toString())
		}
	}
  return { 
     'get':    onGet,
	 'post':   onPost
  };

});