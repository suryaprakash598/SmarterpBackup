/**
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */

define(['N/ui/serverWidget', 'N/currentRecord','N/runtime','N/search'], function(serverWidget,currentRecord,runtime,search) {
function readOnlyFields(params)
{
    try
    {
      var objRecord = currentRecord.get();
      var currentuser = runtime.getCurrentUser();
      var userRole = currentuser.role;
      var form = params.form;

      var sublistObj = form.getSublist({
        id: 'item'
      });

      /*var locationMain = objRecord.getValue({
        fieldId: 'location'
      });

      sublistObj.setValue({
        fieldId: 'location',
        value: locationMain
      });*/
      if (userRole === 1086 || userRole === 1067)
      {
          //var form = params.form;
          var varDescription = sublistObj.getField({id: 'description'});
          var varUnits = sublistObj.getField({id: 'units'});
          //var varPriceLevel = sublistObj.getField({id: 'price'});
          var varAmount = sublistObj.getField({id: 'amount'});
          var varLocation = sublistObj.getField({id: 'location'});
          var varClass = sublistObj.getField({id: 'class'});

          varDescription.updateDisplayType({
            displayType : serverWidget.FieldDisplayType.DISABLED
          });
          varUnits.updateDisplayType({
            displayType : serverWidget.FieldDisplayType.DISABLED
          });
          /*varPriceLevel.updateDisplayType({
            displayType : serverWidget.FieldDisplayType.DISABLED
          });*/
          varAmount.updateDisplayType({
            displayType : serverWidget.FieldDisplayType.DISABLED
          });
          varLocation.updateDisplayType({
            displayType : serverWidget.FieldDisplayType.DISABLED
          });
          varClass.updateDisplayType({
            displayType : serverWidget.FieldDisplayType.DISABLED
          });
		}
    }
    catch(e)
    {
      // you message in case of error
      log.debug('error',e);
    }
}

function beforeSubmit(scriptContext)
{
	var recObj = scriptContext.newRecord; //create mode
	var recordtype = recObj.type;
  
	if(scriptContext.type == scriptContext.UserEventType.CREATE&&(recordtype=='estimate'))
    {
		var entity=recObj.getValue({
			fieldId: 'entity',
		});
		var fields = search.lookupFields({
        	type: 'customer',
        	id: entity,
        	columns: ['custentity_dil_customer_nation_yn','custentity_ns_envcomplianceexempt']
      });

      var envcust;
      var is_national_cust;
      try {
        is_national_cust = fields.custentity_dil_customer_nation_yn;
       	envcust = fields.custentity_ns_envcomplianceexempt;
      }
      catch (e) {
        log.debug('error',e);
      }

      if(scriptContext.type == scriptContext.UserEventType.CREATE && !is_national_cust&&!envcust)
      {
		//find if the Environment Charge is already part of the sales order
            var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 20 //'Environment Compliance Fees'
            });
            log.debug('Environment fee line number',lineNumber);
       
           
                // if Environment fee is not available at the item list then add the line to the item list with environment fee value
               
                    if (lineNumber == -1)
                    {
                      var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
                        recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 20 //'Environment Fees'
                            });
                        }catch(e)
                        {
                            log.error(' error adding environment fee line',e.message());
                        }
                    }
		  }
    }
}

return {
        beforeLoad: readOnlyFields,
		//beforeSubmit: beforeSubmit
    };
});