/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 */
define(['N/record','N/redirect'], function(record,redirect){
	function onRequest(context)
	{
       if (context.request.method == 'POST')
         {
    		//var req_param = context.request.parameters;.
       		var request_param = context.request.parameters;
			var recordId = request_param.recordId;
         	var truckno = request_param.truckno;
         	var ifid = request_param.ifid;
       	  log.debug(' in the suitelet for invoice', request_param.toString());
	  try{  
            var objRecord = record.load({
                type : record.Type.INVOICE,
                id: request_param.recordId,
                isDynamic: true
            });
            objRecord.setValue({
                fieldId: 'custbody_dil_so_ship_truck_no',
                value: request_param.truckno,
                ignoreFieldChange: true
            });
            var invid = objRecord.save();
            log.debug('invoice id saved',invid);
      	} 
        catch(e)
        {
          log.error('error','error in saving invoice '+e.toString());
        }
           
		redirect.toRecord({
				type: record.Type.ITEM_FULFILLMENT,
				id: request_param.ifid,
				isEditMode : false
				});
         }
	}
	return {
		onRequest : onRequest
	}
})