	/**
	 * @NApiVersion 2.x
	 * @NScriptType UserEventScript
	 * @NModuleScope SameAccount
	 */
	 /*Modifications */
	 /*
	 owner  			Date			Modifications
	 Surya				04/14/2021		Removing shipping method condition 
	 Surya				04/21/2021		Object Making is modified to add lines into array instead of sending individual lines multiple 
	 Surya				04/21/2021		Updated releaseNo with salesorder document number
	 Surya				04/21/2021		Updated Item description with salesdescription
	 Surya				04/22/2021		Excluded Dropship orders with giving filter in saved search
	 Surya				04/22/2021		Updated servicedByDepotID value to location
	 Surya				04/23/2021		Updated ETD with Date field data in fulfillment record 
	 Surya				05/03/2021		Added Email Field Logic
	 Surya				05/03/2021		Added displayname if salesdescription is not available for item
	 Surya				05/04/2021		isRequiredCod field is updated based on customer terms _If customer have dueonreceipt then isRequiredCod should be true
	 Surya				05/04/2021		Updated instructions field
	 Surya				05/07/2021		Added shipmethod to payload
	 Surya				05/10/2021		Updated contact and customer type information
	 Surya				06/10/2021		isRequiredCod is updated to use with COD
	 Surya				06/29/2021		Updated LineMemo
	 Surya				08/09/2021		Updated itemrate to 0 for COD Orders
	 Surya				08/20/2021		Updated Contact email  and primaryContact only when it is offered for Send POD in contact record
	 Surya				08/20/2021		Added new field custbody_ns_payload_to_bizspeed to capture data we are sending to bizspeed
	 Surya				08/27/2021		Added Logic to set ETA if empty|null
	 Surya				09/01/2021		Updated Instructions key with adding Delivery Instructions 
	 Surya				09/03/2021		Updated Contact Emails list from single email to array of emails separated with ;
	 */
	define(['N/record', 'N/search', 'N/https'],

	    function (record, search, https) {

	    /**
	     * Function definition to be triggered before record is loaded.
	     *
	     * @param {Object} scriptContext
	     * @param {Record} scriptContext.newRecord - New record
	     * @param {string} scriptContext.type - Trigger type
	     * @param {Form} scriptContext.form - Current form
	     * @Since 2015.2
	     */
	    function beforeLoad(scriptContext) {}

	    /**
	     * Function definition to be triggered before record is loaded.
	     *
	     * @param {Object} scriptContext
	     * @param {Record} scriptContext.newRecord - New record
	     * @param {Record} scriptContext.oldRecord - Old record
	     * @param {string} scriptContext.type - Trigger type
	     * @Since 2015.2
	     */
	    function beforeSubmit(scriptContext) {
			try{
				var ifRec = scriptContext.newRecord;
	
					var ifLineCount = ifRec.getLineCount({
						sublistId: 'item'
					});
					
					var idSO = ifRec.getValue({
						fieldId: 'createdfrom' 
					}); 
					
					var soRec = record.load({
						id: idSO,
						type: record.Type.SALES_ORDER
					});
					var _customer = soRec.getValue({
						fieldId: 'entity' 
					}); 
					if(_customer)
					{
						var ETA =  ifRec.getValue({
									fieldId: 'custbody_dil_so_order_delivery_date' 
							}); 
						if(ETA=='')
						{
							try{  
								var deliveryzone = _searchForCustomerDeliveryZone(_customer);
								log.debug('deliveryzone',deliveryzone);
								var dayindicator = deliveryzone - 1;
								var current_date = new Date();
								var deliverydate = new Date();
								var current_day = current_date.getDay();
								current_date.setDate(current_date.getDate() + 1);
								if (dayindicator > current_day) {
									const newDate = addDays(current_date, (dayindicator - current_day));
									deliverydate = newDate;
									//deliverydate.setDate(current_date.getDate() + (dayindicator - current_day));
								} else {
									deliverydate.setDate(current_date.getDate() + (7 + dayindicator - current_day));
								}
								ifRec.setValue({fieldId: 'custbody_dil_so_order_delivery_date',value: deliverydate});
							}catch(e)
							{
								log.debug('Error in setting ETA',e.toString());
							}
						}
						
					}
					var soLineCount = soRec.getLineCount({
						sublistId: 'item'
					});
					
					var arrQty = new Array();
					var arrItemId = new Array();
					var arrQtyFulfilled = new Array();
					for(var x = 0; x < soLineCount ; x++){
						arrQty.push(soRec.getSublistValue({
							sublistId: 'item',
							fieldId: 'quantity',
							line: x
						}));
						arrQtyFulfilled.push(soRec.getSublistValue({
							sublistId: 'item',
							fieldId: 'quantityfulfilled',
							line: x
						}));
						
						arrItemId.push(soRec.getSublistValue({
							sublistId: 'item',
							fieldId: 'item',
							line: x
						}));
					}
					log.debug('arrQtyFulfilled',arrQtyFulfilled)
					for(var i = 0; i < ifLineCount; i++){
						var itemId = ifRec.getSublistValue({
							sublistId: 'item',
							fieldId: 'item',
							line: i
						});
						var _quantity = ifRec.getSublistValue({
							sublistId: 'item',
							fieldId: 'quantity',
							line: i
						});
						var soLineItem = arrItemId.indexOf(itemId)
						if(soLineItem != -1){
							ifRec.setSublistValue({
								sublistId: 'item',
								fieldId: 'custcol_quantity_ordered',
								line: i,
								value: arrQty[soLineItem]
							});
							ifRec.setSublistValue({
								sublistId: 'item',
								fieldId: 'custcol_quantityfulfilled',
								line: i,
								value: arrQtyFulfilled[soLineItem]
							});
							ifRec.setSublistValue({
								sublistId: 'item',
								fieldId: 'custcol_quantity_remaining',
								line: i,
								value: (arrQty[soLineItem]-_quantity)
							});  
							arrItemId.splice(soLineItem, 1);
							arrQty.splice(soLineItem, 1);
							arrQtyFulfilled.splice(soLineItem, 1);
						}
					}
			}catch(e)
			{
				log.debug('Error in before submit',e.toString());
			}
			
		}

	    /**
	     * Function definition to be triggered before record is loaded.
	     *
	     * @param {Object} scriptContext
	     * @param {Record} scriptContext.newRecord - New record
	     * @param {Record} scriptContext.oldRecord - Old record
	     * @param {string} scriptContext.type - Trigger type
	     * @Since 2015.2
	     */
	    function afterSubmit(scriptContext) {
	        try {

	            var type = scriptContext.newRecord.type;
	            var recid = scriptContext.newRecord.id;
				log.debug('recid',recid);
				var pickupstatus='';
				var objrecord = record.load({type:type,id:recid,isDynamic:!0});
	            var customer = objrecord.getText({
	                fieldId: 'entity'
	            });
	            var orderNumber = objrecord.getValue({
	                fieldId: 'tranid'
	            });
				var shipstatus = objrecord.getValue({
	                fieldId: 'shipstatus'
	            });
				if(type=='storepickupfulfillment')
				{
					pickupstatus = objrecord.getValue({
						fieldId: 'pickupstatus'
					}); 
				}
				
				var is_bizspeed_req_sent = objrecord.getValue({
	                fieldId: 'custbody_is_bizspeed_req_sent'
	            });
				var shipmethod = objrecord.getValue({
	                fieldId: 'shipmethod'
	            });
				var memoInstructions = objrecord.getValue({
	                fieldId: 'memo'
	            });
				log.debug('!is_bizspeed_req_sent',!is_bizspeed_req_sent);
				log.debug('shipstatus',shipstatus);
	            var itemCount = objrecord.getLineCount({
	                sublistId: 'item'
	            });
				var _IFData;
				if(shipstatus=='B' && !is_bizspeed_req_sent ) //&&shipmethod==2
				{
					 _IFData= itemFulfillmentData(recid);
					  for(var i=0;i<itemCount;i++){
						 var lineData ={};
							var item = objrecord.getSublistValue({sublistId:'item',fieldId:'item',line:i});
							var itemDesc = objrecord.getSublistValue({sublistId:'item',fieldId:'itemdescription',line:i});
							var itemname = objrecord.getSublistValue({sublistId:'item',fieldId:'itemname',line:i});
							var rate = objrecord.getSublistValue({sublistId:'item',fieldId:'itemunitprice',line:i});
							var unit = objrecord.getSublistValue({sublistId:'item',fieldId:'unitsdisplay',line:i});
							var orderline = objrecord.getSublistValue({sublistId:'item',fieldId:'orderline',line:i});
							var quantity = objrecord.getSublistValue({sublistId:'item',fieldId:'quantity',line:i});
							var linememo = objrecord.getSublistValue({sublistId:'item',fieldId:'custcolzdo_linememodisp',line:i});
							lineData.item = item;
							lineData.itemDesc =itemDesc;
							lineData.itemDisplayname = itemname;
							lineData.itemSalesDesc=itemDesc;
							lineData.rate = rate;
							lineData.unit = unit;
							lineData.linesequencenumber = orderline;
							lineData.quantity =quantity;
							lineData.taxamount = '';
							lineData.linememo = linememo;
							_IFData.push(lineData);
							log.debug('linememo',linememo)
							/* lineData.itemSalesDesc = result.getValue({ name: "salesdescription",join: "item" }); */
						}
				}else if(pickupstatus=='A'&& !is_bizspeed_req_sent){
					_IFData = storeFulfillmentData(recid);
					for(var i=0;i<itemCount;i++){
						 var lineData ={};
							var item = objrecord.getSublistValue({sublistId:'item',fieldId:'item',line:i});
							var itemDesc = objrecord.getSublistValue({sublistId:'item',fieldId:'itemdescription',line:i});
							var itemname = objrecord.getSublistValue({sublistId:'item',fieldId:'itemname',line:i});
							var rate = objrecord.getSublistValue({sublistId:'item',fieldId:'itemunitprice',line:i});
							var unit = objrecord.getSublistValue({sublistId:'item',fieldId:'unitsdisplay',line:i});
							var orderline = objrecord.getSublistValue({sublistId:'item',fieldId:'orderline',line:i});
							var quantity = objrecord.getSublistValue({sublistId:'item',fieldId:'quantity',line:i});
							var linememo = objrecord.getSublistValue({sublistId:'item',fieldId:'custcolzdo_linememodisp',line:i});
							lineData.item = item;
							lineData.itemDesc =itemDesc;
							lineData.itemDisplayname = itemname;
							lineData.itemSalesDesc=itemDesc;
							lineData.rate = rate;
							lineData.unit = unit;
							lineData.linesequencenumber = orderline;
							lineData.quantity =quantity;
							lineData.taxamount = '';
							lineData.linememo = linememo;
							_IFData.push(lineData);
							log.debug('linememo',linememo)
							/* lineData.itemSalesDesc = result.getValue({ name: "salesdescription",join: "item" }); */
						}
				}
				log.debug('_IFData',_IFData);
				var emails=[];var _primaryContact='';var isCODReq=false;
				if(_IFData[0].customer!='')
				{
					var contactDetails = contactEmail(_IFData[0].customer);
					var customerTermsObj = search.lookupFields({type:'customer',id:_IFData[0].customer,columns:['terms']});
					var terms =customerTermsObj.terms.length>0?customerTermsObj.terms[0].value:'';
					isCODReq=false;
					if(terms==19)//COD
					{
						isCODReq=true; 
					}
					emails = contactDetails.contactEmails;
					_primaryContact = contactDetails.primaryContact;
				}
					
					
					
					//var _primaryContact = customerEmail(_IFData[0].customer);
					var _orderData = objectMaking(_IFData, orderNumber, customer,emails,isCODReq,memoInstructions,_primaryContact)
					log.debug('_orderData',_orderData);
						var orderData = {
						"msg": {
							"module": "SS2.MobileHub.Classes.SyncMobileHelpers.api3PLexternal",
							"opcode": "AddUpdateOrdersWithoutTrips",
							"status": null,
							"messageData": {
								"Orders": _orderData
							},
							"authToken": {
								"UserName": "netsuite_api",
								"Password": "sWWHpW5viOwP",
								"CompanyCode": "dilmar",
								"CryptoKey": null,
								"OrgRefId": "00000000-0000-0000-0000-000000000000",
								"UserRefId": "00000000-0000-0000-0000-000000000000"
							},
							"clockTimeInUTC": "2018-06-29T18:24:42.0977793Z"
						}
					};

					var createProduct = postOrderData(orderData);
					var bizstatusObj = JSON.parse(createProduct.body);
					var bizstatus = bizstatusObj.d.status;
					if(bizstatus=="OK")
					{
						var stringifyData = JSON.stringify(_orderData);
						//,custbody_ns_payload_to_bizspeed:stringifyData
						record.submitFields({type:type,id:recid,values:{custbody_is_bizspeed_req_sent:true},options:{enableSourcing:!1,ignoreMandatoryFields:!0}});
					}else{
						var stringifyData = JSON.stringify(_orderData);
						//record.submitFields({type:type,id:recid,values:{custbody_ns_payload_to_bizspeed:stringifyData},options:{enableSourcing:!1,ignoreMandatoryFields:!0}});
					
					}
				
	            
	        } catch (e) {
	            log.debug('Error in Main', e.toString());
	        }
	    } //function close


	    function postOrderData(OrderData) {
	        try {
	            var _bizspeed_url = 'https://mh-est.goroam.com/SyncMobileSuiteJSON.asmx/BrokerMessageJSON';

	            var headersbizspeed = {
	                'content-type': 'application/json'
	            };
	            var response = https.request({
	                method: https.Method.POST,
	                url: _bizspeed_url,
	                body: JSON.stringify(OrderData),
	                headers: headersbizspeed
	            });
	            log.debug('OrderData response', response)
	            return response;

	        } catch (e) {
	            log.debug('Error in postOrderData', e.toString());
	        }
	    }
	    function itemFulfillmentData(id) {
	        try {
				log.debug('recid in itemFulfillmentData',id);
	            var itemfulfillmentSearchObj = search.create({
	                type: "itemfulfillment",
	                filters:
	                [
	                    ["type", "anyof", "ItemShip"],
	                    "AND",
	                    ["status", "anyof", "ItemShip:B"],
	                    "AND",
	                      ["internalid","anyof",id], 
						  "AND", 
						  ["mainline","is","F"], 
						   "AND", 
						  ["accounttype","anyof","COGS"], 
						  "AND", 
						["custbody_drop_ship_order","is","F"] 
						  /* , 
						  "AND", 
						  ["shipmethod","anyof","2"] */
	                ],
	                columns:
	                [
	                    "createdfrom",
	                    "tranid",
	                    "entity",
						"memo",
	                    "shipaddress1",
	                    "shipaddress2",
	                    "shipcity",
	                    "shipstate",
	                    "shipzip",
	                    "billaddress1",
	                    "billaddress2",
	                    "billcity",
	                    "billstate",
	                    "billzip",
	                    "item",
	                    "rate",
	                    "unit",
	                    "linesequencenumber",
	                    "quantity",
	                    "taxamount",
						"location",
						"trandate",
						"custbody_dil_so_order_delivery_date",
						"shipmethod",
						//"custbody_dil_salesmandelivery",
						//"custbody_dil_commoncarrier",
						"custcolzdo_linememo",
	                    search.createColumn({
	                        name: "ordertype",
	                        sort: search.Sort.ASC
	                    }),
	                    "otherrefnum",
	                    search.createColumn({
	                        name: "internalid",
	                        join: "shippingAddress"
	                    }),
	                    search.createColumn({
	                        name: "internalid",
	                        join: "billingAddress"
	                    }),
						 search.createColumn({
							 name: "displayname",
							 join: "item"
						  }),
						search.createColumn({
						 name: "salesdescription",
						 join: "item"
					  }),
					  search.createColumn({
						 name: "terms",
						 join: "appliedToTransaction"
					  }),
					  search.createColumn({
						 name: "custentity1",
						 join: "customer"
					  }),
					  search.createColumn({
						 name: "accountnumber",
						  join: "customer"
					  }),
					  search.createColumn({
						 name: "otherrefnum",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "memomain",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "custbody_ntd_shell_delivery_notes",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "custbody_bol_delivery_instructions",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "custcolzdo_linememo",
						 join: "appliedToTransaction"
					  })
	                ]
	            });
	            var searchResultCount = itemfulfillmentSearchObj.runPaged().count;
				log.debug('searchResultCount in itemFulfillmentData', searchResultCount);
	            var arr = [];
	            var bodyData = {};
	            var counter = 0;
	            itemfulfillmentSearchObj.run().each(function (result) {
	                // .run().each has a limit of 4,000 results
	                var lineData = {};
	                if (counter == 0) {
	                    bodyData.createdfrom = result.getValue({
	                        name: 'createdfrom'
	                    });
						bodyData.createdfromText = result.getText({
	                        name: 'createdfrom'
	                    });
	                    bodyData.docnumber = result.getValue({
	                        name: 'tranid'
	                    });
						bodyData.memo = result.getValue({
	                        name: 'memo'
	                    });
						bodyData.somemo = result.getValue({
							 name: "memomain",
							 join: "createdFrom"
						  });
						bodyData.shell_delivery_notes = result.getValue({
							 name: "custbody_ntd_shell_delivery_notes",
							 join: "createdFrom"
						  });
						bodyData.delivery_instructions = result.getValue({
							 name: "custbody_bol_delivery_instructions",
							 join: "createdFrom"
						  });
						bodyData.shipmethod = result.getText({
	                        name: 'shipmethod'
	                    });
	                    bodyData.customer = result.getValue({
	                        name: 'entity'
	                    }); 
						bodyData.location = result.getText({
	                        name: 'location'
	                    });
						bodyData.trandate = result.getValue({
	                        name: 'trandate'
	                    });
						bodyData.delivery_date = result.getValue({
	                        name: 'custbody_dil_so_order_delivery_date'
	                    });
	                    bodyData.shipaddress1 = result.getValue({
	                        name: 'shipaddress1'
	                    });
	                    bodyData.shipaddress2 = result.getValue({
	                        name: 'shipaddress2'
	                    });
	                    bodyData.shipcity = result.getValue({
	                        name: 'shipcity'
	                    });
	                    bodyData.shipstate = result.getValue({
	                        name: 'shipstate'
	                    });
	                    bodyData.shipzip = result.getValue({
	                        name: 'shipzip'
	                    });
	                    bodyData.billaddressee = result.getValue({
	                        name: 'billaddressee'
	                    });
	                    bodyData.billaddress1 = result.getValue({
	                        name: 'billaddress1'
	                    });
	                    bodyData.billaddress2 = result.getValue({
	                        name: 'billaddress2'
	                    });
	                    bodyData.billcity = result.getValue({
	                        name: 'billcity'
	                    });
	                    bodyData.billstate = result.getValue({
	                        name: 'billstate'
	                    });
	                    bodyData.billzip = result.getValue({
	                        name: 'billzip'
	                    });
	                    bodyData.otherrefnum = result.getValue({
	                        name: 'otherrefnum'
	                    });
						bodyData.sootherrefnum = result.getValue({
						 name: "otherrefnum",
						 join: "createdFrom"
					  });
	                    bodyData.ordertype = result.getText({
	                        name: 'ordertype'
	                    }); 
						/*bodyData.commoncarrier = result.getValue({
	                        name: 'custbody_dil_commoncarrier'
	                    });
						bodyData.salesmandelivery = result.getValue({
	                        name: 'custbody_dil_salesmandelivery'
	                    });*/
	                    bodyData.shipId = result.getValue({
	                        name: "internalid",
	                        join: "shippingAddress"
	                    });
	                    bodyData.billId = result.getValue({
	                        name: "internalid",
	                        join: "billingAddress"
	                    });
						bodyData.terms = result.getValue( {
							 name: "terms",
							 join: "appliedToTransaction"
						  });
						bodyData.customerType = result.getText( {
							 name: "custentity1",
							 join: "customer"
						  });
						  bodyData.accountnumber = result.getValue( {
							 name: "accountnumber",
							 join: "customer"
						  });
						  
	                    arr.push(bodyData);
	                    counter++;
	                }
	               /*  lineData.item = result.getValue({
	                    name: 'item'
	                });
	                lineData.itemDesc = result.getText({
	                    name: 'item'
	                });
					lineData.itemDisplayname = result.getValue({
						 name: "displayname",
						 join: "item"
					  });
					 lineData.itemSalesDesc = result.getValue({
						 name: "salesdescription",
						 join: "item"
					  });
	                lineData.rate = result.getValue({
	                    name: 'rate'
	                });
	                lineData.unit = result.getValue({
	                    name: 'unit'
	                });
	                lineData.linesequencenumber = result.getValue({
	                    name: 'linesequencenumber'
	                });
	                lineData.quantity = result.getValue({
	                    name: 'quantity'
	                });
					lineData.linememo = result.getValue({
						 name: "custcolzdo_linememo",
						 join: "appliedToTransaction"
					  });
					log.debug('lineData.linememo ',lineData.linememo );
	                lineData.taxamount = result.getValue({
	                    name: 'taxamount'
	                });
	                arr.push(lineData); */
	                return true;
	            });
	            return arr;
	        } catch (e) {
	            log.debug('Error in itemfulfillmentSearchObj', e.toString());
	        }
	    }
	    function storeFulfillmentData(id) {
	        try {
	            var storepickupfulfillmentSearchObj = search.create({
				   type: "storepickupfulfillment",
				   filters:
				   [
					  ["type","anyof","StPickUp"], 
					  "AND", 
					  ["status","anyof","StPickUp:A"], 
					  "AND", 
					  ["mainline","is","F"], 
					  "AND", 
					  ["accounttype","anyof","COGS"], 
					  "AND", 
					  ["internalid","anyof",id]
				   ],
				   columns:
				   [
					  "createdfrom",
					  "tranid",
					  "entity",
					  "memomain",
					  "shipaddress1",
					  "shipaddress2",
					  "shipcity",
					  "shipstate",
					  "shipzip",
					  "billaddress1",
					  "billaddress2",
					  "billcity",
					  "billstate",
					  "billzip",
					  "item",
					  "rate",
					  "unit",
					  "linesequencenumber",
					  "quantity",
					  "taxamount",
					  "location",
					  "trandate",
					  "custbody_dil_so_order_delivery_date",
					  "custcolzdo_linememo",
					  search.createColumn({
						 name: "ordertype",
						 sort: search.Sort.ASC
					  }),
					  "otherrefnum",
					  search.createColumn({
						 name: "internalid",
						 join: "shippingAddress"
					  }),
					  search.createColumn({
						 name: "internalid",
						 join: "billingAddress"
					  }),
					  search.createColumn({
						 name: "displayname",
						 join: "item"
					  }),
					  search.createColumn({
						 name: "salesdescription",
						 join: "item"
					  }),
					  search.createColumn({
						 name: "custentity1",
						 join: "customer"
					  }),
					  search.createColumn({
						 name: "terms",
						 join: "customer"
					  }),
					  search.createColumn({
						 name: "accountnumber",
						  join: "customer"
					  }), 
					  search.createColumn({
						 name: "address1",
						 join: "location"
					  }),
					  search.createColumn({
						 name: "address2",
						 join: "location"
					  }),
					  search.createColumn({
						 name: "city",
						 join: "location"
					  }),
					  search.createColumn({
						 name: "phone",
						 join: "location"
					  }),
					  search.createColumn({
						 name: "state",
						 join: "location"
					  }),
					  search.createColumn({
						 name: "zip",
						 join: "location"
					  }),
					  search.createColumn({
						 name: "otherrefnum",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "memomain",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "custbody_ntd_shell_delivery_notes",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "custbody_bol_delivery_instructions",
						 join: "createdFrom"
					  }),
					  search.createColumn({
						 name: "custcolzdo_linememo",
						 join: "appliedToTransaction"
					  })
				   ]
				});
				var searchResultCount = storepickupfulfillmentSearchObj.runPaged().count;
				log.debug("storepickupfulfillmentSearchObj result count",searchResultCount);
				var arr = [];
	            var bodyData = {};
	            var counter = 0;
				 
	            storepickupfulfillmentSearchObj.run().each(function (result) {
	                // .run().each has a limit of 4,000 results
	                var lineData = {};
	                if (counter == 0) {
	                    bodyData.createdfrom = result.getValue({
	                        name: 'createdfrom'
	                    });
						bodyData.createdfromText = result.getText({
	                        name: 'createdfrom'
	                    });
	                    bodyData.docnumber = result.getValue({
	                        name: 'tranid'
	                    });
						bodyData.memo = result.getValue({
	                        name: 'memomain'
	                    });
						bodyData.somemo = result.getValue({
							 name: "memomain",
							 join: "createdFrom"
						  });
						bodyData.shell_delivery_notes = result.getValue({
							 name: "custbody_ntd_shell_delivery_notes",
							 join: "createdFrom"
						  });
						bodyData.delivery_instructions = result.getValue({
							 name: "custbody_bol_delivery_instructions",
							 join: "createdFrom"
						  });
						 
	                    bodyData.customer = result.getValue({
	                        name: 'entity'
	                    }); 
						bodyData.location = result.getText({
	                        name: 'location'
	                    });
						bodyData.trandate = result.getValue({
	                        name: 'trandate'
	                    });
						bodyData.delivery_date = result.getValue({
	                        name: 'custbody_dil_so_order_delivery_date'
	                    });
	                    bodyData.shipaddress1 = result.getValue({
							 name: "address1",
							 join: "location"
						  });
	                    bodyData.shipaddress2 = result.getValue({
							 name: "address2",
							 join: "location"
						  });
	                    bodyData.shipcity = result.getValue({
							 name: "city",
							 join: "location"
						  });
	                    bodyData.shipstate = result.getValue({
							 name: "state",
							 join: "location"
						  });
	                    bodyData.shipzip = result.getValue({
							 name: "zip",
							 join: "location"
						  });
	                   
	                    bodyData.billaddress1 = result.getValue({
	                        name: 'billaddress1'
	                    });
	                    bodyData.billaddress2 = result.getValue({
	                        name: 'billaddress2'
	                    });
	                    bodyData.billcity = result.getValue({
	                        name: 'billcity'
	                    });
	                    bodyData.billstate = result.getValue({
	                        name: 'billstate'
	                    });
	                    bodyData.billzip = result.getValue({
	                        name: 'billzip'
	                    });
	                    bodyData.otherrefnum = result.getValue({
	                        name: 'otherrefnum'
	                    });
						bodyData.sootherrefnum = result.getValue({
							 name: "otherrefnum",
							 join: "createdFrom"
						  });
	                    bodyData.ordertype = result.getText({
	                        name: 'ordertype'
	                    });
	                    bodyData.shipId = result.getValue({
	                        name: "internalid",
	                        join: "shippingAddress"
	                    });
	                    bodyData.billId = result.getValue({
	                        name: "internalid",
	                        join: "billingAddress"
	                    });
						 
						bodyData.customerType = result.getText( {
							 name: "custentity1",
							 join: "customer"
						  });
						 bodyData.terms = result.getText( {
								 name: "terms",
								 join: "customer"
							  });
						 bodyData.accountnumber = result.getValue( {
								 name: "accountnumber",
								 join: "customer"
							  });
					    bodyData.shipmethod = '';
	                    arr.push(bodyData);
	                    counter++;
	                }
	                /* lineData.item = result.getValue({
	                    name: 'item'
	                });
	                lineData.itemDesc = result.getText({
	                    name: 'item'
	                });
					lineData.itemDisplayname = result.getValue({
						 name: "displayname",
						 join: "item"
					  });
					 lineData.itemSalesDesc = result.getValue({
						 name: "salesdescription",
						 join: "item"
					  });
	                lineData.rate = result.getValue({
	                    name: 'rate'
	                });
	                lineData.unit = result.getValue({
	                    name: 'unit'
	                });
	                lineData.linesequencenumber = result.getValue({
	                    name: 'linesequencenumber'
	                });
	                lineData.quantity = result.getValue({
	                    name: 'quantity'
	                });
					lineData.linememo = result.getValue({
						 name: "custcolzdo_linememo",
						 join: "appliedToTransaction"
					  });
	                lineData.taxamount = result.getValue({
	                    name: 'taxamount'
	                });
	                arr.push(lineData); */
	                return true;
	            });
	            return arr;
	        } catch (e) {
	            log.debug('Error in itemfulfillmentSearchObj', e.toString());
	        }
	    }
	    
		function objectMaking(_IFData, orderNumber, customer,emails,isCODReq,memoInstructions,_primaryContact) {
	        try {
	            var arr = [];
					   if(_IFData.length)
					   {
						   var obj = {
								"startTimeUtcString": new Date().toISOString(),
								"endTimeUtcString": new Date().toISOString(),
								"tripCode": null,
								"orderNo": orderNumber,
								"orderType": _IFData[0].ordertype,
								"instructions":_IFData[0].somemo+" "+_IFData[0].shell_delivery_notes+" "+_IFData[0].delivery_instructions,//memoInstructions ,
								"customerName": customer,
								"accountNo": _IFData[0].shipId||_IFData[0].accountnumber,
								"alternateOrdNumber": _IFData[0].sootherrefnum,
								"stopId": null,
								"parentAcctNo": "133073",
								"shipAddress1": _IFData[0].shipaddress1,
								"shipAddress2": _IFData[0].shipaddress2,
								"shipCity": _IFData[0].shipcity,
								"shipState": _IFData[0].shipstate,
								"shipZip": _IFData[0].shipzip,
								"billName": _IFData[0].billaddressee,
								"billingAddress1": _IFData[0].billaddress1,
								"billingAddress2": _IFData[0].billaddress2,
								"billCity": _IFData[0].billcity,
								"billState": _IFData[0].billstate,
								"billZip": _IFData[0].billzip,
								"customerLatitude": 0,
								"customerLongitude": 0,
								"isRequiredCod": isCODReq,
								"Eta": new Date(_IFData[0].delivery_date),
								"Etd": new Date(_IFData[0].delivery_date),//minutesToAdd(_IFData[0].delivery_date),
								"Timezone": null,
								"email": emails.join(';'),//emails.length>0?emails.join(';'):null,
								"phone": "",
								"releaseNo": _IFData[0].createdfromText,
								"contact": _primaryContact,
								"customerType": _IFData[0].customerType,
								"servicedByDepotID": _IFData[0].location,
								"ShipVia":_IFData[0].shipmethod||''
						   };
								var lineAr = [];
							for (var i = 1; i < _IFData.length; i++) {
							   var lineObj = {
										"orderNo": orderNumber,
										"itemID": _IFData[i].itemDisplayname,
										"itemDescription": _IFData[i].itemSalesDesc|| _IFData[i].itemDesc,
										"UOM": _IFData[i].unit,
										"VendorName": null,
										"lineNum": _IFData[i].linesequencenumber,
										"customerItemID":_IFData[i].itemDisplayname,
										"customerItemDescription": _IFData[i].itemSalesDesc||_IFData[i].itemDesc,
										"itemGroupName": null,
										"itemSubGroupName": null,
										"orderQty": _IFData[i].quantity,
										"taxRate": 0,
										"itemPrice": isCODReq==false?(_IFData[i].rate||0):0,//_IFData[i].rate||0,
										"actionId": 0,
										"lineNotes": _IFData[i].linememo
									};
								lineAr.push(lineObj);	
							}
							obj.Details=lineAr;
							 arr.push(obj);
					   }
	                 
	            return arr;

	        } catch (e) {
	            log.debug('Error in object Making', e.toString());
	        }
	    }
	    function loadItemFulfillment(id)
		{
			try{
				 
			}catch(e)
			{
				log.debug('Error in loadItemFulfillment', e.toString());
			}
		}
		function minutesToAdd(date)
		{
			log.debug('date',date);
			/* if(date=='' || date==undefined)
			{
				var _date = date;
				var d = new Date();
				log.debug('d',d);
				d.setMinutes(30); //390//6:30 hrs
				return d;
				
			}else{ */
				var _date = date;
				var d = new Date(_date);
				log.debug('d',d);
				d.setMinutes(30); //390//6:30 hrs
				return d;
			//}
			 
			
		}
		function contactEmail(customer)
		{
			try{
				log.debug('customer',customer);
				var contactSearchObj = search.create({
				   type: "contact",
				   filters:
				   [
					  // ["parentcustomer.entityid","haskeywords","123 That Hurts EMS"], 
					  ["parentcustomer.internalid","anyof",customer],
					  "AND", 
					  ["isinactive","is","F"], 
					  "AND", 
					  ["email","isnotempty",""] ,
					  "AND", 
					["custentity_dil_send_pod_to_contact","is","T"]  
					  
				   ],
				   columns:
				   [
					  search.createColumn({
						 name: "entityid",
						 sort: search.Sort.ASC
					  }),
					  "email",
					  "phone",
					  "altphone",
					  "fax",
					  "company",
					  "altemail"
				   ]
				});
				/* var searchResultCount = contactSearchObj.runPaged().count;
				log.debug("contactSearchObj result count",searchResultCount);
				 */
				 var contactEmails = [];
				var primaryContact='';
				var first =0;
				contactSearchObj.run().each(function(result){
				   // .run().each has a limit of 4,000 results
				  contactEmails.push(result.getValue({name:'email'})) ;
				  if(first==0)
				  {
					  primaryContact=result.getValue({name:'email'})  ;
					  first=1;
				  }
				  
				   return true;
				});
				var obj={};
				obj.contactEmails=contactEmails;
				obj.primaryContact=primaryContact;
				return obj;
			}catch(e)
			{
				log.debug('error in contactEmail',e.toString())
			}
		}
		function customerEmail(customer)
		{
			try{
				var customerSearchObj = search.create({
				   type: "customer",
				   filters:
				   [
					  ["internalid","anyof",customer],
					  "AND", 
					  ["isinactive","is","F"], 
					  "AND", 
					  ["email","isnotempty",""]
				   ],
				   columns:
				   [
					  "email"
				   ]
				});
				/* var searchResultCount = customerSearchObj.runPaged().count;
				log.debug("customerSearchObj result count",searchResultCount); */
				var emailId = '';
				customerSearchObj.run().each(function(result){
				   // .run().each has a limit of 4,000 results
				   emailId = result.getValue({name:'email'});
				   return true;
				});
				return emailId;
			}catch(e)
			{
				log.debug('error in customerEmail',e.toString());
			}
		}
		function _searchForCustomerDeliveryZone(customer)
		{
			try{
				var customerSearchObj = search.create({
				   type: "customer",
				   filters:
				   [
					  ["internalid","anyof",customer]
				   ],
				   columns:
				   [
					  search.createColumn({name: "custentity_dil_cust_delivery_zone_day", label: "Delivery Zone"}),
					  search.createColumn({
						 name: "custrecord_dil_cust_addr_del_zone",
						 join: "shippingAddress",
						 label: "Default Delivery Zone"
					  }),
					  search.createColumn({
						 name: "custrecord_dil_cust_addr_del_zone",
						 join: "billingAddress",
						 label: "Default Delivery Zone"
					  })
				   ]
				});
				var searchResultCount = customerSearchObj.runPaged().count;
				log.debug("customerSearchObj result count",searchResultCount);
				var deliveryday='';
				customerSearchObj.run().each(function(result){
				   // .run().each has a limit of 4,000 results
				   deliveryday = result.getValue({ name: "custrecord_dil_cust_addr_del_zone",join: "billingAddress" });
				   if(!deliveryday)
				   {
					   deliveryday = result.getValue({ name: "custrecord_dil_cust_addr_del_zone",join: "shippingAddress" });
				   }
				   return true;
				});
				return deliveryday;
			}catch(e)
			{
				log.debug('Error in search for deliveryzone',e.toString());
			}
		}
		function addDays(date, days) {
		  const copy = new Date(Number(date))
		  copy.setDate(date.getDate() + days)
		  return copy
		}
		return {
	        //  beforeLoad: beforeLoad,
	          beforeSubmit: beforeSubmit,
	        afterSubmit: afterSubmit
	    };

	});