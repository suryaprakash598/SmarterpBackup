/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/search','N/runtime'],

function(record,search,runtime) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
	 
	  var main_location;
    function pageInit(scriptContext) {
    	log.debug('wddwc');
    	var currentRecord = scriptContext.currentRecord;
		main_location = currentRecord.getValue("location");
	return true;

    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
		var currentRecord = scriptContext.currentRecord;
		if (scriptContext.fieldId == 'location'){
		main_location = currentRecord.getValue("location");  
		  
            }

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {
		
    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {
    	

		
    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {
	 
		
    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {
		var recObj = scriptContext.currentRecord;
		var line_location = recObj.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'location'
                });
		if (line_location == '' || line_location == null || line_location == undefined || line_location == 'undefined') {
		var l=recObj.setCurrentSublistValue({
						  sublistId: 'item',
						  fieldId: 'location',
						  value:main_location,
						  ignoreFieldChange: true
						});
		}
       if (scriptContext.sublistId != 'item') return true;
            log.debug('validateline called');
            var currentRecord = scriptContext.currentRecord;
            var item = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'item'
                    });
			 promotioncode = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_promotion_code'
                    });
			try{		
			 if (promotioncode) {
                var customrecord_ns_dilmarpromotionsSearchObj = search.create({
                    type: "customrecord_ns_dilmarpromotions",
                    filters: [
                        ["custrecord_promotion_link", "noneof", "@NONE@"],
                        "AND",
                        ["custrecord_promotion_link.startdate", "onorbefore", "today"],
                        "AND",
                        ["custrecord_promotion_link.enddate", "onorafter", "today"],
                        "AND",
                        ["custrecord_ns_promotionitemtest", "anyof", item],
                        "AND",
                        ["custrecordpcode", "is", promotioncode],
						"AND", 
						["custrecord_promotion_link.isinactive","is","F"]
                    ],
                    columns: [
                        search.createColumn({
                            name: "custrecord_promotion_link",
                            label: "custrecord_promotion_link"
                        })
                    ]
                });
                var searchResultCount = customrecord_ns_dilmarpromotionsSearchObj.runPaged().count;
				 if(searchResultCount<1){
					var message=promotioncode+' is not applicable to this item';
					alert(message);
				return true;
				} 
                log.debug("customrecord_ns_dilmarpromotionsSearchObj result count", searchResultCount);
                customrecord_ns_dilmarpromotionsSearchObj.run().each(function(result) {
                    // .run().each has a limit of 4,000 results
                    var p_internalid = result.getValue({
                        name: "custrecord_promotion_link"
                    });
					var couponcode = result.getText({
                        name: "custrecord_promotion_link"
                    });
                    log.debug('couponcode', couponcode);
					
					
					 var lineNumber = currentRecord.findSublistLineWithValue({
                sublistId: 'promotions',
                fieldId: 'promocode',
                value: p_internalid //'promotion id'
            });
            log.debug('promotion line number',lineNumber);
       
           
                // if promotion is not avalible then add promotion
               
                    if (lineNumber == -1)
                    {
						try {
                       var line = currentRecord.getCurrentSublistIndex({
                        sublistId: 'promotions'
                    });
                    currentRecord.insertLine
                        ({
                            sublistId : 'promotions',
                            line: line
                        });
					
                    var promo = currentRecord.setCurrentSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'promocode',
						line: line,
                        value: p_internalid, 
                        ignoreFieldChange:false,
                        forceSyncSourcing: true
                    });
					//log.debug('coupon code',parseInt(p_internalid)+1);
					  /* var coupon = currentRecord.setCurrentSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'couponcode',
                        value:parseInt(p_internalid), // coupon code
                        ignoreFieldChange:false,
                        forceSyncSourcing: true
                    }); */

                    currentRecord.commitLine({
                        sublistId: 'promotions'
                    });

                    return true;
                        }catch(e)
                        {
                            log.error(' error adding promotion',e.message);
                        }
                    }
					
					
                    
                });
			 }
			}catch(e){
				log.debug('error',e.message);
				return true
			}
			
			// updating approval flag
				var price_level = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'price',
                    });
                   
					if(price_level==-1||price_level==7||price_level==8||price_level==9||price_level==5){
						
				var approval_process = currentRecord.setValue({
					fieldId: 'custbody_quote_approval_process',
					value: true
				});
					}
					return true;

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        /*postSourcing: postSourcing,*/
        //sublistChanged: sublistChanged,
        //lineInit: lineInit,
        //validateField: validateField,
        //
		validateLine: validateLine,
        /*validateInsert: validateInsert,
        validateDelete: validateDelete,
        saveRecord: saveRecord*/
    };
    
});
