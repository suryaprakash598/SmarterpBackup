/*******************************************************************************{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *	Modifications			version				Date				Description
 * @NApiVersion 2.0
 * @NScriptType Suitelet
 *
 ******************************************************************************/
define(['N/runtime', 'N/record', 'N/search', 'N/task', 'N/ui/serverWidget', 'N/redirect'], function (
        /** @type {import('N/runtime')} 		**/
        runtime,
        /** @type {import('N/record')}  		**/
        record,
        /** @type {import('N/search')}  		**/
        search,
        /** @type {import('N/task')}     		**/
        task,
        /** @type {import('N/serverWidget')}  **/
        serverWidget,
        /** @type {import('N/redirect')}  **/
        redirect) {
    /**
     * context.request
     * context.response
     *
     * @type {import('N/types').EntryPoints.Suitelet.onRequest}
     */
    function onRequest(context) {
        try {
            if (context.request.method == 'GET') {
                log.debug('parameters', context.request.parameters);
                var taskid = context.request.parameters.taskid;
                var task_script = context.request.parameters.task;
				
                if (taskid) {
                    var formObj = serverWidget.createForm({
                        title: 'Process EDI Status',
                        hideNavBar: false
                    });
                    var percent = alt(taskid);
                    
                    var percentprocess = formObj.addField({
                        id: 'custpage_process_percent',
                        label: '% process completed',
                        type: serverWidget.FieldType.TEXT
                    });
                    percentprocess.updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.INLINE
                    }).defaultValue = percent.status;
                    var sublist = formObj.addSublist({
                        id: 'custpage_process_edi',
                        label: 'EDI Process Status',
                        type: serverWidget.SublistType.LIST
                    });
                    
                    var sublistField1 = sublist.addField({
                        id: '_salesorder_id',
                        label: 'Document Number',
                        type: serverWidget.FieldType.TEXT 
                    });
                    var sublistField1 = sublist.addField({
                        id: '_file_id',
                        label: 'File',
                        type: serverWidget.FieldType.TEXT 
                    });
                    if (percent.status == 'COMPLETE') {
						if(task_script=='rfd')
						{
							var interid = latestRFDID();
						}else if(task_script=='odc')
						{
							var interid = latestODCID();
						}else if(task_script=='ntd')
						{
							var interid = latestNTDID();
						}else if(task_script=='ocrm')
						{
							var interid = latestOCRMID();
						}else if(task_script=='cfd')
						{
							var interid = latestCFDID();
						}
                        
                        if (interid) {
							if(task_script=='rfd')
							{
								var dataArr = latestRFDData(interid);
							}else if(task_script=='odc')
							{
								var dataArr = latestODCData(interid);
							}else if(task_script=='ntd')
							{
								var dataArr = latestNTDData(interid);
							}else if(task_script=='ocrm')
							{
								var dataArr = latestOCRMData(interid);
							}else if(task_script=='cfd')
							{
								var dataArr = latestCFDData(interid);
							}
                            var counter = 0;
                            
                            var result = dataArr.run().getRange({
                                start: 0,
                                end: 1000
                            })
                                for (var counter = 0; counter < result.length; counter++) {
                                    var res = result[counter]
                                   if(task_script=='rfd')
									{
										 var soid = res.getText({
                                        name: 'custrecord_rfd_document_number'
										});
									}else if(task_script=='odc')
									{
										 var soid = res.getText({
                                        name: 'custrecord_odc_document_number'
										});
									}else if(task_script=='ntd')
									{
										 var soid = res.getText({
                                        name: 'custrecord_ntd_document_number'
										});
									}else if(task_script=='ocrm')
									{
										 var soid = res.getText({
                                        name: 'custrecord_ocrm_document_number'
										});
									}else if(task_script=='cfd')
									{
										 var soid = res.getText({
                                        name: 'custrecord_cfd_document_number'
										});
									}
									
								  log.debug('soid',soid);
                                    var soidtext = soid.split(',');
                                    var filename = res.getValue({
                                        name: 'name',
                                        join: "file",
                                        sort: search.Sort.ASC
                                    });

                                    sublist.setSublistValue({
                                        id: '_salesorder_id',
                                        line: counter,
                                        value: soidtext[counter]
                                    });
                                    sublist.setSublistValue({
                                        id: '_file_id',
                                        line: counter,
                                        value: filename
                                    });

                                } 
                        }
                    }

                    context.response.writePage(formObj);
                } else {
                    var formObj = serverWidget.createForm({
                        title: 'Process EDI',
                        hideNavBar: false
                    });

                    var recidField = formObj.addField({
                        id: 'custpage_process_name',
                        label: 'Choose Process Folder',
                        type: serverWidget.FieldType.SELECT
                    });
                    recidField.addSelectOption({
                        value: '0',
                        text: '--Select--'
                    });
                    recidField.addSelectOption({
                        value: '1134',
                        text: 'OCRM'
                    });
                    recidField.addSelectOption({
                        value: '1130',
                        text: 'NTD'
                    });
                    recidField.addSelectOption({
                        value: '1132',
                        text: 'CFD'
                    });
                    recidField.addSelectOption({
                        value: '1136',
                        text: 'ODC'
                    });
                    recidField.addSelectOption({
                        value: '1128',
                        text: 'RFD'
                    });

                    formObj.addSubmitButton({
                        label: 'Submit'
                    });
                    context.response.writePage(formObj);
                }

            } else {

                log.debug('context.request.parameters', context.request.parameters);
                var folderId = context.request.parameters.custpage_process_name;
                var foldername = context.request.parameters.inpt_custpage_process_name;
                var scriptObj = runtime.getCurrentScript();
 
                var folder = folderId;
                var scriptid = '';
                var deployid = '';
                var obj = {};
                if (foldername.toLowerCase() == 'cfd') { 
                    scriptid = scriptObj.getParameter({
                        name: 'custscript_sut_cfd_scriptid'
                    });
                    deployid = scriptObj.getParameter({
                        name: 'custscript_sut_cfd_deployid'
                    });
                    //obj= {'custscript_cfd_file_id' : fileId};
                } else if (foldername.toLowerCase() == 'ocrm') {

                    scriptid = scriptObj.getParameter({
                        name: 'custscript_sut_ocrm_scriptid'
                    });
                    deployid = scriptObj.getParameter({
                        name: 'custscript_sut_ocrm_deployid'
                    });
                    //obj= {'custscript_ocrm_file_id' : fileId};
                } else if (foldername.toLowerCase() == 'ntd') {
                    scriptid = scriptObj.getParameter({
                        name: 'custscript_sut_ntd_scriptid'
                    });
                    deployid = scriptObj.getParameter({
                        name: 'custscript_sut_ntd_deployid'
                    });
                    //obj= {'custscript_ntd_file_id' : 7559};
                } else if (foldername.toLowerCase() == 'rfd') {
                    scriptid = scriptObj.getParameter({
                        name: 'custscript_sut_rfd_scriptid'
                    });
                    deployid = scriptObj.getParameter({
                        name: 'custscript_sut_rfd_deployid'
                    });
                    //obj= {'custscript_ntd_file_id' : 7559};
                } else if (foldername.toLowerCase() == 'odc') {
                    scriptid = scriptObj.getParameter({
                        name: 'custscript_sut_odc_scriptid'
                    });
                    deployid = scriptObj.getParameter({
                        name: 'custscript_sut_deployid'
                    });
                    //obj= {'custscript_ntd_file_id' : 7559};
                }
                var scheduledScript = task.create({
                    taskType: task.TaskType.SCHEDULED_SCRIPT
                });
                scheduledScript.scriptId = scriptid; //'customscript_dil_edi_shell_cfd';
                scheduledScript.deploymentId = deployid; //'customdeploy_dil_edi_shell_cfd';
                scheduledScript.params = obj;
                var id = scheduledScript.submit();

                log.debug('id', id);
                redirect.toSuitelet({
                    scriptId: 1909,
                    deploymentId: 1,
                    parameters: {
                        'taskid': id,
						'task':foldername.toLowerCase()
                    }
                });

            }
        } catch (e) {
            log.debug('Error', e.toString());
        }
		}                       
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
    function alt(id) {
        return task.checkStatus({
            taskId: id
        });
    }
    function latestRFDID() {
        var customrecord_edi_rfdSearchObj = search.create({
            type: "customrecord_edi_rfd",
            filters:
            [
            ],
            columns:
            [
                search.createColumn({
                    name: "internalid",
                    summary: "MAX"
                })
            ]
        });
        var searchResultCount = customrecord_edi_rfdSearchObj.runPaged().count;
        log.debug("customrecord_edi_rfdSearchObj result count", searchResultCount);
        var internalid = '';
        customrecord_edi_rfdSearchObj.run().each(function (result) {
            // .run().each has a limit of 4,000 results
            internalid = result.getValue({
                name: "internalid",
                summary: "MAX"
            });
            return true;
        });
        return internalid;
    }
	function latestODCID()
	{
		var customrecord_edi_odc_invoiceSearchObj = search.create({
		   type: "customrecord_edi_odc_invoice",
		   filters:
		   [
		   ],
		   columns:
		   [
			  search.createColumn({
				 name: "internalid",
				 summary: "MAX"
			  })
		   ]
		});
		var searchResultCount = customrecord_edi_odc_invoiceSearchObj.runPaged().count;
		log.debug("customrecord_edi_odc_invoiceSearchObj result count",searchResultCount);
		var internalid = '';
		customrecord_edi_odc_invoiceSearchObj.run().each(function(result){
		   // .run().each has a limit of 4,000 results
		   internalid = result.getValue({
                name: "internalid",
                summary: "MAX"
            });
		   return true;
		});
		return internalid;
	}
	function latestNTDID()
	{
		var customrecord_edi_ntd_salesorderSearchObj = search.create({
		   type: "customrecord_edi_ntd_salesorder",
		   filters:
		   [
		   ],
		   columns:
		   [
			  search.createColumn({
				 name: "internalid",
				 summary: "MAX"
			  })
		   ]
		});
		var searchResultCount = customrecord_edi_ntd_salesorderSearchObj.runPaged().count;
		log.debug("customrecord_edi_ntd_salesorderSearchObj result count",searchResultCount);
		var internalid = '';
		customrecord_edi_ntd_salesorderSearchObj.run().each(function(result){
		   // .run().each has a limit of 4,000 results
		   internalid = result.getValue({
                name: "internalid",
                summary: "MAX"
            });
		   return true;
		});
		return internalid;
	}
	function latestOCRMID()
	{
		var customrecord_edi_ocrm_salesorderSearchObj = search.create({
			   type: "customrecord_edi_ocrm_salesorder",
			   filters:
			   [
			   ],
			   columns:
			   [
				  search.createColumn({
					 name: "internalid",
					 summary: "MAX"
				  })
			   ]
			});
			var searchResultCount = customrecord_edi_ocrm_salesorderSearchObj.runPaged().count;
			log.debug("customrecord_edi_ocrm_salesorderSearchObj result count",searchResultCount);
			var internalid = '';
			customrecord_edi_ocrm_salesorderSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
				internalid = result.getValue({
					name: "internalid",
					summary: "MAX"
				});
			   return true;
			});
		 
		return internalid;
	}
    function latestCFDID()
	{
		var customrecord_edi_cfd_paymentSearchObj = search.create({
			   type: "customrecord_edi_cfd_payment",
			   filters:
			   [
			   ],
			   columns:
			   [
				  search.createColumn({
					 name: "internalid",
					 summary: "MAX"
				  })
			   ]
			});
			var searchResultCount = customrecord_edi_cfd_paymentSearchObj.runPaged().count;
			log.debug("customrecord_edi_cfd_paymentSearchObj result count",searchResultCount);
			var internalid = '';
			customrecord_edi_cfd_paymentSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
			   internalid = result.getValue({
					name: "internalid",
					summary: "MAX"
				});
			   return true;
			});
			 
		return internalid;
	}
    function latestRFDData(id) {
        var customrecord_edi_rfdSearchObj = search.create({
            type: "customrecord_edi_rfd",
            filters:
            [
                ["internalid", "anyof", id]
            ],
            columns:
            [
                "custrecord_rfd_document_number",
                search.createColumn({
                    name: "name",
                    join: "file",
                    sort: search.Sort.ASC
                })
            ]
        });
        var searchResultCount = customrecord_edi_rfdSearchObj.runPaged().count;
        log.debug("customrecord_edi_rfdSearchObj result count", searchResultCount);
        return customrecord_edi_rfdSearchObj;
        var arr = [];
        customrecord_edi_rfdSearchObj.run().each(function (result) {
            // .run().each has a limit of 4,000 results
            var obj = {};
            obj.soid = result.getValue({
                name: 'custrecord_rfd_document_number'
            });
            obj.filename = result.getValue({
                name: 'name',
                join: "file"
            });
            arr.push(obj);
            return true;
        });
        return arr;
    }
	function latestODCData(id)
	{
		var customrecord_edi_odc_invoiceSearchObj = search.create({
		   type: "customrecord_edi_odc_invoice",
		   filters:
		   [
		   ["internalid", "anyof", id]
		   ],
		   columns:
		   [
			  "custrecord_odc_document_number",
			  search.createColumn({
				 name: "name",
				 join: "file"
			  })
		   ]
		});
		var searchResultCount = customrecord_edi_odc_invoiceSearchObj.runPaged().count;
		log.debug("customrecord_edi_odc_invoiceSearchObj result count",searchResultCount);
		return customrecord_edi_odc_invoiceSearchObj;
		customrecord_edi_odc_invoiceSearchObj.run().each(function(result){
		   // .run().each has a limit of 4,000 results
		   return true;
		});
	}
    function latestNTDData(id)
	{
		 var customrecord_edi_ntd_salesorderSearchObj = search.create({
			   type: "customrecord_edi_ntd_salesorder",
			   filters:
			   [
				  ["internalid","anyof",id]
			   ],
			   columns:
			   [
				  "custrecord_ntd_document_number",
				  search.createColumn({
					 name: "name",
					 join: "file"
				  })
			   ]
			});
			var searchResultCount = customrecord_edi_ntd_salesorderSearchObj.runPaged().count;
			log.debug("customrecord_edi_ntd_salesorderSearchObj result count",searchResultCount);
			return customrecord_edi_ntd_salesorderSearchObj;
			customrecord_edi_ntd_salesorderSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
			   return true;
			});
	}
    function latestOCRMData(id)
	{
		 var customrecord_edi_ocrm_salesorderSearchObj = search.create({
			   type: "customrecord_edi_ocrm_salesorder",
			   filters:
			   [
				["internalid","anyof",id]
			   ],
			   columns:
			   [
				  "custrecord_ocrm_document_number",
				  search.createColumn({
					 name: "name",
					 join: "file"
				  })
			   ]
			});
			var searchResultCount = customrecord_edi_ocrm_salesorderSearchObj.runPaged().count;
			log.debug("customrecord_edi_ocrm_salesorderSearchObj result count",searchResultCount);
			return customrecord_edi_ocrm_salesorderSearchObj;
			customrecord_edi_ocrm_salesorderSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
			   return true;
			});
	}
    function latestCFDData(id)
	{
		var customrecord_edi_cfd_paymentSearchObj = search.create({
		   type: "customrecord_edi_cfd_payment",
		   filters:
		   [
		   ["internalid","anyof",id]
		   ],
		   columns:
		   [
			  "custrecord_cfd_document_number",
			  search.createColumn({
				 name: "name",
				 join: "file"
			  })
		   ]
		});
		var searchResultCount = customrecord_edi_cfd_paymentSearchObj.runPaged().count;
		log.debug("customrecord_edi_cfd_paymentSearchObj result count",searchResultCount);
		return customrecord_edi_cfd_paymentSearchObj;
		customrecord_edi_cfd_paymentSearchObj.run().each(function(result){
		   // .run().each has a limit of 4,000 results
		   return true;
		});
	}
    return {
        'onRequest': onRequest
    };
});