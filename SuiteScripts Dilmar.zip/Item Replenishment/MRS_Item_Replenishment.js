/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 */
 define(['N/runtime', 'N/record', 'N/file'], function(runtime, record, file) {

    var SCRIPT_PARAMETER_FIELD = 'custscript_parameters';

    const REPLENISHMENT_STATUS = {};
    REPLENISHMENT_STATUS.RECORD_ID = 'customrecord_replenishment_status';
    REPLENISHMENT_STATUS.STATUS = 'custrecord_processing_status';
    REPLENISHMENT_STATUS.NOTE = "custrecord_status_note";
    REPLENISHMENT_STATUS.KEY = 'custrecord_unique_key';
    REPLENISHMENT_STATUS.TRAN_ID = 'custrecord_transaction_id';
    REPLENISHMENT_STATUS.ITEM = 'custrecord_item_stat';
    REPLENISHMENT_STATUS.QTY = 'custrecord_replenishment_qty';
    REPLENISHMENT_STATUS.UNIQUE_ID = 'custrecord_unique_id_stat';

    const STATUS = {};
    STATUS.SUCCESS = 1;
    STATUS.ERROR = 2;

    function getInputData() {
        
        var script = runtime.getCurrentScript()
        var fileId = script.getParameter({name: SCRIPT_PARAMETER_FIELD});
        if(fileId){
            var fileObj = file.load({id: fileId });
            if (fileObj.size < 10485760){
                var data = fileObj.getContents();
            }

        }
        var jsonData = JSON.parse(data);
        log.debug('passed parameters', jsonData);
        
        return jsonData ;
    }

    function map(context) {
        log.debug('context', context);
        var lineValue = JSON.parse(context.value);
        if(lineValue.recordtype == "1"){
            // Transfer Order
            log.debug('Transfer Order', lineValue);
            try {
                
                var recordObj = record.create({type: record.Type.TRANSFER_ORDER, isDynamic: true});
                recordObj.setValue({fieldId: 'subsidiary', value: parseInt(lineValue.subsidiary)}) ;
                recordObj.setValue({fieldId: 'transferlocation', value: parseInt(lineValue.location)}) ; 
                recordObj.setValue({fieldId: 'location', value: parseInt(lineValue.source)}) ; 
                //recordObj.setValue({fieldId: 'custbody_unique_key', value: parseInt(lineValue.key)}) ;
                recordObj.setValue({fieldId: 'custbody_unique_id', value: lineValue.unique_id});

                var items = lineValue.itemline;
                for(var ilc = 0; ilc < items.length; ilc++){
                    recordObj.selectNewLine({sublistId: 'item'});
                    recordObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'item', value: parseInt(items[ilc].item)});
                    recordObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'quantity', value: parseFloat(items[ilc].quantity)});
                    recordObj.commitLine({sublistId: 'item'});
                }
                
                var recordId = recordObj.save({ enableSourcing: true, ignoreMandatoryFields: true});
                log.debug('Transfer Record', recordId);

                for(var i = 0; i < items.length; i++){
                    var replenishmentStatus = record.create({type: REPLENISHMENT_STATUS.RECORD_ID, isDynamic: true});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.KEY, value: parseInt(items[i].key)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.ITEM, value:   parseInt(items[i].item)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.QTY, value:  parseFloat(items[i].quantity)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.UNIQUE_ID, value:  lineValue.unique_id});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.STATUS, value:  STATUS.SUCCESS});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.TRAN_ID, value:  recordId});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.NOTE, value:  "Transfer Order has been sucessfully created."});
                    replenishmentStatus.save();
                } 

            } catch (error) {
                log.debug('Error!', error);
                var items = lineValue.itemline;
                for(var i = 0; i < items.length; i++){
                    var replenishmentStatus = record.create({type: REPLENISHMENT_STATUS.RECORD_ID, isDynamic: true});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.KEY, value: parseInt(items[i].key)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.ITEM, value:   parseInt(items[i].item)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.QTY, value:  parseFloat(items[i].quantity)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.UNIQUE_ID, value:  lineValue.unique_id});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.STATUS, value: STATUS.ERROR});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.NOTE, value:  error.message});
                    replenishmentStatus.save();
                }  
            }
           

        }else if(lineValue.recordtype == "2"){
            // Purchase Order
            log.debug('Purchase Order', lineValue);
            try {
                var recordObj = record.create({type: record.Type.PURCHASE_ORDER, isDynamic: true});
                recordObj.setValue({fieldId: 'entity', value: parseInt (lineValue.vendor)}) ; // vendor
               // recordObj.setValue({fieldId: 'custbody_unique_key', value: parseInt(lineValue.key)}) ;
                recordObj.setValue({fieldId: 'custbody_unique_id', value: lineValue.unique_id});
                recordObj.setValue({fieldId: 'location', value: parseInt(lineValue.location)});

                var items = lineValue.itemline;
                for(var ilc = 0; ilc < items.length; ilc++){
                    recordObj.selectNewLine({sublistId: 'item'});
                    recordObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'item', value: parseInt(items[ilc].item)});
                    recordObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'quantity', value: parseFloat(items[ilc].quantity)});
                    recordObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'location', value: parseInt(lineValue.location)});
                    recordObj.commitLine({sublistId: 'item'});
                }

                var recordId = recordObj.save({ enableSourcing: true, ignoreMandatoryFields: true});
                log.debug('Purchase Record', recordId);

                for(var i = 0; i < items.length; i++){
                    var replenishmentStatus = record.create({type: REPLENISHMENT_STATUS.RECORD_ID, isDynamic: true});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.KEY, value: parseInt(items[i].key)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.ITEM, value:   parseInt(items[i].item)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.QTY, value:  parseFloat(items[i].quantity)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.UNIQUE_ID, value:  lineValue.unique_id});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.STATUS, value:  STATUS.SUCCESS});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.TRAN_ID, value:  recordId});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.NOTE, value:  "Purchase Order has been sucessfully created."});
                    replenishmentStatus.save();
                }

            } catch (error) {
                log.debug('Error!', error);
                var items = lineValue.itemline;
                for(var i = 0; i < items.length; i++){
                    var replenishmentStatus = record.create({type: REPLENISHMENT_STATUS.RECORD_ID, isDynamic: true});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.KEY, value: parseInt(items[i].key)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.ITEM, value:   parseInt(items[i].item)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.QTY, value:  parseFloat(items[i].quantity)});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.UNIQUE_ID, value:  lineValue.unique_id});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.STATUS, value: STATUS.ERROR});
                    replenishmentStatus.setValue({fieldId: REPLENISHMENT_STATUS.NOTE, value:  error.message});
                    replenishmentStatus.save();
                }  
            }
        }
    }

    function reduce(context) {
        
    }

    function summarize(summary) {
        
    }

    return {
        getInputData: getInputData,
        map: map,
      //  reduce: reduce,
        summarize: summarize
    }
});