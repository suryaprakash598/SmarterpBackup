/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
 define(['N/search', 'N/currentRecord', 'N/url', 'N/runtime' ], function(search, currentRecord, url, runtime) {

    const FILTERS = {};
    FILTERS.ISINACTIVE = 'isinactive';
    FILTERS.SUBSIDIARY = 'subsidiary';
    FILTERS.INVENTORY_LOCATION  = 'inventorylocation';

    const COLUMNS = {};
    COLUMNS.NAME = 'name';
    COLUMNS.INTERNALID = 'internalid';
    COLUMNS.ITEMID = 'itemid';
    COLUMNS.COMMITTED = 'quantitycommitted' ;
    COLUMNS.AVAILABLE = 'quantityavailable';
    COLUMNS.ON_HAND = 'quantityonhand';
    COLUMNS.ON_ORDER = 'quantityonorder';

    const FORMFIELDS = {};
    FORMFIELDS.SUBSIDIARY = 'custpage_subsidiary';
    FORMFIELDS.LOCATION = 'custpage_location';
    FORMFIELDS.UNIQUE = 'custpage_unique';
    FORMFIELDS.EX_FILTER = 'custpgae_ex_filter';
    FORMFIELDS.SOURCE_FILTER = 'custpage_source_filter';
    FORMFIELDS.VENDOR_FILTER = 'custpage_vednor_filter';
    FORMFIELDS.UNIT_TYPE = 'custpage_unit_type';
	FORMFIELDS.BRAND_TYPE = 'custpage_brand_type';

    const ITEM_SUBLIST = {};
    ITEM_SUBLIST.SUBLIST = 'custpage_item_table';
    ITEM_SUBLIST.SELECT = 'custpage_select';
    ITEM_SUBLIST.ITEM = 'custpage_item';
    ITEM_SUBLIST.ON_HAND = 'custpage_on_hand';
    ITEM_SUBLIST.ON_ORDER = 'custpage_on_order';
    ITEM_SUBLIST.COMMITTED = 'custpage_committed';
    ITEM_SUBLIST.AVAILABLE = 'custpage_available';
    ITEM_SUBLIST.QUANTITY = 'custpage_quantity';
    ITEM_SUBLIST.SOURCING_TYPE = 'custpage_sourcing_type';
    ITEM_SUBLIST.SOURCING_POINT = 'custpage_sourcing_point';
    ITEM_SUBLIST.VENDOR = 'custpage_vendor';
    ITEM_SUBLIST.SOURCE_TRAN = 'custpage_source_transaction';
    ITEM_SUBLIST.TRAN_ID = 'custpage_tran_id';
    ITEM_SUBLIST.KEY = 'custpage_key';
    ITEM_SUBLIST.PROCESSING_STATUS = 'custpage_processing_status';
    ITEM_SUBLIST.MESSAGE = 'custpage_message';

    const REPLENISHMENT_STATUS = {};
    REPLENISHMENT_STATUS.RECORD_ID = 'customrecord_replenishment_status';
    REPLENISHMENT_STATUS.STATUS = 'custrecord_processing_status';
    REPLENISHMENT_STATUS.NOTE = "custrecord_status_note";
    REPLENISHMENT_STATUS.KEY = 'custrecord_unique_key';
    REPLENISHMENT_STATUS.TRAN_ID = 'custrecord_transaction_id';
    REPLENISHMENT_STATUS.CREATED = 'created';

    const STATUS = {};
    STATUS.SUCCESS = 1;
    STATUS.ERROR = 2;

    function fieldChanged(context) {
        var rec = context.currentRecord;
        var subsidiary = rec.getValue({fieldId: FORMFIELDS.SUBSIDIARY});
        var location = rec.getValue({fieldId: FORMFIELDS.LOCATION});
        var exFilter = rec.getValue({fieldId: FORMFIELDS.EX_FILTER});
        var sourceFilter = rec.getValue({fieldId: FORMFIELDS.SOURCE_FILTER});
        var vendorFilter = rec.getValue({fieldId: FORMFIELDS.VENDOR_FILTER});
        var unitType = rec.getValue({fieldId: FORMFIELDS.UNIT_TYPE});
		var brandType = rec.getValue({fieldId: FORMFIELDS.BRAND_TYPE});

        var param = {
            'custpage_subsidiary': subsidiary,
            'custpage_location' : location,
            'custpgae_ex_filter': exFilter,
            'custpage_source_filter': sourceFilter,
            'custpage_vednor_filter': vendorFilter,
            'custpage_unit_type': unitType,
			'custpage_brand_type': brandType
        }

        if(context.fieldId ==  FORMFIELDS.SUBSIDIARY ){
            addLocationsValues (rec);  
        }

        if(context.fieldId == FORMFIELDS.LOCATION){
            if(!subsidiary){
                alert('Please select the subsidiary first.');
            }
            if(subsidiary && location ){
                reloadPage(param);
            }
        }

        if(context.fieldId == FORMFIELDS.EX_FILTER){

            if(subsidiary && location && exFilter){
                reloadPage(param);
            }
        }

        if(context.fieldId == FORMFIELDS.SOURCE_FILTER){

            if(subsidiary && location && sourceFilter){
                reloadPage(param);
            }
        }

        // Showing result only for selected Vendor
        if(context.fieldId == FORMFIELDS.VENDOR_FILTER){
            if(subsidiary && location && vendorFilter){
                reloadPage(param);
            }
        }

        // Showing result only for selected Unit...
        if(context.fieldId == FORMFIELDS.UNIT_TYPE){
            if(subsidiary && location && unitType){
                reloadPage(param);
            }
        }
		
		// Showing result only for brand...
        if(context.fieldId == FORMFIELDS.BRAND_TYPE){
            if(subsidiary && location && brandType){
                reloadPage(param);
            }
        }

        // Navigate to selected page
        if (context.fieldId == 'custpage_pageid') {
            var pageId = context.currentRecord.getValue({
                    fieldId : 'custpage_pageid'
                });
            
            pageId = parseInt(pageId.split('_')[1]);

            var linkUrl = url.resolveScript({
                scriptId : getParameterFromURL('script'),
                deploymentId : getParameterFromURL('deploy'),
                params : {
                    'custpage_subsidiary': subsidiary,
                    'custpage_location' : location,
                    'custpgae_ex_filter': exFilter,
                    'custpage_source_filter': sourceFilter,
                    'custpage_vednor_filter': vendorFilter,
                    'page' : pageId,
					'custpage_brand_type': brandType
                }
            });
            window.onbeforeunload = null;
            window.open(linkUrl, '_self');
           
        }
    }

    function reloadPage(param){
        var linkUrl = url.resolveScript({
            scriptId : getParameterFromURL('script'),
            deploymentId : getParameterFromURL('deploy'),
            params : param
        });

        window.onbeforeunload = null;
        window.open(linkUrl, '_self');
    }

    function validateLine(context){
        var rec = context.currentRecord;
        if(context.sublistId === ITEM_SUBLIST.SUBLIST){
            var isSelect = rec.getCurrentSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.SELECT});
            if(isSelect){
                var sourcePoint = rec.getCurrentSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.SOURCING_POINT});
                var sourceTran = rec.getCurrentSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.SOURCE_TRAN});
                var vendor = rec.getCurrentSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.VENDOR});
                if(!sourceTran){
                    alert('Please select the transaction type.');
                    return false;
                }
                if(sourceTran == "2" && !vendor){
                    alert('For the Selected Type of transaction, Please provide the vendor details.');
                    return false;
                }
                if(sourceTran == "1" && !sourcePoint){
                    alert('For the Selected Type of transaction, Please provide the source point location.');
                    return false;
                }
            }  
        }
        return true;
    }


    function getLocation(subsidiary){

        var locationList = [];
        try {
            
            var locationSearchObj = search.create({
                type: search.Type.LOCATION,
                filters:
                [
                   [FILTERS.SUBSIDIARY, search.Operator.ANYOF,subsidiary], 
                   "AND", 
                   [FILTERS.ISINACTIVE,search.Operator.IS,"F"]
                ],
                columns:
                [
                   search.createColumn({
                      name: COLUMNS.NAME,
                      sort: search.Sort.ASC,
                      label: "Name"
                   }),
                   search.createColumn({name: COLUMNS.INTERNALID, label: "Internal ID"})
                ]
             });
             var searchResultCount = locationSearchObj.runPaged().count;
             log.debug("locationSearchObj result count",searchResultCount);
             locationSearchObj.run().each(function(result){
                // .run().each has a limit of 4,000 results
                if(result){
                    var location = {};
                    location['text'] = result.getValue({name:  COLUMNS.NAME});
                    location['value'] = result.getValue({name: COLUMNS.INTERNALID});
                    locationList.push(location);
                }
                return true;
             });
        } catch (error) {
            log.debug('LOcation search Error', error);
        }
        return locationList;
    }

    function addLocationsValues(rec){

        var subsidiary = rec.getValue({fieldId: FORMFIELDS.SUBSIDIARY});
        if(subsidiary){
            var locationList = getLocation(subsidiary);
            var location = rec.getField({fieldId: FORMFIELDS.LOCATION});
            //alert('subsidiary: '+subsidiary+" location"+ location);
            if(location){
                for(var loc = 0; loc < locationList.length; loc++){
                    location.insertSelectOption({
                        value: locationList[loc].value,
                        text: locationList[loc].text
                    });
                } 
            }
        } 
    }

    function getParameterFromURL(param) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == param) {
                return decodeURIComponent(pair[1]);
            }
        }
        return (false);
    }

    function getScheduleStatus(taskId) {
       
        try {
            var recObj = currentRecord.get();
            var uniqueId = recObj.getValue({fieldId: FORMFIELDS.UNIQUE})

            var scheduledscriptinstanceSearchObj = search.create({
                type: "scheduledscriptinstance",
                filters:
                [
                    ["taskid","startswith",taskId],
                    'AND',
                    ["status","anyof","COMPLETE"]
                ],
                columns:
                [
                    search.createColumn({name: "startdate",summary: "MIN",label: "Start Date" }),
                    search.createColumn({name: "enddate",summary: "MAX",label: "End Date"}),
                    search.createColumn({name: "status",summary: "GROUP",label: "Status"})
                ]

            });
            var searchResultCount = scheduledscriptinstanceSearchObj.runPaged().count;
            log.debug("scheduledscriptinstanceSearchObj result count",searchResultCount);
            if(searchResultCount > 0){
                var linkUrl = url.resolveScript({
                    scriptId : 'customscript_sut_item_replenishment_stat',
                    deploymentId : 'customdeploy_sut_item_replenishment_stat',
                    params : {
                        'uniqueId': uniqueId
                    }
                });
                window.onbeforeunload = null;
                window.open(linkUrl, '_self');
            }    
        } catch (error) {
            log.debug('error', error);
        }
    }

    function getSuiteletPage(suiteletScriptId, suiteletDeploymentId, pageId) {
        var rec = currentRecord.get();
        var subsidiary = rec.getValue({fieldId: FORMFIELDS.SUBSIDIARY});
        var location = rec.getValue({fieldId: FORMFIELDS.LOCATION});
        var exFilter = rec.getValue({fieldId: FORMFIELDS.EX_FILTER});
        var sourceFilter = rec.getValue({fieldId: FORMFIELDS.SOURCE_FILTER});
        var vendorFilter = rec.getValue({fieldId: FORMFIELDS.VENDOR_FILTER});
		var brandFilter = rec.getValue({fieldId: FORMFIELDS.BRAND_TYPE});
       // var fileId = rec.getValue({fieldId: FORMFIELDS.FILE_FIELD});
        
       // var content = writeLineDataIntoFile(rec, pageId);
        
        var param = {
            'custpage_subsidiary': subsidiary,
            'custpage_location' : location,
            'custpgae_ex_filter': exFilter,
            'custpage_source_filter': sourceFilter,
            'custpage_vednor_filter': vendorFilter,
            'page' : pageId,
			'custpage_brand_type': brandType

        }
        var linkUrl = url.resolveScript({
            scriptId : suiteletScriptId,
            deploymentId : suiteletDeploymentId,
            params : param
        });
        window.onbeforeunload = null;
        window.open(linkUrl, '_self');
    }

    function writeLineDataIntoFile(rec, pageId){
        var selectedItemList = [];
        var subsidiary = rec.getValue({fieldId: FORMFIELDS.SUBSIDIARY});
        var location = rec.getValue({fieldId: FORMFIELDS.LOCATION});
        var itemCount = rec.getLineCount({sublistId:  ITEM_SUBLIST.SUBLIST });
        log.debug('CL itemCount', itemCount);
        for(var i= 0; i < itemCount; i++){
            var isSelect = rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.SELECT, line: i});
            //log.debug('CL isSelect', isSelect);
            if(isSelect == true){
                var replenimentQty = parseFloat(rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.QUANTITY, line: i }));
                var item = rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.ITEM, line: i });
                var sourceType = rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.SOURCING_TYPE, line: i });
                var sourcePoint = rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.SOURCING_POINT, line: i });
                var sourceTran = rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.SOURCE_TRAN, line: i });
                var key = rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.KEY, line: i });
                var vendor = rec.getSublistValue({sublistId: ITEM_SUBLIST.SUBLIST, fieldId: ITEM_SUBLIST.VENDOR, line: i });
                var lineValue = {}; 
                lineValue['subsidiary'] = subsidiary;
                lineValue['location'] = location
                lineValue['item'] = item;
                lineValue['quantity'] = replenimentQty;
                lineValue['key'] = key;
                lineValue['recordtype'] = sourceTran;
               // lineValue['unique_id'] = user.id+''+miliSec;
                lineValue['source'] = sourcePoint;
                lineValue['vendor'] = vendor;
                log.debug('CL lineValue', lineValue);
                selectedItemList.push(lineValue);
            }
        }

        var fileContent = {};
        fileContent[pageId] = selectedItemList;
       return fileContent;
    }

    return {
      //  pageInit: pageInit,
     //   saveRecord: saveRecord,
      //  validateField: validateField,
          fieldChanged: fieldChanged,
          getScheduleStatus: getScheduleStatus,
     //   postSourcing: postSourcing,
     //   lineInit: lineInit,
     //   validateDelete: validateDelete,
     //   validateInsert: validateInsert,
          validateLine: validateLine,
          getSuiteletPage: getSuiteletPage
      //  sublistChanged: sublistChanged
    }
});