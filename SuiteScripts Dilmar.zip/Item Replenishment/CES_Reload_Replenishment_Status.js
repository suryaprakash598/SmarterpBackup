/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
 define(['N/url'], function(url) {

    function pageInit(context) {
        
    }

    function saveRecord(context) {
        
    }

    function validateField(context) {
        
    }

    function fieldChanged(context) {
        
    }

    function postSourcing(context) {
        
    }

    function lineInit(context) {
        
    }

    function validateDelete(context) {
        
    }

    function validateInsert(context) {
        
    }

    function validateLine(context) {
        
    }

    function sublistChanged(context) {
        
    }

    function reloadPage(){
        try {
            window.location.reload();

          /*  var linkUrl = url.resolveScript({
                scriptId : getParameterFromURL('script'),
                deploymentId : getParameterFromURL('deploy'),
                params : getParameterFromURL('uniqueId')
            });
    
            window.onbeforeunload = null;
            window.open(linkUrl, '_self');*/
        } catch (error) {
            log.debug('Client Error', error);
        }
        
    }

    function getParameterFromURL(param) {

        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == param) {
                log.debug('decodeURIComponent(pair[1])', decodeURIComponent(pair[1]));
                return decodeURIComponent(pair[1]);
            }
        }
        return (false);
    }

    return {
        
        pageInit: pageInit,
        reloadPage: reloadPage
       // saveRecord: saveRecord,
       // validateField: validateField,
       // fieldChanged: fieldChanged,
       // postSourcing: postSourcing,
       // lineInit: lineInit,
       // validateDelete: validateDelete,
       // validateInsert: validateInsert,
       // validateLine: validateLine,
       // sublistChanged: sublistChanged
    }
});