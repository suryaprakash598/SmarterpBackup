/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(['N/search', 'N/record'], function(search, record) {

    const ITEM = {};
     ITEM.LOCATION_LIST = 'locations';
     ITEM.AVERAGECOSTMLI = 'averagecostmli';
     ITEM.LOCATION = 'location';
     ITEM.AVERAGECOST = 'averagecost';
     ITEM.COST = 'cost';
     ITEM.LASTPURCHASEPRICE = 'lastpurchaseprice';

    function afterSubmit(context) {
        if(context.type == 'delete')
            return;
        
        var rec = context.newRecord;
        var recordObj = record.load({type: rec.type, id: rec.id, isDynamic: true});
        var totalWeight = 0;
        if(recordObj){
            var lineCount = recordObj.getLineCount({sublistId: 'item'});
            for(var line=0; line < lineCount; line++){
                recordObj.selectLine({sublistId: 'item', line: line});
                var item =  recordObj.getCurrentSublistValue({sublistId:'item',fieldId: 'item'});
                var lineItemType = recordObj.getCurrentSublistValue({sublistId:'item',fieldId: 'itemtype'});
                var lineUnitCost = recordObj.getCurrentSublistValue({sublistId : 'item', fieldId : 'rate'}) || '';

                switch (lineItemType) {
                    case 'InvtPart' :
                        lineItemType = 'inventoryitem';
                        break;
        
                    case 'Assembly' :
                        lineItemType = 'assemblyitem';
                        break;
                }
                var itemWeight = getItemWeight(item, lineItemType);
                var quantity = recordObj.getCurrentSublistValue({sublistId:'item',fieldId: 'quantity'});
                log.debug('Line: '+line,'item: '+item+', itemWeight: '+itemWeight+', quantity: '+quantity);
                if(itemWeight && quantity){
                    recordObj.setCurrentSublistValue({sublistId:'item',fieldId: 'custcol_dilmar_item_weight', value: quantity* parseFloat(itemWeight)});
                    totalWeight = (quantity* parseFloat(itemWeight)) + parseFloat(totalWeight)
                }

                if(!lineUnitCost || lineUnitCost === 0) {
                    var fromLocation = recordObj.getValue({fieldId : 'location' }) || '';
                    var newUnitCost = GetItemCost(item, lineItemType,fromLocation);
                    if(newUnitCost){
                        recordObj.setCurrentSublistValue({sublistId : 'item', fieldId : 'rate', value: newUnitCost});
                    }
                }
                recordObj.commitLine({sublistId: 'item'})
            }
            recordObj.setValue({fieldId: 'custbody_dilmar_total_item_weight', value: totalWeight});
            recordObj.save();
        }
    }

    function getItemWeight(item, lineItemType){
        var fieldLookUp = search.lookupFields({
            type: lineItemType,
            id: item,
            columns: ['weight']
        });
        //alert(JSON.stringify(fieldLookUp));
        return fieldLookUp.weight;

     }

     function GetItemCost(item, lineItemType,location) {
        var itemAverageCost = '';

        var itemRec = record.load({
            type : lineItemType,
            id : item,
            isDynamic : true
        });

        var locationLineCount = itemRec.getLineCount({
            sublistId: ITEM.LOCATION_LIST
        });

        if(locationLineCount) {
            for(var locationLine = 0; locationLine < locationLineCount; locationLine++) {
                var lineLocation = itemRec.getSublistValue({
                    sublistId: ITEM.LOCATION_LIST,
                    fieldId: ITEM.LOCATION,
                    line: locationLine
                }) || '';

                if(lineLocation === location) {
                    itemAverageCost = itemRec.getSublistValue({
                        sublistId: ITEM.LOCATION_LIST,
                        fieldId: ITEM.AVERAGECOSTMLI,
                        line: locationLine
                    })
                    break;
                }
            }
        }

        if(!itemAverageCost) {
            // get body level average cost
            itemAverageCost = itemRec.getValue({
                fieldId : ITEM.AVERAGECOST
            }) || '';

            if(!itemAverageCost) {
                // get body level purchase price
                itemAverageCost = itemRec.getValue({
                    fieldId: ITEM.COST
                }) || '';

                if(!itemAverageCost) {
                    // get body level last purchase price
                    itemAverageCost = itemRec.getValue({
                        fieldId : ITEM.LASTPURCHASEPRICE
                    }) || '';
                }
            }
        }

        return itemAverageCost;
    }

    return {
        afterSubmit: afterSubmit
    }
});
