/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *@author Saurabh Singh
 *@description Whenever the item will be created, This script will create Replenishmen details record (Custom Record)
 *for all the inventory locations. 
 */
define(['N/record', 'N/search'], function(record, search) {

    const CUSTOMRECORD = {};
    CUSTOMRECORD.REPLENISHMENT_DETAILS = 'customrecord_replenishment_detail';
    CUSTOMRECORD.ITEM = 'custrecord163';
    CUSTOMRECORD.LOCATION = 'custrecord164';
    CUSTOMRECORD.SOURCE_TYPE = 'custrecord165';
    CUSTOMRECORD.SOURCE_POINT = 'custrecord166';
    CUSTOMRECORD.SOURCE_TRAN = 'custrecord167';
    CUSTOMRECORD.VENDOR = 'custrecord168';

    function beforeLoad(context) {
        
    }

    function beforeSubmit(context) {
        
    }

    function afterSubmit(context) {
        
        if(context.type === 'create' ){
            var rec = context.newRecord ;
            if(rec){
                var itemInventoryLocSearch = search.create({
                    type: "item",
                    filters:
                    [
                       ["internalid","anyof", rec.id]
                    ],
                    columns:
                    [
                       search.createColumn({name: "inventorylocation", label: "Inventory Location"})
                    ]
                 });
                 var searchResultCount = itemInventoryLocSearch.runPaged().count;
                 log.debug("itemInventoryLocSearch result count",searchResultCount);
                 itemInventoryLocSearch.run().each(function(result){
                    // .run().each has a limit of 4,000 results
                    if(result){
                       var location = result.getValue({name: 'inventorylocation' });
                       if(location){
                           try {
                                var replenishment = record.create({type: CUSTOMRECORD.REPLENISHMENT_DETAILS, isDynamic: true});
                                replenishment.setValue({fieldId: CUSTOMRECORD.ITEM, value: rec.id});
                                replenishment.setValue({fieldId: CUSTOMRECORD.LOCATION, value: location});
                                replenishment.save({enableSourcing: true, ignoreMandatoryFields: true});
                            } catch (error) {
                               log.debug('Error!', error);
                            }  
                        }
                    }
                    return true;
                 });
                
            }
        }
    }

    return {
       // beforeLoad: beforeLoad,
      //  beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    }
});
