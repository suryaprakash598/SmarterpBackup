/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */
 define(['N/ui/serverWidget', 'N/search', 'N/url'], function(serverWidget, search, url) {

    const FILTERS = {};
    FILTERS.SCRIPT_INSTANCE = 'scheduledscriptinstance';
    FILTERS.TASK_ID = 'taskid';
    FILTERS.TRANSACTION = 'transaction';
    FILTERS.TYPE = 'type';
    FILTERS.KEY_REF = 'custbody_unique_key';
    FILTERS.DATE_CREATED = 'datecreated';
    FILTERS.ITEM = 'item';
    FILTERS.STATUS = 'status';
    FILTERS.UNIQUE = 'custbody_unique_id';


    const COLUMNS = {};
    COLUMNS.START_DATE = 'startdate';
    COLUMNS.END_DATE = 'enddate';
    
    COLUMNS.INTERNALID = 'internalid';
    COLUMNS.TRANID = 'tranid';
    COLUMNS.ITEM = 'item';
    COLUMNS.QTY = 'quantity';
    COLUMNS.KEY_REF = 'custbody_unique_key';
    COLUMNS.UNIQUE = 'custbody_unique_id';


    const SUMMARY = {};
    SUMMARY.MAX = 'MAX';
    SUMMARY.GROUP = 'GROUP';
    SUMMARY.MIN = 'MIN';

    const ITEM_SUBLIST = {};
    ITEM_SUBLIST.SUBLIST = 'custpage_item_table';
    ITEM_SUBLIST.ITEM = 'custpage_item';
    ITEM_SUBLIST.DISPLAY_NAME = 'custpage_display_name';
    ITEM_SUBLIST.QUANTITY = 'custpage_quantity';
    //ITEM_SUBLIST.SOURCE_TRAN = 'custpage_source_transaction';
    ITEM_SUBLIST.PROCESSING_STATUS = 'custpage_processing_status';
    ITEM_SUBLIST.MESSAGE = 'custpage_message';
    ITEM_SUBLIST.TRAN_ID = 'custpage_tran_id';
    ITEM_SUBLIST.KEY = 'custpage_key';

    
    var SOURCE_TRAN_LIST_ID = 'customlist_source_transaction';
    var SOURCE_ITEM = 'item';
    var SOURCE_TRANSACTION = 'transaction';
    var SOURCE_PROCESSING_STATUS = 'customlist_status_list';

    const REPLENISHMENT_STATUS = {};
    REPLENISHMENT_STATUS.RECORD_ID = 'customrecord_replenishment_status';
    REPLENISHMENT_STATUS.STATUS = 'custrecord_processing_status';
    REPLENISHMENT_STATUS.NOTE = "custrecord_status_note";
    REPLENISHMENT_STATUS.KEY = 'custrecord_unique_key';
    REPLENISHMENT_STATUS.TRAN_ID = 'custrecord_transaction_id';
    REPLENISHMENT_STATUS.ITEM = 'custrecord_item_stat';
    REPLENISHMENT_STATUS.QTY = 'custrecord_replenishment_qty';
    REPLENISHMENT_STATUS.UNIQUE_ID = 'custrecord_unique_id_stat';

    const STATUS = {};
    STATUS.SUCCESS = 1;
    STATUS.ERROR = 2;

    const CLIENT_SCRIPT_FILE_ID = 7544;

    function onRequest(context) {
        if(context.request.method == 'GET'){
            var form = serverWidget.createForm({
                title : 'Processing Status',
                hideNavBar : false
            });
            //form.clientScriptFileId = CLIENT_SCRIPT_FILE_ID;
            form.clientScriptModulePath = '/SuiteScripts/Item Replenishment/CES_Reload_Replenishment_Status.js';
            var uniqueId = context.request.parameters.uniqueId;
            log.debug('uniqueId', uniqueId);
            if(uniqueId){
                form.addButton({id:'custpage_refresh_btn',  label: 'Refresh', functionName: "reloadPage()"});//reloadPage
                var transactions = getCreatedTransactions(uniqueId);
                var replenishmentStatus = getReplenishmentStatus( uniqueId);
                var itemSublist = addSublistField(form);
                if(transactions.length> 0 && replenishmentStatus.length > 0){
                    addSublistValues(itemSublist, replenishmentStatus, transactions);
                }
                context.response.writePage(form);
            }
        }
    }

    function addSublistField(form){

        var itemSublist = form.addSublist({
            id : ITEM_SUBLIST.SUBLIST,
            type : serverWidget.SublistType.LIST,
            label : 'Item'
        });

        var item = itemSublist.addField({
            id : ITEM_SUBLIST.ITEM,
            label : 'Item',
            type : serverWidget.FieldType.SELECT,
            source: SOURCE_ITEM
        });
        item.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });   

        itemSublist.addField({
            id : ITEM_SUBLIST.QUANTITY,
            label : 'Replenish with Quantity',
            type : serverWidget.FieldType.FLOAT
        });

        var processStatus = itemSublist.addField({
            id : ITEM_SUBLIST.PROCESSING_STATUS,
            label : 'Processing Status',
            type : serverWidget.FieldType.SELECT,
            source: SOURCE_PROCESSING_STATUS
        });
        processStatus.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

        itemSublist.addField({
            id : ITEM_SUBLIST.MESSAGE,
            label : 'Note',
            type : serverWidget.FieldType.TEXT
        });

        var tranId = itemSublist.addField({
            id : ITEM_SUBLIST.TRAN_ID,
            label : 'Transaction Link',
            type : serverWidget.FieldType.TEXT
        });
        //tranId.linkText = "View";
       // tranId.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

        var key = itemSublist.addField({
            id : ITEM_SUBLIST.KEY,
            label : 'Unique Key',
            type : serverWidget.FieldType.INTEGER
        });
        key.updateDisplayType({ displayType : serverWidget.FieldDisplayType.HIDDEN });

        return itemSublist;
    }

    function getCreatedTransactions(uniqueId){
        var transactions = [];
        try {
            var transactionSearchObj = search.create({
                type:  FILTERS.TRANSACTION ,
                filters:
                [
                   [ FILTERS.TYPE , search.Operator.ANYOF,"PurchOrd","TrnfrOrd"], 
                   "AND",  
                   [FILTERS.ITEM,"noneof","@NONE@"],
                   "AND", 
                    [ FILTERS.UNIQUE , search.Operator.STARTSWITH, uniqueId]
                ],
                columns:
                [
                   search.createColumn({ name: COLUMNS.INTERNALID, summary: SUMMARY.GROUP,label: "Internal ID" }),
                   search.createColumn({ name: COLUMNS.TRANID,summary: SUMMARY.GROUP,label: "Document Number" }),
                   search.createColumn({ name: COLUMNS.ITEM, summary:SUMMARY.GROUP, label: "Item" }),
                   search.createColumn({ name: COLUMNS.QTY,summary: SUMMARY.MAX, label: "Quantity" }),
                   search.createColumn({ name: FILTERS.TYPE,summary: SUMMARY.GROUP,label: "type"}),

                ]
             });
             var searchResultCount = transactionSearchObj.runPaged().count;
             log.debug("transactionSearchObj result count",searchResultCount);
             var columns = transactionSearchObj.columns;
             transactionSearchObj.run().each(function(result){
                // .run().each has a limit of 4,000 results
                if(result && columns.length > 0){
                    var res = {};
                    res['internalId'] = result.getValue(columns[0]);
                    res['tranId'] =  result.getValue(columns[1]);
                    res['itemid'] =  result.getValue(columns[2]);
                    res['qty'] =  result.getValue(columns[3]);
                    res['type'] = result.getValue(columns[4]);
                    transactions.push(res);
                }
                return true;
             });
        } catch (error) {
            log.debug('Transaction Error', error);
        }
         return transactions;
    }

    function getReplenishmentStatus(uniqueId){
        var replenishmentStatus = [];
         try {
             var searchObj = search.create({
                 type: REPLENISHMENT_STATUS.RECORD_ID,
                 filters:
                 [
                   [REPLENISHMENT_STATUS.UNIQUE_ID, search.Operator.STARTSWITH, uniqueId]
                 ],
                 columns: [
                     search.createColumn({name: REPLENISHMENT_STATUS.STATUS}),
                     search.createColumn({name: REPLENISHMENT_STATUS.NOTE}),
                     search.createColumn({name: REPLENISHMENT_STATUS.TRAN_ID}),
                     search.createColumn({name: REPLENISHMENT_STATUS.KEY}),
                     search.createColumn({name: REPLENISHMENT_STATUS.ITEM}),
                     search.createColumn({name: REPLENISHMENT_STATUS.QTY})

                 ]
             });
             log.debug('Status Rec searchObj', searchObj.runPaged().count );
             searchObj.run().each(function(result){
                 if(result){
                     var status = {} ;
                     status['item'] = result.getValue({name: REPLENISHMENT_STATUS.ITEM});
                     status['qty'] = result.getValue({name: REPLENISHMENT_STATUS.QTY});
                     status['uniquekey'] = result.getValue({name: REPLENISHMENT_STATUS.KEY}) || '';
                     status['status'] = result.getValue({name: REPLENISHMENT_STATUS.STATUS});
                     status['note'] = result.getValue({name: REPLENISHMENT_STATUS.NOTE})||'';
                     status['refrecid'] = parseInt(result.getValue({name: REPLENISHMENT_STATUS.TRAN_ID})) || 0;
                     replenishmentStatus.push(status);
                 }
                 return true;
             });
         } catch (error) {
             log.debug('Custom Record Search Error', error);
         }
 
         return replenishmentStatus;
    }

    function addSublistValues(itemSublist, replenishmentStatus, transactions){

        for(var rsl=0; rsl < replenishmentStatus.length; rsl++ ){
            var tranId = replenishmentStatus[rsl].refrecid ;
            var isMatched = false;

            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.ITEM,
                line: rsl,
                value :replenishmentStatus[rsl].item
            });

            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.QUANTITY,
                line: rsl,
                value : replenishmentStatus[rsl].qty
            });

            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.MESSAGE,
                line: rsl,
                value : replenishmentStatus[rsl].note
            });

            for (var line = 0; line < transactions.length; line++ ){

                if(tranId == transactions[line].internalId){

                    log.debug('transactions[line].type', transactions[line].type);
                    var recType ;
                    if(transactions[line].type == 'TrnfrOrd'){
                        recType = search.Type.TRANSFER_ORDER;
                    }else{
                        recType = search.Type.PURCHASE_ORDER;
                    }

                    itemSublist.setSublistValue({
                        id : ITEM_SUBLIST.PROCESSING_STATUS,
                        line: rsl,
                        value : STATUS.SUCCESS
                    });

                    var URL = url.resolveRecord({
                        recordType: recType,
                        recordId: transactions[line].internalId,
                        isEditMode: false
                    });
                    
                    var newURl = "<a href= https://4622785-sb1.app.netsuite.com"+URL+">"+transactions[line].tranId +"</a>";

                    itemSublist.setSublistValue({
                        id : ITEM_SUBLIST.TRAN_ID,
                        line: rsl,
                        value : newURl
                    });
                    isMatched = true ;
                    break;
                }
            }

            if(!isMatched){
                itemSublist.setSublistValue({
                    id : ITEM_SUBLIST.PROCESSING_STATUS,
                    line: rsl,
                    value : STATUS.ERROR
                });
            }
        }
    }

    return {
        onRequest: onRequest
    }
});