/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */
 define(['N/ui/serverWidget', 'N/search', 'N/task', 'N/runtime', 'N/file'], function(serverWidget, search, task, runtime, file) {

    const FILTERS = {};
    FILTERS.ISINACTIVE = 'isinactive';
    FILTERS.SUBSIDIARY = 'subsidiary';
    FILTERS.INVENTORY_LOCATION  = 'inventorylocation';
    FILTERS.REPLENISH_LOCATION = 'custrecord164';
    FILTERS.SOURCE_TYPE = 'custrecord165';
    FILTERS.VENDOR = 'custrecord168';
    FILTERS.UNIT_TYPE = 'unitstype';
	FILTERS.BRAND_TYPE = 'brandtype';

    const COLUMNS = {};
    COLUMNS.NAME = 'name';
    COLUMNS.INTERNALID = 'internalid';
    COLUMNS.ITEMID = 'itemid';
    COLUMNS.COMMITTED = 'locationquantitycommitted' ;
    COLUMNS.AVAILABLE = 'quantityavailable';
    COLUMNS.ON_HAND = 'locationquantityonhand';
    COLUMNS.ON_ORDER = 'locationquantityonorder';
    COLUMNS.STOCK_LEVEL = 'locationpreferredstocklevel';
    COLUMNS.BACK_ORDER = "locationquantitybackordered";

    const FORMFIELDS = {};
    FORMFIELDS.SUBSIDIARY = 'custpage_subsidiary';
    FORMFIELDS.LOCATION = 'custpage_location';
    FORMFIELDS.REFRESH_BTN = 'custpage_refresh';
    FORMFIELDS.UNIQUE = 'custpage_unique';
    FORMFIELDS.EX_FILTER = 'custpgae_ex_filter';
    FORMFIELDS.SOURCE_FILTER = 'custpage_source_filter';
    FORMFIELDS.VENDOR_FILTER = 'custpage_vednor_filter';
    FORMFIELDS.FILE_FIELD = 'custpage_file';
    FORMFIELDS.FILE_CONTENT = 'custpage_file_content';
    FORMFIELDS.UNIT_TYPE = 'custpage_unit_type';
	FORMFIELDS.BRAND_TYPE = 'custpage_brand_type';

    const ITEM_SUBLIST = {};
    ITEM_SUBLIST.SUBLIST = 'custpage_item_table';
    ITEM_SUBLIST.SELECT = 'custpage_select';
    ITEM_SUBLIST.ITEM = 'custpage_item';
    ITEM_SUBLIST.DISPLAY_NAME = 'custpage_display_name';
    ITEM_SUBLIST.ON_HAND = 'custpage_on_hand';
    ITEM_SUBLIST.ON_ORDER = 'custpage_on_order';
    ITEM_SUBLIST.COMMITTED = 'custpage_committed';
    ITEM_SUBLIST.AVAILABLE = 'custpage_available';
    ITEM_SUBLIST.QUANTITY = 'custpage_quantity';
    ITEM_SUBLIST.SOURCING_TYPE = 'custpage_sourcing_type';
    ITEM_SUBLIST.SOURCING_POINT = 'custpage_sourcing_point';
    ITEM_SUBLIST.VENDOR = 'custpage_vendor';
    ITEM_SUBLIST.SOURCE_TRAN = 'custpage_source_transaction';
    ITEM_SUBLIST.TRAN_ID = 'custpage_tran_id';
    ITEM_SUBLIST.KEY = 'custpage_key';
    ITEM_SUBLIST.PROCESSING_STATUS = 'custpage_processing_status';
    ITEM_SUBLIST.MESSAGE = 'custpage_message';
    ITEM_SUBLIST.STOCK_LEVEL = 'custpage_stock_level';
    ITEM_SUBLIST.BACK_ORDER = 'custpage_back_order';
    ITEM_SUBLIST.UNIT_TYPE = 'custpage_item_unit_type';

    var CLIENT_SCRIPT_FILE_ID = 7543;
    var SOURCING_TYPE_LIST_ID = 'customlist_sourcing_type';
    var SOURCING_POINT_LIST_ID = 'location';
    var SOURCE_TRAN_LIST_ID = 'customlist_source_transaction';
    var SOURCE_ITEM = 'item';
    var SOURCE_SUBSIDIARY = 'subsidiary'
    var SOURCE_TRANSACTION = 'transaction';
    var SOURCE_VENDOR = 'vendor';
    var SOURCE_PROCESSING_STATUS = 'customlist_status_list';
    var SOURCE_EX_FILTER = 'customlist_all_item_replenish_item';
	var SOURCE_BRAND = 'customlist1274';

    const CUSTOMRECORD = {};
    CUSTOMRECORD.REPLENISHMENT_DETAILS = 'customrecord_replenishment_detail';
    CUSTOMRECORD.ITEM = 'custrecord163';
    CUSTOMRECORD.LOCATION = 'custrecord164';
    CUSTOMRECORD.SOURCE_TYPE = 'custrecord165';
    CUSTOMRECORD.SOURCE_POINT = 'custrecord166';
    CUSTOMRECORD.SOURCE_TRAN = 'custrecord167';
    CUSTOMRECORD.VENDOR = 'custrecord168';

    const SCRIPT = {};
    SCRIPT.ID = 'customscript_mrs_item_replenishment';
    SCRIPT.DEPOYMENT_ID = 'customdeploy_mrs_item_replenishment';
    SCRIPT.PARAMETER = 'custscript_parameters';
    var columnsArr ;
    const DEFAULT_SUBSIDIARY = 4;
    var PAGE_SIZE = 100;

    function onRequest(context) {
        if(context.request.method === 'GET'){

            var form = serverWidget.createForm({
                title : 'Item Replenishment',
                hideNavBar : false
            });

            // form.clientScriptFileId = CLIENT_SCRIPT_FILE_ID;
            form.clientScriptModulePath = '/SuiteScripts/Item Replenishment/CES_Item_Replenishment.js';

            var scriptId = context.request.parameters.script;
            var deploymentId = context.request.parameters.deploy;
            var pageId = parseInt(context.request.parameters.page)|| 0;
            var subsidiaryValue = context.request.parameters.custpage_subsidiary;
            var locationValue = context.request.parameters.custpage_location;
            var exFilterValue =  context.request.parameters.custpgae_ex_filter;
            var sourceTypeValue = context.request.parameters.custpage_source_filter;
            var vendor = context.request.parameters.custpage_vednor_filter;
            var unitTypeValue = context.request.parameters.custpage_unit_type;
			var brandTypeValue = context.request.parameters.custpage_brand_type;
            log.debug('Parameters','scriptId: '+scriptId+', deploymentId: '+deploymentId+', pageId: '+pageId+ 
            ', subsidiaryValue: '+subsidiaryValue+ ', locationValue: '+locationValue+
            ', exFilterValue: '+exFilterValue+', sourceTypeValue: '+sourceTypeValue+', vendor: '+vendor+', Unit Type: '+unitTypeValue);

            var subsidiary = form.addField({
                id: FORMFIELDS.SUBSIDIARY, 
                label: 'Subsidiary', 
                type: serverWidget.FieldType.SELECT,
                source: SOURCE_SUBSIDIARY
            });

            var location = form.addField({
                id: FORMFIELDS.LOCATION, 
                label: 'Location', 
                type: serverWidget.FieldType.SELECT,
                source: SOURCING_POINT_LIST_ID
            });
            // All Items/Only to be Replenished
            var exFilter = form.addField({
                id: FORMFIELDS.EX_FILTER, 
                label: 'Display Item', 
                type: serverWidget.FieldType.SELECT,
                source: SOURCE_EX_FILTER
            });

            var sourceTypeFilter = form.addField({
                id: FORMFIELDS.SOURCE_FILTER, 
                label: 'Source Type', 
                type: serverWidget.FieldType.SELECT,
                source: SOURCING_TYPE_LIST_ID
            });

            var vendorFilter = form.addField({
                id: FORMFIELDS.VENDOR_FILTER, 
                label: 'Vendor', 
                type: serverWidget.FieldType.SELECT,
                source: SOURCE_VENDOR
            });
			
			var brandFilter = form.addField({
                id: FORMFIELDS.BRAND_TYPE, 
                label: 'Brand', 
                type: serverWidget.FieldType.SELECT,
				source: SOURCE_BRAND
            });

            var unitType = form.addField({
                id: FORMFIELDS.UNIT_TYPE,
                label: 'Primary Unit Type',
                type: serverWidget.FieldType.SELECT,
                source: 'unitstype'
            })

            if(vendor != undefined){
                vendorFilter.defaultValue = vendor;
            }

            if(exFilterValue == undefined){
                exFilter.defaultValue = 1;
            }else{
                exFilter.defaultValue = exFilterValue;
            }

            if(sourceTypeValue == undefined){
                sourceTypeFilter.defaultValue = 3;
            }else{
                sourceTypeFilter.defaultValue = sourceTypeValue;
            }

            if(unitTypeValue != undefined){
                unitType.defaultValue = unitTypeValue;
            }
           

             // Add Sublist
             var itemSublist = addSublistField(form, context.request);

             if(subsidiaryValue != undefined && locationValue != undefined && exFilterValue != undefined && sourceTypeValue != undefined && brandTypeValue != undefined){
                subsidiary.defaultValue = subsidiaryValue;
                location.defaultValue = locationValue;
				brandFilter.defaultValue = brandTypeValue;
              //  var ReplenishmentDetails = getReplenishmentDetail();
                var retrieveSearch = runSearch(locationValue, sourceTypeValue, vendor, unitTypeValue, exFilterValue, brandTypeValue);
                if(retrieveSearch){
                    var pageCount = Math.ceil(retrieveSearch.count / PAGE_SIZE);
                    log.debug('pageCount', pageCount);
                    // Set pageId to correct value if out of index
                    if (!pageId || pageId == '' || pageId < 0)
                        pageId = 0;
                    else if (pageId >= pageCount)
                        pageId = pageCount - 1;
    
                     // Add drop-down and options to navigate to specific page
                    var selectOptions = form.addField({
                        id : 'custpage_pageid',
                        label : 'Page Index',
                        type : serverWidget.FieldType.SELECT
                    });
    
                    for (i = 0; i < pageCount; i++) {
                        if (i == pageId) {
                            selectOptions.addSelectOption({
                                value : 'pageid_' + i,
                                text : ((i * PAGE_SIZE) + 1) + ' - ' + ((i + 1) * PAGE_SIZE),
                                isSelected : true
                            });
                        } else {
                            selectOptions.addSelectOption({
                                value : 'pageid_' + i,
                                text : ((i * PAGE_SIZE) + 1) + ' - ' + ((i + 1) * PAGE_SIZE)
                            });
                        }
                    }
    
                    var itemList = fetchSearchResult(retrieveSearch, pageId, exFilterValue);
                    log.debug('itemList', itemList.length);
                    //applyFilterToList(locationValue, itemSublist, itemList, exFilterValue, sourceTypeValue, vendor);
                    addFinalSublist(itemSublist, itemList);
                }

            }else{
                subsidiary.defaultValue = DEFAULT_SUBSIDIARY;
            }
            form.addSubmitButton({label: 'Submit' });
            context.response.writePage(form);
        }

        if(context.request.method == 'POST'){
            var request = context.request;
            var subsidiary = request.parameters[FORMFIELDS.SUBSIDIARY] || '';
            var location = request.parameters[FORMFIELDS.LOCATION] || '';
			var brandType = request.parameters[FORMFIELDS.BRAND_TYPE] || '';
            var form = serverWidget.createForm({
                title : 'Processing Status',
                hideNavBar : false
            });

            form.clientScriptModulePath = '/SuiteScripts/Item Replenishment/CES_Item_Replenishment.js';

            var d = new Date();
            var miliSec = Date.parse(d);
            var user = runtime.getCurrentUser();
            var unique = form.addField({id: FORMFIELDS.UNIQUE, label: 'Unique Id', type: serverWidget.FieldType.TEXT});
            unique.defaultValue = user.id+''+miliSec;
            unique.updateDisplayType({ displayType : serverWidget.FieldDisplayType.HIDDEN});

            var itemSublist = addSublistField(form, context.request);
           // var itemList = getItems(location);

            var lineCount = request.getLineCount({group: ITEM_SUBLIST.SUBLIST });
            log.debug('POST lineCount', lineCount);
            var selectedItemList = [];
            var line = 0;
            for (var il = 0; il < lineCount; il++) {
                var isSelect = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.SELECT, line: il });
                if(isSelect == 'T'){
                    var replenimentQty = parseFloat(request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.QUANTITY, line: il }));
                    var item = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.ITEM, line: il });
                    var displayName = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.DISPLAY_NAME, line: il });
                    var sourceType = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.SOURCING_TYPE, line: il });
                    var sourcePoint = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.SOURCING_POINT, line: il });
                    var sourceTran = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.SOURCE_TRAN, line: il });
                    var key = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.KEY, line: il });
                    var vendor = request.getSublistValue({group: ITEM_SUBLIST.SUBLIST, name: ITEM_SUBLIST.VENDOR, line: il });
                    //log.debug('Line Info', 'sourcePoint: '+sourcePoint+', sourceTran: '+sourceTran);

                    var lineValue = {}; 
                    lineValue['subsidiary'] = subsidiary;
                    lineValue['location'] = location
                    lineValue['item'] = item;
                    lineValue['quantity'] = replenimentQty;
                    lineValue['key'] = key;
                    lineValue['recordtype'] = sourceTran;
                    lineValue['unique_id'] = user.id+''+miliSec;
                    lineValue['source'] = sourcePoint;
                    lineValue['vendor'] = vendor;
                    //log.debug('lineValue', lineValue);
                    selectedItemList.push(lineValue);

                    itemSublist.setSublistValue({
                        id : ITEM_SUBLIST.ITEM,
                        line: line,
                        value : item
                    });

                    itemSublist.setSublistValue({
                        id : ITEM_SUBLIST.DISPLAY_NAME,
                        line: line,
                        value : displayName
                    });
                    
                    itemSublist.setSublistValue({
                        id : ITEM_SUBLIST.QUANTITY,
                        line: line,
                        value : replenimentQty
                    });
            
                    itemSublist.setSublistValue({
                        id : ITEM_SUBLIST.KEY,
                        line: line,
                        value : key
                    });
        
                    itemSublist.setSublistValue({
                        id : ITEM_SUBLIST.SOURCE_TRAN,
                        line: line,
                        value : sourceTran
                    });
                    line++;  
                }
            }

             // Call the function to convert the Item sublist in proper JSON format
             if(selectedItemList.length > 0){
                var fileId = createProperFormatFile(selectedItemList);
                if(fileId){
                    var taskId = runMapReduse(fileId);
                    log.debug('taskId', taskId);
                    form.addButton({id:FORMFIELDS.REFRESH_BTN,  label: 'Refresh', functionName: "getScheduleStatus('"+taskId+"')"}); //'+ taskId +'
                }
                context.response.writePage(form);
             }
        }
    }

    function  addSublistField(form, request){

        // Add sublist that will show Items
        if(request.method == 'GET'){
            var itemSublist = form.addSublist({
                id : ITEM_SUBLIST.SUBLIST,
                type : serverWidget.SublistType.LIST,
                label : 'Item'
            });

            var lineID = itemSublist.addField({
                id : 'custpage_line_id',
                label : 'Line Id',
                type : serverWidget.FieldType.TEXT
            });
            lineID.updateDisplayType({ displayType : serverWidget.FieldDisplayType.HIDDEN });

            var selectField = itemSublist.addField({
                id : ITEM_SUBLIST.SELECT,
                label : 'Select',
                type : serverWidget.FieldType.CHECKBOX
            });

            var item = itemSublist.addField({
                id : ITEM_SUBLIST.ITEM,
                label : 'Item',
                type : serverWidget.FieldType.SELECT,
                source: SOURCE_ITEM
            });
            item.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

            var displayName = itemSublist.addField({
                id : ITEM_SUBLIST.DISPLAY_NAME,
                label : 'Display Name',
                type : serverWidget.FieldType.TEXT
            });

            var unitType = itemSublist.addField({
                id : ITEM_SUBLIST.UNIT_TYPE,
                label : 'Primary Unit Type',
                type : serverWidget.FieldType.SELECT,
                source: 'unitstype'
            });
            unitType.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });
			//12/1/2021 Reorder Point 
			var reOrder = itemSublist.addField({
                id : 'custpage_reorder_point',
                label : 'Reorder Point',
                type : serverWidget.FieldType.FLOAT
            });
            reOrder.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var onHand = itemSublist.addField({
                id : ITEM_SUBLIST.ON_HAND,
                label : 'On Hand',
                type : serverWidget.FieldType.FLOAT
            });
            onHand.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var onOrder = itemSublist.addField({
                id : ITEM_SUBLIST.ON_ORDER,
                label : 'On Order',
                type : serverWidget.FieldType.FLOAT
            });
            onOrder.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var committed = itemSublist.addField({
                id : ITEM_SUBLIST.COMMITTED,
                label : 'Committed',
                type : serverWidget.FieldType.FLOAT
            });
            committed.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var backOrder = itemSublist.addField({
                id : ITEM_SUBLIST.BACK_ORDER,
                label : 'Back Order',
                type : serverWidget.FieldType.FLOAT
            });
            backOrder.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });
    
            var stockLevel = itemSublist.addField({
                id : ITEM_SUBLIST.STOCK_LEVEL,
                label : 'Preferred Stock Level',
                type : serverWidget.FieldType.FLOAT
            });
            stockLevel.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });
            
            var available = itemSublist.addField({
                id : ITEM_SUBLIST.AVAILABLE,
                label : 'Available',
                type : serverWidget.FieldType.FLOAT
            });
            available.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var qtyField = itemSublist.addField({
                id : ITEM_SUBLIST.QUANTITY,
                label : 'Replenish with Quantity',
                type : serverWidget.FieldType.FLOAT
            });

            qtyField.updateDisplayType({
                displayType : serverWidget.FieldDisplayType.ENTRY
            });

            var sourceType = itemSublist.addField({
                id : ITEM_SUBLIST.SOURCING_TYPE,
                label : 'Sourcing Type',
                type : serverWidget.FieldType.SELECT,
                source: SOURCING_TYPE_LIST_ID
            });
            sourceType.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });
    
            var sourcePoint = itemSublist.addField({
                id : ITEM_SUBLIST.SOURCING_POINT,
                label : 'Sourcing Point',
                type : serverWidget.FieldType.SELECT,
                source: SOURCING_POINT_LIST_ID
            });
            sourcePoint.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });
           
            var vendorField = itemSublist.addField({
                id : ITEM_SUBLIST.VENDOR,
                label : 'Vendor',
                type : serverWidget.FieldType.SELECT,
                source: SOURCE_VENDOR
            });
            vendorField.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

            var sourceTran = itemSublist.addField({
                id : ITEM_SUBLIST.SOURCE_TRAN,
                label : 'Source Transaction',
                type : serverWidget.FieldType.SELECT,
                source: SOURCE_TRAN_LIST_ID
            });
            sourceTran.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

            var tranId = itemSublist.addField({
                id : ITEM_SUBLIST.TRAN_ID,
                label : 'Transaction Link',
                type : serverWidget.FieldType.TEXT

            });
            tranId.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var key = itemSublist.addField({
                id : ITEM_SUBLIST.KEY,
                label : 'Unique Key',
                type : serverWidget.FieldType.INTEGER,
            });
            key.updateDisplayType({ displayType : serverWidget.FieldDisplayType.HIDDEN });
            itemSublist.addMarkAllButtons();

        }else{
            var itemSublist = form.addSublist({
                id : ITEM_SUBLIST.SUBLIST,
                type : serverWidget.SublistType.LIST,
                label : 'Item'
            });

            var item = itemSublist.addField({
                id : ITEM_SUBLIST.ITEM,
                label : 'Item',
                type : serverWidget.FieldType.SELECT,
                source: SOURCE_ITEM
            });
            item.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

            var displayName = itemSublist.addField({
                id : ITEM_SUBLIST.DISPLAY_NAME,
                label : 'Display Name',
                type : serverWidget.FieldType.TEXT
            });

            itemSublist.addField({
                id : ITEM_SUBLIST.QUANTITY,
                label : 'Replenish with Quantity',
                type : serverWidget.FieldType.FLOAT
            });

            var sourceTran = itemSublist.addField({
                id : ITEM_SUBLIST.SOURCE_TRAN,
                label : 'Source Transaction',
                type : serverWidget.FieldType.SELECT,
                source: SOURCE_TRAN_LIST_ID
            });
            sourceTran.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

            var processStatus = itemSublist.addField({
                id : ITEM_SUBLIST.PROCESSING_STATUS,
                label : 'Processing Status',
                type : serverWidget.FieldType.SELECT,
                source: SOURCE_PROCESSING_STATUS
            });
            processStatus.updateDisplayType({ displayType : serverWidget.FieldDisplayType.INLINE });

            var note = itemSublist.addField({
                id : ITEM_SUBLIST.MESSAGE,
                label : 'Note',
                type : serverWidget.FieldType.TEXTAREA
            });
            note.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var tranId = itemSublist.addField({
                id : ITEM_SUBLIST.TRAN_ID,
                label : 'Transaction Link',
                type : serverWidget.FieldType.TEXT
               
            });
            tranId.updateDisplayType({ displayType : serverWidget.FieldDisplayType.DISABLED });

            var key = itemSublist.addField({
                id : ITEM_SUBLIST.KEY,
                label : 'Unique Key',
                type : serverWidget.FieldType.INTEGER
            });
            key.updateDisplayType({ displayType : serverWidget.FieldDisplayType.HIDDEN });
           // itemSublist.addMarkAllButtons();
        }
        
        return itemSublist;
    }

    function runSearch(location, sourceType, vendor, unitType, displayItem, brandTypeValue){
        try {

            var filterExp = [];
            filterExp.push(["isinactive","is","F"]);
            filterExp.push('AND');
            filterExp.push(["inventorylocation","anyof", location]);
            filterExp.push( "AND");
            filterExp.push(["custrecord163.custrecord164","anyof", location]);

            if(sourceType == '1' || sourceType == '2'){
                filterExp.push( "AND");
                filterExp.push(["custrecord163.custrecord165","anyof", sourceType]);
            }
			
			if(brandTypeValue){
                filterExp.push( "AND");
                filterExp.push(["custitem_dilmar_brand","anyof", brandTypeValue]);
            }

            if(vendor){
                filterExp.push( "AND");
                filterExp.push(["custrecord163.custrecord168","anyof", vendor]);
            }

            if(unitType){
                filterExp.push( "AND");
                filterExp.push(["unitstype","anyof", unitType]);
            }

            
            if(displayItem && displayItem == '2'){
                filterExp.push( "AND");
                filterExp.push(["formulanumeric: ( ( NVL({locationquantityonhand}, 0) + NVL({locationquantityonorder},0)) - (NVL({locationreorderpoint}, 0) + NVL({locationquantitycommitted},0) + NVL({locationquantitybackordered},0)))","lessthan","0"])
            }

            var itemSearchObj = search.create({
                type: "item",
                filters:filterExp,
                columns:
                [
                    search.createColumn({name: "internalid", label: "Internal Id"}),
                    search.createColumn({name: "itemid",label: "Name" }),
                    search.createColumn({name: "displayname", sort: search.Sort.ASC,label: "Name" }),
                    search.createColumn({name: "unitstype", label: "Primary Units Type"}),
                    search.createColumn({name: "locationquantityavailable", label: "Location Available"}),
                    search.createColumn({name: "locationquantitycommitted", label: "Location Committed"}),
                    search.createColumn({name: "locationquantitybackordered", label: "Location Back Ordered"}),
                    search.createColumn({name: "locationquantityonhand", label: "Location On Hand"}),
                    search.createColumn({name: "locationquantityonorder", label: "Location On Order"}),
                    search.createColumn({name: "locationpreferredstocklevel", label: "Location Preferred Stock Level"}),
                    search.createColumn({name: "custrecord167", join: "CUSTRECORD163", label: "Source Transaction" }),
                    search.createColumn({name: "custrecord166", join: "CUSTRECORD163", label: "Sourcing Point " }),
                    search.createColumn({name: "custrecord165", join: "CUSTRECORD163", label: "Sourcing Type" }),
                    search.createColumn({name: "custrecord168", join: "CUSTRECORD163", label: "Vendor" }),
					search.createColumn({name: "locationreorderpoint",  label: "reorderpoint" })
                ]
             });

             var searchResultCount = itemSearchObj.runPaged().count;
             log.debug("itemSearchObj result count",searchResultCount);
             columnsArr = itemSearchObj.columns;
             log.debug('columnsArr', columnsArr.length);
             if(searchResultCount > 0){
                var pageData = itemSearchObj.runPaged({pageSize: PAGE_SIZE});
                return pageData ;
             } 
             
        } catch (error) {
            log.debug('Item Search Error', error);
        }
    }

    function fetchSearchResult(pageData, pageId, exFilterValue){
        var itemList = [];
        var searchPage = pageData.fetch({index: pageId});
        log.debug('Columns',columnsArr);
        searchPage.data.forEach (function (result){
            if(result){
				log.debug('result',result);
                var item = {};
                var itemId = result.getValue({name: columnsArr[0]})
                item['itemid'] = itemId;
                item['itemname'] = result.getValue(columnsArr[1]);
                item['displayname'] = result.getValue(columnsArr[2]);
                item['unittype'] = result.getValue(columnsArr[3]);
                item['available'] = result.getValue(columnsArr[4])|| 0;
                item['commited'] = result.getValue( columnsArr[5])|| 0;
                item['backorder'] = result.getValue(columnsArr[6])|| 0;
                item['onhand'] = result.getValue(columnsArr[7])|| 0;
                item['onorder'] = result.getValue(columnsArr[8])|| 0;
                item['stocklevel'] = result.getValue(columnsArr[9])|| 0;
                
                var replenimentQty = ((parseFloat(item.onhand) + parseFloat(item.onorder)) - (parseFloat(item.stocklevel) + parseFloat(item.commited) +  parseFloat(item.backorder))) ;
                item['available_qty'] = replenimentQty;
                if(replenimentQty < 0){
                    item['replenishqty'] = replenimentQty* -1;
                }else{
                    item['replenishqty'] = 0;
                }
                item['sourcetran'] = result.getValue(columnsArr[10]);
                item['sourcepoint'] = result.getValue(columnsArr[11]);
                item['sourcetype'] = result.getValue(columnsArr[12]);
                item['vendor'] = result.getValue(columnsArr[13]);
				item['reorderpoint'] = result.getValue(columnsArr[14]);
                if(exFilterValue == '2' ){
                    if(replenimentQty < 0){
                        //log.debug('-ve replenimentQty', 'exFilterValue: '+exFilterValue+', '+replenimentQty);
                        itemList.push(item);
                    }  
                }else{
                    //log.debug('+ve replenimentQty', 'exFilterValue: '+exFilterValue+', '+replenimentQty);
                    itemList.push(item);
                } 
            }
            return true;
        });
        return itemList;
    }

    function addFinalSublist(itemSublist, itemList){ 

        for(var line =0; line< itemList.length; line++){
            log.debug('Line: '+line, itemList[line])
            itemSublist.setSublistValue({
                id : 'custpage_line_id',
                line: line,
                value :  itemList[line].itemid+'_'+parseInt(line)
            });
    
            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.ITEM,
                line: line,
                value : itemList[line].itemid
            });

            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.DISPLAY_NAME,
                line : line,
                value : itemList[line].displayname
            });

            if(itemList[line].unittype){
                itemSublist.setSublistValue({
                    id : ITEM_SUBLIST.UNIT_TYPE,
                    line: line,
                    value : itemList[line].unittype
                });
            }
            
            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.COMMITTED,
                line: line,
                value : itemList[line].commited
            });
            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.ON_HAND,
                line: line,
                value : itemList[line].onhand
            });
            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.ON_ORDER,
                line: line,
                value : itemList[line].onorder
            });
    
            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.BACK_ORDER,
                line: line,
                value : itemList[line].backorder
            });

            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.AVAILABLE,
                line: line,
                value : itemList[line].available_qty
            });

            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.STOCK_LEVEL,
                line: line,
                value : itemList[line].stocklevel
            });

            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.QUANTITY,
                line: line,
                value : itemList[line].replenishqty
            });

            if(itemList[line].sourcepoint){
                itemSublist.setSublistValue({
                    id : ITEM_SUBLIST.SOURCING_POINT,
                    line: line,
                    value : itemList[line].sourcepoint
                });
            }
            if(itemList[line].sourcetype){
                itemSublist.setSublistValue({
                    id : ITEM_SUBLIST.SOURCING_TYPE,
                    line: line,
                    value : itemList[line].sourcetype
                });
            }
            if(itemList[line].sourcetran){
                itemSublist.setSublistValue({
                    id : ITEM_SUBLIST.SOURCE_TRAN,
                    line: line,
                    value : itemList[line].sourcetran
                });
            }
    
            if(itemList[line].vendor){
                itemSublist.setSublistValue({
                    id : ITEM_SUBLIST.VENDOR,
                    line: line,
                    value : itemList[line].vendor
                });
            }

            var d = new Date();
            var key = Date.parse(d);
            itemSublist.setSublistValue({
                id : ITEM_SUBLIST.KEY,
                line: line,
                value : itemList[line].itemid+''+key
            });
			if(itemList[line].reorderpoint){
			itemSublist.setSublistValue({
                    id : 'custpage_reorder_point',
                    line: line,
                    value : itemList[line].reorderpoint
                });
			}
    
        }
    }

    function createProperFormatFile(selectedItemList){
        var tranType = [];
        var sourcePoints = [];
        var vendors = [];
        var objectParam = [];
        for(var i = 0; i < selectedItemList.length; i++){
            var sourceTran = selectedItemList[i].recordtype;
            if(tranType.indexOf(sourceTran) === -1){
                var tranFilter = selectedItemList.filter (function (tf){
                    return tf.recordtype == sourceTran;
                });
                if(sourceTran == '1'){
                    // Transfer Order
                    for(var j=0; j< tranFilter.length; j++){
                        var sourcePoint = tranFilter[j].source;
                        if(sourcePoints.indexOf(sourcePoint) === -1){
                            var locationFilter = tranFilter.filter(function (lf){
                                return lf.source == sourcePoint;
                            });
                            var line = {};
                            var itemline = [];
                            line['subsidiary'] = tranFilter[j].subsidiary;
                            line['location'] = tranFilter[j].location;
                            line['recordtype'] = sourceTran;
                            line['unique_id'] = tranFilter[j].unique_id;
                            line['source'] = sourcePoint;
                            
                            for(var l =0; l < locationFilter.length; l++){
                                var items = {};
                                items['item'] = locationFilter[l].item;
                                items['key'] = locationFilter[l].key;
                                items['quantity'] = locationFilter[l].quantity;

                                itemline.push(items);
                            }
                            line['itemline'] = itemline;
                            objectParam.push(line);
                            sourcePoints.push(sourcePoint);
                        }
                    }
                }else if(sourceTran == '2'){
                    // Purchase Order
                    for(var j=0; j< tranFilter.length; j++){
                        var vendor = tranFilter[j].vendor;
                        if(vendors.indexOf(vendor) === -1){
                            var vendorFilter = tranFilter.filter(function (vf){
                                return vf.vendor == vendor;
                            });
                            var line = {};
                            var itemline = [];
                            line['subsidiary'] = tranFilter[j].subsidiary;
                            line['location'] = tranFilter[j].location;
                            line['recordtype'] = sourceTran;
                            line['unique_id'] = tranFilter[j].unique_id;
                            line['vendor'] = vendor;
                            for(var l=0; l<vendorFilter.length; l++){
                                var items = {};
                                items['item'] = vendorFilter[l].item;
                                items['key'] = vendorFilter[l].key;
                                items['quantity'] = vendorFilter[l].quantity;

                                itemline.push(items);
                            }
                            line['itemline'] = itemline;
                            objectParam.push(line);
                            vendors.push(vendor);
                        }
                    }
                }
               
                tranType.push(sourceTran);
            }
        }
        log.debug('objectParam', objectParam);
        var d = new Date();
        var user = runtime.getCurrentUser();
        var fileId ;
        try {
            var fileObj = file.create({
                name: user+''+d+'.txt',
                fileType: file.Type.PLAINTEXT,
                contents: JSON.stringify(objectParam),
                encoding: file.Encoding.UTF8,
                folder: 1241
            });
            fileId = fileObj.save();
            log.debug('fileId', fileId);
        } catch (error) {
            log.debug('File Error', error);
        }
        return fileId;
    }

    function runMapReduse(fileId){
        var taskId ;
        try {
            if(fileId){
    
               var mapTask = task.create({
                    taskType: task.TaskType.MAP_REDUCE,
                    scriptId: SCRIPT.ID,
                    deploymentId: SCRIPT.DEPOYMENT_ID,
                    params: {'custscript_parameters' : fileId}
                });

                taskId = mapTask.submit();
                var taskStatus = task.checkStatus(taskId);
               // log.debug('taskStatus', taskStatus);
            }
        } catch (error) {
            log.debug('Call Map/Reduce', error);
        }  

        return taskId;
    }

    return {
        onRequest: onRequest
    }
});
