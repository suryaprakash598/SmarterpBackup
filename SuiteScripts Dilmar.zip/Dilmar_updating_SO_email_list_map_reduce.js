/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/redirect','N/search'],

function(record, redirect, search) {
   
    /**
     * Marks the beginning of the Map/Reduce process and generates input data.
     *
     * @typedef {Object} ObjectRef
     * @property {number} id - Internal ID of the record instance
     * @property {string} type - Record type id
     *
     * @return {Array|Object|Search|RecordRef} inputSummary
     * @since 2015.1
     */
    function getInputData() {
    	var salesorderSearchObj = search.create({
   type: "salesorder",
   filters:
   [
      ["type","anyof","SalesOrd"], 
      "AND", 
      ["status","anyof","SalesOrd:B","SalesOrd:G","SalesOrd:D","SalesOrd:F","SalesOrd:E"],
      "AND", 
      ["custbody_dil_emailsent","is","F"],
      "AND", 
      ["custbody_so_email_list_updated","is","F"],
      "AND", 
      ["datecreated","onorafter","10/6/2021 12:00 am"],
      "AND", 
      ["mainline","is","T"],
     "AND", 
      ["custbody_dil_so_buyback_vendor","noneof","1","2"]//1=shell 2=petro canada
   ],
   columns:
   [
      search.createColumn({name: "internalid", label: "Internal ID"})
   ]
});
var arr=[];
var searchResultCount = salesorderSearchObj.runPaged().count;
log.debug("salesorderSearchObj result count",searchResultCount);
salesorderSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var so_id = result.getValue({
            name: "internalid"
        })
	arr.push(so_id);
   return true;
});
      log.debug(arr)
return arr;
    }

    /**
     * Executes when the map entry point is triggered and applies to each key/value pair.
     *
     * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
     * @since 2015.1
     */
    function map(context) {
		var rec_id = context.value;
    	try{
    	log.debug('Record ID', rec_id);
				var sales_order =record.load({
 type: record.Type.SALES_ORDER,
 id: rec_id
 })
 var entity=sales_order.getValue({fieldId:'entity'});
 var email=findEmailList(entity);
 var email_list = email.toString();
 log.debug(entity,email_list);
 var setting_emails = sales_order.setValue({
					fieldId: 'custbody_dil_so_emaillist',
					value:email_list
				});
	var setting_native_email_field = sales_order.setValue({
					fieldId: 'email',
					value:email_list
				});
var email_list_updated	=sales_order.setValue({
	fieldId: 'custbody_so_email_list_updated',
					value:true
});		
 
 var id=sales_order.save({enableSourcing: true, ignoreMandatoryFields: true});
    	log.debug('SO',id);
    }
	catch(e){
		log.debug('error',rec_id)
		log.error('error',e)
	}
	}
	
	
	// Search for the contacts associated with Customers and Vendors
function findEmailList(entity){
  	var emails = [];
			var contactSearchObj = search.create({
			   type: "contact",
			   filters:
			   [
				  ["isinactive","is","F"], 
				  "AND", 
				  ["email","isnotempty",""], 
                 "AND",
                 ["custentity_dil_contact_so_notify","is","T"],
				  "AND", 
				  ["company.internalid","anyof",entity]
			   ],
			   columns:
			   [
				  search.createColumn({
				  name: "email"})
				  
			   ]
			});
		
			 var curr_emailaddress,all_emailaddresses;
			contactSearchObj.run().each(function(result){
               if (emails.length <= 10)
              {
                 curr_emailaddress = result.getValue("email");
                 var existing_email = emails.indexOf(curr_emailaddress);
                 if (existing_email == -1)
                    { 
                      all_emailaddresses = all_emailaddresses+curr_emailaddress+";";
                      if (all_emailaddresses.length <= 254)
                      {emails.push(result.getValue("email"));}
                    }
              }
			    return true;
			});
			return emails;
	}
   
   
    /**
     * Executes when the reduce entry point is triggered and applies to each group.
     *
     * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
     * @since 2015.1
     */
    function reduce(context) {

    }


    /**
     * Executes when the summarize entry point is triggered and applies to the result set.
     *
     * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
     * @since 2015.1
     */
    function summarize(summary) {

    }

    return {
        getInputData: getInputData,
        map: map,
        //reduce: reduce,
        //summarize: summarize
    };
    
});
