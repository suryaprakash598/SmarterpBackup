/*******************************************************************************
{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 *
 ******************************************************************************/

define(['N/runtime', 'N/task', 'N/record', 'N/search', 'N/log'], function(
  /** @type {import('N/runtime')} **/ runtime,
  /** @type {import('N/task')}    **/ task,
  /** @type {import('N/record')}  **/ record,
  /** @type {import('N/search')}  **/ search,
  /** @type {import('N/log')}     **/ log
) {

  /**
   * context.newRecord
   * context.oldRecord
   * context.type
   *
   * @type {import('N/types').EntryPoints.UserEvent.afterSubmit}
   */
  function afterSubmit(context) {
     try{
		var rec = context.newRecord;  //create mode
		var rectype = rec.type;
		var recId = rec.id;
		var _createdFrom = rec.getValue({fieldId:'createdfrom'})
		log.debug('_createdFrom',_createdFrom);
		 if(_createdFrom)
		 {
			 var recObj = record.load({type:'salesorder',id:_createdFrom,isDynamic:true});
			 var customer = recObj.getValue({fieldId:'entity'});
			var acceptBackOrders = search.lookupFields({type:'customer',id:customer,columns:['custentity_dil_cust_accept_backorders']});
			log.debug('acceptBackOrders',acceptBackOrders);
			if(!acceptBackOrders.custentity_dil_cust_accept_backorders)
			{
				/* var multifulfillments = recObj.getValue({fieldId:'entity'});
				if(multifulfillments){
					recObj.setValue({fieldId:'custbody_zdo_multiplefulfiments',value:false,ignoreFieldChange:true});
				} */
					recObj.setValue({fieldId:'custbody_zdo_multiplefulfiments',value:true,ignoreFieldChange:true});
				 
			}
			var id = recObj.save({
                    enableSourcing: true,
                    ignoreMandatoryFields: true
          		  });
			log.debug('Id',id);
		 }
		
		
		  //custbody_zdo_multiplefulfiments
		
		
	 }catch(e)
	 {
		 log.debug('Error',e.toString());
	 }
  }

  /**
   * context.newRecord
   * context.type
   * context.form
   * context.request
   *
   * @type {import('N/types').EntryPoints.UserEvent.beforeLoad}
   */
  function beforeLoad(context) {
    // no return value
  }

  /**
   * context.newRecord
   * context.oldRecord
   * context.type
   *
   * @type {import('N/types').EntryPoints.UserEvent.beforeSubmit}
   */
  function beforeSubmit(context) {
    // no return value
  }

  return {
    'afterSubmit':  afterSubmit,
    'beforeLoad':   beforeLoad,
    'beforeSubmit': beforeSubmit
  };

});
