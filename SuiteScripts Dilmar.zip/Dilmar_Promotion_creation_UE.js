/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/currentRecord','N/search','N/ui/serverWidget'],

function(record,currentrecord,search,serverWidget) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
		
			
		 if(scriptContext.type == scriptContext.UserEventType.CREATE||scriptContext.type == scriptContext.UserEventType.EDIT)
		 {
			 
			 var field1=scriptContext.form.getField({
			id : 'custrecord_promotion_error'
			});
			field1.updateDisplayType({
 displayType : serverWidget.FieldDisplayType.HIDDEN
});
		 } if(scriptContext.type == scriptContext.UserEventType.VIEW)
		 {
			 var rec = scriptContext.newRecord; //create mode
			if(!rec){
				rec=scriptContext.oldRecord;
			}
            var rectype = rec.type;
            var recId = rec.id;
            var recObj = record.load({
                type: rectype,
                id: recId 
            });
            var flag=recObj.getValue({fieldId:'custrecord_doc_imported'});
			 if(flag){
				 			 var field1=scriptContext.form.getField({
			id : 'custrecord_promotion_error'
			});
			field1.updateDisplayType({
 displayType : serverWidget.FieldDisplayType.HIDDEN
});
			 }

		 } 

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
		var rec = scriptContext.newRecord; //create mode
			if(!rec){
				rec=scriptContext.oldRecord;
			}
            var rectype = rec.type;
            var recId = rec.id;
            var recObj = record.load({
                type: rectype,
                id: recId 
            });
            var name=recObj.getValue({fieldId:'custrecord_ns_promoname'});
			var description=recObj.getValue({fieldId:'custrecord_doc_promodescription'});
			
		

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {
		 if(scriptContext.type == scriptContext.UserEventType.CREATE||scriptContext.type == scriptContext.UserEventType.EDIT)
		 {
    	var rec = scriptContext.newRecord; //create mode
			if(!rec){
				rec=scriptContext.oldRecord;
			}
            var rectype = rec.type;
            var recId = rec.id;
            var recObj = record.load({
                type: rectype,
                id: recId 
            });
            var name=recObj.getValue({fieldId:'custrecord_ns_promoname'});
			var description=recObj.getValue({fieldId:'custrecord_doc_promodescription'});
			var startdate=recObj.getValue({fieldId:'custrecord_ns_promostartdate'});
			var enddate=recObj.getValue({fieldId:'custrecord_ns_promoenddate'});
			var item=recObj.getValue({fieldId:'custrecord_ns_promotionitemtest'});
			var quantity=recObj.getValue({fieldId:'custrecord_ns_promoquantity'});
			var price=recObj.getValue({fieldId:'custrecord_ns_dilmarpromotionprice'});
			var promoflag=recObj.getValue({fieldId:'custrecord_doc_imported'});
			//var lineid=recObj.getValue({fieldId:'custrecord_doc_lineid'});
			var pcode=recObj.getValue({fieldId:'custrecordpcode'});
			name=name+'.'+item;
			
			
		if(!promoflag){
			log.debug('hahaha')
		//Checking if promotion code avalible or not	
			var promotioncodeSearchObj = search.create({
   type: "promotioncode",
   filters:
   [
   ],
   columns:
   [
      search.createColumn({
         name: "name",
         sort: search.Sort.ASC,
         label: "Name"
      }),
      search.createColumn({name: "code", label: "Coupon Code"}),
      search.createColumn({name: "startdate", label: "Start Date"}),
      search.createColumn({name: "enddate", label: "End Date"}),
      search.createColumn({name: "canbeautoapplied", label: "This Promotion Can Be Automatically Applied"})
   ]
});
var match_found;
var searchResultCount = promotioncodeSearchObj.runPaged().count;
log.debug("promotioncodeSearchObj result count",searchResultCount);
promotioncodeSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var name_old =result.getValue({
                    name: "name" 
                });
				if(name_old==name){
				match_found=true;	
				}
			return true;
			});
			// if name found in search then terminate the execution
			if(match_found)
			{
				 var otherId = record.submitFields({
				type: rectype,
				id: recId,
				values: {
						'custrecord_promotion_error':'Promotion Name already exists. Promotion Name Must be Unique'
						}
				});
				return true;
				
			}
			if(quantity<1||price<1){
				 var otherId = record.submitFields({
				type: rectype,
				id: recId,
				values: {
						'custrecord_promotion_error':'Promotion Quantity/Price must be Greater than 0'
						}
				});
				return true;
			}

			
			
    		 var rec = record.create({
             type: 'promotioncode',
             isDynamic: true,
            
         });
 		
         log.debug('record', rec);
 		rec.setValue({
             fieldId: 'customform',
             value:161
         });//custrecord_ns_pcode
		 rec.setText({
             fieldId: 'custrecord_ns_pcode',
             text:pcode
         });
 		rec.setText({
             fieldId: 'name',
             text: name
         });
 		rec.setValue({
             fieldId: 'startdate',
             value: new Date(startdate)
         });
		 rec.setValue({
             fieldId: 'enddate',
             value: new Date(enddate)
         });
		 rec.setText({
             fieldId: 'description',
             text: description
         });
 		
 		rec.setText({
             fieldId: 'code',
             text: name
         });
 		
         rec.setValue({
             fieldId: 'combinationtype',
             value: 'ITEMLINEEXCLUSIVE'
         });
 		 rec.setValue({
             fieldId: 'whatthecustomerneedstobuy',
             value: 'MINIMUMORDERAMOUNTORSPECIFICITEMS'
         });
 		 rec.setValue({
             fieldId: 'minimumorderamountcheck',
             value:true
         });
 		 rec.setValue({
             fieldId: 'itemquantifier',
             value:quantity
         });
 		 rec.setValue({
             fieldId: 'rate',
             value:10
         });
 		rec.setValue({
            fieldId: 'discount',
            value:12
        });
        rec.setValue({
            fieldId: 'fixedprice',
            value:price
        });
 		rec.setValue({
             fieldId: 'canbeautoapplied',
             value:false
         });
         rec.setValue({
             fieldId: 'specificitemscheck',
             value:true
         });
		 rec.setValue({
             fieldId: 'audience',
             value:'SPECIFICCUSTOMERS'
         });
		 rec.setValue({
             fieldId: 'customergroup',
             value:509
         });
		 
         rec.selectNewLine({
             sublistId: 'items'
         });
         rec.setCurrentSublistValue({
             sublistId: 'items',
             fieldId: 'item',
             value: item
         });
         
         rec.commitLine({
             sublistId: 'items'
         });
         rec.selectNewLine({
             sublistId: 'discounteditems'
         });
         rec.setCurrentSublistValue({
             sublistId: 'discounteditems',
             fieldId: 'discounteditem',
             value: item
         });
         
         rec.commitLine({
             sublistId: 'discounteditems'
         });
         log.debug('record', rec);
 		try {
         var recordId = rec.save();
         log.debug('recordId', recordId);
		 
		 var otherId = record.submitFields({
				type: rectype,
				id: recId,
				values: {
						'custrecord_doc_imported': true,
						'custrecord_promotion_link':recordId,
						'custrecord_promotion_error':''
						}
				});	 
		 
     } catch (e) 
	 {
         log.debug('error', e.toString());
         //return 'creditmemo'; 
     }
		}

    }
	}

    return {
        beforeLoad: beforeLoad,
        //beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
    
});
