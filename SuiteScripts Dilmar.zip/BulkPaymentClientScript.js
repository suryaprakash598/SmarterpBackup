/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/format', 'N/record', 'N/search','N/ui/dialog'],
/**
 * @param {format} format
 * @param {record} record
 * @param {search} search
 */
function(format, record, search,dialog) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
	
function deleteSublistRows(records){
		
		var numLines = records.getLineCount({
		    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id'
		});
		log.debug('num lines',numLines);
		if (numLines > 0)
			{
				for (var j=numLines; j>0; j--)
					{
					var objSublist = records.selectLine({
					    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					    line: j -1
					});
						var applyflag = records.getCurrentSublistValue({
							sublistId:'recmachcustrecord_dil_bulk_pay_hdr_id',
								fieldId:'custrecord_dil_bulk_pay_apply_dtl'
						})
						log.debug('apply flag line',applyflag +' '+j);
						if (!applyflag){
							records.removeLine({
							    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
							    line: j-1,
							    ignoreRecalc: true
							});
						}
					}
			}

	}

	function getTransactionSearch(direct_debit,due_date,cust_name){
		var filter = [
		  ["type","anyof","CustInvc"], 
		  "AND", 
		  ["mainline","is","T"], 
		  "AND", 
		  ["status","anyof","CustInvc:A"], 
		  "AND", 
		  ["accounttype","anyof","AcctRec"], 
		  "AND", 
		  ["amountremaining","greaterthan","0.00"], 
		]		
		
		if (direct_debit)
		{
			filter.push("AND"); 
			filter.push(["customer.custentity_2663_direct_debit","is","T"]);
		}
		
		if (due_date)
		{
			due_date = format.format({value:due_date, type: format.Type.DATE});
			filter.push("AND"); 
			filter.push(["duedate","onorbefore",due_date]);
		}
		
		if (cust_name.length > 0)
		{
			filter.push("AND"); 
			filter.push(["name","anyof",cust_name]);
		}
		
		var invoiceSearchObj = search.create({
		   type: "invoice",
		   filters: filter,
		   columns:
		   [
			  search.createColumn({
				 name: "entity",
				 sort: search.Sort.ASC
			  }),
			  search.createColumn({
				 name: "phone",
				 join: "customer"
			  }),
			  search.createColumn({
				 name: "email",
				 join: "customer"
			  }),
			  "internalid",
			  "tranid",
			  "trandate",
			  "terms",
			  "duedate",
			  "amount",
			  "amountremaining",
			  "discountamount"
		   ]
		});
		return invoiceSearchObj;
	}
	
	
	
	function setPaymentDate(current,applydate){
		//var current = context.currentRecord;
		var numLines = current.getLineCount({
		    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id'
		});
		log.debug('payment set num lines',numLines);
		if (numLines > 0)
			{
				for (var j=0; j<numLines; j++)
					{
					var objSublist = current.selectLine({
					    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					    line: j
					});
					log.debug('apply date ca payment set',format.format({value:applydate, type: format.Type.DATE}));
					//applydate = format.format({value:applydate, type: format.Type.DATE});
					current.setCurrentSublistValue({
								sublistId:'recmachcustrecord_dil_bulk_pay_hdr_id',
								fieldId:'custrecord_dil_bulk_pay_paydt_dtl',
								value: applydate
									
						})
						
					}
			}

	}
	
	function selectLines(current,applyflag){
		//var current = context.currentRecord;
		var numLines = current.getLineCount({
		    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id'
		});
		log.debug('payment set num lines',numLines);
		if (numLines > 0)
			{
				for (var j=0; j<numLines; j++)
					{
					var objSublist = current.selectLine({
					    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					    line: j
					});
	
					current.setCurrentSublistValue({
								sublistId:'recmachcustrecord_dil_bulk_pay_hdr_id',
								fieldId:'custrecord_dil_bulk_pay_apply_dtl',
								value: applyflag
									
						})
						
					}
			}

	}
	
	function loadPayments(records,eft,duedate,customer,pymntdt){
		//records = context.currentRecord;
		log.debug("load payment called result count",duedate+' '+customer+' '+eft);
	
	var transactionSearchObj = getTransactionSearch(eft,duedate,customer);
	var tranArray=[];

	var searchResultCount = transactionSearchObj.runPaged().count;
	log.debug("transactionSearchObj result count",searchResultCount);
	
	transactionSearchObj.run().each(function(result){
				 var tranData = new Object(); 
				 tranData["id"]=result.getValue({name: "internalid"});
				 tranData["entity"] = result.getValue({name: "entity"});
				 tranData["entityname"]= result.getText({name: "entity"});
				 tranData["trandate"]=result.getValue({name: "trandate"});
				 tranData["internalid"]=result.getValue({name: "internalid"});
				 tranData["tranid"]=result.getValue({name: "tranid"});
				 var invduedt = result.getValue({name:"duedate"});
				 if (Date.parse(invduedt)){
				 invduedt = format.parse({value:invduedt, type: format.Type.DATE});}
				 tranData["duedate"]= invduedt;
				 tranData["amount"]=result.getValue({name: "amount"});
				 tranData["amountdue"]=result.getValue({name: "amountremaining"});
				 tranData["terms"]=result.getText({name: "terms"});
				 tranData["email"]=result.getValue({name: "email",join: "customer"});
				 tranData["phone"]=result.getValue({name: "phone",join: "customer"});
				 tranArray.push(tranData);
				 return true;
	});
	
	tranArray.sort();
	if (tranArray.length > 0)
		{
		
		
		 for (var i = 0; i < tranArray.length; i++){
			 log.debug('in tranarray',tranArray.length);
			 log.debug('values',tranArray[i].internalid +' '+tranArray[i].duedate+' '+tranArray[i].amount);
			 var lineNum = records.selectNewLine({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id'
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_inv_internal_id',
				    value: tranArray[i].internalid
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_refno_dtl',
				    value: tranArray[i].tranid
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_amt_dtl',
				    value: tranArray[i].amount
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_cust_dtl',
				    value: tranArray[i].entity
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_cust_ph',
				    value: tranArray[i].phone
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_cust_email_dtl',
				    value: tranArray[i].email
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_terms_dtl',
				    value: tranArray[i].terms
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_dueamt_dtl',
				    value: tranArray[i].amountdue
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_paydt_dtl',
				    value: pymntdt
				});
			 records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_bulk_pay_due_dt_dtl',
				    value: tranArray[i].duedate
				});
           if (eft){
             log.debug('coming inside eft if',eft);
              records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_buik_pay_pymnt_method_dtl',
				    value: 7
				});
           } else
             {
               records.setCurrentSublistValue({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				    fieldId: 'custrecord_dil_buik_pay_pymnt_method_dtl',
				    value: 5
				});
             }
			 records.commitLine({
				    sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id'
				}); 
				 }
		}
	}
	
    	
	
    function pageInit(context) {
    
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     * @param {string} context.fieldId - Field name
     * @param {number} context.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} context.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(context) {
    	var currentRecord = context.currentRecord;
        var custFieldName = context.fieldId;
    	var customerid = currentRecord.getValue({
			fieldId : 'custrecord_dil_bulk_pay_cust_name'
		});
    	
      	var applydate = currentRecord.getValue({
     		fieldId :'custrecord_dil_bulk_pay_pymnt_date'});
     	applydate = format.parse({value:applydate, type: format.Type.DATE});
     	var eft;
     	var bankaccount = currentRecord.getValue({
     		fieldId :'custrecord_dil_bulk_pay_deposit_to_acct'});
      	
   
    	if (custFieldName === 'custrecord_dil_bulk_pay_cust_name' && customerid.length > 0)
        {
           eft = false;
    		loadPayments(currentRecord,eft,duedate,customerid,applydate);
        }
       /* else if (custFieldName === 'custrecord_dil_bulk_pay_eft_customer')
        {
       	
        }*/
        else if (custFieldName === 'custrecord_dil_bulk_pay_duedate')
        {
        	deleteSublistRows(currentRecord);
        	var duedate = currentRecord.getValue({
        		fieldId :'custrecord_dil_bulk_pay_duedate'});
        	if (Date.parse(duedate))	{
        	duedate = format.parse({value:duedate,type: format.Type.DATE});
            eft = true;
        	log.debug('due date',duedate + ' '+format.format({value:duedate,type:format.Type.DATE}));
        	
        	loadPayments(currentRecord,eft,duedate,'',applydate);}
        }
        else if (custFieldName === 'custrecord_dil_bulk_pay_pymnt_date')
        {    	var applydate = currentRecord.getValue({
     		fieldId :'custrecord_dil_bulk_pay_pymnt_date'});
     	applydate = format.parse({value:applydate, type: format.Type.DATE});
        	setPaymentDate(currentRecord,applydate);
        }
        else if (custFieldName === 'custrecord_dil_bulk_pay_select_all_cb')
        {
        	var applyflag = currentRecord.getValue('custrecord_dil_bulk_pay_select_all_cb');
        	selectLines(currentRecord,applyflag);
        }
    	var sublist = context.sublistId;
		var select_apply = context.fieldId;
		/* for the payment amount population from the due amount on apply */
    		if (select_apply === 'custrecord_dil_bulk_pay_apply_dtl'){
     		log.debug(' subslist ',sublist);
			var apply_selected = currentRecord.getCurrentSublistValue({
				sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
				fieldId: select_apply
			});
				if (apply_selected)
				{
				 var dueamount = currentRecord.getCurrentSublistValue({
					 sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					 fieldId: 'custrecord_dil_bulk_pay_dueamt_dtl'
				 })
				 currentRecord.setCurrentSublistValue({
					 sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					 fieldId: 'custrecord_dil_bulk_pay_pymnt_amt_dtl',
					 value : dueamount
				 })
				} else
					{
					currentRecord.setCurrentSublistValue({
    					 sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
    					 fieldId: 'custrecord_dil_bulk_pay_pymnt_amt_dtl',
    					 value : ''
    				 })
					}
		}

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     * @param {string} context.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(context) {

    	    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(context) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(context) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     * @param {string} context.fieldId - Field name
     * @param {number} context.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} context.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(context) {
    	    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(context) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(context) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @param {string} context.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(context) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} context
     * @param {Record} context.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(context) {
   	var currecord = context.currentRecord;
    /*var a;
    	var options = {
    			title: 'Payment Confirmation',
    			message: 'The selected payments will be applied. Press OK or Cancel'
    	};
    	function success(result){
    		log.debug('press result',result);
    		if(result){
    			return true;
     		}
    	}
    	var selectedOption = dialog.confirm(options);
    	if (selectedOption){success(true)
    		return true;
    	}else return false;
*/
			deleteSublistRows(currecord);
			return true;
			  
    }
    return {
        //pageInit: pageInit,
        fieldChanged: fieldChanged,
       // postSourcing: postSourcing,
       // fetchRecords: fetchRecords,
        //sublistChanged: sublistChanged,
        //lineInit: lineInit,
        //validateField: validateField,
        //validateLine: validateLine,
        //validateInsert: validateInsert,
        //validateDelete: validateDelete,
      //  saveRecord: saveRecord
        //loadPayments: loadPayments
    };
    
});
