/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/ui/dialog','N/format','N/record'],
/**
 * @param {dialog} dialog
 */
function(dialog,format,record) {
    
  

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
try{
    	var fulfillment = scriptContext.currentRecord; 
    	
		var lineCount = fulfillment.getLineCount({
    sublistId: 'item'
});

//for each line set the "itemreceive" field to true
for (var i = 0; i < lineCount; i++) {
	var second_fulfiment=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'custcol_bulk_second_fulfiment_check',
	  line: i
  });
  var fulfill=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'itemreceive',
	  line: i
  });
  log.debug(second_fulfiment,fulfill)
		if((second_fulfiment==true||second_fulfiment)&&fulfill){
			log.debug('second_fulfiment',fulfill)
			 var item_name=fulfillment.getSublistValue({
      sublistId: 'item',
      fieldId: 'itemdescription',
	  line: i
  });
		var msg='Please check the item '+ item_name+'. There is an Item Fulfillment created for this item.  Please check the Related Records Tab in the Sales Order.';
		log.debug('msg',msg)
						alert(msg);
						return false;
		}
}
var setting_backorderflag=fulfillment.getValue({
      fieldId: 'custbody_accept_back_order_if'
  });
  var so=fulfillment.getValue({
      fieldId: 'createdfrom'
  });
  var so_str=fulfillment.getText({
      fieldId: 'createdfrom'
  });
  so_str=JSON.stringify(so_str);
          
  if((so_str.indexOf("Sales Order")==-1))//so_str.includes("Sales Order")
  {
    return true;
  }
  var SaleOrder = record.load({
                    type: 'salesorder',
                    id: so,
                    isDynamic: false,
                });
				var firstfulfilment=false;
				var id;
    	for (var i = 0; i < SaleOrder.getLineCount({sublistId: 'links'}); i++) {
			 type = SaleOrder.getSublistValue({
				sublistId: 'links',
				fieldId: 'type',
				line:i
				});
				if(type=='Item Fulfillment'){
			 firstfulfilment=true
			}
	}
  
  if(setting_backorderflag&&firstfulfilment){
	  var msg='The Customer is does not accepting the Back Orders.';
		log.debug('msg',msg)
						alert(msg);
						return false;
  }
    	}
		catch (e) {
        log.error('error',e);
        
      }
	  return true;
    }

    return {
      
       
        saveRecord: saveRecord
    };
    
});
