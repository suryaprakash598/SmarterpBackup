/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/record', 'N/search','N/ui/dialog','N/format','N/http','N/url','N/currentRecord'],

    function(record, search,dialog,format,http,url,currentrecord) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
var exports = {};
        function pageInit(scriptContext) {
            
           

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
           
			

        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {
			
        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {


        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2  shipzip
         */
        function validateField(scriptContext) {


        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {
			 

        }
		
		

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }
		function searching(){
	   
   	var record = currentrecord.get();
   	
   	var sdate=record.getValue({
      	 fieldId: 'custpage_sdate'
      	 });
	var edate=record.getValue({
     	 fieldId: 'custpage_edate'
     	 });
   	 
	 
	 var output = url.resolveScript({
		   scriptId: 'customscript_dil_payment_transfer_pc',
		   deploymentId: 'customdeploy_dil_payment_transfer_pc',
		   //returnExternalUrl: true
		  });
	  
	 //11/5/2020 format needed
	 if(sdate){
	 var filterDate = new Date(sdate);
	 var fDate  = filterDate.getDate();
	 var fMonth  = filterDate.getMonth()+1;
	 var fYear  = filterDate.getFullYear();
	 var dateFilter  = fMonth+"/"+fDate+"/"+fYear;
   	 
 		   output=output+'&sdate='+dateFilter;
	 }
	 if(edate){
		 var filterDate = new Date(edate);
		 var fDate  = filterDate.getDate();
		 var fMonth  = filterDate.getMonth()+1;
		 var fYear  = filterDate.getFullYear();
		 var dateFilter  = fMonth+"/"+fDate+"/"+fYear;
	   	 
	 		   output=output+'&edate='+dateFilter; 
	 }
	 
 	 output=output+'&filter=true'
	 
if (window.onbeforeunload){
   window.onbeforeunload=function() { null;};
};
 	   console.log(output);
 	  location.replace(output);
 
   }
   function resetfun(){
	   //var vid =context.request.parameters.custpage_ven_name;
	   console.log('calling');
	  
	
   	 var output = url.resolveScript({
 		   scriptId: 'customscript_dil_payment_transfer_pc',
 		   deploymentId: 'customdeploy_dil_payment_transfer_pc',
 		   //returnExternalUrl: true
 		  });
 	 
 	   console.log(output);
 	  location.replace(output);

   }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
		  var finalResult = false
	
        //Flag to indicate if user provided final answer or not
	finalResultSet = false;
	
        function saveRecord(scriptContext) {
			var total=0;
			 var currentRecord = scriptContext.currentRecord;
		var numLines = currentRecord.getLineCount({
			sublistId: 'rebateprocess'
			});
			for (var i =0; i < numLines; i++) {
				var is_Checked = currentRecord.getSublistValue({
                        sublistId: 'rebateprocess',
                        fieldId: '_mark',
						line:i
                    });
					
			if(is_Checked){
				var amount_remaining = currentRecord.getSublistValue({
                        sublistId: 'rebateprocess',
                        fieldId: '_amount_remaining',
						line:i
                    });
				var type = currentRecord.getSublistValue({
                        sublistId: 'rebateprocess',
                        fieldId: '_type',
						line:i
                    });
					console.log('amount_remaining'+format.parse({value:amount_remaining, type: format.Type.FLOAT}));
					var l=format.parse({value:amount_remaining, type: format.Type.FLOAT});
					if(type=='Invoice'){
						total=  total+ format.parse({value:amount_remaining, type: format.Type.FLOAT});// parseFloat(total).toFixed(2)+parseFloat(amount_remaining).toFixed(2);
					}
					else{
						total=  total+ format.parse({value:amount_remaining, type: format.Type.FLOAT});// parseFloat(total).toFixed(2)+parseFloat(amount_remaining).toFixed(2);
					}
					console.log(l);
				
			}
			}
			
			if (!finalResultSet)
    	{
    		//Here you do your own saveRecord validation/automation.
        	//.....
        	//.....
        	//.....
        	//During validation/automation, 
    		//	if something fails, you would return false
    		//	which will never get to below line.
    		
    		//If everything pases, show the dialog box

    		dialog.confirm({
    			'title':'Amount Selected',
    			'message':'Total collection / credit(-) '+total+
                                  ' Do you wish to continue?'
    		}).then(success).catch(fail);
    	}
    	//If user provided a final answer from confirm box, return out
    	else
    	{
    		//Reset the finalResultSet flag to false 
    		//	in case user selected "Cancel" on the confirm box.
    		finalResultSet = false;
    		
    		//return will either give the control back to user
    		//	or continue with saving of the record
    		return finalResult;
    	}
    
 
// alert('Please enter PO Vendor and Create PO for all items');
 
        }
		function success(result)
    {
    	//Sets value of finalResult to user provided answer
    	finalResult = result;
    	//Updates the finalResultSet flag to true
    	//	to indicate that user has made his/her choice
    	finalResultSet = true;
    	
    	//getNLMultiButtonByName function is undocumented client side
    	//	function call used by NetSuite when save button is clicked
    	//	triggering this function will simulate clicking Save button
    	//	programmatically and force NetSuite to trigger saveRecord again
    	//	with global variables finalResult and finalResultSet altered!
    	
    	//NS Hack to call simulate user clicking Save Button
    	getNLMultiButtonByName('multibutton_submitter').onMainButtonClick(this);
    }
    
    function fail(reason)
    {
    	return false;
    }
exports.searching = searching;
   exports.resetfun = resetfun;
   exports.saveRecord = saveRecord;
  
   return exports;
       

    });