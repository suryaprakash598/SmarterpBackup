/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
define(['N/error','N/record','N/format','N/search','N/ui/message','N/ui/dialog','N/runtime'],
    function(error,record,format,search,message,dialog,runtime) {

            var line_array = [];
          var currIndex;
		  var addrlocation,addrsalesrep,addrzone;
	function disablefields(recordid)
	{
      try{
		var itemsublist = recordid.getSublist({sublistId:'item'});
		var porate = itemsublist.getColumn({fieldId: 'porate'});
		var povendor =itemsublist.getColumn({fieldId: 'povendor'});
		var price = itemsublist.getColumn({fieldId: 'price'});
		var taxcode = itemsublist.getColumn({fieldId: 'taxcode'});
        var quantity = itemsublist.getColumn({fieldId: 'quantity'});
        var requestdate = itemsublist.getColumn({fieldId: 'requesteddate'});
        var isfromNTD = recordid.getValue('custbody_is_from_ntd');
        var billaddresslist = recordid.getField('billaddresslist');
        var opportunity_fld = recordid.getField({fieldId:'opportunity'});
        log.debug('opportunity field visible',opportunity_fld.isVisible);
        if (opportunity_fld.isVisible)
        {   var opportunity_val = recordid.getValue('opportunity');
            log.debug('opportunity_val',opportunity_val);
        	if (opportunity_val.length > 0)
				price.isDisabled = true;
        };
		povendor.isDisabled = true;
        porate.isDisabled = true;
		taxcode.isDisabled = true;
        billaddresslist.isDisabled = true;
       // if (requestdate.isVisible) {requestdate.isVisible = false;}
       if (isfromNTD){quantity.isDisabled = true;};
      } catch(e)
        {
          log.error('error while defaulting',e.toString());
        }
	}
	
	
	function showErrorMessage(msgText) {
        var myMsg = message.create({
            title: "Location Required",
            message: msgText,
            type: message.Type.ERROR
        });

        myMsg.show({
            duration: 5000
        });
    }
  
				
		
	
  function pageInit(context) {
			var currentRecord = context.currentRecord;
			var userObj = runtime.getCurrentUser();
			var userRole = userObj.role;
			var soid =0;
			var customerid = currentRecord.getValue({fieldId:'entity'});
			var location_ship = currentRecord.getValue({fieldId: 'shipaddresslist'});
			var createdfrom_so = currentRecord.getField('createdfrom');
			if (createdfrom_so !== null) 
				soid = currentRecord.getValue({fieldId:'createdfrom'});
			
             if ((context.mode == 'create' || context.mode == 'copy') && customerid.length > 0 && location_ship > 0 && soid == 0)
			{
				try{
				
				var diladdrarray=[];
				diladdrarray['location']='';
				diladdrarray['salesrep']='';
				diladdrarray['zone']='';
				
				if (!isNaN(location_ship) )
				{
						
					var customerSearchObj = search.create({
								   type: "customer",
								   filters:
									   [
										  ["internalid","anyof",customerid]
									   ],
								   columns:
									   [
										 search.createColumn({
											 name: "custrecord_dil_cust_addr_location",
											 join: "Address"
											}),
										search.createColumn({
											 name: "custrecord_dil_cust_addr_sales_rep",
											 join: "Address"
											}),
										search.createColumn({
											 name: "addressinternalid",
											 join: "Address"
											}),
                                        search.createColumn({
                                             name: "custrecord_dil_cust_addr_del_zone",
                                             join: "Address"
                                            })
										]
										});
					var addrintid;
					customerSearchObj.run().each(function(result){
					   // .run().each has a limit of 4,000 results
					   addrintid = result.getValue({name: "addressinternalid",
													 join: "Address"
												  });
					   log.debug('shipaddresslist',location_ship+' addrintid '+addrintid);
					   if (addrintid == location_ship)
					   {
						   diladdrarray['location'] = result.getValue({
														 name: "custrecord_dil_cust_addr_location",
														 join: "Address"
													  });
							diladdrarray['salesrep'] = result.getValue({
														 name: "custrecord_dil_cust_addr_sales_rep",
														 join: "Address"
													  });
                            diladdrarray['zone'] = result.getValue({
														 name: "custrecord_dil_cust_addr_del_zone",
														 join: "Address"
													  });
																		
						}
						return true;
						//return diladdrarray;
					});
					log.debug(' page init location salesrep deliveryday',diladdrarray['location'] +' salesrep '+ diladdrarray['salesrep'] +' zone '+diladdrarray['zone']);
					// Set location, delivery date, and delivery zone based on the address details
					addrlocation = (isNaN(diladdrarray['location']) ? '' : diladdrarray['location']);
				    addrsalesrep = (isNaN(diladdrarray['salesrep']) ? '' : diladdrarray['salesrep']);
					addrzone = (isNaN(diladdrarray['zone']) ? '' : diladdrarray['zone']);
					
				// Set location, delivery date, and delivery zone based on the address details
					currentRecord.setValue({fieldId:'location',value: addrlocation});
					currentRecord.setValue({fieldId:'salesrep',value: addrsalesrep });
					currentRecord.setValue({fieldId:'custbody_dil_so_cust_delivery_day',value: addrzone});
				
				// Derive the delivery date based on the customer delivery zone
				
					var deliveryzone = currentRecord.getValue({
								fieldId : 'custbody_dil_so_cust_delivery_day'
							});
					log.debug('delivery zone page init',deliveryzone);
					if (!isNaN(deliveryzone))
						{
						var dayindicator = deliveryzone - 1;
						var current_date = new Date();
							  current_date.setDate(current_date.getDate() + 1);
				
						 var deliverydate = new Date();
						var current_day = current_date.getDay();
						if (dayindicator > current_day)
						{
						 deliverydate.setDate(current_date.getDate() + (dayindicator-current_day));
						} else
						{
							deliverydate.setDate(current_date.getDate() + ( 7 + dayindicator-current_day));
						}
						
						currentRecord.setValue({
							fieldId: 'custbody_dil_so_order_delivery_date',
							value : deliverydate
						});
						currentRecord.setValue({
							fieldId: 'shipdate',
							value : deliverydate
						});
					}
					else
					{
						currentRecord.setValue({
							fieldId: 'custbody_dil_so_order_delivery_date',
							value : ''
						});
						currentRecord.setValue({
							fieldId: 'shipdate',
							value : ''
						});
					}
					
				}
				}
				catch(e)
				{
					log.error('error',e.toString());
				}
				
			
		}			
	return true;
  }
       
  /*function saveRecord(context) {
           var currentRecord = context.currentRecord;
            if ( currentRecord.getValue({fieldId: 'tobeemailed'}) )
				{
				 currentRecord.setValue({
							fieldId : 'tobeemailed',
							value: false
							});
				}
        
            return true;
        }
  */
 function validateField(context) {
          
        }
		
 function fieldChanged(context) {
            var currentRecord = context.currentRecord;
        	var customerid = currentRecord.getValue({
					fieldId : 'entity'
				});
            //var sublistName = context.sublistId;
            var custFieldName = context.fieldId;
            var location_main = currentRecord.getValue({fieldId: 'location'});
        
     	    var location_ship = currentRecord.getValue({fieldId: 'shipaddresslist'});
			
            //var line = context.line;
            if (custFieldName === 'shipaddresslist' && location_ship.length > 0 && location_ship > 0)
			{
				try{
				log.debug('location ship field changed',location_ship+' '+ location_ship>0);
				var diladdrarray=[];
				diladdrarray['location']='';
				diladdrarray['salesrep']='';
				diladdrarray['zone']='';
				if (!isNaN(location_ship) && location_ship > 0)
				{
					log.debug('coming inside the location if',location_ship);
					
					var customerSearchObj = search.create({
								   type: "customer",
								   filters:
									   [
										  ["internalid","anyof",customerid]
									   ],
								   columns:
									   [
										 search.createColumn({
											 name: "custrecord_dil_cust_addr_location",
											 join: "Address"
											}),
										search.createColumn({
											 name: "custrecord_dil_cust_addr_sales_rep",
											 join: "Address"
											}),
										search.createColumn({
											 name: "addressinternalid",
											 join: "Address"
											}),
                                        search.createColumn({
                                             name: "custrecord_dil_cust_addr_del_zone",
                                             join: "Address"
                                            })
										]
										});
					var addrintid;
					customerSearchObj.run().each(function(result){
					   // .run().each has a limit of 4,000 results
					   addrintid = result.getValue({name: "addressinternalid",
													 join: "Address"
												  });
					   log.debug('shipaddresslist',location_ship+' addrintid '+addrintid);
					   if (addrintid == location_ship)
					   {
						   diladdrarray['location'] = result.getValue({
														 name: "custrecord_dil_cust_addr_location",
														 join: "Address"
													  });
							diladdrarray['salesrep'] = result.getValue({
														 name: "custrecord_dil_cust_addr_sales_rep",
														 join: "Address"
													  });
                            diladdrarray['zone'] = result.getValue({
														 name: "custrecord_dil_cust_addr_del_zone",
														 join: "Address"
													  });
																		
						}
						return true;
						//return diladdrarray;
					});
					addrlocation = (diladdrarray['location'] === undefined ? '' : diladdrarray['location']);
				    addrsalesrep =  (diladdrarray['salesrep'] === undefined ? '' : diladdrarray['salesrep']);
					addrzone = (diladdrarray['zone'] === undefined ? '' : diladdrarray['zone']);
					
					log.debug('location salesrep deliveryday',addrlocation+' salesrep '+ addrsalesrep +' zone '+ addrzone);
					
					// Set location, delivery date, and delivery zone based on the address details
					currentRecord.setValue({fieldId:'location',value: (addrlocation === undefined ? '' : addrlocation)});
					currentRecord.setValue({fieldId:'salesrep',value: (addrsalesrep === undefined ? '' : addrsalesrep ) });
					currentRecord.setValue({fieldId:'custbody_dil_so_cust_delivery_day',value: (addrzone=== undefined ? '' : addrzone)});
				
					// Derive the delivery datebased on the customer delivery zone
					
					var deliveryzone = currentRecord.getValue({
								fieldId : 'custbody_dil_so_cust_delivery_day'
							});
					log.debug('delivery zone',deliveryzone +' '+isNaN(deliveryzone));
					if (!isNaN(deliveryzone) && deliveryzone !== undefined && deliveryzone > 0)
						{
							var dayindicator = deliveryzone - 1;
							var current_date = new Date();
								  current_date.setDate(current_date.getDate() + 1);
					
							 var deliverydate = new Date();
							var current_day = current_date.getDay();
							if (dayindicator > current_day)
							{
							 deliverydate.setDate(current_date.getDate() + (dayindicator-current_day));
							} else
							{
								deliverydate.setDate(current_date.getDate() + ( 7 + dayindicator-current_day));
							}
							
							currentRecord.setValue({
								fieldId: 'custbody_dil_so_order_delivery_date',
								value : deliverydate
							});
							currentRecord.setValue({
								fieldId: 'shipdate',
								value : deliverydate
							});
							
						}
						else
						{
							currentRecord.setValue({
								fieldId: 'custbody_dil_so_order_delivery_date',
								value : ''
							});
							currentRecord.setValue({
								fieldId: 'shipdate',
								value : ''
							});
						} 
				}
					}catch(e)
					{ log.error('error',e.toString());
					}						
								
          }
		}
			
        function postSourcing(context) {
        /*   var currentRecord = context.currentRecord;
          
			*/	
          
            
               /*var location_line = currentRecord.getCurrentSublistValue({
                              sublistId: sublistName,
                              fieldId: 'location'
                          });
                 
              log.debug('coming inside the post sourcing insert',sublistFieldName );*/
         
	   }
        function lineInit(context) {/*
            var currentRecord = context.currentRecord;
            var sublistName = context.sublistId;
            if (sublistName === 'partners')
                currentRecord.setCurrentSublistValue({
                    sublistId: sublistName,
                    fieldId: 'partner',
                    value: '55'
                });
       */ }
        function validateDelete(context) {/*
            var currentRecord = context.currentRecord;
            var sublistName = context.sublistId;
            if (sublistName === 'partners')
                if (currentRecord.getCurrentSublistValue({
                        sublistId: sublistName,
                        fieldId: 'partner'
                    }) === '55')
                    currentRecord.setValue({
                        fieldId: 'memo',
                        value: 'Removing partner sublist'
                    });
            return true;
        */}
        function validateInsert(context) { 
       
        }
  
  
        function validateLine(context) {
            return true;
        }
        function sublistChanged(context) 
  		{
         
         	
          }
        return {
            pageInit: pageInit,
            fieldChanged: fieldChanged
          // postSourcing: postSourcing,
           // sublistChanged: sublistChanged,
          //  lineInit: lineInit,
          //  validateField: validateField,
         //   validateLine: validateLine,
          // validateInsert: validateInsert,
          //  validateDelete: validateDelete,
           //saveRecord: saveRecord
        };
    });