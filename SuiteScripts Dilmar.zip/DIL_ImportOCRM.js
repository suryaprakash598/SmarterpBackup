/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 
 Date		Owner			Modification	
 29/07/2021	Surya			If it is dropship order excluding approve functionality
 */
 
define(['N/search', 'N/file', 'underscore', 'SuiteScripts/RecurlyLib', 'N/record','N/email','N/runtime'],

    function (search, file, underscore, RECURLY_MODULE, record,email,runtime) {

    //Load saved search
    function execute(scriptContext) {
        var fileIds = getNotProcessedOCRMFiles();
        log.debug('fileIds', fileIds);
        var salesorderIds = [];
        for (var fi = 0; fi < fileIds.length; fi++) {

            var fileObj = file.load({
                id: fileIds[fi]
            });
            var dataArr = RECURLY_MODULE.csvToArr(fileObj.getContents());
            var shellSO = dataArr[1][1];
            var NSSO = dataArr[1][3];
			log.debug('NSSO',NSSO);
			log.debug('shellSO',shellSO);
            var _ocrm = savedSearchOCRM(shellSO, NSSO);
            log.debug('_ocrm', _ocrm);
            if (_ocrm != '') {
                var _status = dataArr[1][8];
                log.debug('_status', _status);
                var recObj = record.load({
                    type: record.Type.SALES_ORDER,
                    id: _ocrm,
                    isDynamic: !0
                });
				var _isDropShip = recObj.getValue({fieldId:'custbody_drop_ship_order'});
				log.debug('_isDropShip',_isDropShip);
                 if (_status == 'A' && !_isDropShip) { //if dropship then we are not changing status, it is doing by an workflow
                    recObj.setValue({
                        fieldId: 'orderstatus',
                        value: 'B',
                        ignoreFieldChange: true
                    });
                } else if (_status == 'R') {
                    recObj.setValue({
                        fieldId: 'orderstatus',
                        value: 'A',
                        ignoreFieldChange: true
                    }); 
					recObj.setValue({
                        fieldId: 'custbody_shell_reject_reason',
                        value: 'Reject',
                        ignoreFieldChange: true
                    });
                }
				recObj.setValue({
                        fieldId: 'custbody_dil_so_pend_aprvl_reason',
                        value: '',
                        ignoreFieldChange: true
                    });
                var Existshell = recObj.getValue({
                    fieldId: 'custbody_dil_so_shell_sales_order_num'
                });
                log.debug('Existshell', Existshell);
                if (Existshell == '') {
                    recObj.setValue({
                        fieldId: 'custbody_dil_so_shell_sales_order_num',
                        value: shellSO,
                        ignoreFieldChange: true
                    });
                }

                var id =recObj.save({
					enableSourcing: true,
					ignoreMandatoryFields: true
				});
                log.debug('id', id);
                var soObj = search.lookupFields({
                    type: search.Type.SALES_ORDER,
                    id: id,
                    columns: ['tranid']
                });
                var docNumber = soObj.tranid;
                salesorderIds.push({
                    'fileid': fileIds[fi],
                    'salesorderId': id,
                    'docNumber': docNumber
                })
            }
        }
		if (salesorderIds.length) {
            createCustomRecord(salesorderIds);
            sendEmail(salesorderIds);
		}

    }
    function savedSearchOCRM(shellSO, NSSO) {
        try {
            var salesorderSearchObj = search.create({
                type: "salesorder",
                filters:
                [
                    ["type", "anyof", "SalesOrd"],
                    "AND",
                    [
                        ["custbody_dil_so_shell_sales_order_num", "is", shellSO],
                        "OR",
                        ["numbertext", "haskeywords", NSSO]
                    ],
                    "AND",
                    ["status", "anyof", "SalesOrd:A"],
                    "AND",
                    ["mainline", "is", "T"],
                    "AND",
                    ["cogs", "is", "F"],
                    "AND",
                    ["taxline", "is", "F"],
                    "AND",
                    ["shipping", "is", "F"]
                ],
                columns:
                [
                    "tranid",
                    "internalid"
                ]
            });
            var searchResultCount = salesorderSearchObj.runPaged().count;
            log.debug("salesorderSearchObj result count", searchResultCount);
            var internalid = '';
            salesorderSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                internalid = result.getValue({
                    name: 'internalid'
                });
                return true;
            });
            return internalid;
        } catch (e) {
            log.debug('Error in savedSearchOCRM', e.toString());
        }
    }
    function getNotProcessedOCRMFiles() {
        try {
            var folderSearchObj = search.create({
                type: "folder",
                filters:
                [
                    ["internalid", "anyof", "1243"]
                ],
                columns:
                [
                    search.createColumn({
                        name: "name",
                        join: "file"
                    }),
                    search.createColumn({
                        name: "internalid",
                        join: "file"
                    })
                ]
            });
            var searchResultCount = folderSearchObj.runPaged().count;
            log.debug("folderSearchObj result count", searchResultCount);
            var fileIds = [];
            folderSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                fileIds.push(result.getValue({
                        name: "internalid",
                        join: "file"
                    }));
                return true;
            });
            return fileIds;
        } catch (e) {
            log.debug('Error in getNotProcessedOCRMFiles', e.toString());
        }
    }
    function createCustomRecord(arr) {
        try {

            //redirect.toSuitelet({scriptId:1909,deploymentId:1,parameters:{'fileid':1}});
            log.debug('arr', arr);
            var customRecObj = record.create({
                type: 'customrecord_edi_ocrm_salesorder',
                isDynamic: !0
            });
            var soids = [];

            for (var i = 0; i < arr.length; i++) {
                soids.push(arr[i].salesorderId);
            }
            log.debug('soids', soids);
            customRecObj.setValue({
                fieldId: 'custrecord_ocrm_document_number',
                value: soids
            });
            var id = customRecObj.save();
            for (var i = 0; i < arr.length; i++) {
                record.attach({
                    record: {
                        type: 'file',
                        id: arr[i].fileid,
                    },
                    to: {
                        type: 'customrecord_edi_ocrm_salesorder',
                        id: id
                    }
                })
            }
        } catch (e) {
            log.debug('error', e.toString());
        }

    }
    function sendEmail(arr) {
        try {
			//var scriptObj = runtime.getCurrentScript(); 
	//var recipientId = scriptObj.getParameter({name: 'custscript_orcm_email'}) 
            var senderId = -5;
            log.debug('arr', arr);
            var recipientId = ['amber@dilmar.com'];
            var subject = 'EDI OCRM Files';
            var body = 'Hi, EDI OCRM processed files';
            body += '<table><tr><th>Document Number</th><th>File</th></tr>';
            var ids = moveFilesToProcessed(arr);
            /* for (var i = 0; i < arr.length; i++) {
                body += '<tr>';
                body += '<td>' + arr[i].docNumber + '</td><td>' + arr[i].fileid + '</td>';
                body += '</tr>';
            }
            body += '</table>';
            email.send({
                author: senderId,
                recipients: recipientId,
                  cc: cclist,
                bcc: bcclist,  
                subject: subject,
                body: body
            }); */

        } catch (e) {
            log.debug('error', e.toString());
        }
    }
	function moveFilesToProcessed(fileArr) {
	        try {
	            var arr = [];
	            for (var i = 0; i < fileArr.length; i++) {
	                var proceefile = file.load({
	                    id: fileArr[i].fileid
	                });
	                if (proceefile.fileType == 'CSV') {
	                    var newFileName = 'Processed_' + proceefile.name;
	                    proceefile.name = newFileName;
	                    proceefile.folder = 1244;
	                    //submit the file so that the new file name would be saved
	                    var id = proceefile.save();
	                    arr.push(id);
	                }
	            }
	            return arr;

	        } catch (e) {
	            log.debug('Error', e.toString())
	        }
	    }
    return {
        execute: execute
    };

});