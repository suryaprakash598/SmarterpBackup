function invoicePdfprint()
{
	//Read the Record ID and isRebateSource
	var internalid = request.getParameter('id');
	var isRebateSource = request.getParameter('rebate');
	nlapiLogExecution('debug','internalid',internalid);
		try{
			//load the invoice record
			var record = nlapiLoadRecord('storepickupfulfillment', internalid);
			var renderer = nlapiCreateTemplateRenderer();
			//load the template file --  invoicePDF.html
			var getFile = nlapiLoadFile('304136');
			var file = getFile.getValue();
			renderer.setTemplate(file);
			renderer.addRecord('record', record);
			var xml = renderer.renderToString();
			//nlapiLogExecution('debug','xml',xml);
			// convert xml to PDF
			var PDFfile = nlapiXMLToPDF(xml);
			nlapiLogExecution('debug','PDFfile',PDFfile);
			response.setContentType('PDF','PRINT.pdf','INLINE');
			 response.write(PDFfile.getValue());
			 

	}
	catch(e)
	{
		nlapiLogExecution('debug','Error',e.toString());
	}
	
	
}