/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/search'],
/**
 * @param {record} record
 */
function(record,search) {
   
    /**
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} context
     * @param {ServerRequest} context.request - Encapsulation of the incoming request
     * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
     * @Since 2015.2
     * 178509
     */
    function execute(context) {
		var invoice_ids=[492972,
496779,
517904,
519294,
525327,
525328,
525349,
525352,
529978,
529979,
529981,
529982,
529983,
529984,
529986,
529987,
529988,
529989,
530083,
530084,
530085,
530086,
530087,
530088,
530089,
530183,
530185,
530186,
530187,
530188,
530189,
530190,
530191,
530296,
530298,
530302,
530319,
530327,
530328,
530329,]
    	for(var j = 0; j < invoice_ids.length; j++){
		var invoice =record.load({
 type:'itemfulfillment',
 id: invoice_ids[j]
 });
 var setting_emails = invoice.setValue({
					fieldId: 'custbody_is_bizspeed_req_sent',
					value:true
				});
 
 var id=invoice.save({enableSourcing: true, ignoreMandatoryFields: true});
    	log.debug('IF',id);
		} 
    	
    	
    	
    	


    }
	

    return {
        execute: execute
    };
    
});
