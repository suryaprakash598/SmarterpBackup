/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/record',],
/**
 * @param {format} format
 * @param {record} record
 */
function(search, record) {

function execute(scriptContext) {
var invoiceSearchObj = search.create({
   type: "invoice",
   filters:
   [
      ["type","anyof","CustInvc"], 
      "AND", 
      ["mainline","is","T"], 
      "AND", 
      ["customer.custentity_ns_envcomplianceexempt","is","F"], 
      "AND", 
      ["customer.custentity_dil_customer_nation_yn","is","F"], 
      "AND", 
      ["anylineitem","noneof","20"], 
      "AND", 
      ["createdfrom.datecreated","onorafter","6/1/2021 12:00 am"], 
      "AND", 
      ["datecreated","onorafter","6/3/2021 12:00 am"]
   ],
   columns:
   [
      search.createColumn({name: "entity", label: "Name"}),
      search.createColumn({name: "tranid", label: "Document Number"}),
      search.createColumn({
         name: "custentity_ns_envcomplianceexempt",
         join: "customer",
         label: "Env Compliance Exempt"
      }),
      search.createColumn({
         name: "custentity_dil_customer_nation_yn",
         join: "customer",
         label: "National Customer"
      }),
      search.createColumn({name: "internalid", label: "Internal ID"})
   ]
});
var searchResultCount = invoiceSearchObj.runPaged().count;
log.debug("invoiceSearchObj result count",searchResultCount);
invoiceSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   try{
			   var objRecord = record.load({
					type : record.Type.INVOICE,
					id: result.getValue('internalid'),
					isDynamic: true
				});
				var memo=objRecord.getValue({
					fieldId: 'memo'
				});
     log.debug('id', result.getValue('internalid'))
             	objRecord.setValue({
					fieldId: 'memo',
					value: memo,
					ignoreFieldChange: true
				});
				objRecord.save();
               }catch(e)
                 {
                   log.error('error',e.toString());
                 }
   return true;
});
}
return {
	execute : execute
}
});
