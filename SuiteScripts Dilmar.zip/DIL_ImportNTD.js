	/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 */
 /*
 Owner			Date			Modification
Surya							commenting location field setting as it is defaulting on 23/04/2021
 Surya			29/04/2021		Added Driver and deliveryInstructions fields 
 Surya			29/04/2021		Added Delivery Date logic
 Surya			02/06/2021		Commented Location as per howard
 Surya			04/06/2021		Updated logic to move duplicates files to processed folder with duplicate as prefix
 Surya			07/06/2021		Updated logic to move error files to NTD Error Files folder with Error as prefix
 Surya			10/08/2021		Created Script parameter to take email dynamically
 */
 
define(['N/search', 'N/runtime','N/file','N/record', 'underscore','SuiteScripts/RecurlyLib','N/email'],

    function (search, runtime,file, record,underscore,RECURLY_MODULE,email) {

    //Load saved search
    function execute(scriptContext) {
		try{
			
		var salesorderIds = [];
		var scriptObj = runtime.getCurrentScript();
		var fileid = scriptObj.getParameter({name: 'custscript_ntd_file_id'}) ;	
		var files = searchForFiles();
		//log.debug('files',files);		
			for(var f=0;f<files.length;f++)
			{
				var csvFile = file.load({id:files[f]});
				var dataArr = RECURLY_MODULE.csvToArr(csvFile.getContents());
				 //log.debug('dataArr',dataArr);
				 var dummyArr = dataArr;
				 var data = [];
				 var bodyobj={};
				 //log.debug('dataArr[1]',dataArr[1]);
				 bodyobj.po = dataArr[1][2];
				 bodyobj.shellorder = dataArr[1][3];
				 bodyobj.orderDate = dataArr[1][4];
				 bodyobj.customerShipId = dataArr[1][5];
				 bodyobj.plantid = dataArr[1][11];
				 bodyobj.driverInstructions = dataArr[1][16];
				 bodyobj.deliveryInstructions = dataArr[1][17];
				 dummyArr.shift();
				 dummyArr.shift();
				 data.push(bodyobj);
				 data.push(dummyArr);
				 log.debug('data',data);
				 var isShellOrderExists =  searchForShellSalesOrder(bodyobj.shellorder);
				if(isShellOrderExists)
				{
					var dup_fileIds=[];
					dup_fileIds.push({
						 'fileid':files[f]
					 });
					sendNotification(bodyobj.shellorder,dup_fileIds);
					continue;
				}
				 var salesorderId = createNTDSalesOrder(data,files[f]);
				 if(salesorderId)
				 {
					var soObj = search.lookupFields({type:search.Type.SALES_ORDER,id:salesorderId,columns:['tranid']});
					var docNumber = soObj.tranid;
					 salesorderIds.push({
						 'fileid':files[f],
						 'salesorderId':salesorderId,
						 'docNumber':docNumber
					 }) 
				 }
				 
			}
			if (salesorderIds.length) {
				createCustomRecord(salesorderIds);
				//sendEmail(salesorderIds);
			}
		}catch(e)
		{
			log.debug('Error in Main',e.toString());
			sendErrorEmail(e);
		}
    }
     function createNTDSalesOrder(data,_fileId)
	 {
       		 try{
			 
				//var customer = 107;//
				var customer = searchCustomer(data[0].customerShipId,_fileId);
               	log.debug('customer',customer)
				if(customer)
				{
					//var locationInternalId = searchForLocation(data[0].plantid);
					var locationInternalId = searchCustomerDefaultLocation(customer);
					var objRecord = record.create({type:record.Type.SALES_ORDER,isDynamic:!0,defaultValues:{customform:158,entity:customer}});
                    			
					/* FETCHING FROM CUSTOMER ADDRESS RECORDS */
					//var deliveryzone = objRecord.getValue({fieldId: 'custbody_dil_so_cust_delivery_day'});
					var deliveryzone =_searchForCustomerDeliveryZone(customer)
                    log.debug('Delivery zone : ',deliveryzone);



					if (deliveryzone == '')
					{
							var deliverydate1 = new Date();
							var current_date1 = new Date();
							current_date1.setDate(current_date1.getDate());
							log.debug('Current Date1',current_date1);
							var exp_deliverydate = new Date();
							const newDate1 = addDays(current_date1,2);
							exp_deliverydate = newDate1;
							 
							if (exp_deliverydate.getDay() == '6' || exp_deliverydate.getDay() == '7')              //Saturday & Sunday
							{
                              log.debug('Expected Deliv date is =',exp_deliverydate);
                              log.debug('Expected Deliv day is =',exp_deliverydate.getDay());
								if(exp_deliverydate.getDay() == '6')
								{
								  const newDate2 = addDays(exp_deliverydate, 2);
										deliverydate1 = newDate2;
										//log.debug('IF Saturday then date =',deliverydate1);
								}
								else
								{
								  const newDate3 = addDays(exp_deliverydate, 1);
										deliverydate1 = newDate3;
										//log.debug('IF Sunday then date =',deliverydate1);
								}
							}
							else
							{
							 //log.debug('TEST - ELSE LOOP EXECUTING =',exp_deliverydate); // TEST
							deliverydate1 = exp_deliverydate;
							 //log.debug('Else Exp_deliverydate',deliverydate1); 
							}
							objRecord.setValue({fieldId:'custbody_dil_so_order_delivery_date',value: deliverydate1});
							objRecord.setValue({fieldId:'shipdate',value: deliverydate1});

					}
					else
					{
									var dayindicator = deliveryzone - 1;
									var current_date = new Date();
									var deliverydate = new Date();
									
									current_date.setDate(current_date.getDate() + 1);
                              //log.debug('Current Date =',current_date);
                      
                      				var current_day = current_date.getDay();  //Current_day = Day(Today's_date + 1)
                              //log.debug('Current Day =',current_day);
                      
									if (dayindicator > current_day) {
										deliverydate.setDate(current_date.getDate() + (dayindicator - current_day));
									} else {
										deliverydate.setDate(current_date.getDate() + (7 + dayindicator - current_day));
									}
									objRecord.setValue({fieldId: 'custbody_dil_so_order_delivery_date',value: deliverydate});
									objRecord.setValue({fieldId: 'shipdate',value: deliverydate});
					}

					
					objRecord.setValue({fieldId:'otherrefnum',value:data[0].po,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'orderstatus',value:'B',ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custbody_dil_so_shell_sales_order_num',value:data[0].shellorder,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custbody_ntd_shell_delivery_notes',value:data[0].deliveryInstructions,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custbody_ntd_shell_driver_notes',value:data[0].driverInstructions,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custbody_is_from_ntd',value:true,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'location',value:locationInternalId,ignoreFieldChange:true});
					
					for(var i=0;i<data[1].length;i++)
					{
						//log.debug('data[i][3]',data[1][i][3]);
						//log.debug('data[i][1]',data[1][i][1]);
						log.debug('data[1][i][2]',data[1][i][2]);
						var item = searchItem(data[1][i][2],_fileId);
						log.debug('item',item);
						
						if(item)
						{
							objRecord.selectNewLine({sublistId:'item'});
							objRecord.setCurrentSublistValue({sublistId:'item',fieldId:'item',value:item});
							objRecord.setCurrentSublistValue({sublistId:'item',fieldId:'quantity',value:data[1][i][3]}); 
							objRecord.setCurrentSublistValue({sublistId:'item',fieldId:'location',value:locationInternalId}); 
							//NO AMOUNT IN INCOMING FILE & UNITS ARE SINGLE SO IT WILL AUTO POPULATE
							//objRecord.setCurrentSublistValue({sublistId:'item',fieldId:'amount',value:10}); 
							//objRecord.setCurrentSublistText({sublistId:'item',fieldId:'units',text:data[1][i][4]}); 
							objRecord.commitLine({sublistId:'item'});
						}else{
							var obj = {};
							obj.message='Item Not Found';
							createErrorRecord(_fileId,obj);
							return false;
						}
						
					}
					var id = objRecord.save();
					
					log.debug('id',id);
					return id;
				}else{
					return 0; 
				}
				
		 }catch(e)
		 {
			 log.debug('error in createNTDSalesOrder',e.toString());
			 sendErrorEmail(e,_fileId);
		 }	 
	} //function createNTDSalesOrder(data,_fileId)
  
 function addDays(date, days) 
  {
  const copy = new Date(Number(date))
  copy.setDate(date.getDate() + days)
  return copy
} 
  
	 function searchCustomer(shipid,_fileId)
	 {
		 try{
			 var customerSearchObj = search.create({
			   type: "customer",
			   filters:
			   [
				  ["custentity_dil_cust_ext_ship_to","equalto",shipid]
			   ],
			   columns:
			   [
				  "internalid",
				  search.createColumn({
					 name: "entityid"
				  })
			   ]
			});
			var searchResultCount = customerSearchObj.runPaged().count;
			var customerId =0;
			customerSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
			   customerId=result.getValue({name:'internalid'});
			   return true;
			});
			if(searchResultCount==0)
			{
				var obj={
					'msg':'Customer not found'
				}
				sendErrorEmail(JSON.stringify(obj),_fileId);
			}
			return customerId;
		 }catch(e)
		 {
			 log.debug('error in search customer',e.toString());
			 sendErrorEmail(e,_fileId);
		 }
	 }
	 function searchItem(shellProduct,_fileId)
	 {
		 try{
			 var itemSearchObj = search.create({
				   type: "item",
				   filters:
				   [
					  ["itemid","is",shellProduct]
				   ],
				   columns:
				   [
					 search.createColumn({
						 name: "itemid"
					  }),
					  "internalid"
				   ]
				});
				var searchResultCount = itemSearchObj.runPaged().count;
				var itemId = 0;
				itemSearchObj.run().each(function(result){
				   // .run().each has a limit of 4,000 results
				   itemId=result.getValue({name:'internalid'});
				   return true;
				});
				if(searchResultCount==0)
				{
					var obj={
						'msg':'Item not found'
					}
					sendErrorEmail(JSON.stringify(obj),_fileId);
				}
				return itemId;
		 }catch(e)
		 {
			 log.debug('error in search item',e.toString());
			 sendErrorEmail(e,_fileId);
		 } 
	 }
	 function searchForFiles()
	 {
		  try{
			  var fileSearchObj = search.create({
				   type: "file",
				   filters:
				   [
					  ["folder","anyof","1245"]
				   ],
				   columns:
				   [
					  "internalid"
				   ]
				});
				var searchResultCount = fileSearchObj.runPaged().count;
				log.debug("fileSearchObj result count",searchResultCount);
				var arr = [];
				fileSearchObj.run().each(function(result){
				   // .run().each has a limit of 4,000 results
				  arr.push( result.getValue({name:'internalid'}));
				   return true;
				});
				 return arr;
		 }catch(e)
		 {
			 log.debug('error in searchForFiles',e.toString());
			 sendErrorEmail(e);
		 } 
	 }
	 function createCustomRecord(arr) {
        try {

            //redirect.toSuitelet({scriptId:1909,deploymentId:1,parameters:{'fileid':1}});
            log.debug('arr', arr);
            var customRecObj = record.create({
                type: 'customrecord_edi_ntd_salesorder',
                isDynamic: !0
            });
            var soids = [];

            for (var i = 0; i < arr.length; i++) {
                soids.push(arr[i].salesorderId);
            }
			log.debug('soids',soids);
            customRecObj.setValue({
                fieldId: 'custrecord_ntd_document_number',
                value: soids
            }); 
            var id = customRecObj.save();
            for (var i = 0; i < arr.length; i++) {
                record.attach({
                    record: {
                        type: 'file',
                        id: arr[i].fileid,
                    },
                    to: {
                        type: 'customrecord_edi_ntd_salesorder',
                        id: id
                    }
                })
            }
        } catch (e) {
            log.debug('error', e.toString());
        }

    }
    function sendEmail(arr) {
        try {
			var scriptObj = runtime.getCurrentScript(); 
			var recipientId = scriptObj.getParameter({name: 'custscript_ntd_email'}) 
				var senderId = -5;
				 //var recipientId = ['amber@dilmar.com'];
				var subject = 'EDI NTD Files';
				var body = 'Hi, EDI NTD processed files';
				body += '<table><tr><th>Document Number</th><th>File</th></tr>';
				var ids = moveFilesToProcessed(arr);
				for (var i = 0; i < arr.length; i++) {
					body += '<tr>';
					body += '<td>' + arr[i].docNumber + '</td><td>' + ids[i] + '</td>';
					body += '</tr>';
				}
				body += '</table>';
				email.send({
					author: senderId,
					recipients: recipientId,
					subject: subject,
					body: body
				});
			} catch (e) {
				log.debug('error', e.toString());
			}
    }
	function sendErrorEmail(er,_fileId)
	{
		try{
			var scriptObj = runtime.getCurrentScript(); 
			var recipientId = scriptObj.getParameter({name: 'custscript_ntd_email'}) 
			var senderId = -5;
            //var recipientId = ['amber@dilmar.com'];
            var subject = 'Error in NTD processing';
            var body = 'Hi,There is an error in NTD processing, Please take necessary action and update the file'+er.toString();
			body+='/nIf customer not found then try to update customer shipto in file /n If item not found then update correct part number in file.';
			body+='Reupload the file to NTD folder. Filecabinet -->EDI Shell -->NTD';
            if(_fileId)
			{
				var proceefile = file.load({
					id: _fileId
				});
				if (proceefile.fileType == 'CSV') {
                        var newFileName = 'Error_' + proceefile.name;
                        proceefile.name = newFileName;
                        proceefile.folder = 2590; //NTD Error Files
                        //submit the file so that the new file name would be saved
                        var id = proceefile.save(); 
                    }
				email.send({
					author: senderId,
					recipients: recipientId,
					subject: subject,
					body: body,
					attachments: [proceefile]
				});
				createErrorRecord(_fileId,er);
			}
			else{
				email.send({
                author: senderId,
                recipients: recipientId,
                subject: subject,
                body: body
            });
			}
            
		}catch(e)
		{
			log.debug('Error in sendErrorEmail',e.toString());
		}
	}
    function moveFilesToProcessed(fileArr)
	{
		try{
			var arr = [];
			for(var i=0;i<fileArr.length;i++)
			{
				var proceefile = file.load({
                        id: fileArr[i].fileid
                    });
                    if (proceefile.fileType == 'CSV') {
                        var newFileName = 'Processed_' + proceefile.name;
                        proceefile.name = newFileName;
                        proceefile.folder = 1246;
                        //submit the file so that the new file name would be saved
                        var id = proceefile.save();
						arr.push(id);
                    }
			}
			return arr;
			 
		}catch(e)
		{
			log.debug('Error',e.toString())
		}
	}
	function searchForLocation(plantid)
	{
		try{
			var locationSearchObj = search.create({
			   type: "location",
			   filters:
			   [
				  ["custrecord_dil_plant_id","is",plantid], 
				  "AND", 
				  ["isinactive","is","F"]
			   ],
			   columns:
			   [
				  search.createColumn({
					 name: "name",
					 sort: search.Sort.ASC
				  }),
				  "internalid"
			   ]
			});
			var searchResultCount = locationSearchObj.runPaged().count;
			log.debug("locationSearchObj result count",searchResultCount);
			var locationId = '';
			locationSearchObj.run().each(function(result){
			   // .run().each has a limit of 4,000 results
			   locationId = result.getValue({name:'internalid'});
			   return true;
			});
			return locationId;
		}catch(e)
		{
			log.debug('Error in searchForLocation',e.toString());
			sendErrorEmail(e);
		}
	}
	 function searchForShellSalesOrder(shellSO){
		try{
			var salesorderSearchObj = search.create({
			   type: "salesorder",
			   filters:
			   [
				  ["type","anyof","SalesOrd"], 
				  "AND", 
				  ["custbody_is_from_ntd","is","T"], 
				  "AND", 
				  ["mainline","is","T"], 
				  "AND", 
				  ["shipping","is","F"], 
				  "AND", 
				  ["taxline","is","F"], 
				  "AND", 
				  ["custbody_dil_so_shell_sales_order_num","is",shellSO]
			   ],
			   columns:
			   [
				  "custbody_is_from_ntd",
				  "tranid",
				   "custbody_dil_so_shell_sales_order_num"
			   ]
			});
			var searchResultCount = salesorderSearchObj.runPaged().count;
			log.debug("salesorderSearchObj searchForShellSalesOrder result count",searchResultCount);
			if(searchResultCount>0)
			{
				return true;
			}else{
				return false;
			}
			 
		}catch(e)
		{
			log.debug('error in searchForShellSalesOrder',e.toString());
		}
	}
	function sendNotification(shellsalesorder,fileArr)
	{
		//var scriptObj = runtime.getCurrentScript(); 
			//var recipientId = scriptObj.getParameter({name: 'custscript_ntd_email'}) 
			var senderId = -5;
            var recipientId = ['amber@dilmar.com'];
            var subject = 'NTD Duplicate';
            var body = 'Hi, Found NTD Duplicate Order With shell salesorder:'+shellsalesorder;
             
			 try{
					var arr = [];var attachments = [];
					for(var i=0;i<fileArr.length;i++)
					{
						var proceefile = file.load({
								id: fileArr[i].fileid
							});
							attachments.push(proceefile);
							if (proceefile.fileType == 'CSV') {
								var newFileName = 'duplicate_' + proceefile.name;
								proceefile.name = newFileName;
								proceefile.folder = 1246;
								//submit the file so that the new file name would be saved
								var id = proceefile.save();
								arr.push(id);
							}
					}
					email.send({
						author: senderId,
						recipients: recipientId, 
						subject: subject,
						body: body,
						attachments: attachments
					});
			 
				}catch(e)
				{
					log.debug('Error',e.toString())
				}
            
	}
	function createErrorRecord(fileid,er)
	{
		try{
				var csvFile = file.load({id:fileid});
				var dataArr = RECURLY_MODULE.csvToArr(csvFile.getContents());
				 var dummyArr = dataArr;
				 var data = [];
				 var bodyobj={};
				 bodyobj.po = dataArr[1][2];
				 bodyobj.shellorder = dataArr[1][3];
				 bodyobj.orderDate = dataArr[1][4];
				 bodyobj.customerShipId = dataArr[1][5];
				 bodyobj.plantid = dataArr[1][11];
				 bodyobj.driverInstructions = dataArr[1][16];
				 bodyobj.deliveryInstructions = dataArr[1][17];
				 dummyArr.shift();
				 dummyArr.shift();
				 data.push(bodyobj);
				 data.push(dummyArr);
					var customer = data[0].customerShipId;
					var objRecord= record.create({type:'customrecord_shell_ntd_error_record',isDynamic:!0});
					objRecord.setValue({fieldId:'custrecord_shell_ntd_customer',value:customer,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custrecord_shell_ntd_po',value:data[0].po,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custrecord_shell_ntd_so_shell_sales_num',value:data[0].shellorder,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custrecord_shell_ntd_delivery_notes',value:data[0].deliveryInstructions,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custrecord_shell_ntd_driver_notes',value:data[0].driverInstructions,ignoreFieldChange:true});
					objRecord.setValue({fieldId:'custrecord_shell_ntd_error',value:er.toString(),ignoreFieldChange:true});
					
					for(var i=0;i<data[1].length;i++)
					{
						var item = data[1][i][2];
						objRecord.selectNewLine({sublistId:'recmachcustrecord_shell_ntd_parent_error_record'});
						objRecord.setCurrentSublistValue({sublistId:'recmachcustrecord_shell_ntd_parent_error_record',fieldId:'custrecord_shell_ntd_item',value:item});
						objRecord.setCurrentSublistValue({sublistId:'recmachcustrecord_shell_ntd_parent_error_record',fieldId:'custrecord_shell_ntd_qty',value:data[1][i][3]}); 
						objRecord.commitLine({sublistId:'recmachcustrecord_shell_ntd_parent_error_record'});
					}
					var id = objRecord.save();
		}catch(e)
		{
			log.debug('Error in creating Error Record',e.toString());
		}
	}
	function searchCustomerDefaultLocation(_customerid)
	{
		try{
			var warehouseLocation='';
			if(_customerid)
			{
				var loc = search.lookupFields({type:'customer',id:_customerid,columns:['custentity_dil_cust_dflt_dlvry_location']});
				warehouseLocation = loc.custentity_dil_cust_dflt_dlvry_location["length"]>0?loc.custentity_dil_cust_dflt_dlvry_location[0].value:'';
			} 
			return warehouseLocation;
		}catch(e)
		{
			log.debug('error in searchCustomerDefaultLocation',e.toString());
		}
	}
   function _searchForCustomerDeliveryZone(customer)
		{
			try{
				var customerSearchObj = search.create({
				   type: "customer",
				   filters:
				   [
					  ["internalid","anyof",customer]
				   ],
				   columns:
				   [
					  search.createColumn({name: "custentity_dil_cust_delivery_zone_day", label: "Delivery Zone"}),
					  search.createColumn({
						 name: "custrecord_dil_cust_addr_del_zone",
						 join: "shippingAddress",
						 label: "Default Delivery Zone"
					  }),
					  search.createColumn({
						 name: "custrecord_dil_cust_addr_del_zone",
						 join: "billingAddress",
						 label: "Default Delivery Zone"
					  })
				   ]
				});
				var searchResultCount = customerSearchObj.runPaged().count;
				log.debug("customerSearchObj result count",searchResultCount);
				var deliveryday='';
				customerSearchObj.run().each(function(result){
				   // .run().each has a limit of 4,000 results
				   deliveryday = result.getValue({ name: "custrecord_dil_cust_addr_del_zone",join: "billingAddress" });
				   if(!deliveryday)
				   {
					   deliveryday = result.getValue({ name: "custrecord_dil_cust_addr_del_zone",join: "shippingAddress" });
				   }
				   return true;
				});
				return deliveryday;
			}catch(e)
			{
				log.debug('Error in search for deliveryzone',e.toString());
			}
		}
   return {
        execute: execute
    };
	
});