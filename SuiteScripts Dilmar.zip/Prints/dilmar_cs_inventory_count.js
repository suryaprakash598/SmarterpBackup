/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord', 'N/url', 'N/ui/message', 'N/https'],

    /**
     * @param {currentRecord} currentRecord
     * @param {url} url
     * @param {message} message
     * @param {https} https
     * @returns {{printLetter: printLetter}}
     */

    function(currentRecord, url, message, https) {

        const DILMAR_PRINT_SCRIPT_ID = 'customscript_dilmar_ss_inventory_count';
        const DILMAR_PRINT_SCRIPT_DEPLOY_ID = 'customdeploy_dilmar_ss_inventory_count';
    
        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        function printTransaction() {
            var recordObj = currentRecord.get();
            var ParametersL = {
                custpara_recordid : recordObj.id,
                custpara_recordtype : recordObj.type
            };
            var Url = url.resolveScript({
                scriptId : DILMAR_PRINT_SCRIPT_ID,
                deploymentId : DILMAR_PRINT_SCRIPT_DEPLOY_ID,
                params : ParametersL,
                returnExternalUrl : false
            });

            window.open(Url, '_blank');
        }

        return {
            pageInit: pageInit,
            printTransaction: printTransaction
        };

    });
