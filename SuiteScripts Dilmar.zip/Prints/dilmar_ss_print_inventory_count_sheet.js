/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
define(['N/render', 'N/record', 'N/file', 'N/search', 'N/xml'],
    /**
     * @param {record} record
     * @param {render} render
     * @param {file} file
     * @param {search} search
     * @param {xml} xml
     * @param {email} email
     */
    function(render, record, file, search, xml) {

        const DILMAR_PRINT_INVENTORY_COUNT_TEMPLATE_ID = '8325';

        const TRANSACTION_BODY = {};
        TRANSACTION_BODY.TRANID = 'tranid';
        TRANSACTION_BODY.CURRENCY = 'currency';
        TRANSACTION_BODY.CREATED_BY = 'recordcreatedby';

        const TRANSACTION_LINE = {};
        TRANSACTION_LINE.SUBLIST_ITEM = 'item';
        TRANSACTION_LINE.RATE = 'rate';
        TRANSACTION_LINE.DISCOUNT_AMOUNT = 'custcol_discountamount';
        TRANSACTION_LINE.TAX_RATE = 'taxrate1';
        TRANSACTION_LINE.TAX_AMOUNT = 'tax1amt';
        TRANSACTION_LINE.NET_AMOUNT = 'custcol_net_amount';
        TRANSACTION_LINE.TOTAL_AMOUNT = 'custcol_itemrate';

        /**
         * Definition of the Suitelet script trigger point.
         *
         * @param {Object} context
         * @param {ServerRequest} context.request - Encapsulation of the incoming request
         * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
         * @Since 2015.2
         */

        function onRequest(context) {
            var request = context.request;
            var response = context.response;

            var recordId = request.parameters.custpara_recordid;

            var recordObj = record.load({
                type : record.Type.INVENTORY_COUNT,
                id : recordId
            });

            // create renderer template to print sales transaction
            var renderer = render.create();
            renderer.templateContent = file.load(DILMAR_PRINT_INVENTORY_COUNT_TEMPLATE_ID).getContents();

            renderer.addRecord({
                templateName : 'record',
                record : recordObj
            });


            var tranId = recordObj.getValue({
                fieldId : TRANSACTION_BODY.TRANID
            });

            var newfile = renderer.renderAsPdf();
            newfile.name = tranId + ".pdf";

            response.writeFile({
                file: newfile,
                isInline: true
            });
        }

        return {
            onRequest: onRequest
        };
    });