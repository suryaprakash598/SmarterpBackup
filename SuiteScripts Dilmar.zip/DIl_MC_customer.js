/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 Owner		Date		Description
 Surya		24/05/2021	Limited sales rep id to 2 characters
 Surya		15/09/2021	Date created to Date in filter
 */
 define(['N/search', 'N/file', 'N/encode', 'N/record', 'N/email','SuiteScripts/SFTPConnectionEstablish'],

 function (search, file,  encode, record, email,_SFTPObj) {

 //Load saved search
 function execute(scriptContext) {
	 
     var _mcInvHeader = savedSearchCustomer();
      var textFile = '';
     for(var i=0;i<_mcInvHeader.length;i++)
	 {
		textFile+= headerRecord(_mcInvHeader[i]);
	 }
	// log.debug('textFile',textFile);
	 var fileObj = file.create({
                 name: 'customer'+new Date(),
                 fileType: file.Type.PLAINTEXT,
                 contents: textFile,
                 description: '',
                 encoding: file.Encoding.UTF8,
                 folder: 1250//1086
             });

             //Save the CSV file
             var fileId = fileObj.save()
			 var connectionObj =  _SFTPObj.executeSFTP();
			log.debug('connectionObj',connectionObj);
			 var fileData = file.load({id:fileId});
			 if(connectionObj)
			 {
				 connectionObj.upload({
					directory: '/',
					filename: 'customer.txt',
					file: fileData,
					replaceExisting: false
					}); 
			 }
 }
 function savedSearchCustomer() {
     try {
         var arr = [];
           var invoiceSearchObj = search.create({
		   type: "invoice",
		   filters:
		   [
			  ["type","anyof","CustInvc"], 
			  "AND", 
			   ["trandate","within","thismonth"], //previousoneweek 
			  //["trandate","within","6/01/2021","9/17/2021"], 
			  "AND", 
				["item.custitem_dilmar_brand","anyof","52"], 
			  "AND", 
			  ["mainline","is","F"], 
			  "AND", 
			  ["taxline","is","F"], 
			  "AND", 
			  ["shipping","is","F"], 
			  "AND", 
			  ["cogs","is","F"],
			  "AND", 
			["customer.isdefaultshipping","is","T"]
		   ],
		   columns:
		   [
			  search.createColumn({
				 name: "entity",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "custentity1",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "category",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "custentity_dil_customer_pa_code",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "vatregnumber",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "addressee",
				 join: "shippingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "address1",
				 join: "shippingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "address2",
				 join: "shippingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "city",
				 join: "shippingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "state",
				 join: "shippingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "zip",
				 join: "shippingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "phone",
				 join: "shippingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "internalid",
				 join: "shippingAddress",
				 summary: "GROUP" 
			  }),
			  search.createColumn({
				 name: "contact",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "address1",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "address2",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "addressee",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "attention",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "city",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "phone",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "state",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "zip",
				 join: "billingAddress",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "internalid",
				 join: "billingAddress",
				 summary: "GROUP" 
			  }),
			  search.createColumn({
				 name: "salesrep",
				 join: "customer",
				 summary: "GROUP"
			  }),search.createColumn({
				 name: "email",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "fax",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "accountnumber",
				 join: "customer",
				 summary: "GROUP"
			  }),
			   search.createColumn({
				 name: "formulatext1",
				 summary: "GROUP",
				 formula: " NVL({shippingaddress.address1}, {customer.shipaddress1}  ) "
			  }),
			   search.createColumn({
				 name: "formulatext2",
				 summary: "GROUP",
				 formula: " NVL({shippingaddress.address2}, {customer.shipaddress2}  ) " 
			  }),
			  search.createColumn({
				 name: "formulatext3",
				 summary: "GROUP",
				 formula: "NVL({shippingaddress.addressee}, {customer.shipaddressee})"
			  }),
			  search.createColumn({
				 name: "formulatext4",
				 summary: "GROUP",
				 formula: "NVL({shippingaddress.city}, {customer.shipcity})"
			  }),
			  search.createColumn({
				 name: "formulatext5",
				 summary: "GROUP",
				 formula: "NVL({shippingaddress.state}, {customer.shipstate})"
			  }),
			  search.createColumn({
				 name: "formulatext6",
				 summary: "GROUP",
				 formula: "NVL({shippingaddress.zip},{customer.shipzip})"
			  }),
			  search.createColumn({
				 name: "formulatext7",
				 summary: "GROUP",
				 formula: "NVL({shippingaddress.phone}, {customer.addressphone})"
			  }),
			  search.createColumn({
				 name: "formulanumeric8",
				 summary: "GROUP",
				 formula: "NVL({shippingaddress.internalid}, {customer.addressinternalid})"
			  })
		   ]
		});
		var searchResultCount = invoiceSearchObj.runPaged().count;
		invoiceSearchObj.run().each(function(result){
            // .run().each has a limit of 4,000 results
             log.debug('result',result)
            var obj ={};
             
			obj.customerName = result.getText({ name: "entity",summary: "GROUP"});
			obj.customer = result.getValue({ name: "entity",summary: "GROUP"});
			// obj.customerType = result.getText({ name: "custentity1",join: "customer",summary: "GROUP"}); //custentity_dil_cust_stratification_grade
			obj.customerType = result.getText({ name: "category",join: "customer",summary: "GROUP"}); //custentity_dil_cust_stratification_grade
			obj.customerTax = result.getValue({ name: "vatregnumber",join: "customer",summary: "GROUP"});
			obj.pACode = result.getValue({ name: "custentity_dil_customer_pa_code",join: "customer",summary: "GROUP"});
			
			/* obj._saddressee = result.getValue({name:"addressee",join:"shippingAddress",summary:"GROUP"});
			obj._saddress1 = result.getValue({name:"address1",join:"shippingAddress",summary:"GROUP"});
			obj._saddress2 = result.getValue({name:"address2",join:"shippingAddress",summary:"GROUP"});
			obj._scity = result.getValue({name:"city",join:"shippingAddress",summary:"GROUP"});
			obj._sstate = result.getValue({name:"state",join:"shippingAddress",summary:"GROUP"});
			obj._szip = result.getValue({name:"zip",join:"shippingAddress",summary:"GROUP"});
			obj._sphone = result.getValue({name:"phone",join:"shippingAddress",summary:"GROUP"});
			obj._sAddInternalid = result.getValue({name:"internalid",join:"shippingAddress",summary:"GROUP"}); */
			
			obj._saddressee = result.getValue({name:"formulatext3",summary:"GROUP",formula:"NVL({shippingaddress.addressee}, {customer.shipaddressee})"});
			obj._saddress1 = result.getValue({name:"formulatext1",summary:"GROUP",formula:"NVL({shippingaddress.address1}, {customer.shipaddress1})"});
			obj._saddress2 = result.getValue({name:"formulatext2",summary:"GROUP",formula:" NVL({shippingaddress.address2}, {customer.shipaddress2}  ) " });
			obj._scity = result.getValue({name:"formulatext4",summary:"GROUP",formula:"NVL({shippingaddress.city}, {customer.shipcity})"});
			obj._sstate = result.getValue({name:"formulatext5",summary:"GROUP",formula:"NVL({shippingaddress.state}, {customer.shipstate})"});
			obj._szip = result.getValue({name:"formulatext6",summary:"GROUP",formula:"NVL({shippingaddress.zip},{customer.shipzip})"});
			obj._sphone = result.getValue({name:"formulatext7",summary:"GROUP",formula:"NVL({shippingaddress.phone}, {customer.addressphone})"});
			obj._sAddInternalid = result.getValue({name:"formulanumeric8",summary:"GROUP",formula:"NVL({shippingaddress.internalid}, {customer.addressinternalid})"});
		
			obj.address1 = result.getValue({name:"address1",join:"billingAddress",summary:"GROUP"});
			obj.address2 = result.getValue({name:"address2",join:"billingAddress",summary:"GROUP"});
			obj.addressee = result.getValue({name:"addressee",join:"billingAddress",summary:"GROUP"});
			obj.attention = result.getValue({name:"attention",join:"billingAddress",summary:"GROUP"});
			obj.city = result.getValue({name:"city",join:"billingAddress",summary:"GROUP"});
			obj.phone = result.getValue({name:"phone",join:"billingAddress",summary:"GROUP"});
			obj.state = result.getValue({name:"state",join:"billingAddress",summary:"GROUP"});
			obj.zip = result.getValue({name:"zip",join:"billingAddress",summary:"GROUP"});
			obj._bAddInternalid = result.getValue({name:"internalid",join:"billingAddress",summary:"GROUP"});
			
			obj.salesrep = result.getValue({name:"salesrep", join: "customer",summary:"GROUP"});
			if(obj.salesrep)
			{
				var salesrepCode = search.lookupFields({type:'employee',id:obj.salesrep,columns:['custentity_salesrep_code']});
				obj.salesrep_code = salesrepCode.custentity_salesrep_code;	
			}else{
				obj.salesrep_code='';
			} 
			
			obj.email = result.getValue({name:"email",join:"customer",summary:"GROUP"});
			obj.fax = result.getValue({name:"fax",join:"customer",summary:"GROUP"});
			obj.accountnumber = result.getValue({name:"accountnumber",join:"customer",summary:"GROUP"});
			obj.contact = result.getValue({name:"contact",join:"customer",summary:"GROUP"});
            arr.push(obj);
            return true;
         });
         return arr;
     } catch (e) {
         log.debug('Error in savedSearchList', e.toString());
     }
 }
  
 function headerRecord(data) {
	 log.debug('_data',data);
     var tempString = '';
	var _data =  Object.keys(data); 
     if (_data.length) {
		 //
		var vendorcode='';
		  //var salespersonId = data.salesrep;
		 // salespersonId = salespersonId.match(/.{1,2}/g)[0]||'';
		 var cuType=data.customerType;
		 var customerType = cuType.match(/.{1,2}/g)[0]||'';
         tempString +=  data.pACode + "\t" + 
						data. addressee+ "\t" +
						data.address1 + "\t" +
						data.address2 + "\t" +
						data.city + "\t" +
						data.state + "\t" +
						data.zip + "\t" +
						data.phone + "\t" +
						data.fax+"\t"+
						data.email + "\t" +
						data.contact + "\t" +
						data.customerTax + "\t" +
						data._bAddInternalid + "\t" +
						
						data._saddressee + "\t" +
						data._saddress1 + "\t" +
						data._saddress2 + "\t" +
						data._scity + "\t" +
						data._sstate + "\t" +
						data._szip + "\t" +
						data._sphone + "\t" +
						data.fax + "\t" +
						data.email + "\t" +
						data.contact + "\t" +
						data.customerTax + "\t" +
						data._sAddInternalid + "\t" +
						data.salesrep_code + "\t" + 
						customerType + "\r\n";
		 
     }
	 tempString=tempString.replace(/- None -/g, " ");;
     return tempString;
 }
 function pad(num, size) {
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}
 
 return {
     execute: execute
 };

});