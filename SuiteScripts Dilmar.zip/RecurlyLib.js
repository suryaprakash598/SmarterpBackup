
/**
 * Module for all Recurly SFTP Integration & process
 * 
 */


define(['N/record', 'N/sftp', 'N/task', 'N/search'],

function(RECORD, SFTP, TASK, SEARCH) {
	
	//replace null or trim double quotes
    function checkNullAndFormat(value) {
    	if (value == null || value == 'NaN' || value == undefined) {
    		return '';
    	}
    	return value.replace(/^\"+|\"+$/g, '');
    }
    
    //CSV to ARRAY
    function csvToArr(csv) {
  	  //csv to array
  	  var strData = csv,
  	    strDelimiter = ',';
  	  strDelimiter = strDelimiter || ',';

  	  var objPattern = new RegExp(
  	    // Delimiters.
  	    '(\\' +
  	      strDelimiter +
  	      '|\\r?\\n|\\r|^)' +
  	      // Quoted fields.
  	      '(?:"([^"]*(?:""[^"]*)*)"|' +
  	      // Standard fields.
  	      '([^"\\' +
  	      strDelimiter +
  	      '\\r\\n]*))',
  	    'gi'
  	  );

  	  var arrData = [[]];

  	  var arrMatches = null;

  	  while ((arrMatches = objPattern.exec(strData))) {
  	    var strMatchedDelimiter = arrMatches[1];

  	    if (strMatchedDelimiter.length && strMatchedDelimiter !== strDelimiter) {
  	      arrData.push([]);
  	    }

  	    var strMatchedValue;

  	    if (arrMatches[2]) {
  	      strMatchedValue = arrMatches[2].replace(new RegExp('""', 'g'), '"');
  	    } else {
  	      strMatchedValue = arrMatches[3];
  	    }

  	    arrData[arrData.length - 1].push(strMatchedValue);
  	  }
  	  //remove extra line with no data - in 1st column
  	  for (var i = 0; i < arrData.length; i++) {
  	    if (arrData[i][0].toString().trim() == '') {
  	      arrData.splice(i, 1);
  	      i--;
  	    }
  	  }
  	  return arrData;
  	}
    
    
    // Get Customer ID
    function getCustomerId(recurlyCustomerId){
	var customerId = '';
	
	var customerSearchObj = SEARCH.create({
		   type: "customer",
		   filters:
		   [
		      ["custentity_wd_recurly_website_id","is",recurlyCustomerId]
		   ],
		   columns:
		   [
		      SEARCH.createColumn({name: "internalid", label: "Internal ID"})
		   ]
		});
	
		/*var searchResultCount = customerSearchObj.runPaged().count;
		log.debug("customerSearchObj result count",searchResultCount);*/
	
		customerSearchObj.run().each(function(result){
			customerId = result.getValue({name: "internalid"})
		   return false;
		});
		
		return customerId;
    }
    
    //Get Item Internal ID
    function getItemId(itemExtId){
    	var itemId = '';
    	
    	var itemSearchObj = SEARCH.create({
    		   type: "item",
    		   filters:
    		   [
    		      ["externalid","anyof",itemExtId]
    		   ],
    		   columns:
    		   [
    		      SEARCH.createColumn({name: "internalid", label: "Internal ID"})
    		   ]
    		});
    		
		itemSearchObj.run().each(function(result){
			itemId = result.getValue({name: "internalid"});
		   return false;
		});
		
		return itemId;
    }
    
    
    //RE-RUN the Script
    function reRunCurrentScript(scriptId, deploymentId){
    	log.audit('Re-Run of the Script', 'RE-RUN of the script started');
    	
    	var MapReduceScriptTask = TASK.create({
            taskType: TASK.TaskType.MAP_REDUCE
        });
    	MapReduceScriptTask.scriptId = scriptId;
    	MapReduceScriptTask.deploymentId = deploymentId;
        return MapReduceScriptTask.submit();
    }
    
    //GET CSV FIle Name to process
    function getFileNameToProcess(connection, filePrefix){
    	var newFileName = '';
    	
    	var dirList = connection.list({
			path: '',
			sort: SFTP.Sort.NAME	//Ascending
		});
    	
    	//Get the top CUST_INVOICES
    	for(var f = 0; f < dirList.length; f++){
    		if(!dirList[f]["directory"] && dirList[f]["name"].toUpperCase().indexOf(filePrefix) == 0){
    			newFileName = dirList[f]["name"];
    			break;
    		}
    	}
    	
    	return newFileName;
    }
    
    
    // Connect to SFTP
    function getSFTPConnection(credentialRecId){
    	
    	var rec_SFTPCred = RECORD.load({
    		type: 'customrecord_wd_consol_invoice_capture',
    		id: credentialRecId	//2
    	});
    	
    	return SFTP.createConnection({
    		username: rec_SFTPCred.getValue({fieldId: 'custrecord_wd_username'}),
    		passwordGuid: rec_SFTPCred.getValue({fieldId: 'custrecord_wd_password'}),
    		url: rec_SFTPCred.getValue({fieldId: 'custrecord_wd_url'}),
    		port: rec_SFTPCred.getValue({fieldId: 'custrecord_wd_port'}),
    		directory: '/',
    		timeout: SFTP.MAX_CONNECT_TIMEOUT,
    		hostKey: rec_SFTPCred.getValue({fieldId: 'custrecord_wd_hostkey'})
    	});
    }
    
    
    //Get customer invoice id
    function getInvoiceId(recurlyInvoiceId){
    	var invoiceId = '';
    	
    	var invoiceSearchObj = SEARCH.create({
    		   type: "invoice",
    		   filters:
    		   [
    		      ["type","anyof","CustInvc"], 
    		      "AND", 
    		      ["mainline","is","T"], 
    		      "AND", 
    		      ["externalid","anyof",recurlyInvoiceId]
    		   ],
    		   columns:
    		   [
    		      SEARCH.createColumn({
    		         name: "internalid",
    		         sort: SEARCH.Sort.ASC,
    		         label: "Internal ID"
    		      })
    		   ]
    		});
    	
    		//var searchResultCount = invoiceSearchObj.runPaged().count;
    		//log.debug("invoiceSearchObj result count",searchResultCount);
    		
    	invoiceSearchObj.run().each(function(result){
    		invoiceId = result.getValue({name: "internalid"});
    		   return false;
    		});
    	
    	return invoiceId;
    }
    
    //Cash Sale internal id
    function getCashSaleId(recurlyInvoiceId){
    	var cashSaleId = '';
    	
    	var invoiceSearchObj = SEARCH.create({
    		   type: RECORD.Type.CASH_SALE,
    		   filters:
    		   [
    		      ["type","anyof","CashSale"], 
    		      "AND", 
    		      ["mainline","is","T"], 
    		      "AND", 
    		      ["externalid","anyof",recurlyInvoiceId]
    		   ],
    		   columns:
    		   [
    		      SEARCH.createColumn({
    		         name: "internalid",
    		         sort: SEARCH.Sort.ASC,
    		         label: "Internal ID"
    		      })
    		   ]
    		});
    	
    		//var searchResultCount = invoiceSearchObj.runPaged().count;
    		//log.debug("invoiceSearchObj result count",searchResultCount);
    		
    	invoiceSearchObj.run().each(function(result){
    		cashSaleId = result.getValue({name: "internalid"});
    		   return false;
    		});
    	
    	return cashSaleId;
    }
    
    
    //Payment Method internal id
    function getPymntMethod(currencyId){
    	var paymntMethodId = '';
    	
    	var search_recurlyPymtMethod = SEARCH.create({
    		   type: 'customrecord_wd_recurly_paymt_method',
    		   filters:
    		   [
    		      ["custrecord_wd_currency","anyof",currencyId]
    		   ],
    		   columns:
    		   [
    		      SEARCH.createColumn({
    		         name: "custrecord_wd_pymnt_method",
    		         sort: SEARCH.Sort.ASC,
    		         label: "Payment Method"
    		      })
    		   ]
    		});
    	
    		//var searchResultCount = invoiceSearchObj.runPaged().count;
    		//log.debug("invoiceSearchObj result count",searchResultCount);
    		
    	search_recurlyPymtMethod.run().each(function(result){
    		paymntMethodId = result.getValue({name: "custrecord_wd_pymnt_method"});
    		   return false;
    		});
    	
    	return paymntMethodId;
    }
    
    
    

    return {
        "checkNullAndFormat"	: checkNullAndFormat,
        "csvToArr"				: csvToArr,
        "getCustomerId"			: getCustomerId,
        "getItemId"				: getItemId,
        "reRunCurrentScript"	: reRunCurrentScript,
        "getFileNameToProcess"	: getFileNameToProcess,
        "getSFTPConnection"		: getSFTPConnection,
        "getInvoiceId"			: getInvoiceId,
        "getCashSaleId"			: getCashSaleId,
        "getPymntMethod"		: getPymntMethod
    };
    
});
