/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
 
define(['N/runtime', 'N/record', 'N/search', 'N/log'], function (runtime,record,search,log) {

    /**
     * context.newRecord
     * context.oldRecord
     * context.type
     *
     * @type {import('N/types').EntryPoints.UserEvent.afterSubmit}
     */
    function beforeSubmit(scriptContext) {
		
           var recObj = scriptContext.newRecord; //create mode
		
          //getting line count
			var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
			  for (var i = 1; i < lineCount; i++) {
				  var obj={};
				var item=recObj.getSublistValue({
						  sublistId: 'item',
						  fieldId: 'item',
						  line: i
						});
				//if item is promotion item then update the above line promotion applied flag		
				if(item==12){
					var m=recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'custcol_promotion_applied',
						  line: i-1,
						  value:true
						});
						i++
				}				
		}
		//checking is the customer is National cust or not
		var entity=recObj.getValue({
					fieldId: 'entity',
				});
      /*
		try {		
		var fields = search.lookupFields({
        type: 'customer',
        id: entity,
        columns: ['custentity_dil_customer_nation_yn','custentity_ns_envcomplianceexempt']
      });
      
      var is_national_cust;
	  var env_cust;
      /*
        is_national_cust = fields.custentity_dil_customer_nation_yn;
		env_cust= fields.custentity_ns_envcomplianceexempt;
      } catch (e) {
        log.debug('error',e);
        
      }
		
 if ( scriptContext.type == scriptContext.UserEventType.CREATE &&!is_national_cust&& !env_cust)
      {
        log.error('ss')
        //find if the Environment Charge is already part of the sales order
            var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 20 //'Environment Compliance Fees'
            });
            log.debug('Environment fee line number',lineNumber);
       
           
                // if Environment fee is not available at the item list then add the line to the item list with environment fee value
               
                    if (lineNumber == -1)
                    {
                        recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 20 //'Environment Fees'
                            });
                        }catch(e)
                        {
                            log.error(' error adding environment fee line',e.message());
                        }
                    }		
			  
        	
        } */
      /*  //store pickup address
      
                //log.debug('Drop_ship_Cust field changed',Drop_ship_Cust);
                //log.debug('Drop_ship_vendor field changed',Drop_ship_vendor);
				
				Atlanta 30046
				Charleston 29418
				Charlotte 29034
				Columbia 29201
				Distribute 29501
				Florence 29501
				Goldsboro 29530
				Latta 29565
				Wilmington 28401
				
				var store_pickup = recObj.getValue("custbody_drop_ship_order");
				if(store_pickup){
                  //var location_zip={"Atlanta":'30046',"Charleston":'29418',"Charlotte":'29034',"Columbia":'29201',"Distribute":'29501',
                 //                  "Florence":'29501',"Goldsboro":'29530',"Latta":'29565',"Wilmington":'28401'};
                 var location_zip={};
				 location_zip[35] = '30046';
				 location_zip[38] = '29418';
				 location_zip[39] = '29034';
				 location_zip[40] = '29201';
				 location_zip[41] = '29501';
				 location_zip[42] = '29501';
				 location_zip[44] = '29530';
				 location_zip[46] = '29565';
				 location_zip[50] = '28401';
				 
		var locationd = recObj.getValue({
 fieldId: 'location'
});
		log.debug(locationd);
		var shipaddrSubrecord  = recObj.getSubrecord({
 fieldId: 'shippingaddress'
});
shipaddrSubrecord.setValue({
            fieldId: 'country',
            value: 'US'
        });
	var l=	 shipaddrSubrecord.setValue({
            fieldId: 'zip',
            value:location_zip[locationd]//'29034'
        });
log.debug('l',l)
				
			} */
		 var store_pickup=recObj.getValue({
					fieldId: 'shipmethod',
				});
				try{
				if(store_pickup==3031){
					var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
			  for (var i = 0; i < lineCount; i++) {
				  
				var line_location=recObj.getSublistValue({
						  sublistId: 'item',
						  fieldId: 'location',
						  line: i
						});
				var line_taxcode=recObj.getSublistValue({
						  sublistId: 'item',
						  fieldId: 'taxcode',
						  line: i
						});		
						log.debug(line_location,line_taxcode);
//tax code internal ids hardcoded.	
var tax={};
tax[35] = -5061;
				 tax[38] = -16134;
				 tax[39] = -11953;
				 tax[40] = -16170;
				 tax[41] = -16154;
				 tax[42] = -16154;
				 tax[44] = -12019;
				 tax[46] = -16151;
				 tax[50] = -11986;					
/* var tax=[50:{tax_code:'NC_WAYNE',tax_Id:-12019},
45:{tax_code:'SC_DILLON_QGQY',tax_Id:-16151},
44:{tax_code:'NC_WAYNE',tax_Id:-12019},-16154
42:{tax_code:'SC_FLORENCE_SZCM',tax_Id:},
40:{tax_code:'SC_RICHLAND_VWPV',tax_Id:-16170},
39:{tax_code:'NC_GASTON',tax_Id:-11953},
38:{tax_code:'SC_CHARLESTON__NORTH CHARLESTON_SLKR',tax_Id:-16134},
35:{tax_code:'GA_GWINNETT',tax_Id:-5061}]; */ 
log.debug('tax object',tax);
				if((tax.hasOwnProperty(line_location))&&(line_taxcode!=-8)){
					var setting_taxcode=recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'taxcode',
						  line: i,
						  value:tax[line_location]
						});
						log.debug('tax code done');
				}						
		} 
				}
				}catch(e){
					log.error('error',e.message())
				}
    }
  
	function afterSubmit(scriptContext) {
		try{
		var rec = scriptContext.newRecord; //create mode
			if(!rec){
				rec=scriptContext.oldRecord;
			}
            var rectype = rec.type;
            var recId = rec.id;
            var recObj = record.load({
                type: rectype,
                id: recId 
            });
          
          	//shipcity
          var fields = search.lookupFields({
                    type: rectype,
                    id: recId,
                    columns: ['shipcity']
                });

                try {
                    var shipcity = fields.shipcity;
                } catch (e) {
                    log.debug('error',e);

                }
    
      //log.error('shipcity',shipcity);
		var shipcity_1 = recObj.setValue({
					fieldId: 'custbody_dil_fulfillmentshipto',
					value: shipcity
				});	
          var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
          for (var i = 0; i < lineCount; i++) {
				  
				var line_location=recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'custcol_so_line_number',
						  line: i,
						  value:i
						});
				 }
		 //var recObj = scriptContext.newRecord; 
         var shell_order_number=recObj.getValue({fieldId:'custbody_dil_so_shell_sales_order_num'});
		 var internalid=recObj.getValue({fieldId:'id'});
          recObj.save({ ignoreMandatoryFields: true });
		 var PO_id;
		 var type;
		 log.debug('record',recObj);
		 log.debug('shell_order_number',shell_order_number);

		 
		if(shell_order_number){  	
	var s = search.create({
    type: search.Type.TRANSACTION,
    filters:
        [{
            name: 'type',
            operator: search.Operator.ANYOF,
            values: 'SalesOrd'
        },
        {
            name: 'internalidnumber',
            operator: search.Operator.EQUALTO,
            values: internalid
        }],
    columns:
        [{
            name: 'applyingtransaction'
        },
        {
            name: 'recordtype',
            join: 'applyingtransaction'
        }]
});

s.run().each(function(result) {
   
    var tranType = result.getValue({
        name: 'recordtype',
        join: 'applyingtransaction'
    });
	if(tranType=='purchaseorder'){
	 PO_id = result.getValue({
        name: 'applyingtransaction'
    });	
	}
    return true;
});
	
	log.debug('PO_id',PO_id);
	if(PO_id){
	var purchase_order = record.load({
                    type: record.Type.PURCHASE_ORDER,
                    id: PO_id,
                    isDynamic: false,
                });
	var memo=purchase_order.setValue({
					fieldId: 'memo',
					value: shell_order_number
				});
	purchase_order.save({ ignoreMandatoryFields: true });			
	}
		}
	}catch(e){
		log.error('error',e);
	}
	}	
	
		
    

    return {
        beforeSubmit: beforeSubmit,
		afterSubmit: afterSubmit
    };

});