/*******************************************************************************
{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType ScheduledScript
 *
 ******************************************************************************/

define(['N/runtime', 'N/render', 'N/record', 'N/search', 'N/email'], function(
  /** @type {import('N/runtime')} **/ runtime,
  /** @type {import('N/task')}    **/ render,
  /** @type {import('N/record')}  **/ record,
  /** @type {import('N/search')}  **/ search,
  /** @type {import('N/email')}     **/ email
) {

  /**
   * context.type
   *
   * @type {import('N/types').EntryPoints.Scheduled.execute}
   */
  function execute(context) {
    // no return value
	try{
		var invoiceSearchObj = search.create({
		   type: "invoice",
		   filters:
		   [
			  ["type","anyof","CustInvc"], 
			  "AND", 
			  ["trandate","onorafter","6/1/2021"], 
			  "AND", 
			  ["mainline","is","T"], 
			  "AND", 
			  ["taxline","is","F"], 
			  "AND", 
			  ["shipping","is","F"], 
			  "AND", 
			  ["cogs","is","F"], 
			  "AND", 
			  ["customer.custentity_dil_cust_buyback_vid","noneof","1"], 
			  "AND", 
			  ["terms","noneof","19"], 
			  "AND", 
			  ["formulatext: {customer.email}","isnotempty",""], 
			  "AND", 
			  ["status","anyof","CustInvc:A"], 
			  "AND", 
			  ["name","anyof","38053"]
		   ],
		   columns:
		   [
			  search.createColumn({
				 name: "tranid",
				 summary: "GROUP",
				 sort: search.Sort.ASC
			  }),
			  search.createColumn({
				 name: "trandate",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "entity",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "email",
				 join: "customer",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "amount",
				 summary: "SUM"
			  }),
			  search.createColumn({
				 name: "createdfrom",
				 summary: "GROUP"
			  }),
			  search.createColumn({
				 name: "formulatext",
				 summary: "GROUP",
				 formula: "Case when {messages.isemailed} is null then 'No Email Sent' else 'Yes' end"
			  }),
			  search.createColumn({
				 name: "formulatext",
				 summary: "GROUP",
				 formula: "Case When {customer.email} is null then 'Print Invoice' else 'Email Invoice' end"
			  }),
			  search.createColumn({
				 name: "statusref",
				 summary: "GROUP"
			  }),
      search.createColumn({
         name: "internalid",
         summary: "GROUP"
      })
		   ]
		});
		var searchResultCount = invoiceSearchObj.runPaged().count;
		log.debug("invoiceSearchObj result count",searchResultCount);
		invoiceSearchObj.run().each(function(result){
		   // .run().each has a limit of 4,000 results
		   var receiver =result.getValue({
				 name: "email",
				 join: "customer",
				 summary: "GROUP"
			  }); 
			  var copiedRecordId =result.getValue({
				 name: "internalid",
				 summary: "GROUP"
			  });
			  log.debug('receiver',receiver);
			  log.debug('copiedRecordId',copiedRecordId);
		   var senderId = 39767;
				var recipientId = [receiver];
				var subject = 'Hello';
				var body = 'Hello';
				body += ''; 
				  var TransactionPdfObj = render.transaction({
					 entityId:parseInt(copiedRecordId),
					 printMode:render.PrintMode.PDF
				  });
				email.send({
					author: senderId,
					recipients: recipientId,
					subject: subject,
					body: body,
					attachments: [TransactionPdfObj]
				});
		   return true;
		});
				
	}catch(e)
	{
		log.debug('Error',e.toString());
	}
  }

  return {
    'execute': execute
  };

});
