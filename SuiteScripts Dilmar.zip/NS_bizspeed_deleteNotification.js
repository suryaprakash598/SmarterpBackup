/*******************************************************************************
{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 *
 ******************************************************************************/

define(['N/runtime', 'N/task', 'N/record', 'N/search', 'N/https'], function(
  /** @type {import('N/runtime')} **/ runtime,
  /** @type {import('N/task')}    **/ task,
  /** @type {import('N/record')}  **/ record,
  /** @type {import('N/search')}  **/ search,
  /** @type {import('N/log')}     **/ https
) {

  /**
   * context.newRecord
   * context.oldRecord
   * context.type
   *
   * @type {import('N/types').EntryPoints.UserEvent.afterSubmit}
   */
  function afterSubmit(context) {
     try{
		 if(context.type=='delete')
		 {
			 	var rec = context.oldRecord;  
				var rectype = rec.type;
				var recId = rec.id; 
				var docnumber = rec.getValue({fieldId:'tranid'});
				
				var orderData = {
					"msg": {
						"module": "SS2.MobileHub.Classes.SyncMobileHelpers.api3PLexternal",
						"opcode": "CancelOrders",
						"status": null,
						"messageData": {
							"Orders": [
								{
									"orderNo": docnumber,
									"customerName": null,
									"accountNo": null
								}
							]
						},
						"authToken": {
							"UserName": "netsuite_api",
							"Password": "sWWHpW5viOwP",
							"CompanyCode": "dilmar",
							"CryptoKey": null,
							"OrgRefId": "00000000-0000-0000-0000-000000000000",
							"UserRefId": "00000000-0000-0000-0000-000000000000",
							"DeviceRefId": "00000000-0000-0000-0000-000000000000"
						},
						"clockTimeInUTC": null
					}
				}
				 var deleteProduct = postOrderData(orderData);
				 log.debug('deleteProduct',deleteProduct);
				 
		 }
		if(false)
		{
			try{
				
			}catch(e)
			{
				 log.debug('Error',e.toString());
			}
		}
		
	 }catch(e)
	 {
		 log.debug('Error',e.toString());
	 }
  }
  function postOrderData(OrderData) {
	        try {
	            log.debug('orderData', OrderData);
	            var _bizspeed_url = 'https://mh-est.goroam.com/SyncMobileSuiteJSON.asmx/BrokerMessageJSON'; 
	            var headersbizspeed = {
	                'content-type': 'application/json'
	            };
	            var response = https.request({
	                method: https.Method.POST,
	                url: _bizspeed_url,
	                body: JSON.stringify(OrderData),
	                headers: headersbizspeed
	            });
	            log.debug('OrderData response', response)
	            return response;

	        } catch (e) {
	            log.debug('Error in postOrderData', e.toString());
	        }
	}
	/**
   * context.newRecord
   * context.type
   * context.form
   * context.request
   *
   * @type {import('N/types').EntryPoints.UserEvent.beforeLoad}
   */
  function beforeLoad(context) {
    // no return value
	try{
		var form = context.form;
		form.clientScriptFileId=6803;//8447;
		var objRecord = context.newRecord;
		var recid=objRecord.id;
		var isReqSent = objRecord.getValue({fieldId:'custbody_is_bizspeed_req_sent'});
		var iscancelled = objRecord.getValue({fieldId:'custbody_is_biz_cancel_req_sent'});
		var shipstatus = objRecord.getValue({fieldId:'shipstatus'});
		var docnumber = objRecord.getValue({fieldId:'tranid'});
		if(context.type=='view'&& isReqSent&&shipstatus=='B'&&!iscancelled){
			form.addButton({
				 id: 'custpage_cancel_biz_req',
				 label: 'Cancel Biz Request',
				 functionName: 'cancelBizReq("'+docnumber+'","'+recid+'")'
			});
			
		} if(context.type=='view'&& isReqSent && shipstatus=='B'&&!iscancelled)
		{
			form.addButton({
				 id: 'custpage_update_biz_req',
				 label: 'Update Biz Request',
				 functionName: 'updateBizReq("'+docnumber+'","'+recid+'")'
			});
			
		} if(context.type=='view'&& isReqSent && shipstatus=='B'&&iscancelled)
		{
			form.addButton({
				 id: 'custpage_resend_biz_req',
				 label: 'Resend Biz Request',
				 functionName: 'resendBizReq("'+docnumber+'","'+recid+'")'
			});
		}
		

	}catch(e)
	{
		log.debug('Error in beforeLoad', e.toString());
	}
  }
    
  return {
    'afterSubmit':  afterSubmit ,
    'beforeLoad':   beforeLoad
  };

});
