/**
 * @NApiVersion 2.x
 * @NScriptType WorkflowActionScript
 */
define(['N/record'], function(record) {
    function onAction(context){
     
        var newRecord = context.newRecord;
		var accept_backorders = newRecord.getValue('custbody_dil_cust_accept_backorders');
		if (!accept_backorders)
        {
			var so_id = newRecord.getValue('createdfrom');
			log.debug('so_id',so_id);
			var objRecord = record.load({
				type: record.Type.SALES_ORDER,
				id: so_id,
				isDynamic: true,
			});
			var itemsublist = objRecord.getSublist({
				sublistId: 'item'
			});
			var itemCount = objRecord.getLineCount({
				sublistId: 'item'
			});
            var ischanged = false;
			for (var i = 0; i < itemCount; i++){
				try{
					var linenum = objRecord.selectLine({
						sublistId: 'item',
						line: i
					});
                 	 var isclosed = objRecord.getCurrentSublistValue({
                          sublistId: 'item',
                          fieldId: 'isclosed'
                      });
					if (!isclosed)	
                    {
                      var closed = objRecord.setCurrentSublistValue({
                          sublistId: 'item',
                          fieldId: 'isclosed',
                          value: true
                      });
                      objRecord.commitLine({sublistId: 'item'});
                      ischanged = true;
                      log.debug('current closed line value',objRecord.getCurrentSublistValue({
                          sublistId: 'item',
                          fieldId: 'isclosed'
                      }));
                	}
			} catch(e){
					 log.error({
                                title: 'error of Item ' + i,
                                details: e.message()
                            });
					return 0;
				}
			}
          
          if (ischanged)
          { 
			var salesorderid= objRecord.save();
			log.debug('sales order saved',salesorderid);
			}
		}
        
        return salesorderid||'';
    }
    return {
        onAction: onAction
    }
});