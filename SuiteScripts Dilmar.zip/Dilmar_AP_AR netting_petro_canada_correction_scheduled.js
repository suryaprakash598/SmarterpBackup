/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 * @NModuleScope SameAccount
 */
define([ 'N/redirect', 'N/runtime', 'N/record', 'N/ui/message', 'N/search', 'N/url', 'N/format', 'N/email', 'N/file', 'N/task'],

    function (redirect, runtime, record, message, search, url, format,email, file, task) {

    /**
     * Definition of the Scheduled script trigger point.
     *
     * @param {Object} scriptContext
     * @param {string} scriptContext.type - The context in which the script is executed. It is one of the values from the scriptContext.InvocationType enum.
     * @Since 2015.2
     */
    function execute(scriptContext) {

        var scriptObj = runtime.getCurrentScript();
        log.debug('Script parameter of custscript1:', '');
		var fileSearchObj = search.create({
   type: "file",
   filters:
   [
      ["folder","anyof","1251"], 
      "AND", 
       ["created","onorafter","11/18/2021 12:00 am"]
	   
   ],
   columns:
   [search.createColumn({name: "internalid", label: "Internal ID"})
   ]
});
var searchResultCount = fileSearchObj.runPaged().count;
log.debug("fileSearchObj result count",searchResultCount);
var file_ids=[];
fileSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var id=result.getValue({name: "internalid"})
    file_ids.push(id);
	
	
   return true;
});
for(var i=0;i<file_ids.length;i++){
	try{
        var fileObj = file.load({
            id: file_ids[i] 
        });
        var contents = fileObj.getContents();
        var groupResult = JSON.parse(contents);

        var keys = Object.keys(groupResult);
        //journal creation
        var journal = record.create({
            type: record.Type.JOURNAL_ENTRY,
            isDynamic: true
        });

        //set the values in the required fields
        var l = groupResult[keys[0]];
        journal.setValue('subsidiary', l[0].subsidiary);
        //log.debug('subsidiary', groupResult[keys[0]].subsidiary)
        //journal.setValue('trandate',dataSource[0].date);
        journal.setValue('approvalstatus', 1); //pending approval

        var total_creditamount = 0;
        var total_debitamount = 0;
        var invoice_internalid = [];
        var bill_internalid = [];
        for (var m = 0; m < keys.length; m++) {
            //creating invoice
            var rebateData = groupResult[keys[m]];
            for (var j = 0; j < rebateData.length; j++) {
                var data = {};
                
				 data.creditamount = rebateData[j].creditamount;
                data.debitamount = rebateData[j].debitamount;
                //data.memo = rebateData[j].memo;
                data.internalid = rebateData[j].internalid;
                data.customer = rebateData[j].customer;
              data.type = rebateData[j].type;
             if(data.type=='Invoice'){
                 invoice_internalid.push(data.internalid)
             }
              else{
                   bill_internalid.push(data.internalid)
              }

               
            }
        }
        log.debug('total_debitamount', total_debitamount);
        log.debug('total_creditamount', total_creditamount);

        var bank_acount = total_creditamount - total_debitamount;
        log.debug('bank_account', Math.abs(bank_acount));
        if (bank_acount > 0) {
            log.debug('bank debit amount', bank_acount)
            journal.selectNewLine('line');
            journal.setCurrentSublistValue('line', 'account', 265); //265	0121	SOUTH STATE //previous 254
            journal.setCurrentSublistValue('line', 'credit', Math.abs(bank_acount)); //dataSource[i].creditamount);12232  costco 157
            journal.setCurrentSublistValue('line', 'memo', 'Total collection debit(-)');
            // journal.setCurrentSublistValue('line','entity',157);
            //Commits the currently selected line on a sublist.
            journal.commitLine('line');

        } else if (bank_acount < 0) {
            log.debug('bank credit amount', bank_acount)
            journal.selectNewLine('line');
            journal.setCurrentSublistValue('line', 'account', 265);//265	0121	SOUTH STATE //previous 254
            journal.setCurrentSublistValue('line', 'debit', Math.abs(bank_acount)); //dataSource[i].creditamount);12232  costco 157
            journal.setCurrentSublistValue('line', 'memo', 'Total collection credit(+)');
            //journal.setCurrentSublistValue('line','entity',157);
            //Commits the currently selected line on a sublist.
            journal.commitLine('line');
        }
        
        try{
           var billPayment = record.create({
                type: record.Type.VENDOR_PAYMENT,
                isDynamic: false,
                defaultValues: {
                        entity:34754 //petro canada
                    }
                });
				billPayment.setValue({
                    fieldId: 'account',
                    value: 654              }); 
               
               for (var m = 0; m < bill_internalid.length; m++) {
                var bill_lineid = billPayment.findSublistLineWithValue({
                    sublistId: 'apply',
                    fieldId: 'doc',
                    value: bill_internalid[m]
                });
                billPayment.setSublistValue({
                    sublistId: 'apply',
                    fieldId: 'apply',
                    line: bill_lineid,
                    value: true
                });
                //log.debug('bill_lineid', bill_lineid);
			   }

                var rid = billPayment.save({
                    ignoreMandatoryFields: true
                });
                log.debug('vendor payment', rid)
          /*  for (var m = 0; m < bill_internalid.length; m++) {
				var vendorBillPayment = record.transform({
										fromType: 'vendorbill',
										fromId: bill_internalid[m],
										toType:'vendorpayment'
										});
				 
				vendorBillPayment.setValue({
                    fieldId: 'account',
                    value: 654                }); 
               

                var rid = vendorBillPayment.save({
                    ignoreMandatoryFields: true
                });
                log.debug('vendor payment', rid)
            }*/

        }
          catch(e){
            log.debug('vendor payment error',e)
          }
}
catch(e){
	log.debug('error',e)
}
	}

    }

    return {
        execute: execute
    };

});