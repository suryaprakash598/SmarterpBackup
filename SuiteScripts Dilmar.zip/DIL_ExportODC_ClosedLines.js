/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 */
define(['N/search', 'N/file', 'underscore', 'N/encode', 'N/record', 'N/email'],

    function(search, file, underscore, encode, record, email) {

        //Load saved search
        function execute(scriptContext) {
            var _odc = savedSearchODC();
            log.debug('_odc', _odc);
            var _groupOdc = underscore.groupBy(_odc, 'createdfrom');
            log.debug('_groupOdc', _groupOdc);
            var controlObj = controlRecord();
            var TrailerObj = ''; //trailerRecord(); NO TRAILER IN ODC
            var keys = Object.keys(_groupOdc);
            log.debug('keys', keys);
            var arr = [];
            for (var k = 0; k < keys.length; k++) {
                try {
                    var csvFile = '';
                    var data = _groupOdc[keys[k]];
                    var headerObj = headerRecord(_groupOdc[keys[k]]);
                    var lineObj = lineItemRecord(_groupOdc[keys[k]]);
                    csvFile += controlObj + headerObj + lineObj + TrailerObj;

                    //Creation of file
                    var fileObj = file.create({
                        //To make each file unique and avoid overwriting, append date on the title
                        name: 'Closed_ODC_' + k + "_" + data[0].docNumber,
                        fileType: file.Type.CSV,
                        contents: csvFile,
                        description: 'File sent to shell from distributor to confirm delivery has been made',
                        encoding: file.Encoding.UTF8,
                        folder: 205252 //1086
                    });

                    //Save the CSV file
                    var fileId = fileObj.save()
                    //log.debug('File ID...', fileId)
                    arr.push({
                        'fileId': fileId,
                        'docnumber': data[0].docNumber,
                        'traninternalid': data[0].traninternalid
                    });


                } catch (e) {
                    log.debug('Error in Main', e.toString());
                }
            }
            if (arr.length) {
                //createCustomRecord(arr);
                //sendEmail(arr);
                //updateFileGeneratedInfo(arr);

            }

        }

        function savedSearchODC() {
            try {
                var arr = [];

                var invoiceSearchObj = search.create({
                    type: "salesorder",
                    filters: [
                        ["type", "anyof", "SalesOrd"],
                        "AND",
                        ["shipping", "is", "F"],
                        "AND",
                        ["taxline", "is", "F"],
                        "AND",
                        ["mainline", "is", "F"],
                        "AND",
                        ["customer.custentity_dil_customer_nation_yn", "is", "T"],
                        "AND",
                        ["status", "anyof", "SalesOrd:G", "SalesOrd:H"],
                        "AND",
                        ["custbody_dil_closed_odc_sent", "is", "F"],
                        "AND",
      ["number","equalto","2719474"]
                    ],
                    columns: [
                        search.createColumn({
                            name: "tranid",
                            join: "billingTransaction",
                            summary: "GROUP",
                            label: "Document Number"
                        }),
                        search.createColumn({
                            name: "trandate",
                            join: "billingTransaction",
                            summary: "GROUP",
                            label: "Date"
                        }),
                        search.createColumn({
                            name: "custbody_dil_so_shell_sales_order_num",
                            summary: "GROUP",
                            label: "SAP Sales Order #"
                        }),
                        search.createColumn({
                            name: "statusref",
                            join: "billingTransaction",
                            summary: "GROUP",
                            label: "Status"
                        }),
                        search.createColumn({
                            name: "otherrefnum",
                            join: "billingTransaction",
                            summary: "GROUP",
                            label: "PO/Check Number"
                        }),
                        search.createColumn({
                            name: "custbody_dil_so_ship_truck_no",
                            join: "billingTransaction",
                            summary: "GROUP",
                            label: "Ship Truck No."
                        }),
                        search.createColumn({
                            name: "custbody_dil_so_order_delivery_date",
                            join: "billingTransaction",
                            summary: "GROUP",
                            label: "Expected Delivery Date"
                        }),
                        search.createColumn({
                            name: "quantity",
                            summary: "GROUP",
                            label: "Quantity"
                        }),
                        search.createColumn({
                            name: "custentity_dil_cust_ext_ship_to",
                            join: "customer",
                            summary: "GROUP",
                            label: "Shell Ship To Number"
                        }),
                        search.createColumn({
                            name: "custentity_dil_cust_ext_sold_to",
                            join: "customer",
                            summary: "GROUP",
                            label: "Shell Sold To Number"
                        }),
                        search.createColumn({
                            name: "unit",
                            summary: "GROUP",
                            label: "Units"
                        }),
                        search.createColumn({
                            name: "custrecord_dil_dist_ship_from_num",
                            join: "location",
                            summary: "GROUP",
                            label: "Distributor Ship From Number"
                        }),
                        search.createColumn({
                            name: "custrecord_dil_plant_id",
                            join: "location",
                            summary: "GROUP",
                            label: "Plant ID"
                        }),
                        search.createColumn({
                            name: "custrecord_dil_loc_sh_shipping_point",
                            join: "location",
                            summary: "GROUP",
                            label: "Shipping Point"
                        }),
                        search.createColumn({
                            name: "itemid",
                            summary: "GROUP",
                            join: "item",
                            label: "Item"
                        }),
                        search.createColumn({
                            name: "quantitybilled",
                            summary: "GROUP",
                            label: "Quantity Billed"
                        }),
                        search.createColumn({
                            name: "custcol_quantity_remaining",
                            summary: "GROUP",
                            label: "QUANTITY Remaining"
                        }),
                        search.createColumn({
                            name: "tranid",
                            summary: "GROUP",
                            label: "Document Number"
                        })
                    ]
                });


                /* search.create({
			   type: "salesorder",
			   filters:
			   [
				  ["type","anyof","SalesOrd"], 
				  "AND", 
				  ["status","anyof","SalesOrd:H"], 
				  "AND", 
				  ["mainline","is","F"], 
				  "AND", 
				  ["customer.custentity_dil_customer_nation_yn","is","T"], 
				  "AND", 
				  ["quantitybilled","equalto","0"], 
				  "AND", 
				  ["custbody_dil_so_buyback_vendor","anyof","1"],
				  "AND", 
				["custbody_dil_closed_odc_sent","is","F"]
			   ],
			   columns:
			   [
				  "tranid",
				  search.createColumn({
					 name: "internalid",
					 sort: search.Sort.DESC
				  }),
				  "trandate",
				  "otherrefnum",
				  "custbody_dil_so_shell_sales_order_num",
				  "custbody_dil_so_ship_truck_no",
				  "custbody_dil_so_order_delivery_date",
				  "statusref", 
				  "quantity",
				  search.createColumn({
					 name: "custentity_dil_cust_ext_ship_to",
					 join: "customer"
				  }),
				  search.createColumn({
					 name: "custentity_dil_cust_ext_sold_to",
					 join: "customer"
				  }),
				  "unit",
				  search.createColumn({
					 name: "custrecord_dil_dist_ship_from_num",
					 join: "location"
				  }),
				  search.createColumn({
					 name: "custrecord_dil_plant_id",
					 join: "location"
				  }),
				  search.createColumn({
					 name: "custrecord_dil_loc_sh_shipping_point",
					 join: "location"
				  }),search.createColumn({
					 name: "itemid",
					 join: "item",
					 label: "Name"
				  })
			   ]
			}); */
                var searchResultCount = invoiceSearchObj.runPaged().count;
                log.debug("invoiceSearchObj result count", searchResultCount);
                /* salesorderSearchObj.run().each(function(result){
                   // .run().each has a limit of 4,000 results
                   return true;
                }); */
                invoiceSearchObj.run().each(function(result) {
                    // .run().each has a limit of 4,000 results
                    var obj = {};
                    obj.docNumber = result.getValue({
                        name: 'tranid',
						join: "billingTransaction",
                        summary: "GROUP"
                    });
                    obj.traninternalid = result.getValue({
                        name: 'internalid',
						join: "billingTransaction",
                        summary: "GROUP"
                    });
                    obj.trandate = result.getValue({
                        name: 'trandate',
						join: "billingTransaction",
                        summary: "GROUP"
                    });
                    obj.otherrefnum = result.getValue({
                        name: 'otherrefnum',
						join: "billingTransaction",
                        summary: "GROUP"
                    });
                    obj.createdfrom = result.getValue({
                        name: 'tranid',
                        summary: "GROUP"
                    });
                    obj.unit = result.getText({
                        name: 'unit',
                        summary: "GROUP"
                    });
                    obj.quantity = result.getValue({
                        name: 'quantitybilled',
                        summary: "GROUP"
                    });
                  log.debug('obj.quantity',obj.quantity);
                    obj.shellSoNumber = result.getValue({
                        name: 'custbody_dil_so_shell_sales_order_num',
                        summary: "GROUP"
                    });
                    obj.ship_truck_no = result.getValue({
                        name: 'custbody_dil_so_ship_truck_no',
                        summary: "GROUP"
                    });
                    obj.delivery_date = result.getValue({
                        name: 'custbody_dil_so_order_delivery_date',
                        summary: "GROUP"
                    });
                    obj.ship_to = result.getValue({
                        name: 'custentity_dil_cust_ext_ship_to',
                        join: "customer",
                        summary: "GROUP"
                    });
                    obj.sold_to = result.getValue({
                        name: 'custentity_dil_cust_ext_sold_to',
                        join: "customer",
                        summary: "GROUP"
                    });
                    obj.shipfromid = result.getValue({
                        name: 'custrecord_dil_dist_ship_from_num',
                        join: "location",
                        summary: "GROUP"
                    });
                    obj.shipping_point = result.getValue({
                        name: 'custrecord_dil_loc_sh_shipping_point',
                        join: "location",
                        summary: "GROUP"
                    });
                    obj.plantid = result.getValue({
                        name: "custrecord_dil_plant_id",
                        join: "location",
                        summary: "GROUP"
                    });
                    obj.shellproductnumber = result.getValue({
                        name: "itemid",
                        join: "item",
                        summary: "GROUP"
                    });
                    arr.push(obj);
                    return true;
                });
                return arr;
            } catch (e) {
                log.debug('Error in savedSearchList', e.toString());
            }
        }

        function controlRecord() {
            var tempString = '';
            //TagID,SenderID,SenderQualifer,ReceiverID,ReceiverQualifier,SenderInterchangeNo,MessageReferenceNo,MessageType,SMDVersion,TestFlag
            tempString += "CTL,11243268,,SOPUS,,,,ORDER_DELIVERY_CONFIRMATION,," + "\r\n";
            return tempString;
        }

        function trailerRecord() {
            var tempString = '';
            tempString += "TRL" + "\r\n";
            return tempString;
        }

        function headerRecord(data) {
            var tempString = '';
            if (data.length) {
                //TagID ,CustomerSoldToID ,CustomerShipToID ,DistributorShipFromID ,ShellSalesOrderNumber ,
                //DistributorPONumber,DeliveryTicketNumber , DateDelivered ,PlantID ,ShippingPoint ,CustomerPONumber
                var delivery_date = '';
				var otherrefnum;
                if (data[0].delivery_date) {
                    delivery_date = formatDate(data[0].delivery_date);
                }
                var createdfrom = '';
                if (data[0].createdfrom) {
                    createdfrom = data[0].createdfrom.split('#')[1]
                }
//HDR,11248318,12106157,11263040,0263422732,SO2720484,SO2720484,,U297,1673,null

for(var i=0;i<data.length;i++){
	if(delivery_date){
		delivery_date = formatDate(data[i].delivery_date);
	}
	
}
                tempString += "HDR" + "," +
                    data[0].sold_to + "," +
                    data[0].ship_to + "," +
                    data[0].shipfromid + "," +
                    data[0].shellSoNumber + "," +
                    data[0].docNumber + "," +
                    data[0].createdfrom + "," +
                    // data[0].docNumber + "," + 
                    delivery_date + "," +
                    data[0].plantid + "," +
                    data[0].shipping_point + "," +
                    data[0].otherrefnum + "\r\n";
            }
            return tempString;
        }

        function lineItemRecord(data) {
            var tempString = '';
            var lineNumber = 0;
            var unitsObj = units();
            for (var i = 0; i < data.length; i++) {
                lineNumber = lineNumber + 10;
                var unitsshort = unitsObj[data[i].unit];
                //log.debug('unitsshort',unitsshort);
                //TagID , LineItemNumber , ShellProductNumber ,Quantity ,UnitOfMeasure ,GratisFlat , ValuationType ,HandlingType,SalesOrganisation, DistributionChannel
                tempString += "LIN" + "," + (lineNumber) + "," + data[i].shellproductnumber + "," + data[i].quantity + "," + unitsshort + ",N" + "\r\n";
            }
            return tempString;
        }

        function createCustomRecord(arr) {
            try {

                //redirect.toSuitelet({scriptId:1909,deploymentId:1,parameters:{'fileid':1}});
                log.debug('arr', arr);
                var customRecObj = record.create({
                    type: 'customrecord_edi_odc_invoice',
                    isDynamic: !0
                });
                var invoiceids = [];

                for (var i = 0; i < arr.length; i++) {
                    invoiceids.push(arr[i].traninternalid);
                }
                log.debug('invoiceids', invoiceids);
                customRecObj.setValue({
                    fieldId: 'custrecord_odc_document_number',
                    value: invoiceids
                });
                var id = customRecObj.save();
                for (var i = 0; i < arr.length; i++) {
                    record.attach({
                        record: {
                            type: 'file',
                            id: arr[i].fileId,
                        },
                        to: {
                            type: 'customrecord_edi_odc_invoice',
                            id: id
                        }
                    })
                }
            } catch (e) {
                log.debug('error', e.toString());
            }

        }

        function sendEmail(arr) {
            try {
                var senderId = -5;
                log.debug('arr', arr);
                var recipientId = ['amber@dilmar.com'];
                var subject = 'EDI ODC Files';
                var body = 'Hi, EDI ODC processed files';
                body += '<table><tr><th>Document Number</th><th>File</th></tr>';
                for (var i = 0; i < arr.length; i++) {
                    body += '<tr>';
                    body += '<td>' + arr[i].docnumber + '</td><td>' + arr[i].fileId + '</td>';
                    body += '</tr>';
                }
                body += '</table>';
                /* email.send({
                    author: senderId,
                    recipients: recipientId,
                      cc: cclist,
                    bcc: bcclist,  
                    subject: subject,
                    body: body
                }); */

            } catch (e) {
                log.debug('error', e.toString());
            }
        }

        function units() {
            var obj = {
                'Bulk': 'GAL',
                '1 Gal': 'GAL',
                'Carton': 'CT',
                'Case': 'CT',
                'Drum': 'EA',
                'Each': 'EA',
                'Ecobox': 'CT',
                'Keg': 'EA',
                'Pail': 'EA',
                'Tote': 'EA'
            };
            return obj;
        }

        function updateFileGeneratedInfo(arr) {
            try {
                for (var i = 0; i < arr.length; i++) {
                    log.debug('arr inupdateFileGeneratedInfo ', arr[i])
                    var recobj = record.load({
                        type: 'salesorder',
                        id: arr[i].traninternalid,
                        isDynamic: !0
                    });
                    recobj.setValue({
                        fieldId: 'custbody_dil_closed_odc_sent',
                        value: true,
                        ignoreFieldChange: true
                    });
                    recobj.save();
                    //record.submitFields({type:'invoice',id:arr[i].traninternalid,values:{custbody_is_file_generated:true},options:{enableSourcing:!1,ignoreMandatoryFields:!0}});
                }
            } catch (e) {
                log.debug('error', e.toString())
            }
        }

        function formatDate(date) {

            var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

            if (month.length < 2)
                month = '0' + month;
            if (day.length < 2)
                day = '0' + day;

            return [year, month, day].join('');


        }

        return {
            execute: execute
        };

    });