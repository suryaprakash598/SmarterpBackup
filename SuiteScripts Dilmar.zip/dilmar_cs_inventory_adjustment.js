/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
 define(['N/record'],
 /**
     * @param {record} record
  */
 function(record) {
 
     const TRANSACTION_BODY = {};
     TRANSACTION_BODY.ADJ_LOCATION = 'adjlocation';
 
     const TRANSACTION_LINE = {};
     TRANSACTION_LINE.INVENTORY_LIST = 'inventory';
     TRANSACTION_LINE.LOCATION = 'location';
     TRANSACTION_LINE.ITEM = 'item';
     TRANSACTION_LINE.UNITCOST = 'unitcost';
 
     const ITEM = {};
     ITEM.LOCATION_LIST = 'locations';
     ITEM.AVERAGECOSTMLI = 'averagecostmli';
     ITEM.LOCATION = 'location';
     ITEM.AVERAGECOST = 'averagecost';
     ITEM.COST = 'cost';
     ITEM.LASTPURCHASEPRICE = 'lastpurchaseprice';
 
     /**
      * Function to be executed after page is initialized.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
      *
      * @since 2015.2
      */
     function pageInit(scriptContext) {
 
     }
 
     /**
      * Function to be executed when field is changed.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      * @param {string} scriptContext.fieldId - Field name
      * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
      * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
      *
      * @since 2015.2
      */
     function fieldChanged(scriptContext) {
         var currentRecord = scriptContext.currentRecord;
 if(scriptContext.fieldId === TRANSACTION_BODY.ADJ_LOCATION) {
         var adjLocation = currentRecord.getValue({
             fieldId: TRANSACTION_BODY.ADJ_LOCATION
         }) || '';
 
         if(adjLocation) {
             var lineCount = currentRecord.getLineCount({
                 sublistId: TRANSACTION_LINE.INVENTORY_LIST
             });
 
             if (lineCount > 0) {
                 for (var line = 0; line < lineCount; line++) {
                     currentRecord.setSublistValue({
                         sublistId: TRANSACTION_LINE.INVENTORY_LIST,
                         fieldId: TRANSACTION_LINE.LOCATION,
                         value: adjLocation,
                         line : line
                     })
                 }
             }
         }
 }
     }
 
     /**
      * Function to be executed when field is slaved.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      * @param {string} scriptContext.fieldId - Field name
      *
      * @since 2015.2
      */
     function postSourcing(scriptContext) {
         var currRec = scriptContext.currentRecord;

         if (scriptContext.sublistId === TRANSACTION_LINE.INVENTORY_LIST && scriptContext.fieldId === TRANSACTION_LINE.ITEM) {
             // update line level location
             UpdateAdjustmentLineLocation(scriptContext, currRec);
 
             // update est. unit cost
             UpdateAdjustmentLineUnitCost(scriptContext, currRec);
         }
     }
 
     function UpdateAdjustmentLineLocation(scriptContext, currRec) {
         var adjLocation = currRec.getValue({
             fieldId: TRANSACTION_BODY.ADJ_LOCATION
         }) || '';

        // alert(adjLocation);
 
         if(adjLocation != null && adjLocation != undefined && adjLocation != ''){
             var lineLocation = currRec.getCurrentSublistValue({
                 sublistId: TRANSACTION_LINE.INVENTORY_LIST,
                 fieldId: TRANSACTION_LINE.LOCATION
             }) || '';
 
             if (adjLocation !== lineLocation) {
                 currRec.setCurrentSublistValue({
                     sublistId: TRANSACTION_LINE.INVENTORY_LIST,
                     fieldId: TRANSACTION_LINE.LOCATION,
                     value: adjLocation
                 })
             }
         }
     }
 
     function UpdateAdjustmentLineUnitCost(scriptContext, currRec) {
         var lineUnitCost = currRec.getCurrentSublistValue({
             sublistId : TRANSACTION_LINE.INVENTORY_LIST,
             fieldId : TRANSACTION_LINE.UNITCOST
         }) || '';
 
         if(!lineUnitCost) {
             var lineItem = currRec.getCurrentSublistValue({
                 sublistId : TRANSACTION_LINE.INVENTORY_LIST,
                 fieldId : TRANSACTION_LINE.ITEM
             }) || '';

             var lineItemType = currRec.getCurrentSublistValue({
                sublistId : TRANSACTION_LINE.INVENTORY_LIST,
                fieldId : 'itemtype'
            }) || '';

            switch (lineItemType) {
                case 'InvtPart' :
                    lineItemType = 'inventoryitem';
                    break;
    
                case 'Assembly' :
                    lineItemType = 'assemblyitem';
                    break;

               case 'NonInvtPart':
                   lineItemType = 'noninventoryitem';
                   break;

               case 'Service':
                   lineItemType = 'serviceitem';
                   break;
            }
 
             var lineLocation = currRec.getCurrentSublistValue({
                 sublistId : TRANSACTION_LINE.INVENTORY_LIST,
                 fieldId : TRANSACTION_LINE.LOCATION
             }) || '';
 
             if(lineItem) {
                 var newUnitCost = GetItemCost(lineItem, lineLocation);
                 if (newUnitCost) {
                     currRec.setCurrentSublistValue({
                         sublistId: TRANSACTION_LINE.INVENTORY_LIST,
                         fieldId: TRANSACTION_LINE.UNITCOST,
                         value: newUnitCost
                     })
                 }
             }
         }
     }
 
     function GetItemCost(item, location) {
         var itemAverageCost = '';
         var itemRec;
         try {
            itemRec = record.load({
                type : record.Type.INVENTORY_ITEM,
                id : item,
                isDynamic : true
            });
         } catch (error) {
            itemRec = record.load({
                type : record.Type.ASSEMBLY_ITEM,
                id : item,
                isDynamic : true
            });
         }
         
         if(itemRec){
            var locationLineCount = itemRec.getLineCount({
                sublistId: ITEM.LOCATION_LIST
            });
    
            if(locationLineCount) {
                for(var locationLine = 0; locationLine < locationLineCount; locationLine++) {
                    var lineLocation = itemRec.getSublistValue({
                        sublistId: ITEM.LOCATION_LIST,
                        fieldId: ITEM.LOCATION,
                        line: locationLine
                    }) || '';
    
                    if(lineLocation === location) {
                        itemAverageCost = itemRec.getSublistValue({
                            sublistId: ITEM.LOCATION_LIST,
                            fieldId: ITEM.AVERAGECOSTMLI,
                            line: locationLine
                        })
                        break;
                    }
                }
            }
    
            if(!itemAverageCost) {
                // get body level average cost
                itemAverageCost = itemRec.getValue({
                    fieldId : ITEM.AVERAGECOST
                }) || '';
    
                if(!itemAverageCost) {
                    // get body level purchase price
                    itemAverageCost = itemRec.getValue({
                        fieldId: ITEM.COST
                    }) || '';
    
                    if(!itemAverageCost) {
                        // get body level last purchase price
                        itemAverageCost = itemRec.getValue({
                            fieldId : ITEM.LASTPURCHASEPRICE
                        }) || '';
                    }
                }
            }
         }
 
         
 
         return itemAverageCost;
     }
 
     /**
      * Function to be executed after sublist is inserted, removed, or edited.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      *
      * @since 2015.2
      */
     function sublistChanged(scriptContext) {
 
     }
 
     /**
      * Function to be executed after line is selected.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      *
      * @since 2015.2
      */
     function lineInit(scriptContext) {
 
     }
 
     /**
      * Validation function to be executed when field is changed.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      * @param {string} scriptContext.fieldId - Field name
      * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
      * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
      *
      * @returns {boolean} Return true if field is valid
      *
      * @since 2015.2
      */
     function validateField(scriptContext) {
 
     }
 
     /**
      * Validation function to be executed when sublist line is committed.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      *
      * @returns {boolean} Return true if sublist line is valid
      *
      * @since 2015.2
      */
     function validateLine(scriptContext) {
 
     }
 
     /**
      * Validation function to be executed when sublist line is inserted.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      *
      * @returns {boolean} Return true if sublist line is valid
      *
      * @since 2015.2
      */
     function validateInsert(scriptContext) {
 
     }
 
     /**
      * Validation function to be executed when record is deleted.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @param {string} scriptContext.sublistId - Sublist name
      *
      * @returns {boolean} Return true if sublist line is valid
      *
      * @since 2015.2
      */
     function validateDelete(scriptContext) {
 
     }
 
     /**
      * Validation function to be executed when record is saved.
      *
      * @param {Object} scriptContext
      * @param {Record} scriptContext.currentRecord - Current form record
      * @returns {boolean} Return true if record is valid
      *
      * @since 2015.2
      */
     function saveRecord(scriptContext) {
 
     }
 
     return {
         // pageInit: pageInit,
         fieldChanged: fieldChanged,
         postSourcing: postSourcing
         /*
         sublistChanged: sublistChanged,
         lineInit: lineInit,
         validateField: validateField,
         validateLine: validateLine,
         validateInsert: validateInsert,
         validateDelete: validateDelete,
         saveRecord: saveRecord
         */
     };
     
 });
 