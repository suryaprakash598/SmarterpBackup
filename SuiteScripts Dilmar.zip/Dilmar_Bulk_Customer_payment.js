/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/format', 'N/record','N/ui/dialog','N/runtime','N/render','N/file','N/task','N/search'],
/**
 * @param {format} format
 * @param {record} record
 */
function(format, record,dialog,runtime,render,file,task,search) {


   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(context) {
    	
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(context) {
    	if (context.type !== context.UserEventType.CREATE)
            return;
    	var newRecord = context.newRecord;
    	var custArray = [];
		var data=[];
    	var scriptObj = runtime.getCurrentScript();
		var folderid =scriptObj.getParameter({name: 'custscript_dil_tran_pdf_folder'}); 
       
    	var deposit_acct = newRecord.getValue({
    		fieldId: 'custrecord_dil_bulk_pay_deposit_to_acct'
    		})
    	var posting_period = newRecord.getValue({
    		fieldId: 'custrecord_dil_bulk_pay_posting_period'
    	})
    	
    	var payCount = newRecord.getLineCount({
			sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id'
		});
	  
		for (var i = 0; i < payCount; i++){
			
				
				var applied =  newRecord.getSublistValue({
					sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					fieldId: 'custrecord_dil_bulk_pay_apply_dtl',
					line: i
				});
				if (applied){
					var custid = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_cust_dtl',
						line: i
					});
				var custpos = custArray.indexOf(custid);
				if (custpos == -1){custArray.push(custid)};
				};
		}
		log.debug('array length',custArray.length);
		custArray.forEach(function(result){
			var total_payment =0;
			log.debug('customerid',result);
			var selected_custid = result;
			 var dataarray=[];	
			for (var j = 0; j < payCount; j++){
				 var tranData = new Object(); 
					
				var for_custid = newRecord.getSublistValue({
					sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					fieldId: 'custrecord_dil_bulk_pay_cust_dtl',
					line: j
				});
				var to_apply = newRecord.getSublistValue({
					sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					fieldId: 'custrecord_dil_bulk_pay_apply_dtl',
					line: j
				});
				if (for_custid == selected_custid && to_apply){
					
					var invid = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_refno_dtl',
						line: j
					});
					var paydt = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_paydt_dtl',
						line: j
					});
					var payamt = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_pymnt_amt_dtl',
						line: j
					});
					var pymntmethod = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_buik_pay_pymnt_method_dtl',
						line: j
					});
					var custemail = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_cust_email_dtl',
						line: j
					});
					total_payment = total_payment + payamt;
					tranData["invid"] = invid;
					tranData["paydt"] = format.parse({value:paydt, type: format.Type.DATE});
					tranData["payamt"]=payamt;
					tranData["total_pay"]=total_payment;
					tranData["pay_method"]=pymntmethod;
					tranData["emailaddress"]=custemail;
					dataarray.push(tranData);
					   log.debug('tran data array inv id',invid + pymntmethod);

				}
			}
			log.debug('dataarray length',dataarray.length);
			var obj={};
			obj.selected_custid=selected_custid;
			obj.deposit_acct=deposit_acct;
			obj.trandate=dataarray[0].paydt;
			obj.postingperiod=posting_period;
			obj.paymentmethod=dataarray[0].pay_method;
			obj.tranData=dataarray;
			data.push(obj);
			
			 

		})
			var filename=new Date();
			  var n = filename.toString();
			  n=n.split(' ').join('_');
			  n=n.split(':').join('_');
			  n=n.substring(0, 24);
			  n='Customer Payments '+ n +'.txt';
			var fileObj = file.create({
					name: n,  
					fileType: file.Type.PLAINTEXT,
					contents: JSON.stringify(data),
					description: 'This is a plain text file.',
					encoding: file.Encoding.UTF8,
					folder: 217197,
					isOnline: true
				});
				var fileId = fileObj.save();
				log.debug('file id', fileId);
      var is_script_running=isExecuting('customscript_dil_bulk_cust_payment_mr','customdeploy_dil_bulk_cust_payment_mr');
				if(!is_script_running){
					var mapreducetask = task.create({
					taskType: task.TaskType.MAP_REDUCE,
					scriptId: 'customscript_dil_bulk_cust_payment_mr',
					deploymentId: 'customdeploy_dil_bulk_cust_payment_mr',
				});
				var mrTaskId = mapreducetask.submit();
				log.debug('mrTaskId', mrTaskId);


				log.debug('finished', 'finished');
				}
					

				
				
    }
  function isExecuting(scriptId, deploymentId) {
const executingStatuses = ["PENDING","PROCESSING","RESTART","RETRY"];
return Boolean(search.create({
type: record.Type.SCHEDULED_SCRIPT_INSTANCE,
filters: [
["status", search.Operator.ANYOF, executingStatuses], "AND",
["script.scriptid", search.Operator.IS, scriptId] ,"AND",
["scriptDeployment.scriptid", search.Operator.ISNOT, deploymentId]
],
columns: ["script.internalid"]
}).runPaged().count);
}

    return {
        //beforeLoad: beforeLoad,
        //beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
    
});
