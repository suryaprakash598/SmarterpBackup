/*******************************************************************************{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType ScheduledScript
 *
 ******************************************************************************/
define(['N/runtime', 'N/task', 'N/record', 'N/search', 'N/log'], function (
        /** @type {import('N/runtime')} **/
        runtime,
        /** @type {import('N/task')}    **/
        task,
        /** @type {import('N/record')}  **/
        record,
        /** @type {import('N/search')}  **/
        search,
        /** @type {import('N/log')}     **/
        log) {

    /**
     * context.type
     *
     * @type {import('N/types').EntryPoints.Scheduled.execute}
     */
    function execute(context) {
        try {
            var scriptObj = runtime.getCurrentScript();
            //var _requestParams = scriptObj.getParameter({name: 'custscript1'})
            var notProcessedRecords = getNotProcessedRecords();

            for (var npr = 0; npr < notProcessedRecords.length; npr++) {
                try {

                    var nprId = notProcessedRecords[npr];
                    var nprObj = record.load({
                        type: 'customrecord_bizspeed_acknowledge',
                        id: nprId
                    });
                    var _requestParams = nprObj.getValue({
                        fieldId: 'custrecord_bizspeed_data'
                    });
					log.debug('_requestParams',JSON.stringify(_requestParams));
					_requestParams=JSON.parse(_requestParams)
                    var dataKeys = Object.keys(_requestParams);
                    if (dataKeys.length > 0) {
                        var bizspeedShipped = new Date();
                        for (var i = 0; i < _requestParams.length; i++) {
                            var ifId = _requestParams[i].orderNo;
                            log.debug('ifId',ifId);
                            //log.debug('ifId.substring(0, 2)',ifId.substring(0, 2));
                            if (ifId.substring(0, 2) == 'IF') {
                                try {
                                    var id = searchTransaction(ifId);
                                    log.debug('id', id);
                                    //log.debug('_requestParams[0].Details', _requestParams[i].Details);
                                    if (id) {
                                        var recObj = record.load({
                                            type: 'itemfulfillment',
                                            id: id
                                        }); //,isDynamic:!0
                                        recObj.setValue({
                                            fieldId: 'custbody_bizspeed_ship_date',
                                            value: bizspeedShipped,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'shipstatus',
                                            value: 'C',
                                            ignoreFieldChange: true
                                        });
										recObj.setValue({
                                            fieldId: 'custbody_qty_shipped_validated_bizspee',
                                            value: true,
                                            ignoreFieldChange: true
                                        });
										/* var rtd = _requestParams[i].Rtd;
										var parts =rtd.split('T')[0].split('-');
										// Please pay attention to the month (parts[1]); JavaScript counts months from 0:
										// January - 0, February - 1, etc.
										var a =Date.parse(parts)
										var mydate = (parts[1])+'/'+ parts[2]+'/'+parts[0]; 
										if(false){
											recObj.setValue({
                                            fieldId: 'trandate',
                                            value: mydate,
                                            ignoreFieldChange: true
                                        });
										} */
										
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_trip_code',
                                            value: _requestParams[i].tripCode,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_truckid',
                                            value: _requestParams[i].truckID,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_pod_url',
                                            value: _requestParams[i].pod_url,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_rtd',
                                            value: _requestParams[i].Rtd,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_rta',
                                            value: _requestParams[i].Rta,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_signed_by_name',
                                            value: _requestParams[i].signed_by_name,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_comments',
                                            value: _requestParams[i].customer_comments,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_po_reference',
                                            value: _requestParams[i].alternateOrdNumber,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_bizspeed_data_lt',
                                            value: JSON.stringify(_requestParams[i]),
                                            ignoreFieldChange: true
                                        });
                                        var lineDetails = _requestParams[i].Details;
                                        var lines = recObj.getLineCount({
                                            sublistId: 'item'
                                        });
                                        for (var ii = 0; ii < lines; ii++) {
                                            var itemName = recObj.getSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'itemname',
                                                line: ii
                                            });
                                            var line = recObj.getSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'line',
                                                line: ii
                                            });
											var _orderLine = recObj.getSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'orderline',
                                                line: ii
                                            });
											log.debug('_orderLine',_orderLine);
											var _temp_is_itemExists=false;
                                            for (var k = 0; k < lineDetails.length; k++) {
                                                var _biz_itemID = lineDetails[k].itemID;
												var _biz_itemDesc = lineDetails[k].itemDescription;
                                                var _biz_itemLine = lineDetails[k].lineNum;
                                                var _biz_itemDeliverQty = lineDetails[k].deliverQty;
                                                log.debug('condition',itemName+'=='+_biz_itemID+'=='+_biz_itemDesc+'=='+_orderLine+'=='+_biz_itemLine);
                                                if ((itemName == _biz_itemID|| itemName==_biz_itemDesc)&& _orderLine==_biz_itemLine) //comparing line with orderline instead of line
                                                {
                                                    //log.debug('_biz_itemDeliverQty', _biz_itemDeliverQty);
                                                    if (_biz_itemDeliverQty == 0) {
                                                        recObj.setSublistValue({
                                                            sublistId: 'item',
                                                            fieldId: 'itemreceive',
                                                            line: ii,
                                                            value: false
                                                        });
                                                    } else {
                                                        recObj.setSublistValue({
                                                            sublistId: 'item',
                                                            fieldId: 'quantity',
                                                            line: ii,
                                                            value: _biz_itemDeliverQty
                                                        });
                                                        var objSubRecord = recObj.getSublistSubrecord({
                                                            sublistId: 'item',
                                                            fieldId: 'inventorydetail',
                                                            line: ii
                                                        });
                                                        objSubRecord.setSublistValue({
                                                            sublistId: 'inventoryassignment',
                                                            fieldId: 'quantity',
                                                            value: _biz_itemDeliverQty,
                                                            line: 0
                                                        });
                                                    }
													_temp_is_itemExists=true;
                                                }else{
													//log.debug('error in finding item',id)
													//createErrorRecord(_requestParams[i],'error in finding item',id);
												}
                                            }
											if(!_temp_is_itemExists)
											{
												createErrorRecord(_requestParams[i],'error in finding item',id);
												break;
											}
                                        }
                                        recObj.save();

                                    }
                                } catch (e) {
                                    log.debug('error', e.toString());
									createErrorRecord(_requestParams[i],e.toString(),id);
                                }
                            } else if (ifId.substring(0, 2) == 'SP') {
                                try {

                                    var id = searchSPFTransaction(ifId);
                                    //log.debug('id',id);
                                    //log.debug('_requestParams[0].Details',_requestParams[0].Details);
                                    if (id) {
                                        var recObj = record.load({
                                            type: 'storepickupfulfillment',
                                            id: id
                                        }); //,isDynamic:!0
                                        recObj.setValue({
                                            fieldId: 'custbody_bizspeed_ship_date',
                                            value: bizspeedShipped,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'pickupstatus',
                                            value: 'B',
                                            ignoreFieldChange: true
                                        });
										/* var rtd = _requestParams[i].Rtd;
										var parts =rtd.split('T')[0].split('-');
										// Please pay attention to the month (parts[1]); JavaScript counts months from 0:
										// January - 0, February - 1, etc.
										var a =Date.parse(parts)
										var mydate = (parts[1])+'/'+ parts[2]+'/'+parts[0]; 
										if(false){
											recObj.setValue({
                                            fieldId: 'trandate',
                                            value: mydate,
                                            ignoreFieldChange: true
                                        });
										} */
										
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_trip_code',
                                            value: _requestParams[i].tripCode,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_truckid',
                                            value: _requestParams[i].truckID,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_pod_url',
                                            value: _requestParams[i].pod_url,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_rtd',
                                            value: _requestParams[i].Rtd,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_rta',
                                            value: _requestParams[i].Rta,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_signed_by_name',
                                            value: _requestParams[i].signed_by_name,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_comments',
                                            value: _requestParams[i].customer_comments,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_biz_po_reference',
                                            value: _requestParams[i].alternateOrdNumber,
                                            ignoreFieldChange: true
                                        });
                                        recObj.setValue({
                                            fieldId: 'custbody_bizspeed_data_lt',
                                            value: JSON.stringify(_requestParams[i]),
                                            ignoreFieldChange: true
                                        });
										
                                        var lineDetails = _requestParams[i].Details;
                                        var lines = recObj.getLineCount({
                                            sublistId: 'item'
                                        });
                                        for (var ii = 0; ii < lines; ii++) {
                                            var itemName = recObj.getSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'itemname',
                                                line: ii
                                            });
                                            var line = recObj.getSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'line',
                                                line: ii
                                            });
											var _orderLine = recObj.getSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'orderline',
                                                line: ii
                                            });
											log.debug('_orderLine',_orderLine);
                                            for (var k = 0; k < lineDetails.length; k++) {
                                                var _biz_itemID = lineDetails[k].itemID;
                                                var _biz_itemDesc = lineDetails[k].itemDescription;
                                                var _biz_itemLine = lineDetails[k].lineNum;
                                                var _biz_itemDeliverQty = lineDetails[k].deliverQty;
                                                if (itemName == _biz_itemID || itemName==_biz_itemDesc&& _orderLine==_biz_itemLine) //&& line==_biz_itemLine
                                                {
                                                    //log.debug(itemName+'=='+_biz_itemID,itemName==_biz_itemID);
                                                    log.debug('_biz_itemDeliverQty', _biz_itemDeliverQty);
                                                    if (_biz_itemDeliverQty == 0) {
                                                        recObj.setSublistValue({
                                                            sublistId: 'item',
                                                            fieldId: 'itemreceive',
                                                            line: ii,
                                                            value: false
                                                        });
                                                    } else {
                                                        recObj.setSublistValue({
                                                            sublistId: 'item',
                                                            fieldId: 'quantity',
                                                            line: ii,
                                                            value: _biz_itemDeliverQty
                                                        });
                                                        var objSubRecord = recObj.getSublistSubrecord({
                                                            sublistId: 'item',
                                                            fieldId: 'inventorydetail',
                                                            line: ii
                                                        });
                                                        objSubRecord.setSublistValue({
                                                            sublistId: 'inventoryassignment',
                                                            fieldId: 'quantity',
                                                            value: _biz_itemDeliverQty,
                                                            line: 0
                                                        });
                                                    }

                                                }else{
													log.debug('error in finding item',id)
													//createErrorRecord(_requestParams[i],'error in finding item',id);
												}
                                            }
                                        }
                                        recObj.save();

                                    }
                                } catch (e) {
                                    log.debug('Error in store fulfillment', e.toString());
									createErrorRecord(_requestParams[i],e.toString(),id);
                                }
                            }

                        }

                    }

                    nprObj.setValue({
                        fieldId: 'custrecord_is_processed',
                        value: true,
                        ignoreFieldChange: true
                    });
                    nprObj.save();
                } catch (e) {
                    log.debug('Error', e.toString());
					createErrorRecord('',e.toString(),'');
                }
            }
        } catch (e) {
            log.debug('Error in main', e.toString());
			createErrorRecord('',e.toString(),'');
        }
    }

    function getNotProcessedRecords() {
        try {
            var customrecord_bizspeed_acknowledgeSearchObj = search.create({
                type: "customrecord_bizspeed_acknowledge",
                filters: [
                    ["custrecord_is_processed", "is", "F"],
                    "AND",
                    ["custrecord_bizspeed_data", "isnotempty", ""]/* ,
					"AND",
					["internalid","is",2005] */
                ],
                columns: [
                    search.createColumn({
                        name: "custrecord_bizspeed_data",
                        label: "Bizspeed Data"
                    }),
                    search.createColumn({
                        name: "custrecord_is_processed",
                        label: "isProcessed?"
                    }),
                    search.createColumn({
                        name: "internalid",
                        label: "Internal ID"
                    })
                ]
            });
            var searchResultCount = customrecord_bizspeed_acknowledgeSearchObj.runPaged().count;
            log.debug("customrecord_bizspeed_acknowledgeSearchObj result count", searchResultCount);
            var customRecordId = [];
            customrecord_bizspeed_acknowledgeSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                customRecordId.push(result.getValue({
                        name: 'internalid'
                    }))
                return true;
            });
            return customRecordId;
        } catch (e) {
            log.debug('Error in getting files', e.toString());
        }
    }
	function searchTransaction(ordernumber) {
        try {
            var itemfulfillmentSearchObj = search.create({
                type: "itemfulfillment",
                filters:
                [
                    ["type", "anyof", "ItemShip"],
                    "AND",
                    ["numbertext", "is", ordernumber]

                ],
                columns:
                [
                    "internalid"
                ]
            });
            var searchResultCount = itemfulfillmentSearchObj.runPaged().count;
            log.debug("itemfulfillmentSearchObj result count", searchResultCount);
            var internalid = '';
            itemfulfillmentSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                internalid = result.getValue({
                    name: 'internalid'
                });
                return true;
            });
            return internalid;
        } catch (e) {
            log.debug('error in search Transaction', e.toString());
        }
    }
	function createErrorRecord(orderdata,reason,ordernumber)
	{
		try{
			var objRecord = record.create({type:'customrecord_bizspeed_error_handling'});
			objRecord.setValue({fieldId:'custrecord_biz_er_reason',value:reason,ignoreFieldChange:true});
			objRecord.setValue({fieldId:'custrecord_order_data',value:JSON.stringify(orderdata),ignoreFieldChange:true});
			if(ordernumber!=''){
			objRecord.setValue({fieldId:'custrecord_biz_er_ordernumber',value:ordernumber,ignoreFieldChange:true});
			}
			objRecord.save();
			
		}catch(e)
		{
			log.debug('error in createErrorRecord',e.toString());
		}
	}
	function searchSPFTransaction(ordernumber) {
        try {
            log.debug('ordernumber', ordernumber);
            var storepickupfulfillmentSearchObj = search.create({
                type: "storepickupfulfillment",
                filters:
                [
                    ["type", "anyof", "StPickUp"],
                    "AND",
                    ["numbertext", "is", ordernumber]
                ],
                columns:
                [
                    "internalid"
                ]
            });
            log.debug('storepickupfulfillmentSearchObj', storepickupfulfillmentSearchObj);
            var searchResultCount = storepickupfulfillmentSearchObj.runPaged().count;
            log.debug("storepickupfulfillmentSearchObj result count", searchResultCount);
            var internalid = '';
            storepickupfulfillmentSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                internalid = result.getValue({
                    name: 'internalid'
                });
                return true;
            });
            return internalid;
        } catch (e) {
            log.debug('Error in searchSPFTransaction', e.toString());
        }
    }
	
    return {
        'execute': execute
    };

});