/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 */
 define(['N/search', 'N/file', 'underscore','N/encode', 'N/record', 'N/email'],

 function (search, file, underscore, encode, record, email) {

 //Load saved search
 function execute(scriptContext) {
     var _odc = savedSearchODC();
	 log.debug('_odc',_odc);
     var _groupOdc = underscore.groupBy(_odc, 'docNumber');
	 log.debug('_groupOdc',_groupOdc);
     var controlObj = controlRecord();
     var TrailerObj = ''; //trailerRecord(); NO TRAILER IN ODC
     var keys = Object.keys(_groupOdc);
	 log.debug('keys',keys);
     var arr = [];
     for (var k = 0; k < keys.length; k++) {
         try {
             var csvFile = '';
              var data = _groupOdc[keys[k]];
             var headerObj = headerRecord(_groupOdc[keys[k]]);
             var lineObj = lineItemRecord(_groupOdc[keys[k]]);
             csvFile += controlObj + headerObj + lineObj + TrailerObj;

             //Creation of file
             var fileObj = file.create({
                 //To make each file unique and avoid overwriting, append date on the title
                 name: 'ODC_'+k+"_" + data[0].docNumber,
                 fileType: file.Type.CSV,
                 contents: csvFile,
                 description: 'File sent to shell from distributor to confirm delivery has been made',
                 encoding: file.Encoding.UTF8,
                 folder: 1567//1086
             });

             //Save the CSV file
             var fileId = fileObj.save()
                 //log.debug('File ID...', fileId)
             arr.push({
                 'fileId': fileId,
                 'docnumber': data[0].docNumber ,
                 'traninternalid': data[0].traninternalid 
             });


         } catch (e) {
             log.debug('Error in Main', e.toString());
         }
     }
     if (arr.length) {
         createCustomRecord(arr);
         //sendEmail(arr);
         updateFileGeneratedInfo(arr);
         
     }

 }
 function savedSearchODC() {
     try {
         var arr = [];
		 
         var invoiceSearchObj = search.create({
            type: "invoice",
            filters:
            [
               ["type","anyof","CustInvc"], 
               "AND", 
			  // ["internalid","anyof",invArr],
                  ["datecreated","within","today"],  
               "AND", 
               ["taxline","is","F"], 
               "AND", 
               ["cogs","is","F"], 
               "AND", 
               ["shipping","is","F"], 
               "AND", 
               ["mainline","is","F"], 
                 "AND", 
               ["customer.custentity_dil_customer_nation_yn","is","T"],  
                 "AND", 
               ["custbody_is_file_generated","is","F"],  
               "AND", 
               ["customer.custentity_dil_cust_buyback_vid","anyof","1"], 
               "AND", 
               ["item.type","noneof","OthCharge","Discount"]
            ],
            columns:
            [
               search.createColumn({name: "tranid", label: "Document Number"}),
               search.createColumn({name: "internalid", label: "Internalid"}),
               search.createColumn({name: "trandate", label: "Date"}),
               search.createColumn({name: "otherrefnum", label: "PO/Check Number"}),
               search.createColumn({name: "custbody_dil_so_shell_sales_order_num", label: "Shell Sales Order #"}),
               search.createColumn({name: "custbody_dil_so_ship_truck_no", label: "Ship Truck No."}),
               search.createColumn({name: "custbody_dil_so_order_delivery_date", label: "Delivery Date"}),
               search.createColumn({name: "createdfrom", label: "created from"}),
               search.createColumn({name: "quantity", label: "Quantity"}),
               search.createColumn({
                  name: "custentity_dil_cust_ext_ship_to",
                  join: "customer",
                  label: "Shell Ship To Number"
               }),
               search.createColumn({
                  name: "custentity_dil_cust_ext_sold_to",
                  join: "customer",
                  label: "Shell Sold To Number"
               }),
                 search.createColumn({name: "unit", label: "Units"}),
               search.createColumn({
                  name: "custrecord_dil_dist_ship_from_num",
                  join: "location" 
               }),
			   search.createColumn({
                  name: "custrecord_dil_loc_sh_shipping_point",
                  join: "location" 
               }),
               search.createColumn({
                  name: "custrecord_dil_plant_id",
                  join: "location" 
               }), search.createColumn({
                  name: "itemid",
                  join: "item"
               })
            ]
         });
         invoiceSearchObj.run().each(function(result){
            // .run().each has a limit of 4,000 results
            var obj ={};
            obj.docNumber = result.getValue({name:'tranid'});
            obj.traninternalid = result.getValue({name:'internalid'});
            obj.trandate = result.getValue({name:'trandate'});
            obj.otherrefnum = result.getValue({name:'otherrefnum'});
            obj.createdfrom = result.getText({name:'createdfrom'});
            obj.unit = result.getValue({name:'unit'});
            obj.quantity = result.getValue({name:'quantity'});
            obj.shellSoNumber = result.getValue({name:'custbody_dil_so_shell_sales_order_num'});
            obj.ship_truck_no = result.getValue({name:'custbody_dil_so_ship_truck_no'});
            obj.delivery_date = result.getValue({name:'custbody_dil_so_order_delivery_date'});
            obj.ship_to = result.getValue({name:'custentity_dil_cust_ext_ship_to', join: "customer"});
            obj.sold_to = result.getValue({name:'custentity_dil_cust_ext_sold_to',join: "customer"});
            obj.shipfromid = result.getValue({name:'custrecord_dil_dist_ship_from_num',join: "location"});
            obj.shipping_point = result.getValue({name:'custrecord_dil_loc_sh_shipping_point',join: "location"});
            obj.plantid = result.getValue({	 name: "custrecord_dil_plant_id",	 join: "location" 	  });
            obj.shellproductnumber = result.getValue({	 name: "itemid",	 join: "item" 	  });
            arr.push(obj);
            return true;
         });
         return arr;
     } catch (e) {
         log.debug('Error in savedSearchList', e.toString());
     }
 }
 function controlRecord() {
     var tempString = '';
	 //TagID,SenderID,SenderQualifer,ReceiverID,ReceiverQualifier,SenderInterchangeNo,MessageReferenceNo,MessageType,SMDVersion,TestFlag
     tempString += "CTL,11243268,,SOPUS,,,,ORDER_DELIVERY_CONFIRMATION,," + "\r\n";
     return tempString;
 }

 function trailerRecord() {
     var tempString = '';
     tempString += "TRL" + "\r\n";
     return tempString;
 }
 function headerRecord(data) {
     var tempString = '';
     if (data.length) {
         //TagID ,CustomerSoldToID ,CustomerShipToID ,DistributorShipFromID ,ShellSalesOrderNumber ,
		 //DistributorPONumber,DeliveryTicketNumber , DateDelivered ,PlantID ,ShippingPoint ,CustomerPONumber
		 var delivery_date='';
			if(data[0].delivery_date )
			{
				delivery_date = formatDate(data[0].delivery_date );
			}
			var createdfrom = '';
			if(data[0].createdfrom)
			{
				createdfrom = data[0].createdfrom.split('#')[1]
			}
			
         tempString += "HDR" + "," + 
						data[0].sold_to + "," +
						data[0].ship_to + "," +
						data[0].shipfromid + "," +
						data[0].shellSoNumber + "," +
						createdfrom + ","+
						data[0].docNumber +"," +
						// data[0].docNumber + "," + 
						delivery_date + ","+
						data[0].plantid + ","+ 
						data[0].shipping_point + "," +
						data[0].otherrefnum + "\r\n";
     }
     return tempString;
 }
 function lineItemRecord(data) {
     var tempString = '';
     var lineNumber = 0;
     var unitsObj = units();
     for (var i = 0; i < data.length; i++) {
         lineNumber = lineNumber + 10;
         var unitsshort = unitsObj[data[i].unit];
         //log.debug('unitsshort',unitsshort);
         //TagID , LineItemNumber , ShellProductNumber ,Quantity ,UnitOfMeasure ,GratisFlat , ValuationType ,HandlingType,SalesOrganisation, DistributionChannel
         tempString += "LIN" + "," + (lineNumber) + "," + data[i].shellproductnumber + "," + data[i].quantity +","+ unitsshort + ",N"+"\r\n";
     }
     return tempString;
 }
 function createCustomRecord(arr) {
     try {

         //redirect.toSuitelet({scriptId:1909,deploymentId:1,parameters:{'fileid':1}});
         log.debug('arr', arr);
         var customRecObj = record.create({
             type: 'customrecord_edi_odc_invoice',
             isDynamic: !0
         });
         var invoiceids = [];

         for (var i = 0; i < arr.length; i++) {
             invoiceids.push(arr[i].traninternalid);
         }
         log.debug('invoiceids',invoiceids);
         customRecObj.setValue({
             fieldId: 'custrecord_odc_document_number',
             value: invoiceids
         }); 
         var id = customRecObj.save();
         for (var i = 0; i < arr.length; i++) {
             record.attach({
                 record: {
                     type: 'file',
                     id: arr[i].fileId,
                 },
                 to: {
                     type: 'customrecord_edi_odc_invoice',
                     id: id
                 }
             })
         }
     } catch (e) {
         log.debug('error', e.toString());
     }

 }
 function sendEmail(arr) {
     try {
         var senderId = -5;
         log.debug('arr', arr);
         var recipientId = ['amber@dilmar.com'];
         var subject = 'EDI ODC Files';
         var body = 'Hi, EDI ODC processed files';
         body += '<table><tr><th>Document Number</th><th>File</th></tr>';
         for (var i = 0; i < arr.length; i++) {
             body += '<tr>';
             body += '<td>' + arr[i].docnumber + '</td><td>' + arr[i].fileId + '</td>';
             body += '</tr>';
         }
         body += '</table>';
         email.send({
             author: senderId,
             recipients: recipientId,
             /* cc: cclist,
             bcc: bcclist, */
             subject: subject,
             body: body
         });

     } catch (e) {
         log.debug('error', e.toString());
     }
 }
 function units() {
     var obj = {
         'Bulk': 'GAL',
         '1 Gal': 'GAL',
         'Carton': 'CT',
         'Case': 'CT',
         'Drum': 'EA',
         'Each': 'EA',
         'Ecobox': 'CT',
         'Keg': 'EA',
         'Pail': 'EA',
         'Tote': 'EA'
     };
     return obj;
 }
function updateFileGeneratedInfo(arr)
{
  try{
      for (var i = 0; i < arr.length; i++) {
             log.debug('arr inupdateFileGeneratedInfo ',arr[i])
			 var recobj = record.load({type:'invoice',id:arr[i].traninternalid,isDynamic:!0});
			 recobj.setValue({fieldId:'custbody_is_file_generated',value:true,ignoreFieldChange:true});
			  recobj.save();
         //record.submitFields({type:'invoice',id:arr[i].traninternalid,values:{custbody_is_file_generated:true},options:{enableSourcing:!1,ignoreMandatoryFields:!0}});
         }
  }catch(e)
  {
      log.debug('error',e.toString())
  }
}
function formatDate(date) {
	  
		 var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

		if (month.length < 2) 
			month = '0' + month;
		if (day.length < 2) 
			day = '0' + day;

		return [year, month, day].join('');
	 
    
}

 return {
     execute: execute
 };

});