/**
 *@NApiVersion 2.0
 *@NScriptType Suitelet
 */

/**
     * get the parameters
     *
     * @param {number} vid(vendor internalid) - vendor internal id
     * @param {date} start Date - MM/DD/YYYY
     * @param {date} end Date - MM/DD/YYYY
     */

define(['N/ui/serverWidget', 'N/redirect', 'N/runtime', 'N/record', 'N/ui/message', 'N/search', 'N/url', 'N/format','N/ui/dialog','N/task','N/file'],
    function (serverWidget, redirect, runtime, record, message, search, url,format,dialog,task,file) {

    function onRequest(context) {
      log.debug('testing');
      var type = context.request.method;
       var sdate=context.request.parameters.sdate;
      var edate=context.request.parameters.edate;
      var filterapplied=context.request.parameters.filter;
      log.debug('filterapplied',filterapplied);
        if (context.request.method === 'GET') {
        	try {
        		
                var form = serverWidget.createForm({
                    title: 'Payment Transfer'
                });
              
				// adding start date field
                var startDate = form.addField({
                    id: 'custpage_sdate',
                    type: serverWidget.FieldType.DATE,
                    label: 'Start Date',

                });
				//startDate.isMandatory = true;
                //adding end date field
                var endDate = form.addField({
                    id: 'custpage_edate',
                    type: serverWidget.FieldType.DATE,
                    label: 'End Date',

                });
				//endDate.isMandatory = true;


                 // Attaching client script for button actions
                form.clientScriptFileId =9044;

                form.addSubmitButton({
                    label: 'Submit'
                });
              form.addButton({
                    id: 'custpage_buttonid',
                    label: 'Search',
                    functionName: 'searching()'
                });
                form.addButton({
                    id: 'custpage_resetbutton',
                    label: 'Reset',
                    functionName: 'resetfun()'
                });
				
				
				
				if(filterapplied){
					startDate.defaultValue = sdate;
                endDate.defaultValue = edate;
                endDate.updateDisplayType({
                	 displayType : serverWidget.FieldDisplayType.DISABLED
                });
            	startDate.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.DISABLED
                });
            	
                }
              else{
                 var filterDate = new Date();
		 var fDate  = filterDate.getDate();
		 var fMonth  = filterDate.getMonth()+1;
		 var fYear  = filterDate.getFullYear();
		 var dateFilter  = fMonth+"/"+fDate+"/"+fYear;
              startDate.defaultValue = dateFilter;
                endDate.defaultValue = dateFilter;
                sdate=dateFilter;
                edate=dateFilter;
              }


                //adding Sublist

                var sublist = form.addSublist({
                    id: 'rebateprocess',
                    label: 'Payment Transfer',
                    type: serverWidget.SublistType.LIST
                });
               // sublist.addMarkAllButtons();
                var columns = DAO_sublistFields();

               
                for (var i = 0; i < columns.length; i++) {
                    //log.debug(columns[i].id,'id');
                    //log.debug(columns[i].type,'type');

                    if (columns[i].type == 'checkbox') {
                        var sublistField = sublist.addField({
                            id: columns[i].id,
                            label: columns[i].label,
                            type: serverWidget.FieldType.CHECKBOX,
                            source: columns[i].source
                        });
                    } else {
                        var sublistField = sublist.addField({
                            id: columns[i].id,
                            label: columns[i].label,
                            type: serverWidget.FieldType.TEXT,
                            source: columns[i].source
                        });
						if(columns[i].id=='_subsidiary'||columns[i].id=='_amount_credit'||columns[i].id=='_amount_debit'||columns[i].id=='_period'||columns[i].id=='_status'||columns[i].id=='_internalid'||columns[i].id=='_nameid'||columns[i].id=='_customerid'){
							sublistField.updateDisplayType({
                            displayType: serverWidget.FieldDisplayType.HIDDEN
                        });
						}
                    }
                   
                }
                var counter = 0;
                var invoiceSearchObj = searchData(sdate, edate);
			var results = invoiceSearchObj.run();
    var searchResults = [];
    var searchid = 0;
    do {
        var resultslice = results.getRange({start:searchid,end:searchid+1000});
        resultslice.forEach(function(slice) {
            searchResults.push(slice);
            searchid++;
            }
        );
    } while (resultslice.length >=1000);
 searchResults.forEach(function(result) {
				try{
					
				
                    var valueObj = resultVaues(result);
					//log.debug('object',valueObj);

                    sublist.setSublistValue({
                        id: '_date',
                        line: counter,
                        value: valueObj.date ||' '
                    });
                    sublist.setSublistValue({
                        id: '_period',
                        line: counter,
                        value: valueObj.period || ' '
                    });
                    sublist.setSublistValue({
                        id: '_type',
                        line: counter,
                        value: valueObj.type|| ' '
                    });

                    sublist.setSublistValue({
                        id: '_doc_number',
                        line: counter,
                        value: valueObj.docnumber ||' '
                    });
                    sublist.setSublistValue({
                        id: '_name',
                        line: counter,
                        value: valueObj.customer ||' '
                    });
                    sublist.setSublistValue({
                        id: '_account',
                        line: counter,
                        value: valueObj.account ||' '
                    });
					if(valueObj.shell_invoice_number){
                     sublist.setSublistValue({
                        id: '_shell_invoice_number',
                        line: counter,
                        value: valueObj.shell_invoice_number || ''
                    });
					}
					if(valueObj.type=='Bill'){
					if(valueObj.amountremaining)
					{
                    sublist.setSublistValue({
                        id: '_amount_remaining',
                        line: counter,
                        // if it is credit memo append '-' before rebate rate else add rebate rate
                        value:  - (valueObj.amountremaining) || ''
                    });	
					}
					}
					else{
					if(valueObj.amountremaining){
                    sublist.setSublistValue({
                        id: '_amount_remaining',
                        line: counter,               
                        value: valueObj.amountremaining ||''
                    });
					}
					}
					
					
					
                    sublist.setSublistValue({
                        id: '_status',
                        line: counter,
                        value: valueObj.statusref ||' '
                    });
					if(valueObj.creditamount){
                    sublist.setSublistValue({
                        id: '_amount_credit',
                        line: counter,
                        value: valueObj.creditamount || ''
                    });
					}
					if(valueObj.debitamount)
					{
                    sublist.setSublistValue({
                        id: '_amount_debit',
                        line: counter,
                        value: valueObj.debitamount || ''
                    });
					}
					if(valueObj.subsidiary)
					{
                    sublist.setSublistValue({
                        id: '_subsidiary',
                        line: counter,
                        value: valueObj.subsidiary || ''
                    });
					}
					sublist.setSublistValue({
                        id: '_internalid',
                        line: counter,
                        value: valueObj.internalid|| ''
                    });
					sublist.setSublistValue({
                        id: '_nameid',
                        line: counter,
                        value: valueObj.nameid|| ''
                    });
					sublist.setSublistValue({
                        id: '_customerid',
                        line: counter,
                        value: valueObj.customerid|| ''
                    });
					
                    counter++;
                  if(counter==4000){ 
                    return false;}
					
                    return true;
				}catch(e)
					{
						log.debug('Error in search Running',e.toString())
					}
                });

                context.response.writePage(form);

            } catch (e) {
                log.debug('error', e.toString())
            }
        }
        
      else  {
            log.debug('else block');
              var delimiter = /\u0002/;
              var delimiter1 = /\u0001/;
              var sublistData = context.request.parameters.rebateprocessdata.split(delimiter);
              var arrIndex = {
                  "Mark": 0,
                  "Date": 1,
                  "Period": 2,
                  "Type": 3,
                  "DocumentNumber": 4,
                  "Customer": 5,
                  "Account": 6,
                  "Memo": 7,
                  "AmountRemaining": 8,
                  "Status": 9,
                  "CreditAmount": 10,
                  "DebitAmount": 11,
				  "Subsidiary": 12,
				  "Internalid": 13,
                  "CustomerID": 14,

              };
             

              //log.debug('sublistData', sublistData);
              var mainArray = [];
              for (var i = 0; i < sublistData.length; i++) {
                  mainArray.push(sublistData[i].split(delimiter1));
              }
              var dataSource = mainArray.filter(function (data) {
                  if (data[0] == "F") {
                      return false; // skip
                  }
                  return true;
              }).map(function (data) {
                  var obj = {};
                  obj.date = data[arrIndex.Date]
                      obj.period = data[arrIndex.Period]
                      obj.type = data[arrIndex.Type]
                      obj.docnumber = data[arrIndex.DocumentNumber]
                      obj.customer = data[arrIndex.Customer]
                      obj.account = data[arrIndex.Account]
                      obj.memo = data[arrIndex.Memo]
                      obj.amountremaining = data[arrIndex.AmountRemaining]
                      obj.status = data[arrIndex.Status]
                      obj.creditamount = data[arrIndex.CreditAmount]
                      obj.debitamount = data[arrIndex.DebitAmount]
					  obj.subsidiary = data[arrIndex.Subsidiary]
					  obj.internalid = data[arrIndex.Internalid]
					  obj.customerid = data[arrIndex.CustomerID]
                      
                      return obj;
              });

              var groupResult = dataSource.reduce(function (r, a) {
                  r[a.account] = r[a.account] || [];
                  r[a.account].push(a);
                  return r;
              }, Object.create(null));
              log.debug('groupResult', groupResult);
              var keys = Object.keys(groupResult);
              log.debug('keys', keys);
			  var filename=new Date();
			  var n = filename.toString();
			  n=n.split(' ').join('_');
			  n=n.split(':').join('_');
			  n=n.substring(0, 24);

			   var fileObj = file.create({
								name: n,
								fileType: file.Type.PLAINTEXT,
								contents: JSON.stringify(groupResult),
								description: 'This is a plain text file.',
								encoding: file.Encoding.UTF8,
								folder: 1251,
								isOnline: true
							});
					var fileId = fileObj.save();
					log.debug('file id',fileId);
            	  var scheduletask = task.create({
         			 taskType: task.TaskType.SCHEDULED_SCRIPT,
         			 scriptId: 'customscript_dilmar_ap_ar_netting',
         			 deploymentId: 'customdeploy_dilmar_ap_ar_netting',
         			});
                  scheduletask.params = {custscript_file_id: fileId };
                  var mrTaskId = scheduletask.submit();
          		log.debug('mrTaskId',mrTaskId);
                 
              
              log.debug('finished','finished');
              redirect.redirect({
            	  url:'https://4622785.app.netsuite.com/app/common/scripting/scriptstatus.nl?sortcol=dcreated&sortdir=DESC&date=TODAY&scripttype=2895&primarykey=4587'
            	 });

			  
           }
		   
    }
    
    // Custom functions
    function checkNullRequired(value) {
    	var returnObj = true;
    	if (value == null || value == 'NaN' || value == undefined || value.toString().trim() == '' ) {
    		returnObj = false;
    	}
    	return returnObj;
    }
    
    function resultVaues(result) {
        var obj = {};
		//log.debug('result',result)
        obj.id = result.id;
        obj.date = result.getValue({
            name: "trandate"
            
        })
            obj.period = result.getText({
            name: "postingperiod"
        }) || 1,
        obj.type = result.getText({
            name: "type"
        }),
            obj.docnumber = result.getValue({
            name: "tranid"
        }),
        obj.customer = result.getText({
            name: "entity"
        }),
        obj.account = result.getText({
            name: "account"
        }),
         obj.shell_invoice_number = result.getValue({
            name: "custbody_shell_invoice_number"
        }),
        obj.amountremaining = result.getValue({
            name: "amountremaining"
        }),
        obj.statusref = result.getText({
            name: "statusref"
        }),
        obj.creditamount = result.getValue({
            name: "creditamount"
        }),
        obj.debitamount = result.getValue({
            name: "debitamount"
        }),
        obj.subsidiary = result.getValue({
            name: "subsidiary"
        }),
        obj.internalid = result.getValue({
            name: "internalid"
        }),
        obj.nameid = result.getValue({
            name: "entity"
        }),
		obj.customerid = result.getValue({
            name: "entity"
        })
            return obj;
    }
    
    function searchData(sdate, edate) {
      var filter=[["type","anyof","VendBill","CustInvc"],
                  "AND",
	  ["accounttype","anyof","AcctPay","AcctRec"], 
      "AND", 
      ["posting","is","T"], 
      "AND", 
      ["amountremainingisabovezero","is","T"], 
      "AND", 
      [["custbody_dil_so_buyback_vendor","anyof","1"],"OR",["name","anyof","34703"]], 
      "AND", 
      ["mainline","is","T"]
   ];
   if(sdate&&edate)
           {
            filter.push('AND'); 
            filter.push(["trandate","within",sdate,edate]); 
           }
    var transactionSearchObj = search.create({
   type: "transaction",
   filters:filter,
   columns:
   [
      search.createColumn({
         name: "trandate",
         label: "Date"
      }),
      search.createColumn({name: "postingperiod", label: "Period"}),
      search.createColumn({name: "type", label: "Type"}),
      search.createColumn({name: "tranid", label: "Document Number"}),
	  search.createColumn({name: "custbody_shell_invoice_number", label: "Shell Invoice Number"}),
      search.createColumn({
         name: "entity",
         sort: search.Sort.ASC,
         label: "Name"
      }),
      search.createColumn({name: "account", label: "Account"}),
      //search.createColumn({name: "memo", label: "Memo"}),
      search.createColumn({name: "amountremaining", label: "Amount Remaining"}),
      search.createColumn({name: "statusref", label: "Status"}),
      search.createColumn({name: "creditamount", label: "Amount (Credit)"}),
      search.createColumn({name: "debitamount", label: "Amount (Debit)"}),
	  search.createColumn({name: "subsidiary", label: "Subsidiary"}),
	  search.createColumn({name: "internalid", label: "InternalId"})
   ]
});
var searchResultCount = transactionSearchObj.runPaged().count;
log.debug("transactionSearchObj result count",searchResultCount);

        return transactionSearchObj;
    }
    
    function DAO_sublistFields() {
        var columns = [
            {
                id: '_mark',
                label: 'MARK',
                type: 'checkbox'
            }, {
                id: '_date',
                label: 'DATE',
                type: 'DATE',
                source: ''
            }, {
                id: '_period',
                label: 'PERIOD',
                type: 'TEXT',
                source: ''
            }, {
                id: '_type',
                label: 'Type',
                type: 'TEXT',
                source: ''
            }, {
                id: '_doc_number',
                label: 'DOCUMENT NUMBER',
                type: 'TEXT',
                source: ''
            }, {
                id: '_name',
                label: 'NAME',
                type: 'TEXT',
                source: ''
            }, {
                id: '_account',
                label: 'ACCOUNT',
                type: 'TEXT',
                source: ''
            }, {
                id: '_shell_invoice_number',
                label: 'Shell INV #',
                type: 'TEXT',
                source: ''
            }, {
                id: '_amount_remaining',
                label: 'AMOUNT REMAINING',
                type: 'TEXT',
                source: ''
            }, {
                id: '_status',
                label: 'STATUS',
                type: 'TEXT',
                source: ''
            }, {
                id: '_amount_credit',
                label: 'AMOUNT CREDIT',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_amount_debit',
                label: 'AMOUNT DEBIT',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_subsidiary',
                label: 'SUBSIDIARY',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_internalid',
                label: 'InternalId',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_nameid',
                label: 'InternalId',
                type: 'TEXT',
                source: ''
            },
            {
                id: '_customerid',
                label: 'customer Id',
                type: 'TEXT',
                source: ''
            }
            
            ];
        return columns;
    }
    
    return {
        onRequest: onRequest
    };
});
