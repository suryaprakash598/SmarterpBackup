	/**
	   
	 */
	define(['N/sftp','N/error','N/file'],
		function (sftp,error,file) {
		function executeSFTP(context) { 
			var connection;
			
				//Estblish a connection between NS and SFTP
			var myPwdGuid = "19f3a94de7494e8a8462581f35757954";
			var myHostKey = "AAAAB3NzaC1yc2EAAAADAQABAAAAgQDCh9qdcv1i9Y6nDwpspLaW1OosdrrtOl0t7uiof2/QYs0RTmT1DVRz0D0SNweNjtB/5069pFaNMthEh591gNrnipxy2FA2Zz7x5fv0v/AbTjmTujK14GYDBvMQTA58jGf1NWRn0+CkJvhCqY4eylkYgXdn4Y5QgGQYoEvN9P6zdQ==";
			try {
				connection = sftp.createConnection({
					username: 'dilmar',
					passwordGuid: myPwdGuid, // references var myPwdGuid
					url: 'dstftp2.dstinc.com',
					directory: '',
					hostKey: myHostKey // references var myHostKey
				});
				log.debug('connection',connection)
				/* var csvFile = file.load({id:140648});
				connection.upload({
					directory: '/',
					filename: 'testInv.txt',
					file: csvFile,
					replaceExisting: false
					});  */
			} catch (e) {
				//incase any error in creating connection
				log.debug('creating connection', e.toString());
				return false;
			}
			
		 return connection;
	}
		return {
		"executeSFTP": executeSFTP
			};
		});