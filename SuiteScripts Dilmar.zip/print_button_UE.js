/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord','N/url','N/record','N/search','N/ui/serverWidget'],
/**
 * @param {currentRecord} currentRecord
 */
function(currentrecord,url,record,search,serverWidget) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) { 
    	if (scriptContext.type == 'view')
    	{ 
    	 var record1 = scriptContext.newRecord;
    	 log.debug('',record1);
         var recId  = record1.getValue({
             fieldId: 'id'
         });
        
    	var scripturl  = url.resolveScript({scriptId:'customscript_print_pickup_pdf',
       	 deploymentId: 'customdeploy_print_pickup_pdf'});
      var createPdfUrl =scripturl+ '&id=' + recId;
     
 
        scriptContext.form.addButton({
            id: "custpage_mybutton",
            label: "Print SPC",
            functionName: "window.open('" + createPdfUrl + "');"
        });
        }
        
    	}	

    
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {

    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit,
       
    };
    
});