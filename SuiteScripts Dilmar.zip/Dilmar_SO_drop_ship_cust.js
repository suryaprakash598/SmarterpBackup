/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
 
define(['N/runtime', 'N/record', 'N/search', 'N/log'], function (runtime,record,search,log) {

    /**
     * context.newRecord
     * context.oldRecord
     * context.type
     *
     * @type {import('N/types').EntryPoints.UserEvent.afterSubmit}
     */
     function beforeSubmit(scriptContext) {	
           var recObj = scriptContext.newRecord; //create mode
		
            var customer=recObj.getValue({fieldId:'entity'});
			if(customer){
			var fields = search.lookupFields({
            type: 'customer',
            id: customer,
            columns: ['custentity_drop_ship_customer','custentity_preferred_vendor']
        });
        
        var Drop_ship_Cust;
        try{
        Drop_ship_Cust = fields.custentity_drop_ship_customer;
        }
        catch(e){
        	log.debug('not a Drop Ship Customer');
			
			  }
			  log.debug('Drop_ship_Cust',Drop_ship_Cust)
		if(!Drop_ship_Cust)	{
			/* var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
			  for (var i = 0; i < lineCount; i++) {
				  var obj={};
				var l=recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'povendor',
						  line: i,
						  value:null
						});
						log.debug('povendor',l)
				var m=recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'createpo',
						  line: i,
						  value:null
						});		
						log.debug('povendor',m)
		}  
			  
        	return; */
        }
      
      
      else{
			var Drop_ship_vendor;
        try{
        Drop_ship_vendor = fields.custentity_preferred_vendor;
        }
        catch(e){
        	log.debug('not a Drop Ship Customer');
			
			  }
        log.debug('Drop_ship_vendor',Drop_ship_vendor)
		var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
			  for (var i = 0; i < lineCount; i++) {
				  var obj={};
				var l=recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'povendor',
						  line: i,
						  value:Drop_ship_vendor[0].value
						});
				var po =recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'createpo',
						  line: i,
						  value:'DropShip'
						});
						log.debug('po',po);
						var item =recObj.getSublistValue({
						  sublistId: 'item',
						  fieldId: 'item',
						  line: i
						});
                var item_code = recObj.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_dil_item_code',
                        line: i 
                    });
				//search for price level 1
					try{
						var level;
						
					if(Drop_ship_vendor[0].value==35628){
						//Southern Lube & Fuels
						var custid=3365;
					 	level=get_pricelevel(custid,item_code)
						
					}
					else if(Drop_ship_vendor[0].value==35627) {
						//SOC Energy, Inc.
						var custid=3332;
					 	level=get_pricelevel(custid,item_code)
						
					}
					else if(Drop_ship_vendor[0].value==34651){
						var custid=613;
					 	level=get_pricelevel(custid,item_code)
					}
					else{
						level=[{"value":"1","text":"Level 1"}]
					}
					log.debug('level',level);
					//if price level empty then take level 1 price
					if(!level){
						level=[{"value":"1","text":"Level 1"}]
					}
                      var price_level1;
                      if(!level.price){
                    var itemSearchObj = search.create({
                        type: "item",
                        filters: [
                            ["pricing.pricelevel", "anyof", level[0].value],
                            "AND",
                            ["internalid", "anyof", item]
                        ],
                        columns: [
                           
                            search.createColumn({
                                name: "unitprice",
                                join: "pricing",
                                label: "Unit Price"
                            })
                        ]
                    });
                    var searchResultCount = itemSearchObj.runPaged().count;
                    log.debug("itemSearchObj result count", searchResultCount);
                    itemSearchObj.run().each(function(result){
						// .run().each has a limit of 4,000 results
						price_level1 = result.getValue({
            name: "unitprice",
            join: "pricing",
            
        }) 
						return true;
					});
                      }
                     else{
					price_level1=level.price;	
					} 
                    log.debug('price_level1', price_level1)
                    var porate = recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'porate',
						  line: i,
                        value: price_level1,
                    });
					
					}
					catch (e) {
                log.debug('error', e.toString())
            }		
			  }
		// updating dropship order check box if we createing dropship
				
				var dropship_flag = recObj.setValue({
					fieldId: 'custbody_drop_ship_order',
					value: true
				});	
		}
            }      
			
    }
	function get_pricelevel(custid,item_code){
			var level;
			var customerSearchObj = search.create({
   type: "customer",
   filters:
   [
      ["internalid","anyof",custid]
   ],
   columns:
   [
      search.createColumn({name: "itempricinglevel", label: "Item Pricing Level"}),
      search.createColumn({name: "itempricingunitprice", label: "Item Pricing Unit Price"}),
      search.createColumn({name: "pricingitem", label: "Pricing Item"})
   ]
});
var searchResultCount = customerSearchObj.runPaged().count;
log.debug("customerSearchObj result count",searchResultCount);
customerSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var customer_item= result.getValue({
            name: "pricingitem"
        })
  log.debug('customer_item',customer_item);
  if(customer_item==item_code){
	  var item_price= result.getValue({
            name: "itempricingunitprice"
        });
		level={"price":item_price};
		return true;
  }
   return true;
});
			
	if(level){
		return level;
	}		
			var fields = search.lookupFields({
                    type: 'customer',
                    id: custid,
                    columns: ['pricelevel']
                });

                try {
                    level = fields.pricelevel;
                } catch (e) {
                    log.debug('price level is not there');
					level=1;

                }
				return level;				
		}

    return {
        'beforeSubmit': beforeSubmit
    };

});