/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record', 'N/runtime', 'N/https', 'N/url'],
    function (record, runtime, https, url) {
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    // Search for the contacts associated with Customers and Vendors
    function findEmailList(entity) {
        var contactSearchObj = search.create({
            type: "contact",
            filters:
            [
                ["isinactive", "is", "F"],
                "AND",
                ["email", "isnotempty", ""],
                "AND",
                ["company.internalid", "anyof", entity],
                "AND",
                ["custentity_dil_contact_inv_notify", "is", "T"]
            ],
            columns:
            [
                search.createColumn({
                    name: "email"
                })

            ]
        });
        var emails = [];
        var curr_emailaddress,
        all_emailaddresses;
        contactSearchObj.run().each(function (result) {
            if (emails.length <= 10) {
                curr_emailaddress = result.getValue("email");
                var existing_email = emails.indexOf(curr_emailaddress);
                if (existing_email == -1) {
                    all_emailaddresses = all_emailaddresses + curr_emailaddress + ";";
                    if (all_emailaddresses.length <= 254) {
                        emails.push(result.getValue("email"));
                    }
                }
            }
            return true;
        });
        return emails;
    }

    function afterSubmit(context) {
        var fulfillrecord = context.newRecord;
        var scriptObj = runtime.getCurrentScript();
        var scriptDep = scriptObj.deploymentId;
        var ship_status = '',
        pickup_status = '',
        truck_no = '',
        received_by = '',
        received_dt = '',
        ship_dt = '';
        var invoiceid;
        //  var oldrecord = context.oldRecord;
        // var old_ship_status = oldrecord.getValue('shipstatus'); //by surya
        // log.debug('old ship status',old_ship_status);
        truck_no = fulfillrecord.getValue('custbody_biz_truckid');
        received_dt = fulfillrecord.getValue('custbody_biz_rtd');
        received_by = fulfillrecord.getValue('custbody_biz_signed_by_name');
        ship_dt = fulfillrecord.getValue('custbody_bizspeed_ship_date');
        sales_orderid = fulfillrecord.getValue('createdfrom');
		
		//Surya 08/11/2021 : PO field from item fullfilment to invoice 
		var _po = fulfillrecord.getValue('custbody_po_reference');
		var _biz_po = fulfillrecord.getValue('custbody_biz_po_reference');
		
        if (scriptDep == 'customdeploy_dil_ord_ful_inv_gen')
            ship_status = fulfillrecord.getValue('shipstatus');

        if (scriptDep == 'customdeploy_dil_store_ful_inv_gen')
            pickup_status = fulfillrecord.getValue('pickupstatus');

        // log.debug('before invoice generation:',scriptDep+' shipdt '+ ship_dt + ' received by '+received_by+' SOID '+sales_orderid+' Truck '+truck_no +' ShipStatus '+ship_status+' pickupstatus '+pickup_status+' '+runtime.executionContext);

        if (runtime.executionContext == runtime.ContextType.RESTLET || runtime.executionContext == runtime.ContextType.SCHEDULED) {
            log.debug('coming into the context', runtime.executionContext);
            //&& ship_dt.length > 0;
            if ((ship_status == 'C' || pickup_status == 'B') && received_dt.length > 0) {
                // log.debug('inside details:',runtime.executionContext+' '+ship_dt + ' '+received_by+' '+sales_orderid+' '+truck_no +' '+ship_status);
                try {
                    var invoicerec = record.transform({
                        fromType: 'salesorder',
                        fromId: sales_orderid,
                        toType: 'invoice',
                        isDynamic: true
                    });
					var _po_reference = _po?_po:_biz_po;
					log.debug('_po_reference',_po_reference);
                    invoicerec.setValue({
                        fieldId: 'otherrefnum',
                        value: _po_reference,
                        ignoreFieldChange: true
                    });
					
					invoicerec.setValue({
                        fieldId: 'custbody_bizspeed_ship_date',
                        value: ship_dt,
                        ignoreFieldChange: true
                    });

                    invoicerec.setValue({
                        fieldId: 'custbody_dil_inv_received_date',
                        value: received_dt,
                        ignoreFieldChange: true
                    });
                    invoicerec.setValue({
                        fieldId: 'custbody_dil_inv_received_by',
                        value: received_by,
                        ignoreFieldChange: true
                    });
                    invoicerec.setValue({
                        fieldId: 'custbody_is_sent_to_shell',
                        value: false,
                        ignoreFieldChange: true
                    });
                    invoicerec.setValue({
                        fieldId: 'custbody_is_file_generated',
                        value: false,
                        ignoreFieldChange: true
                    });
                    invoicerec.setValue({
                        fieldId: 'custbody_dil_so_ship_truck_no',
                        value: truck_no,
                        ignoreFieldChange: true
                    });
                    //	log.debug('details:',ship_dt + ' '+received_by+' '+received_dt+' '+truck_no);
                    // Submit the record
                    invoiceid = invoicerec.save();
                    // log.debug('Saved Record', invoiceid);
                    try {
                        if (invoiceid > 0) {
                            var suiteletURL = url.resolveScript({
                                scriptId: 'customscript_dil_inv_save_ue_suitelet',
                                deploymentId: 'customdeploy_dil_inv_save_ue_suitelet_dl',
                                returnExternalUrl: true
                            });
                            var param_values = {
                                'recordId': invoiceid,
                                'truckno': truck_no,
                                'ifid': fulfillrecord.id
                            };

                            log.debug('suitelet url and parameters ', suiteletURL + ' ' + param_values);
                            var response = https.post({
                                url: suiteletURL,
                                body: param_values
                            });
                            var responsebody = JSON.stringify(response.body);
                            log.debug('responsebody', responsebody);
                        }
                    } catch (e) {
                        log.error('error resolving suitelet', e.toString());
                    };

                } catch (e) {
                    log.error('invalid operation', e.toString());
                }

            }
        }
    }
    return {
        afterSubmit: afterSubmit,
    };
});