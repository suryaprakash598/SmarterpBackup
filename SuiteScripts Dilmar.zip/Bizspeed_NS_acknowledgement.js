/*******************************************************************************{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType Restlet
 *
Owner				Date			Modifications
Surya				05/10/2021		Added Comments and RTA fields to NetSuite

 ******************************************************************************/

define(['N/runtime', 'N/task', 'N/record', 'N/search', 'N/log'], function (
        /** @type {import('N/runtime')} **/
        runtime,
        /** @type {import('N/task')}    **/
        task,
        /** @type {import('N/record')}  **/
        record,
        /** @type {import('N/search')}  **/
        search,
        /** @type {import('N/log')}     **/
        log) {

    /**
     * @type {import('N/types').EntryPoints.RESTlet.delete_}
     */
    function onDelete(requestParams) {
        // return string or object data
        return '1';
    }

    /**
     * @type {import('N/types').EntryPoints.RESTlet.get}
     */
    function onGet(requestParams) {
        // return string or object data
        return '1';
    }

    /**
     * @type {import('N/types').EntryPoints.RESTlet.post}
     */
    function onPost(requestParams) {
        // return string or object data
        try {
            //READ PARAMETERS
            var _requestParams = requestParams;
            log.debug('_requestParams', _requestParams);
            var dataKeys = Object.keys(_requestParams);
            try {
                var _requestParams = requestParams;
                var objRecord = record.create({
                    type: 'customrecord_bizspeed_acknowledge',
                    isDynamic: !0
                });
                objRecord.setValue({
                    fieldId: 'custrecord_bizspeed_data',
                    value: JSON.stringify(_requestParams),
                    ignoreFieldChange: true
                });
                var id = objRecord.save();
                return 'OK';
            } catch (e) {
                log.debug('Error', e.toString());
                return 'Error'+e.toString();
            }

            if (dataKeys.length > 0) {
                var bizspeedShipped = new Date();
                for (var i = 0; i < _requestParams.length; i++) {
                    var ifId = _requestParams[i].orderNo;
                    //log.debug('ifId',ifId);
                    //log.debug('ifId.substring(0, 2)',ifId.substring(0, 2));
                    if (ifId.substring(0, 2) == 'IF') {
                        var id = searchTransaction(ifId);
                        log.debug('id', id);
                        log.debug('_requestParams[0].Details', _requestParams[i].Details);
                        if (id) {
                            try {

                                var recObj = record.load({
                                    type: 'itemfulfillment',
                                    id: id
                                }); //,isDynamic:!0
                                recObj.setValue({
                                    fieldId: 'custbody_bizspeed_ship_date',
                                    value: bizspeedShipped,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'shipstatus',
                                    value: 'C',
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_trip_code',
                                    value: _requestParams[i].tripCode,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_truckid',
                                    value: _requestParams[i].truckID,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_pod_url',
                                    value: _requestParams[i].pod_url,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_rtd',
                                    value: _requestParams[i].Rtd,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_rta',
                                    value: _requestParams[i].Rta,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_signed_by_name',
                                    value: _requestParams[i].signed_by_name,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_comments',
                                    value: _requestParams[i].customer_comments,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_biz_po_reference',
                                    value: _requestParams[i].alternateOrdNumber,
                                    ignoreFieldChange: true
                                });
                                recObj.setValue({
                                    fieldId: 'custbody_bizspeed_data',
                                    value: _requestParams[i],
                                    ignoreFieldChange: true
                                });
                                var lineDetails = _requestParams[i].Details;
                                var lines = recObj.getLineCount({
                                    sublistId: 'item'
                                });
                                for (var ii = 0; ii < lines; ii++) {
                                    var itemName = recObj.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'itemname',
                                        line: ii
                                    });
                                    var line = recObj.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'line',
                                        line: ii
                                    });
                                    for (var k = 0; k < lineDetails.length; k++) {
                                        var _biz_itemID = lineDetails[k].itemID;
                                        var _biz_itemLine = lineDetails[k].lineNum;
                                        var _biz_itemDeliverQty = lineDetails[k].deliverQty;
                                        if (itemName == _biz_itemID) //&& line==_biz_itemLine
                                        {
                                            //log.debug(itemName+'=='+_biz_itemID,itemName==_biz_itemID);
                                            log.debug('_biz_itemDeliverQty', _biz_itemDeliverQty);
                                            if (_biz_itemDeliverQty == 0) {
                                                recObj.setSublistValue({
                                                    sublistId: 'item',
                                                    fieldId: 'itemreceive',
                                                    line: ii,
                                                    value: false
                                                });
                                            } else {
                                                recObj.setSublistValue({
                                                    sublistId: 'item',
                                                    fieldId: 'quantity',
                                                    line: ii,
                                                    value: _biz_itemDeliverQty
                                                });
                                                var objSubRecord = recObj.getSublistSubrecord({
                                                    sublistId: 'item',
                                                    fieldId: 'inventorydetail',
                                                    line: ii
                                                });
                                                objSubRecord.setSublistValue({
                                                    sublistId: 'inventoryassignment',
                                                    fieldId: 'quantity',
                                                    value: _biz_itemDeliverQty,
                                                    line: 0
                                                });
                                            }
                                        }
                                    }
                                }
                                recObj.save();
                            } catch (e) {
                                log.debug('Error', e.toString());
								createErrorRecord(_requestParams[i],e.toString(),id)
                            }
                        }
                    } else if (ifId.substring(0, 2) == 'SP') {
                        var id = searchSPFTransaction(ifId);
                        //log.debug('id',id);
                        //log.debug('_requestParams[0].Details',_requestParams[0].Details);
                        if (id) {
							try{
								
							
                            var recObj = record.load({
                                type: 'storepickupfulfillment',
                                id: id
                            }); //,isDynamic:!0
                            recObj.setValue({
                                fieldId: 'custbody_bizspeed_ship_date',
                                value: bizspeedShipped,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'pickupstatus',
                                value: 'B',
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_trip_code',
                                value: _requestParams[i].tripCode,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_truckid',
                                value: _requestParams[i].truckID,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_pod_url',
                                value: _requestParams[i].pod_url,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_rtd',
                                value: _requestParams[i].Rtd,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_rta',
                                value: _requestParams[i].Rta,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_signed_by_name',
                                value: _requestParams[i].signed_by_name,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_comments',
                                value: _requestParams[i].customer_comments,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_biz_po_reference',
                                value: _requestParams[i].alternateOrdNumber,
                                ignoreFieldChange: true
                            });
                            recObj.setValue({
                                fieldId: 'custbody_bizspeed_data',
                                value: _requestParams[i],
                                ignoreFieldChange: true
                            });
                            var lineDetails = _requestParams[i].Details;
                            var lines = recObj.getLineCount({
                                sublistId: 'item'
                            });
                            for (var ii = 0; ii < lines; ii++) {
                                var itemName = recObj.getSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'itemname',
                                    line: ii
                                });
                                var line = recObj.getSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'line',
                                    line: ii
                                });
                                for (var k = 0; k < lineDetails.length; k++) {
                                    var _biz_itemID = lineDetails[k].itemID;
                                    var _biz_itemLine = lineDetails[k].lineNum;
                                    var _biz_itemDeliverQty = lineDetails[k].deliverQty;
                                    if (itemName == _biz_itemID) //&& line==_biz_itemLine
                                    {
                                        //log.debug(itemName+'=='+_biz_itemID,itemName==_biz_itemID);
                                        log.debug('_biz_itemDeliverQty', _biz_itemDeliverQty);
                                        if (_biz_itemDeliverQty == 0) {
                                            recObj.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'itemreceive',
                                                line: ii,
                                                value: false
                                            });
                                        } else {
                                            recObj.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'quantity',
                                                line: ii,
                                                value: _biz_itemDeliverQty
                                            });
                                            var objSubRecord = recObj.getSublistSubrecord({
                                                sublistId: 'item',
                                                fieldId: 'inventorydetail',
                                                line: ii
                                            });
                                            objSubRecord.setSublistValue({
                                                sublistId: 'inventoryassignment',
                                                fieldId: 'quantity',
                                                value: _biz_itemDeliverQty,
                                                line: 0
                                            });
                                        }

                                    }
                                }
                            }
                            recObj.save();

                        }catch (e) {
                                log.debug('Error', e.toString());
								createErrorRecord(_requestParams[i],e.toString(),id)
                            }
						} 
                    }

                }

            }
        } catch (e) {
            log.debug('Error in Post Method', e.toString());
        }
        return 'OK';
    }

    /**
     * @type {import('N/types').EntryPoints.RESTlet.put}
     */
    function onPut(requestParams) {
        // return string or object data
        return '1';
    }
    function searchTransaction(ordernumber) {
        try {
            var itemfulfillmentSearchObj = search.create({
                type: "itemfulfillment",
                filters:
                [
                    ["type", "anyof", "ItemShip"],
                    "AND",
                    ["numbertext", "is", ordernumber]

                ],
                columns:
                [
                    "internalid"
                ]
            });
            var searchResultCount = itemfulfillmentSearchObj.runPaged().count;
            log.debug("itemfulfillmentSearchObj result count", searchResultCount);
            var internalid = '';
            itemfulfillmentSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                internalid = result.getValue({
                    name: 'internalid'
                });
                return true;
            });
            return internalid;
        } catch (e) {
            log.debug('error in search Transaction', e.toString());
        }
    }
    function searchSPFTransaction(ordernumber) {
        try {
            log.debug('ordernumber', ordernumber);
            var storepickupfulfillmentSearchObj = search.create({
                type: "storepickupfulfillment",
                filters:
                [
                    ["type", "anyof", "StPickUp"],
                    "AND",
                    ["numbertext", "is", ordernumber]
                ],
                columns:
                [
                    "internalid"
                ]
            });
            log.debug('storepickupfulfillmentSearchObj', storepickupfulfillmentSearchObj);
            var searchResultCount = storepickupfulfillmentSearchObj.runPaged().count;
            log.debug("storepickupfulfillmentSearchObj result count", searchResultCount);
            var internalid = '';
            storepickupfulfillmentSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
                internalid = result.getValue({
                    name: 'internalid'
                });
                return true;
            });
            return internalid;
        } catch (e) {
            log.debug('Error in searchSPFTransaction', e.toString());
        }
    }
	function createErrorRecord(orderdata,reason,id)
	{
		try{
			var objRecord = record.create({type:'customrecord_bizspeed_error_handling'});
			objRecord.setValue({fieldId:'custrecord_biz_er_reason',value:reason,ignoreFieldChange:true});
			objRecord.setValue({fieldId:'custrecord_biz_er_ordernumber',value:id,ignoreFieldChange:true});
			objRecord.setValue({fieldId:'custrecord_order_data',value:orderdata,ignoreFieldChange:true});
			objRecord.save();
			
		}catch(e)
		{
			log.debug('error in createErrorRecord',e.toString());
		}
	}

    return {
        'delete': onDelete,
        'get': onGet,
        'post': onPost,
        'put': onPut
    };

});