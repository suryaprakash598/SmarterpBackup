/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/email','N/search'],
/**
 * @param {record} record
 */
function(record,email,search) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
    	
    	
    	
    	

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
    	
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {
		try{
		if(scriptContext.type == scriptContext.UserEventType.CREATE){
		 var recObj = scriptContext.newRecord; 
    			
    			/* var lineCount = recObj.getLineCount({
    			    sublistId: 'item'
    			});
    	      log.debug('line count',lineCount);
    			var items=[];
    			
    			for( var i = 0; i < lineCount; i++)
    			{
    				
    				//Getting Sublist Values
    				var item = recObj.getSublistValue({
    				    sublistId: 'item',
    				    fieldId: 'item',
    				    line: i
    				});
					items.push(item)
				} */
            var salesorder_id=recObj.getValue({fieldId:'createdfrom'});
          var vendor_delivery_ref=recObj.getValue({fieldId:'custbody_dil_vendordeliveryref'});
			//log.debug('sales order id',salesorder_id)
		if(salesorder_id){
		 SaleOrder = record.load({
                    type: 'salesorder',
                    id: salesorder_id,
                    isDynamic: false,
                });
				var type;
				var id;
          var po_num;
		var dropship=SaleOrder.getValue({fieldId:'custbody_drop_ship_order'});		
    	for (var i = 0; i < SaleOrder.getLineCount({sublistId: 'links'}); i++) {
			 type = SaleOrder.getSublistValue({
				sublistId: 'links',
				fieldId: 'type',
				line:i
				});
				if(type=='Purchase Order'){
			 id = SaleOrder.getSublistValue({
				sublistId: 'links',
				fieldId: 'id',
				line:i
				});
			po_num = SaleOrder.getSublistValue({
				sublistId: 'links',
				fieldId: 'tranid',
				line:i
				});
			}
	}
	//log.debug('purchase order',id)
	if(id&&dropship){
		log.debug('purchse order id',id);
	var objRecord3 = record.transform({
    	    fromType:record.Type.PURCHASE_ORDER,
    	    fromId:id,
    	    toType:record.Type.VENDOR_BILL,
    	    isDynamic:true,
    	});
		var rid3 = objRecord3.save({
    ignoreMandatoryFields: true
		});
		log.debug('customer payment',rid3)
      //adding handling fee
      
		
		
		try{
	
    	var is_national_cust;
		var handling_Fee_quantity=0;
					
		var	vendor_bill=record.load({
                    type: record.Type.VENDOR_BILL,
                    id: rid3,
                    isDynamic: false,
                });
       var linked_po=	vendor_bill.setValue({
				fieldId:'custbody_dil_linkedpo',
				value:id
				});	
		var tranid=vendor_bill.setValue({
				fieldId:'tranid',
				value:vendor_delivery_ref
				});
          var customer = vendor_bill.getSublistValue({
				sublistId: 'item',
				fieldId: 'customer',
				line:0
				});
		if(customer){
		try {
		var fields = search.lookupFields({
        type: 'customer',
        id: customer,
        columns: ['custentity_drop_ship_customer']
      });
      
          
        is_national_cust = fields.custentity_drop_ship_customer;
		log.debug('is_national_cust',is_national_cust);
      } catch (e) {
        log.debug('error',e);
        
      }
	  if(is_national_cust){	
    	for (var i = 0; i < vendor_bill.getLineCount({sublistId: 'item'}); i++) {
			var quantity = vendor_bill.getSublistValue({
				sublistId: 'item',
				fieldId: 'quantity',
				line:i
				});
			var gallon_conversion = vendor_bill.getSublistValue({
				sublistId: 'item',
				fieldId: 'custcol_ns_gallonconversionfactor',
				line:i
				});	
			handling_Fee_quantity=Number(handling_Fee_quantity)+(Number(quantity)*Number(gallon_conversion))
			log.debug('handling_Fee_quantity',handling_Fee_quantity);
	}
	
	var lineCount=vendor_bill.getLineCount({sublistId: 'item'});
	var lineNumber = vendor_bill.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3024 //'Handling fee'
            });
            log.debug('Handling fee',lineNumber);
       
           
                // if Handling fee is not available at the item list 
               
                    if (lineNumber == -1)
                    {
                        vendor_bill.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        vendor_bill.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3024 //'Handling fee'
                            });
						var qauntity=vendor_bill.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:Number(handling_Fee_quantity) //'Handling fee'
						})	
                        }catch(e)
                        {
                            log.error(' error adding handling fee line',e.message());
                        }
                    }
					else{
						log.debug('handling_Fee_quantity',handling_Fee_quantity);
						var qauntity=vendor_bill.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:Number(handling_Fee_quantity) //'Handling fee'
						})	
					}
         vendor_bill.save({
    ignoreMandatoryFields: true
		});           
	  }
	  
		}
		
//}
		}
catch(e){
	log.debug('error',e)
}
	}
	//SaleOrder.save({ ignoreMandatoryFields: true });
		}
}
		}
catch(e){
	log.debug('error',e)
}
	}	


    	
    
    
    	


    return {
       // beforeLoad: beforeLoad,
       // beforeSubmit: beforeSubmit,
      afterSubmit: afterSubmit
    };
    
});
