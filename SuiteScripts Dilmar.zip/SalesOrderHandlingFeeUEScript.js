/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 */
define(['N/record','N/search','N/action','N/format','N/runtime'], function(record,search,action,format,runtime) {
	
		
	// Search for the credit approvers emails
function creditApproverEmailList(){
		
	var employeeSearchObj = search.create({
		   type: "employee",
		   filters:
		   [
		      ["role","anyof","1087"]
		   ],
		   columns:
		   [
		      search.createColumn({
		         name: "entityid",
		         sort: search.Sort.ASC
		      }),
		      "email"
		   ]
		});
	    var creditapprvemails = [];
	
		var searchResultCount = employeeSearchObj.runPaged().count;
		log.debug("employeeSearchObj result count",searchResultCount);
		employeeSearchObj.run().each(function(result){
			creditapprvemails.push(result.getValue("email"));
		   return true;
		});
		return creditapprvemails;
	}
		
	
// Search for the contacts associated with Customers and Vendors
function findEmailList(entity){
  	var emails = [];
			var contactSearchObj = search.create({
			   type: "contact",
			   filters:
			   [
				  ["isinactive","is","F"], 
				  "AND", 
				  ["email","isnotempty",""], 
                 "AND",
                 ["custentity_dil_contact_so_notify","is","T"],
				  "AND", 
				  ["company.internalid","anyof",entity]
			   ],
			   columns:
			   [
				  search.createColumn({
				  name: "email"})
				  
			   ]
			});
		
			 var curr_emailaddress,all_emailaddresses;
			contactSearchObj.run().each(function(result){
               if (emails.length <= 10)
              {
                 curr_emailaddress = result.getValue("email");
                 var existing_email = emails.indexOf(curr_emailaddress);
                 if (existing_email == -1)
                    { 
                      all_emailaddresses = all_emailaddresses+curr_emailaddress+";";
                      if (all_emailaddresses.length <= 254)
                      {emails.push(result.getValue("email"));}
                    }
              }
			    return true;
			});
			return emails;
	}
  
	
	function beforeSubmit(context)
	{	var newRecord = context.newRecord;
	   
                  var delivery_date = newRecord.getValue({
                        fieldId: 'custbody_dil_so_order_delivery_date'
                    });
    
     if (context.type != context.UserEventType.CREATE || context.type != context.UserEventType.COPY || context.type != context.UserEventType.VIEW) 
       {
     /* for setting the delivery date after the credit approval date */
    			  var deliveryzone = newRecord.getValue({
						fieldId : 'custbody_dil_so_cust_delivery_day'
					});
         		if (Number(deliveryzone) > 1)
					var dayindicator = deliveryzone - 1;
					var current_date = newRecord.getValue({
                        fieldId: 'custbody_dil_so_credit_apr_dttm'
                    	});
                 if (Date.parse(current_date) && Number(deliveryzone) > 1)
                   {
                         current_date.setDate(current_date.getDate() + 1);
                         var deliverydate = new Date();
                        var current_day = current_date.getDay();
                        if (dayindicator > current_day)
                        {
                         deliverydate.setDate(current_date.getDate() + (dayindicator-current_day));
                        } else
                        {
                            deliverydate.setDate(current_date.getDate() + ( 7 + dayindicator-current_day));
                        }

                        newRecord.setValue({
                            fieldId: 'custbody_dil_so_order_delivery_date',
                            value : deliverydate
                        });
                        newRecord.setValue({
                            fieldId: 'shipdate',
                            value : deliverydate
                        });
                   }
       }
     			  if (delivery_date)
     			 { delivery_date = format.parse({value:delivery_date, type: format.Type.DATE});
                   delivery_date = format.format({value: delivery_date,type:format.Type.DATE});
                 }
     
     		 
         
     
       var sublistName = newRecord.getSublist({
              sublistId : 'item'
            });
       var requesteddatecol = sublistName.getColumn({
      			fieldId: 'requesteddate'
			});
       var linecount = newRecord.getLineCount({
                    sublistId: 'item'
                });
                 for (i=0; i < linecount;i++)
                {
             /*     var unit_to_gallon = newRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ns_gallonconversionfactor',
                    	line: i
                    });
                  log.debug('in save validation',i +' '+Number(unit_to_gallon));
           		 var quantity_line = newRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'quantity',
                   	    line: i
                    });
                   */
                 
                   if(delivery_date )
                   {
                      newRecord.setSublistValue({
                          sublistId: 'item',
                          fieldId: 'requesteddate',
                          value: delivery_date,
                        line: i
                      });
                           log.debug('delivery date',delivery_date + ' '+newRecord.getSublistValue({ sublistId: 'item',fieldId: 'requesteddate', line: i}) );
               
                   }
                
             }
        
     if (context.type == context.UserEventType.CREATE || context.type == context.UserEventType.EDIT || context.type == context.UserEventType.COPY)	
        { var isstorepickup = newRecord.getValue('custbody_dil_so_store_pickup_cb');
          //var salesmandelivery = newRecord.getValue('custbody_dil_salesmandelivery');
         // var commoncarrier = newRecord.getValue('custbody_dil_commoncarrier');
          log.debug('is store pickup',isstorepickup); 
          if(isstorepickup){
             try{
            	var numLines = newRecord.getLineCount({
                              sublistId: 'item'
                          });
            
              for (i = 0; i< numLines; i++)
              { 
                 var fulfilled_flag = newRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'custcol_dil_item_to_be_fulfilled',
                                        line: i
                                      });
                if(fulfilled_flag) 
                  newRecord.setSublistValue({
                  						sublistId: 'item',
                                        fieldId: 'itemfulfillmentchoice',
                                        line: i,
                    					value: '2'
                                      });
                					
              }
             }catch(e)
               {
                 log.error('error',e.toString());
               }
            newRecord.setText({
              fieldId: 'shipmethod', // set ship method to 'In-Store Pickup'
              text: 'In-Store Pickup'
            })
            newRecord.setValue({
              fieldId: 'shipaddresslist', // mark the shipping address to blank
              value: ''
            })
          }else{
              try{
            	var numLines = newRecord.getLineCount({
                              sublistId: 'item'
                          });
            
              for (i = 0; i<= numLines; i++)
              { 
                 var fulfilled_flag = newRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'custcol_dil_item_to_be_fulfilled',
                                        line: i
                                      });
                if(fulfilled_flag) 
                  newRecord.setSublistValue({
                  						sublistId: 'item',
                                        fieldId: 'itemfulfillmentchoice',
                                        line: i,
                    					value: '1'
                                      });
                					
              }
             }catch(e)
               {
                 log.error('error in setting fulfilment',e.toString());
               }
          /*  if (salesmandelivery)
              {
            newRecord.setText({
              fieldId: 'shipmethod', // set ship method to 'Salesman Delivery'
              text: 'Salesman Delivery'
            });
              }
           else if (commoncarrier)
              {
                newRecord.setText({
                    fieldId: 'shipmethod', // set ship method to 'Common Carrier'
                    text: 'Common Carrier'
                  });
              }
            else
              {
                newRecord.setText({
                      fieldId: 'shipmethod', // set ship method to 'Own Truck'
                      text: 'Own Truck'
                        });
              }*/
          }
            
          log.debug('coming after', newRecord.getValue({
              fieldId: 'orderfulfillmentchoice'
            }));
        }
     

         if (context.type == context.UserEventType.CREATE) 
             {
            // set email field values for credit approvers and contacts
                var userObj = runtime.getCurrentUser();
                var userRole = userObj.role;
               var customerid = newRecord.getValue('entity');
                var userPermission_emp = userObj.getPermission({
                                                         name : 'LIST_EMPLOYEE'
                                            });
                        var userPermission_emprec =  userObj.getPermission({
                                                         name : 'LIST_EMPLOYEE_RECORD'
                                            }); 
                        log.debug('userPermission_emp',userPermission_emp + ' '+ (userPermission_emp !== undefined)+' '+(userPermission_emprec !== undefined));
                        try{
                              if (userPermission_emp !== undefined && userPermission_emprec !== undefined)
                                {
                                  var approveremaillist = creditApproverEmailList();
                                  if (approveremaillist.length > 0)
                                      {
                                          var appr_email_addresses = approveremaillist.join(";");
                                          newRecord.setValue({
                                              fieldId: 'custbody_dil_so_credit_approver_list',
                                              value : appr_email_addresses
                                          });
                                      }
                              };
                              // if (to_email) {
                                var userPermission_contact = userObj.getPermission({
                                                               name : 'LIST_CONTACT'
                                                  });
                                if (userPermission_contact !== undefined)
                                {
                                      var emaillist = findEmailList(customerid);
                                  	var cust_email = newRecord.getValue({
                                                                fieldId : 'email'
                                                            });
                                  log.debug('email list joined',emaillist);
                                      if (emaillist.length > 0)
                                          {
                                              var email_addresses = emaillist.join(";")+";"+cust_email;
                                              newRecord.setValue({
                                                  fieldId: 'email',
                                                  value : email_addresses
                                              });
                                          };
                                };
                        }catch(e)
                          {
                            log.error(' error in setting email addresses',e.toString());
                          };
               
               
         
          
        }
            var location_main = newRecord.getValue({fieldId: 'location'});
          try{
            	var numLines = newRecord.getLineCount({
                              sublistId: 'item'
                          });
            
              for (i = 0; i< numLines; i++)
              { 
                var location_line = newRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'location',
                                        line: i
                                      });
                var fulfilled_flag = newRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'custcol_dil_item_to_be_fulfilled',
                                        line: i
                                      });
                if (location_line.length == 0 && fulfilled_flag)
                  {
                   newRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'location',
                                    line: i,
                                    value: location_main
                                      });
			        log.debug('location line in save', i);
                  }
               }
          }catch(e)
            {
              log.error('error in setting location',e.toString());
             // return false;
            }
     
     // setting the proper delivery date for memorized transactions
            var currentRecord = context.newRecord;
      log.debug('coming in last before submit');
	   try{
                  var delivery_date = currentRecord.getValue({
                        fieldId: 'custbody_dil_so_order_delivery_date'
                    });
                 var tran_date = currentRecord.getValue({
                        fieldId: 'trandate'
                    });
      				var deliveryzone = currentRecord.getValue({
								fieldId : 'custbody_dil_so_cust_delivery_day'
							});
					log.debug('delivery zone user event ',deliveryzone);
      			if ((Date.parse(delivery_date) && delivery_date <= tran_date) && Number(deliveryzone) > 1)
					{
                      log.debug('coming inside the date comparison before submit',tran_date);
						var dayindicator = deliveryzone - 1;
						var current_date = new Date();
							  current_date.setDate(current_date.getDate() + 1);
				
						 var deliverydate = new Date();
						var current_day = current_date.getDay();
						if (dayindicator > current_day)
						{
						 deliverydate.setDate(current_date.getDate() + (dayindicator-current_day));
						} else
						{
							deliverydate.setDate(current_date.getDate() + ( 7 + dayindicator-current_day));
						}
						
						currentRecord.setValue({
							fieldId: 'custbody_dil_so_order_delivery_date',
							value : deliverydate
						});
						currentRecord.setValue({
							fieldId: 'shipdate',
							value : deliverydate
						});
                    }
               } catch(e)
                      {
                        log.error('error in after submit to set dates ',e.toString());
                      }
    }
	function afterSubmit(context){
        
	}
    return {
        beforeSubmit: beforeSubmit,
		afterSubmit: afterSubmit
    }
});