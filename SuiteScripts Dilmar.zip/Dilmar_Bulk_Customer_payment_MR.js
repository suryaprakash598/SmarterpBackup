/**
 * @NApiVersion 2.0
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/email', 'N/record', 'N/search', 'N/config', 'N/runtime', 'N/file','N/render','N/format','N/task'],
/**
 * @param {email} email
 * @param {record} record
 * @param {search} search
 * @param {config} config
 * @param {runtime} runtime
 */
function(email, record, search, CONFIG, runtime, file,render,format,task) {
   
    
    function getInputData() {
    	var arr_emailfileId = [];
    
			  var fileSearchObj = search.create({
   type: "file",
   filters:
   [
      ["folder","anyof","217197"],
	  "AND",
	  ["name","doesnotstartwith","Processed"]
	   
   ],
   columns:
   [search.createColumn({name: "internalid", label: "Internal ID"})
   ]
});
var searchResultCount = fileSearchObj.runPaged().count;
log.debug("fileSearchObj result count",searchResultCount);
fileSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var id=result.getValue({name: "internalid"})
    arr_emailfileId.push(id);
	
	
   return true;
});
log.debug(arr_emailfileId);
		return arr_emailfileId; 
    }

    
    function map(context) {
		try{
    	var file_id = context.value;
    	 var fileObj_data = file.load({
        id:file_id
      });
	  log.debug(fileObj_data.name);
	   var contents = fileObj_data.getContents();
	  var groupResult = JSON.parse(contents);
	  
	  var scriptObj = runtime.getCurrentScript();
		var folderid =scriptObj.getParameter({name: 'custscript_dil_tran_pdf_folder_new'}); 
        var email_author = scriptObj.getParameter({name: 'custscript_dil_payment_email_author_new'});
		var attachment;
		 var objRecord = record.load({
             type: record.Type.EMAIL_TEMPLATE, 
             id: 15,
             isDynamic: true
        		 });
		 var email_body = objRecord.getValue({
              fieldId: 'content'
          });
		 var email_sub = objRecord.getValue({
			 fieldId:'subject'
		 })
		 
		 for(var i=0;i<groupResult.length;i++){
			 var data=groupResult[i];
			 
			var pymntRecord = record.create({
				type : record.Type.CUSTOMER_PAYMENT,
				isDynamic: true,
				});
				var filterDate = new Date(data.trandate);
	 var fDate  = filterDate.getDate();
	 var fMonth  = filterDate.getMonth()+1;
	 var fYear  = filterDate.getFullYear();
	 var date  = fMonth+"/"+fDate+"/"+fYear;
	 log.debug('date',date);
				pymntRecord.setValue('customer',data.selected_custid);
				pymntRecord.setValue('undepfunds','F');
				pymntRecord.setValue('account', data.deposit_acct);
				pymntRecord.setValue('trandate',format.parse({value:date, type: format.Type.DATE}));
				pymntRecord.setValue('postingperiod', data.posting_period);
                pymntRecord.setValue('paymentmethod',data.paymentmethod);
         
			var invcount = pymntRecord.getLineCount({
				sublistId: 'apply'
			})
			log.debug('invoice count in payment record',invcount);
			var dataarray=data.tranData;
			dataarray.sort();
			for (k = 0 ; k < dataarray.length; k++)
				{
				   log.debug('data array inv id',dataarray[k].invid);
					
				 for (inv = 0; inv < invcount; inv++)
					 {
					   var invinternalid = pymntRecord.getSublistValue({
						   sublistId: 'apply',
						   fieldId: 'refnum',
						   line: inv
					   });
					   log.debug('invoice internal id and data array inv id',invinternalid +' '+dataarray[k].invid);
					   if (dataarray[k].invid == invinternalid)
						   {
						   pymntRecord.selectLine({
							   sublistId: 'apply',
							   line: inv});
						   
						   
						   pymntRecord.setCurrentSublistValue({
						    	sublistId:'apply',
						    	fieldId: 'apply',
						    	value: true
						    });
						    pymntRecord.setCurrentSublistValue({
						    	sublistId: 'apply',
						    	fieldId: 'amount',
						    	value: dataarray[k].payamt
						    });
						  /*  pymntRecord.setCurrentSublistValue({
						    	sublistId: 'apply',
						    	fieldId: 'paymentmethod',
						    	value: dataarray[k].pay_method
						    })*/
						    
						    
						    log.debug('invoice internal id',invinternalid);
						    break; 
						   }
					 
					 }
				 
				}
				var payrecid = pymntRecord.save();
			var today_date = new Date();
			var year =0, month=0, day = 0;
			year = today_date.getFullYear();
			month = today_date.getMonth() + 1;
			month = (month < 10) ? "0".concat(month) : month.toString();
			day = today_date.getDate();
			day = (day < 10) ? "0".concat(day) : day.toString();
			var datestring = year +month.toString() +day.toString();
			var pdf_file_name = payrecid +"_"+ datestring;
		
       
			try{
				var transactionFile = render.transaction({
				entityId: payrecid,
				printMode: render.PrintMode.PDF,
				//formId: custom_form
				});
			}catch(e)
			{
				log.error(' render error',e.toString())
			}
			try{
					var fileObj = file.create({
								name: pdf_file_name,
								fileType: file.Type.PDF,
								contents: transactionFile.getContents(),
								folder: folderid
							});

					var pdfFileId = fileObj.save();
					log.debug( 'pdffile' , pdfFileId + ' saved');
				}catch(e)
				{
					log.error(' render error',e.toString())
				}
			try{
				    attachment = file.load({
					id: pdfFileId
					});
				}catch(e)
					{log.error('File Attachment Error ',e.toString());}
				 
				try{
						log.debug('send email','coming in sending email'+email_sub + ' '+ dataarray[0].emailaddress);
						email.sendBulk({
							 author: email_author,
							 recipients: dataarray[0].emailaddress, 
							 subject: email_sub,
							 body: email_body,
							 attachments: [attachment],
							// replyTo: return_email,
							 relatedRecords : {
							 transactionId: payrecid }
							});
					}
					catch (e)
						{
							log.error('Invalid/No Email address Error ',e.toString());
								email.send({
									 author: email_author,
									 recipients: 'credit@dilmar.com', //default email address to send for any improper email addresses,
									 subject: email_sub + 'Error while sending email',
									// replyTo: return_email,
									 body: email_body + '<br\/>'+e.toString(),
									 attachments: [attachment]
								});			
						}
		 }
		 
		 
		 
		 
		 
		 
		log.debug('fileObj_data',fileObj_data.name);
		fileObj_data.name='Processed '+fileObj_data.name;
		log.debug('fileObj_data new',fileObj_data.name);
		fileObj_data.save();
    	}catch(e){
    		log.error('Error', e);
    	}
    }

    
    function reduce(context) {

    }

    function summarize(summary) {
			  var fileSearchObj = search.create({
   type: "file",
   filters:
   [
      ["folder","anyof","217197"],
       "AND",
	  ["name","doesnotstartwith","Processed"]//sandbox 
   ],
   columns:
   [search.createColumn({name: "internalid", label: "Internal ID"})
   ]
});
var searchResultCount = fileSearchObj.runPaged().count;
log.debug("fileSearchObj result count",searchResultCount);
if(searchResultCount>0){
	var mapreducetask = task.create({
					taskType: task.TaskType.MAP_REDUCE,
					scriptId: 'customscript_dil_bulk_cust_payment_mr',
					deploymentId: 'customdeploy_dil_bulk_cust_payment_mr',
				});
				var mrTaskId = mapreducetask.submit();
				log.debug('mrTaskId', mrTaskId);


				log.debug('finished', 'finished');
}
    }

    return {
        getInputData: getInputData,
        map: map,
        //reduce: reduce,
        summarize: summarize
    };
    
});
