/*******************************************************************************
{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 *
 ******************************************************************************/

define(['N/runtime', 'N/record', 'N/search', 'N/https','N/currentRecord'], function(
  /** @type import('N/runtime')}   **/ runtime,
  /** @type import('N/record')}    **/ record,
  /** @type import('N/search')}    **/ search,
  /** @type import('N/log')}       **/ https,
  /** @type import('N/log')}       **/ currentRecord
) {

  /**
   * context.currentRecord
   * context.sublistId
   * context.fieldId
   * context.line
   * context.column
   *
   * @type {import('N/types').EntryPoints.Client.fieldChanged}
   */
  function fieldChanged(context) {
    // no return value
  }
/**
   * context.currentRecord
   * context.mode // [copy, paste, create]
   *
   * @type {import('N/types').EntryPoints.Client.pageInit}
   */
  function pageInit(context) {
	  
    // no return value
	
	
  }
  
   
function cancelBizReq(docnumber,recid)
{
	debugger;
	var currentRecordObj = currentRecord.get();
	    try{
			var orderData = {
					"msg": {
						"module": "SS2.MobileHub.Classes.SyncMobileHelpers.api3PLexternal",
						"opcode": "CancelOrders",
						"status": null,
						"messageData": {
							"Orders": [
								{
									"orderNo": docnumber,
									"customerName": null,
									"accountNo": null
								}
							]
						},
						"authToken": {
							"UserName": "netsuite_api",
							"Password": "sWWHpW5viOwP",
							"CompanyCode": "dilmar",
							"CryptoKey": null,
							"OrgRefId": "00000000-0000-0000-0000-000000000000",
							"UserRefId": "00000000-0000-0000-0000-000000000000",
							"DeviceRefId": "00000000-0000-0000-0000-000000000000"
						},
						"clockTimeInUTC": null
					}
				}
			var _bizspeed_url = 'https://mh-est.goroam.com/SyncMobileSuiteJSON.asmx/BrokerMessageJSON';

	            var headersbizspeed = {
	                'content-type': 'application/json'
	            };
				
			https.request.promise({
					method: https.Method.POST,
	                url: _bizspeed_url,
	                body: JSON.stringify(orderData),
	                headers: headersbizspeed

			})
		.then(function(response){
			log.debug({
				title: 'Response',
				details: response
			});
			record.submitFields({type:'itemfulfillment',id:recid,values:{custbody_is_biz_cancel_req_sent:true},options:{enableSourcing:!1,ignoreMandatoryFields:!0}});
		})
		.catch(function onRejected(reason) {
			log.debug({
				title: 'Invalid Request: ',
				details: reason
			});
		})
		}catch(e)
		{
			
		}
}
function updateBizReq(docnumber,recid)
{
	try{
		var IFObj = record.load({type:'itemfulfillment',id:recid});
		IFObj.setValue({fieldId:'custbody_is_bizspeed_req_sent',value:false,ignoreFieldChange:true});
		IFObj.save();
		window.location.reload();
	}catch(e)
	{
		log.debug('error in updateBizReq',e.toString())
	}
}
function resendBizReq(docnumber,recid)
{
	try{
		var IFObj = record.load({type:'itemfulfillment',id:recid});
		IFObj.setValue({fieldId:'custbody_is_bizspeed_req_sent',value:false,ignoreFieldChange:true});
		IFObj.setValue({fieldId:'custbody_is_biz_cancel_req_sent',value:false,ignoreFieldChange:true});
		IFObj.save();
		window.location.reload();
	}catch(e)
	{
		log.debug('error in resendBizReq',e.toString())
	}
}
  return {
   'pageInit':       pageInit,
	'cancelBizReq':cancelBizReq ,
	'updateBizReq':updateBizReq ,
	'resendBizReq':resendBizReq
  };

});