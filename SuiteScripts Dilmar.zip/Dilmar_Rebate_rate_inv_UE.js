/*******************************************************************************{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  2.0
 *
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 *
 ******************************************************************************/

define(['N/runtime', 'N/record', 'N/search', 'N/log','N/format'], function (
        /** @type {import('N/runtime')} **/
        runtime,
        /** @type {import('N/record')}  **/
        record,
        /** @type {import('N/search')}  **/
        search,
        /** @type {import('N/log')}     **/
        log,format) {
 function beforeSubmit(scriptContext) {
  	/*	//checking is the customer is National cust or not
		var recObj = scriptContext.newRecord; //create mode
		var entity=recObj.getValue({
					fieldId: 'entity',
				});
		try {		
		var fields = search.lookupFields({
        type: 'customer',
        id: entity,
        columns: ['custentity_dil_customer_nation_yn','custentity_ns_envcomplianceexempt']
      });
      
      var is_national_cust;
	  var env_cust;
      
        is_national_cust = fields.custentity_dil_customer_nation_yn;
		env_cust= fields.custentity_ns_envcomplianceexempt;
      } catch (e) {
        log.debug('error',e);
        
      }
		
 if (scriptContext.type == scriptContext.UserEventType.CREATE && !is_national_cust&& !env_cust)
      {
        //find if the Environment Charge is already part of the sales order
            var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 20 //'Environment Compliance Fees'
            });
            log.debug('Environment fee line number',lineNumber);
       var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
           
                // if Environment fee is not available at the item list then add the line to the item list with environment fee value
               
                    if (lineNumber == -1)
                    {
                        recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 20 //'Environment Fees'
                            });
                        }catch(e)
                        {
                            log.error(' error adding environment fee line',e.message());
                        }
                    }		
			  
        	
        }*/
}
  
    /**
     * context.newRecord
     * context.oldRecord
     * context.type
     *
     * @type {import('N/types').EntryPoints.UserEvent.afterSubmit}
     */
    function afterSubmit(context) {
		if (context.type != context.UserEventType.DELETE) {
        try {
			var items=[];var arr=[];
            var rec = context.newRecord; //create mode
			if(!rec){
				rec=context.oldRecord;
			}
            var rectype = rec.type;
            var recId = rec.id;
            var recObj = record.load({
                type: rectype,
                id: recId 
            });
          
          
   			var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
			  //reading all line items
			  for (var i = 0; i < lineCount; i++) {
				  var obj={};
				var item = recObj.getSublistValue({
				  sublistId: 'item',
				  fieldId: 'item',
				  line: i
				});
				var qty = recObj.getSublistValue({
				  sublistId: 'item',
				  fieldId: 'quantity',
				  line: i
				});
				var gallon_conversion = recObj.getSublistValue({
				  sublistId: 'item',
				  fieldId: 'custcol_ns_gallonconversionfactor',
				  line: i
				});
				
				obj.item=item;
				obj.qty=qty;
				obj.gallon_conversion=gallon_conversion;
				arr.push(obj);
				items.push(item);
			  }
			 // log.debug('arr',arr);
			  var cust = recObj.getValue({
				fieldId: 'entity'
				});
			var trandate=recObj.getValue({
				fieldId: 'trandate'
				});
			//searching for rebate items
			  var rebateDataObj = rebateRateSearch(items,cust,trandate);
			  
			  if(rebateDataObj.length>0)
			  {
				  for(var m=0;m<arr.length;m++)
				  {
					  var rebateamount;
					  for(var l=0;l<rebateDataObj.length;l++)
					  {
						  var item = arr[m].item;
						  var gallon_conversion = arr[m].gallon_conversion;
						  var qty = arr[m].qty;
						 
						  
						  var rebateItem = rebateDataObj[l].item;
						  var rebateItemRate = rebateDataObj[l].rate;
						   var detail = rebateDataObj[l].detail;
					
							
						  if(item==rebateItem ){
                             recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'custcolzdo_rebatedetails',
						  line: m,
						  value: detail
						});
							if(!rebateDataObj[l].rebate_per_unit){  
                          rebateamount=qty*gallon_conversion*rebateItemRate 
							recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'custcol_zdo_totalrebate',
						  line: m,
						  value: rebateamount
						});  	 
						  }
						  else{
							  var rebateItemRate = rebateDataObj[l].rebate_rate_per_unit;
							rebateamount=qty*rebateItemRate 
							recObj.setSublistValue({
						  sublistId: 'item',
						  fieldId: 'custcol_zdo_totalrebate',
						  line: m,
						  value: rebateamount
						});    
						  }
						  }
					  }  
				  }
			  }
			  
			var billstate;
			var sc_fee_exempt=false;
			var fields = search.lookupFields({
                type: 'customer',
                id: cust,
                columns: ['custentity_do_scef_exempt']
            });
			try{
                sc_fee_exempt=fields.custentity_do_scef_exempt; 
                }
                catch(e){
                	log.debug('error while checking bill state');
                	
                }//custitem_sc_solidwastefee
				log.debug('state',billstate);
				//log.debug('fee exempt',sc_fee_exempt);
			//if(billstate=='SC'&&!sc_fee_exempt){
				var fee_items=sc_waste_fee_items(items);
				var waste_fee_quantity=0;
				var gas_tax_quantity=0;
				var disel_tax_quantity=0;
				var alabama_tax_quantity=0;
				if(fee_items.length>0)
			  {
				  for(var m=0;m<arr.length;m++)
				  {
					  for(var l=0;l<fee_items.length;l++)
					  {
						  var item = arr[m].item;
						  var gallon_conversion = arr[m].gallon_conversion;
						  var qty = arr[m].qty;
						 
						  
						  var feeItem = fee_items[l].itemid;
						  var fee = fee_items[l].fee;
							var gas_tax=fee_items[l].gas_tax;
							var disel_tax=fee_items[l].disel_tax;
							var alabama_tax=fee_items[l].alabama_tax;
						 // log.debug('feeItem',feeItem)
						//  log.debug('fee',fee)
						  if(item==feeItem&&fee ){
							log.debug('waste_fee_quantity',waste_fee_quantity)  
                          waste_fee_quantity=(qty*gallon_conversion)+waste_fee_quantity; 
							 	 
						  }
						  if(item==feeItem&&gas_tax){
							  gas_tax_quantity=gas_tax_quantity+(gallon_conversion*qty);
						  }
						  if(item==feeItem&&disel_tax){
							  disel_tax_quantity=disel_tax_quantity+(gallon_conversion*qty);
						  }
						  if(item==feeItem&&alabama_tax){
							  alabama_tax_quantity=alabama_tax_quantity+(gallon_conversion*qty);
						  }
					  }  
				  }			  
				  if(gas_tax_quantity>0){
				  //adding  South Carolina Gas Tax
				  var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3029 //' South Carolina Gas Tax'
            });
            //log.debug('SC waste fee line number',lineNumber);
       
           
                // if  South Carolina Gas Tax is not available at the item list then add the  South Carolina Gas Tax
               
                    if (lineNumber == -1)
                    {
				  recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        var item=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3029 //' South Carolina Gas Tax'
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:parseInt(gas_tax_quantity)
                            });	
                        }catch(e)
                        {
                            log.error(' error adding  South Carolina Gas Tax line',e.message());
                        } 
					}
					else{
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:parseInt(gas_tax_quantity)
                            });	
					}
					
					//adding  Federal Excise Gasoline Tax
				  var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3030 //' Federal Excise Gasoline Tax'
            });
            log.debug('SC waste fee line number',lineNumber);
       
           
                // if  Federal Excise Gasoline Tax is not available at the item list then add the  Federal Excise Gasoline Tax
               
                    if (lineNumber == -1)
                    {
				  recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        var item=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3030 //' Federal Excise Gasoline Tax'
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:parseInt(gas_tax_quantity)
                            });	
                        }catch(e)
                        {
                            log.error(' error adding  Federal Excise Gasoline Tax',e.message());
                        } 
					}
					else{
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:parseInt(gas_tax_quantity)
                            });	
					}
					
					
					
				  }
				  
				  if(disel_tax_quantity>0){
				  //adding   South Carolina Diesel Tax
				  var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3027 //'  South Carolina Diesel Tax'
            });
            log.debug('SC waste fee line number',lineNumber);
       
           
                // if  South Carolina Gas Tax is not available at the item list then add the  South Carolina Gas Tax
               
                    if (lineNumber == -1)
                    {
				  recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        var item=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3027 //' South Carolina Gas Tax'
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:parseInt(disel_tax_quantity)
                            });	
                        }catch(e)
                        {
                            log.error(' error adding  South Carolina Gas Tax line',e.message());
                        } 
					}
					else{
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:parseInt(disel_tax_quantity)
                            });	
					}
					
					//adding  Federal Excise Diesel Fuel Tax
				  var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3028 //' Federal Excise Diesel Fuel Tax'
            });
            log.debug('SC waste fee line number',lineNumber);
       
           
                // if  Federal Excise Diesel Fuel Tax is not available at the item list then add the Federal Excise Diesel Fuel Tax
               
                    if (lineNumber == -1)
                    {
				  recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        var item=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3028 //' Federal Excise Diesel Fuel Tax'
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:parseInt(disel_tax_quantity)
                            });	
                        }catch(e)
                        {
                            log.error(' error adding  Federal Excise Diesel Fuel Tax',e.message());
                        } 
					}
					else{
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:parseInt(disel_tax_quantity)
                            });	
					}
					
					
					
				  }
			  }
			  var billstate=recObj.getValue({fieldId: 'shipstate'});
			  
			    if(waste_fee_quantity>0&&billstate=='SC'&&!sc_fee_exempt){
				  //adding SC waste fee
				  var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3025 //'SC waste Fees'
            });
            log.debug('SC waste fee line number',lineNumber);
       
           
                // if SC waste fee is not available at the item list then add the SC waste fee value
               
                    if (lineNumber == -1)
                    {
				  recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        var item=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3025 //'SC Waste fee'
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:parseInt(waste_fee_quantity)
                            });	
                        }catch(e)
                        {
                            log.error(' error adding handling fee line',e.message());
                        } 
					}
					else{
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:parseInt(waste_fee_quantity)
                            });	
					}
				  }
				     if(alabama_tax_quantity>0&&billstate=='AL'&&!sc_fee_exempt){
				  //adding alabama tax
				  var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 3026 //'Alabama tax'
            });
            log.debug('alabama tax line number',lineNumber);
       
           
                // if alabama tax is not available at the item list then add the alabama tax
               
                    if (lineNumber == -1)
                    {
				  recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        var item=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 3026 //'alabama tax '
                            });
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineCount,
                                value:parseInt(alabama_tax_quantity)
                            });	
                        }catch(e)
                        {
                            log.error(' error adding alabama tax line',e.message());
                        } 
					}
					else{
						var qauntity=recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: lineNumber,
                                value:parseInt(alabama_tax_quantity)
                            });	
					}
				  }
			
        } catch (e) {
            log.debug('Error', e.toString());
			return true
        }
      //adding ECF fee
		//checking is the customer is National cust or not
		try{
		
		var entity=recObj.getValue({
					fieldId: 'entity',
				});
		try {		
		var fields = search.lookupFields({
        type: 'customer',
        id: entity,
        columns: ['custentity_dil_customer_nation_yn','custentity_ns_envcomplianceexempt']
      });
      
      var is_national_cust;
	  var env_cust;
      
        is_national_cust = fields.custentity_dil_customer_nation_yn;
		env_cust= fields.custentity_ns_envcomplianceexempt;
      } catch (e) {
        log.debug('error',e);
        
      }
	  var ecf_invoice_number;
	  var salesorder_id=recObj.getValue({
					fieldId: 'createdfrom'
				});
		if(salesorder_id){
		 SaleOrder = record.load({
                    type: 'salesorder',
                    id: salesorder_id,
                    isDynamic: false,
                });
		ecf_invoice_number=SaleOrder.getValue({
					fieldId: 'custbody_ecf_invoice_number',
				});		
		}				
	log.debug('ecf_invoice_number',ecf_invoice_number);	
 if ( !is_national_cust&& !env_cust&&!ecf_invoice_number)
      {
        //find if the Environment Charge is already part of the sales order
            var lineNumber = recObj.findSublistLineWithValue({
                sublistId: 'item',
                fieldId: 'item',
                value: 20 //'Environment Compliance Fees'
            });
			var lineCount = recObj.getLineCount({
				sublistId: 'item'
			  });
            log.debug('Environment fee line number',lineNumber);
       
           
                // if Environment fee is not available at the item list then add the line to the item list with environment fee value
               
                    if (lineNumber == -1)
                    {
                        recObj.insertLine
                        ({
                            sublistId : 'item',
                            line: lineCount
                        });
                       
                        try {
                        recObj.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'item',
                                line: lineCount,
                                value: 20 //'Environment Fees'
                            });
                        }catch(e)
                        {
                            log.error(' error adding environment fee line',e.message());
                        }
                    }		
		   if(SaleOrder){
		ecf_invoice_number=SaleOrder.setValue({
					fieldId: 'custbody_ecf_invoice_number',
					value:recId 
				});
        
		var sales_id = SaleOrder.save({
                enableSourcing: true,
                ignoreMandatoryFields: true
            });		
        }
        	
        }
		}
		catch (e) {
        log.error('error',e);
		return true;
      }
      // set the line location to header location by default if the location is empty
	  try{
     var location_main = recObj.getValue({fieldId: 'location'});
          
            	var numLines = recObj.getLineCount({
                              sublistId: 'item'
                          });
            
              for (i = 0; i< numLines; i++)
              { 
                var location_line = recObj.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'location',
                                        line: i
                                      });
                
                if (location_line.length == 0)
                  {
                   recObj.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'location',
                                    line: i,
                                    value: location_main
                                      });
			        log.debug('location line in save', i);
                  }
               }
            var id = recObj.save({
                enableSourcing: true,
                ignoreMandatoryFields: true
            }); 
            log.debug('Id', id);
          }catch(e)
            {
              log.error('error',e.toString());
             return true;
            }
    }
		}
    
       
    

    function rebateRateSearch(items,cust,trandate) {
        try {
			log.debug('trandate',trandate)
			var filterDate = new Date(trandate);
	 var fDate  = filterDate.getDate();
	 var fMonth  = filterDate.getMonth()+1;
	 var fYear  = filterDate.getFullYear();
	 var dateFilter  = fMonth+"/"+fDate+"/"+fYear;
			  var rebateData = [];
            var customrecord_rebate_price_tableSearchObj = search.create({
                type: "customrecord_rebate_price_table",
                filters:
                [
                    ["custrecord_item", "anyof", items],
					"AND",
					["custrecord_customer","anyof",cust],
					"AND", 
					["custrecordcustrecord_start_date","onorbefore",dateFilter], 
					"AND", 
					["custrecordcustrecord_enddate","onorafter",dateFilter]
					
                ],
                columns:
                [
                    search.createColumn({name: "custrecord_rate", label: "Rate"}),
					search.createColumn({name: "custrecord_item", label: "Item"}),
					search.createColumn({name: "custrecord_rebate_per_unit", label: "Rebate Per Unit"}),
					search.createColumn({name: "custrecord_rebate_rate_per_unit", label: "Rebate Rate Per Unit"}),
                  search.createColumn({name: "custrecord_details", label: "Detail"})
                ]
            });
			log.debug('search data',customrecord_rebate_price_tableSearchObj)
            var searchResultCount = customrecord_rebate_price_tableSearchObj.runPaged().count;
            customrecord_rebate_price_tableSearchObj.run().each(function (result) {
                // .run().each has a limit of 4,000 results
				var obj = {};
				var rebate_per_unit=result.getValue({
                    name: "custrecord_rebate_per_unit" 
                })
				
				var rate = result.getValue({
                    name: "custrecord_rate" 
                });	
				
				
			    var rebate_rate_per_unit = result.getValue({
                    name: "custrecord_rebate_rate_per_unit" 
                });		
				
                
				var item = result.getValue({
                    name: "custrecord_item" 
                });
              var detail = result.getValue({
                    name: "custrecord_details" 
                });
				
				obj.item=item;
				obj.rate=rate;
				obj.rebate_rate_per_unit=rebate_rate_per_unit;
				obj.rebate_per_unit=rebate_per_unit;
				obj.detail=detail;
				rebateData.push(obj);
                return true;
            });
			return rebateData;
        } catch (e) {
            log.debug('Error in rebateRateSearch', e.toString());
        }
    }
	function sc_waste_fee_items(items){
		var itemSearchObj = search.create({
   type: "item",
   filters:
   [
      ["internalid","anyof",items]
   ],
   columns:
   [
      search.createColumn({
         name: "internalid",
         sort: search.Sort.ASC,
         label: "internalid"
      }),
      search.createColumn({name: "custitem_sc_solidwastefee", label: "South Carolina solid waste Fee "}),
	  search.createColumn({name: "custitem_zdo_gastax", label: "Gasoline Tax"}),
      search.createColumn({name: "custitem_zdo_diseltax", label: "Diesel Tax"}),
	  search.createColumn({name: "custitem_zdo_alabamalube", label: "Alabama Lube Excise "})

   ]
});
var sc_items=[];
var searchResultCount = itemSearchObj.runPaged().count;
log.debug("itemSearchObj result count",searchResultCount);
itemSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var obj = {};
				
                var itemid = result.getValue({
                    name: "internalid" 
                });
				var fee = result.getValue({
                    name: "custitem_sc_solidwastefee" 
                });
				var gas_tax=result.getValue({
                    name: "custitem_zdo_gastax" 
                });
				var disel_tax=result.getValue({
                    name: "custitem_zdo_diseltax" 
                });
				var alabama_tax=result.getValue({
                    name: "custitem_zdo_alabamalube" 
                });
				
				obj.itemid=itemid;
				obj.fee=fee;
				obj.gas_tax=gas_tax;
				obj.disel_tax=disel_tax;
				obj.alabama_tax=alabama_tax;
				sc_items.push(obj);
                return true;
});
return sc_items;
	}

    return {
      // 'beforeSubmit': beforeSubmit,
        'afterSubmit': afterSubmit
    };

});