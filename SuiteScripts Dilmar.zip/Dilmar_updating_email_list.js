/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
define(['N/record','N/search'],
/**
 * @param {record} record
 */
function(record,search) {
   
    /**
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} context
     * @param {ServerRequest} context.request - Encapsulation of the incoming request
     * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
     * @Since 2015.2
     * 178509
     */
    function onRequest(context) {
		var invoice_ids=[385818,385966,386434,386440,386748,387527,387531,387544,387550,387554,387555,387579,387609,387618,387624,387626,387629,387631,387633,387635,387636,387637,387639,387641,387642,387643,387647,387648,387649,387849,387850,387851,387852,387854,387857,387858,387860,387865,387866,387869,387870,387871,387873,387877,387878,387879,387880,387881,387959,387960,387962,387964,387965,387968,387969,387970,387971,388061,388062,388063,388065,388069,388073,388075,388076,388078,388079,388080,388081,388083,388087,388089,388093,388094,388095,388292,388304,388312,388318,388332,388334,388338,388339,388342,388343,388344,388346,388354,389295,389298,389306,389308,389313,389315,389317,389319,389321,389324,389404,389523,389639,389650,389652,389653,389935,389937,389939,389942,389944,390043,390069,390075,390080,390171,390379,390386,390390,390391,390395,390396,390397,390699,390717,390729,390732,390733,390734,390740,390742,390745,390838,390845,390855,390945,390947,391152,391154,391155,391157,391158,391159,391161,391167,391168,391169,391171,391172,391177,391178,391485,391488]
    	for(var j = 0; j < invoice_ids.length; j++){
		var invoice =record.load({
 type: record.Type.INVOICE,
 id: invoice_ids[j]
 })
 var entity=invoice.getValue({fieldId:'entity'});
 var email=findEmailList(entity);
 var email_list = email.toString();
 var setting_emails = invoice.setValue({
					fieldId: 'custbody_dil_emaillist',
					value:email_list
				});
 
 var id=invoice.save({enableSourcing: true, ignoreMandatoryFields: true});
    	log.debug('invoice',id);
		} 
    	
    	
    	
    	


    }
	// Search for the contacts associated with Customers and Vendors
function findEmailList(entity){
  	var emails = [];
			var contactSearchObj = search.create({
			   type: "contact",
			   filters:
			   [
				  ["isinactive","is","F"], 
				  "AND", 
				  ["email","isnotempty",""], 
                 "AND",
                 ["custentity_dil_contact_inv_notify","is","T"],
				  "AND", 
				  ["company.internalid","anyof",entity]
			   ],
			   columns:
			   [
				  search.createColumn({
				  name: "email"})
				  
			   ]
			});
		
			 var curr_emailaddress,all_emailaddresses;
			contactSearchObj.run().each(function(result){
               if (emails.length <= 10)
              {
                 curr_emailaddress = result.getValue("email");
                 var existing_email = emails.indexOf(curr_emailaddress);
                 if (existing_email == -1)
                    { 
                      all_emailaddresses = all_emailaddresses+curr_emailaddress+";";
                      if (all_emailaddresses.length <= 254)
                      {emails.push(result.getValue("email"));}
                    }
              }
			    return true;
			});
			return emails;
	}

    return {
        onRequest: onRequest
    };
    
});
