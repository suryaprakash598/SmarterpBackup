/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/record'],
    /**
     * @param {record} record
     */
    function(record) {

        const TRANSACTION_BODY = {};
        TRANSACTION_BODY.TOTAL_WEIGHT = 'custbody_dilmar_total_item_weight';
        TRANSACTION_BODY.LOCATION = 'location';
        TRANSACTION_BODY.TOTAL_ITEM_COUNT = 'custbody_total_item_count';

        const TRANSACTION_LINE = {};
        TRANSACTION_LINE.ITEM_LIST = 'item';
        TRANSACTION_LINE.LOCATION = 'location';
        TRANSACTION_LINE.ITEM = 'item';
        TRANSACTION_LINE.UNITCOST = 'unitcost';
        TRANSACTION_LINE.ITEM_WEIGHT = 'custcol_dilmar_item_weight';
        TRANSACTION_LINE.TRANSFER_PRICE = 'rate';
        TRANSACTION_LINE.QUANTITY = 'quantity';

        const ITEM = {};
        ITEM.LOCATION_LIST = 'locations';
        ITEM.AVERAGECOSTMLI = 'averagecostmli';
        ITEM.LOCATION = 'location';
        ITEM.AVERAGECOST = 'averagecost';
        ITEM.COST = 'cost';
        ITEM.LASTPURCHASEPRICE = 'lastpurchaseprice';


        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {

        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {
            if(scriptContext.sublistId === TRANSACTION_LINE.ITEM_LIST && scriptContext.fieldId === TRANSACTION_LINE.ITEM) {
                var currRec = scriptContext.currentRecord;
                // update est. unit cost
                try{
                   UpdateAdjustmentLineUntitCost(scriptContext, currRec);
                }catch(e){
                  log.debug('Error', e);
                }
               
            }
        }

        function UpdateAdjustmentLineUntitCost(scriptContext, currRec) {
            var lineUnitCost = currRec.getCurrentSublistValue({
                sublistId : TRANSACTION_LINE.ITEM_LIST,
                fieldId : TRANSACTION_LINE.TRANSFER_PRICE
            }) || '';
          var lineItemType = currRec.getCurrentSublistValue({
                sublistId : TRANSACTION_LINE.ITEM_LIST,
                fieldId : 'itemtype'
            }) || '';
          
           switch (lineItemType) {
                    case 'InvtPart' :
                        lineItemType = 'inventoryitem';
                        break;
        
                    case 'Assembly' :
                        lineItemType = 'assemblyitem';
                        break;
                }

            if(!lineUnitCost || lineUnitCost === 0) {
                var lineItem = currRec.getCurrentSublistValue({
                    sublistId : TRANSACTION_LINE.ITEM_LIST,
                    fieldId : TRANSACTION_LINE.ITEM
                }) || '';

                var fromLocation = currRec.getValue({
                    fieldId : TRANSACTION_BODY.LOCATION
                }) || '';

                if(lineItem) {
                    var newUnitCost = GetItemCost(lineItem, itemLineType,fromLocation);
                    if (newUnitCost) {
                        currRec.setCurrentSublistValue({
                            sublistId: TRANSACTION_LINE.ITEM_LIST,
                            fieldId: TRANSACTION_LINE.TRANSFER_PRICE,
                            value: newUnitCost
                        })
                    }
                }
            }
        }

        function GetItemCost(item, itemLineType,location) {
            var itemAverageCost = '';

            var itemRec = record.load({
                type : record.Type.INVENTORY_ITEM,
                id : item,
                isDynamic : true
            });

            var locationLineCount = itemRec.getLineCount({
                sublistId: ITEM.LOCATION_LIST
            });

            if(locationLineCount) {
                for(var locationLine = 0; locationLine < locationLineCount; locationLine++) {
                    var lineLocation = itemRec.getSublistValue({
                        sublistId: ITEM.LOCATION_LIST,
                        fieldId: ITEM.LOCATION,
                        line: locationLine
                    }) || '';

                    if(lineLocation === location) {
                        itemAverageCost = itemRec.getSublistValue({
                            sublistId: ITEM.LOCATION_LIST,
                            fieldId: ITEM.AVERAGECOSTMLI,
                            line: locationLine
                        })
                        break;
                    }
                }
            }

            if(!itemAverageCost) {
                // get body level average cost
                itemAverageCost = itemRec.getValue({
                    fieldId : ITEM.AVERAGECOST
                }) || '';

                if(!itemAverageCost) {
                    // get body level purchase price
                    itemAverageCost = itemRec.getValue({
                        fieldId: ITEM.COST
                    }) || '';

                    if(!itemAverageCost) {
                        // get body level last purchase price
                        itemAverageCost = itemRec.getValue({
                            fieldId : ITEM.LASTPURCHASEPRICE
                        }) || '';
                    }
                }
            }

            return itemAverageCost;
        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {

        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {
            var currRec = scriptContext.currentRecord;

            var itemLineCount = currRec.getLineCount({
                sublistId: TRANSACTION_LINE.ITEM_LIST
            });

            var totalWeight = 0;
            var totalItemCount = 0;

            if(itemLineCount > 0) {
                for(var itemLine = 0; itemLine < itemLineCount; itemLine++) {
                    var liteItemWeight = currRec.getSublistValue({
                        sublistId: TRANSACTION_LINE.ITEM_LIST,
                        fieldId: TRANSACTION_LINE.ITEM_WEIGHT,
                        line: itemLine
                    }) || 0;

                    liteItemWeight = liteItemWeight ? parseFloat(liteItemWeight) : 0;
                    // add line totals
                    totalWeight = parseFloat(totalWeight) + parseFloat(liteItemWeight);

                    var transferPrice = currRec.getSublistValue({
                        sublistId: TRANSACTION_LINE.ITEM_LIST,
                        fieldId: TRANSACTION_LINE.TRANSFER_PRICE,
                        line: itemLine
                    })  || 0;


                    if(transferPrice === 0) {
                        var itemQuantity = currRec.getSublistValue({
                            sublistId: TRANSACTION_LINE.ITEM_LIST,
                            fieldId: TRANSACTION_LINE.QUANTITY,
                            line: itemLine
                        })  || 0;
                        totalItemCount = parseFloat(totalItemCount) + parseFloat(itemQuantity)
                    }
                }
            }

            // set totals
            currRec.setValue({
                fieldId: TRANSACTION_BODY.TOTAL_WEIGHT,
                value: totalWeight
            });

            currRec.setValue({
                fieldId: TRANSACTION_BODY.TOTAL_ITEM_COUNT,
                value: totalItemCount
            })

            return true;
        }

        return {
            // pageInit: pageInit,
            // fieldChanged: fieldChanged,
            postSourcing: postSourcing,
            /*
            sublistChanged: sublistChanged,
            lineInit: lineInit,
            validateField: validateField,
            validateLine: validateLine,
            validateInsert: validateInsert,
            validateDelete: validateDelete,
            saveRecord: saveRecord
           
            saveRecord: saveRecord */
        };

    });
