/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/record', 'N/search','N/ui/dialog'],

    function(record, search,dialog) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */

        var Drop_ship_Cust;
        var Drop_ship_vendor;
        var item;
        var promotioncode;
		var cust,national_cust;

        function pageInit(scriptContext) {
            
            var currentRecord = scriptContext.currentRecord;

            var customer = currentRecord.getValue("entity");
			cust=customer;
            if (customer != '' && customer != null && customer != undefined && customer != 'undefined') {
             try { 
              var fields = search.lookupFields({
                    type: 'customer',
                    id: customer,
                    columns: ['custentity_drop_ship_customer', 'custentity_preferred_vendor','custentity_dil_customer_nation_yn']
                });

               
                    Drop_ship_Cust = fields.custentity_drop_ship_customer;
                } catch (e) {
                    log.debug('not a Drop Ship Customer');

                }
                try {
                    Drop_ship_vendor = fields.custentity_preferred_vendor;
                } catch (e) {
                    log.debug('not a Drop Ship Customer');

                }
                try {
                    national_cust = fields.custentity_dil_customer_nation_yn;
                } catch (e) {
                    log.debug('not a Drop Ship Customer');

                }
                //log.debug('Drop_ship_Cust pageinit',Drop_ship_Cust);
                //log.debug('Drop_ship_vendor pageinit',Drop_ship_vendor);

            }

            return true;

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            var currentRecord = scriptContext.currentRecord;
            if (scriptContext.fieldId == 'entity') {
                var customer = currentRecord.getValue("entity");
				cust= customer;
 try {
                var fields = search.lookupFields({
                    type: 'customer',
                    id: customer,
                    columns: ['custentity_drop_ship_customer', 'custentity_preferred_vendor','custentity_dil_customer_nation_yn']
                });

               
                    Drop_ship_Cust = fields.custentity_drop_ship_customer;
                } catch (e) {
                    log.debug('not a Drop Ship Customer');

                }
                try {
                    Drop_ship_vendor = fields.custentity_preferred_vendor;
                } catch (e) {
                    log.debug('not a Drop Ship Customer');

                }
               try {
                    national_cust = fields.custentity_dil_customer_nation_yn;
                } catch (e) {
                    log.debug('not a Drop Ship Customer');

                }
                //log.debug('Drop_ship_Cust field changed',Drop_ship_Cust);
                //log.debug('Drop_ship_vendor field changed',Drop_ship_vendor);

            }

        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {
		/*	try{
            //log.debug('sublist chaged called');
			 var currentRecord = scriptContext.currentRecord;
			
            if (scriptContext.sublistId != 'item') return true;
			var line = currentRecord.getCurrentSublistIndex({
                        sublistId: 'item'
                    }); 
					log.debug('line starting',line);
					if(line!=0){
						line=line-1;
					}
          log.debug('something')
            item = currentRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'item',
				line:line
            });
            log.debug('item', item);

            promotioncode = currentRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'custcol_promotion_code',
				line: line
            });
            log.debug('promotion code', promotioncode);
            if (promotioncode) {
                var customrecord_ns_dilmarpromotionsSearchObj = search.create({
                    type: "customrecord_ns_dilmarpromotions",
                    filters: [
                        ["custrecord_promotion_link", "noneof", "@NONE@"],
                        "AND",
                        ["custrecord_promotion_link.startdate", "onorbefore", "today"],
                        "AND",
                        ["custrecord_promotion_link.enddate", "onorafter", "today"],
                        "AND",
                        ["custrecord_ns_promotionitemtest", "anyof", item],
                        "AND",
                        ["custrecordpcode", "is", promotioncode],
						"AND", 
						["custrecord_promotion_link.isinactive","is","F"]
                    ],
                    columns: [
                        search.createColumn({
                            name: "custrecord_promotion_link",
                            label: "custrecord_promotion_link"
                        })
                    ]
                });
                var searchResultCount = customrecord_ns_dilmarpromotionsSearchObj.runPaged().count;
				 if(searchResultCount<1){
					var message=promotioncode+' is not applicable to this item';
					alert(message);
				return true;
				} 
                log.debug("customrecord_ns_dilmarpromotionsSearchObj result count", searchResultCount);
                customrecord_ns_dilmarpromotionsSearchObj.run().each(function(result) {
                    // .run().each has a limit of 4,000 results
                    var p_internalid = result.getValue({
                        name: "custrecord_promotion_link"
                    });
					var couponcode = result.getText({
                        name: "custrecord_promotion_link"
                    });
                    log.debug('p_internalid', p_internalid);
					
					
					 var lineNumber = currentRecord.findSublistLineWithValue({
                sublistId: 'promotions',
                fieldId: 'promocode',
                value: p_internalid //'promotion id'
            });
            log.debug('promotion line number',lineNumber);
       
           
                // if Environment fee is not available at the item list then add the line to the item list with environment fee value
               
                    if (lineNumber == -1)
                    {
						try {
                       var line = currentRecord.getCurrentSublistIndex({
                        sublistId: 'promotions'
                    });
                    currentRecord.insertLine
                        ({
                            sublistId : 'promotions',
                            line: line
                        });
					
                    var promo = currentRecord.setCurrentSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'promocode',
						line: line,
                        value: p_internalid, 
                        ignoreFieldChange:false,
                        forceSyncSourcing: true
                    });
					log.debug('coupon code',parseInt(p_internalid)+1);
					  var coupon = currentRecord.setCurrentSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'couponcode',
                        value:parseInt(p_internalid)+1, // 11 is the internal id of the fixed line item
                        ignoreFieldChange:false,
                        forceSyncSourcing: true
                    }); 

                    currentRecord.commitLine({
                        sublistId: 'promotions'
                    });

                    return true;
                        }catch(e)
                        {
                            log.error(' error adding environment fee line',e.message());
                        }
                    }
					
					
                    
                });
            }
			}catch(e){
				log.debug('error',e);
				return true
			}
			
			
            return true; */

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {


        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {


        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {
			 if (scriptContext.sublistId != 'item') return true;
            log.debug('validateline called');
            var currentRecord = scriptContext.currentRecord;
          var item = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'item'
                    });
			 promotioncode = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_promotion_code'
                    });
			try{		
			 if (promotioncode) {
                var customrecord_ns_dilmarpromotionsSearchObj = search.create({
                    type: "customrecord_ns_dilmarpromotions",
                    filters: [
                        ["custrecord_promotion_link", "noneof", "@NONE@"],
                        "AND",
                        ["custrecord_promotion_link.startdate", "onorbefore", "today"],
                        "AND",
                        ["custrecord_promotion_link.enddate", "onorafter", "today"],
                        "AND",
                        ["custrecord_ns_promotionitemtest", "anyof", item],
                        "AND",
                        ["custrecordpcode", "is", promotioncode],
						"AND", 
						["custrecord_promotion_link.isinactive","is","F"]
                    ],
                    columns: [
                        search.createColumn({
                            name: "custrecord_promotion_link",
                            label: "custrecord_promotion_link"
                        })
                    ]
                });
                var searchResultCount = customrecord_ns_dilmarpromotionsSearchObj.runPaged().count;
				 if(searchResultCount<1){
					var message=promotioncode+' is not applicable to this item';
					alert(message);
				return true;
				} 
                log.debug("customrecord_ns_dilmarpromotionsSearchObj result count", searchResultCount);
                customrecord_ns_dilmarpromotionsSearchObj.run().each(function(result) {
                    // .run().each has a limit of 4,000 results
                    var p_internalid = result.getValue({
                        name: "custrecord_promotion_link"
                    });
					var couponcode = result.getText({
                        name: "custrecord_promotion_link"
                    });
                    log.debug('p_internalid', p_internalid);
					
					
					 var lineNumber = currentRecord.findSublistLineWithValue({
                sublistId: 'promotions',
                fieldId: 'promocode',
                value: p_internalid //'promotion id'
            });
            log.debug('promotion line number',lineNumber);
       
           
                // if promotion is not avalible then add promotion
               
                    if (lineNumber == -1)
                    {
						try {
                       var line = currentRecord.getCurrentSublistIndex({
                        sublistId: 'promotions'
                    });
                    currentRecord.insertLine
                        ({
                            sublistId : 'promotions',
                            line: line
                        });
					
                    var promo = currentRecord.setCurrentSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'promocode',
						line: line,
                        value: p_internalid, 
                        ignoreFieldChange:false,
                        forceSyncSourcing: true
                    });
					log.debug('coupon code',parseInt(p_internalid)+1);
					 /* var coupon = currentRecord.setCurrentSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'couponcode',
                        value:parseInt(p_internalid)+1, // coupon code
                        ignoreFieldChange:false,
                        forceSyncSourcing: true
                    }); */

                   currentRecord.commitLine({
                        sublistId: 'promotions'
                    });

                    return true;
                        }catch(e)
                        {
                            log.error(' error adding promotion',e.message());
                        }
                    }
					
					
                    
                });
			 }
			}catch(e){
				log.debug('error',e);
				return true
			}
            // item=currentRecord.getCurrentSublistValue({
            // sublistId: 'item',
            // fieldId: 'item',
            // });
            // log.debug('item',item);

            // promotioncode=currentRecord.getCurrentSublistValue({
            // sublistId: 'item',
            // fieldId: 'custcol_promotion_code',
            // });	
            // log.debug('promotion code',promotioncode);

            /* var recObj = scriptContext.currentRecord;
            log.debug('record',recObj); */
            //log.debug('Drop_ship_Cust validateLine',Drop_ship_Cust);
            //  log.debug('Drop_ship_vendor validateLine',Drop_ship_vendor);
			
            var dropship_check = currentRecord.getValue("custbody_drop_ship_order");
            if (!Drop_ship_Cust) {

                /*	var l=recObj.setCurrentSublistValue({
                			  sublistId: 'item',
                			  fieldId: 'povendor',
                			  value:null,
                			  ignoreFieldChange: true
                			});
                			log.debug('povendor',l)
                	var m=recObj.setCurrentSublistValue({
                			  sublistId: 'item',
                			  fieldId: 'createpo',
                			 value:null,
                			 ignoreFieldChange: true
                			});		
                			log.debug('createpo',m)
                			log.debug('setting null');
                */
            }
			else {


                var sublistName = scriptContext.sublistId;
                if (sublistName === 'item') {
                    var vendor = currentRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'povendor',
                        value: Drop_ship_vendor[0].value,
                        ignoreFieldChange: true
                    });
                    var po = currentRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'createpo',
                        value: 'DropShip',
                        ignoreFieldChange: true
                    });
                    var item = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'item'
                    });
                    log.debug('item number', item)
                  var item_code = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_dil_item_code'
                    });
                    //search for price level 1
					try{
						var level;
						if(Drop_ship_vendor[0].value==35628){
						//Southern Lube & Fuels
						var custid=3365;
					 	level=get_pricelevel(custid,item_code)
						
					}
					else if(Drop_ship_vendor[0].value==35627) {
						//SOC Energy, Inc.
						var custid=3332;
					 	level=get_pricelevel(custid,item_code)
						
					}
					else if(Drop_ship_vendor[0].value==34651){
						var custid=613;
					 	level=get_pricelevel(custid,item_code)
					}
					else{
						level=[{"value":"1","text":"Level 1"}]
					}
					log.debug('level',level);
                      //if price level empty then take level 1 price
					if(!level){
						level=[{"value":"1","text":"Level 1"}]
					}
                    var price_level1;
					if(!level.price){  
                    var itemSearchObj = search.create({
                        type: "item",
                        filters: [
                            ["pricing.pricelevel", "anyof", level[0].value],
                            "AND",
                            ["internalid", "anyof", item]
                        ],
                        columns: [
                           
                            search.createColumn({
                                name: "unitprice",
                                join: "pricing",
                                label: "Unit Price"
                            })
                        ]
                    });
                   
                    var searchResultCount = itemSearchObj.runPaged().count;
                    log.debug("itemSearchObj result count", searchResultCount);
                    itemSearchObj.run().each(function(result){
						// .run().each has a limit of 4,000 results
						price_level1 = result.getValue({
            name: "unitprice",
            join: "pricing",
            
        }) 
						return true;
					});
                    }
                      else{
					price_level1=level.price;	
					}
                    log.debug('price_level1', price_level1)
                    var porate = currentRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'porate',
                        value: price_level1,
                        ignoreFieldChange: true
                    });
					
					}
					catch (e) {
                log.debug('error', e.toString())
            }
					
                }
				

            }
			// updating dropship order check box if we createing dropship
				var vendor = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'povendor',
                    });
                    var po = currentRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'createpo',
                    });
					if(vendor||po){
						log.debug(vendor)
				var dropship_flag = currentRecord.setValue({
					fieldId: 'custbody_drop_ship_order',
					value: true
				});
					}


            return true;

        }

		function get_pricelevel(custid,item_code){
			var level;
			var customerSearchObj = search.create({
   type: "customer",
   filters:
   [
      ["internalid","anyof",custid]
   ],
   columns:
   [
      search.createColumn({name: "itempricinglevel", label: "Item Pricing Level"}),
      search.createColumn({name: "itempricingunitprice", label: "Item Pricing Unit Price"}),
      search.createColumn({name: "pricingitem", label: "Pricing Item"})
   ]
});
var searchResultCount = customerSearchObj.runPaged().count;
log.debug("customerSearchObj result count",searchResultCount);
customerSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var customer_item= result.getValue({
            name: "pricingitem"
        })
  log.debug('customer_item',customer_item);
  if(customer_item==item_code){
	  var item_price= result.getValue({
            name: "itempricingunitprice"
        });
		level={"price":item_price};
		return true;
  }
   return true;
});

	if(level){
		return level;
	}
			var fields = search.lookupFields({
                    type: 'customer',
                    id: custid,
                    columns: ['pricelevel']
                });

                try {
                    level = fields.pricelevel;
                } catch (e) {
                    log.debug('price level is not there');
					level=1;

                }
				return level;
		}

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {
			var currentRecord = scriptContext.currentRecord;

    var drop_ship = currentRecord.getValue({
        fieldId: 'custbody_drop_ship_order'
    });

    if (drop_ship&&national_cust){
		var numLines = currentRecord.getLineCount({
			sublistId: 'item'
			});
			for (var i =0; i < numLines; i++) {
				var item = currentRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'item',
						line:i
                    });
					if(item!=20){  //20 is env fee 
				var vendor = currentRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'povendor',
						line:i
                    });
                    var po = currentRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'createpo',
						line: i
                    });
					if(!vendor|| !po){
					/* 	
					dialog.alert({
            title: 'Drop Ship Order ',
            message: 'Please enter PO Vendor and Create PO for all items'
        }); */
        //return false;
		alert('Please enter PO Vendor and Create PO for all items');
				return false;
					}
					
					}
			}
			
			
    }
	var promo_numLines = currentRecord.getLineCount({
			sublistId: 'promotions'
			});
			for (var i =0; i < promo_numLines; i++) {
				var purchasediscount = currentRecord.getSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'purchasediscount',
						line:i
                    });
					if(purchasediscount>=0){
					var promo_name = currentRecord.getSublistValue({
                        sublistId: 'promotions',
                        fieldId: 'promocode_display',
						line:i
                    });
                      log.debug('promo name',promo_name);
						var msg='Please check the '+ promo_name+'.The price offered is lowered than the promotional price, so this promotion will not be applied. Please remove the promotion code to proceed with order.'
						alert(msg);
				return false;
					}

        }
		return true
		}

        return {
            pageInit: pageInit,
            fieldChanged: fieldChanged,
            /*postSourcing: postSourcing,*/
           // sublistChanged: sublistChanged,
            //lineInit: lineInit,
            //validateField: validateField,
            validateLine: validateLine,
            /*validateInsert: validateInsert,
            validateDelete: validateDelete,*/
            saveRecord: saveRecord
        };

    });