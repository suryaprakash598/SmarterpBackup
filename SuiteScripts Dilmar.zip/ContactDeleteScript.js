/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/search'],
/**
 * @param {record} record
 */
function(record,search) {
   
    /**
     * Definition of the Scheduled script trigger point.
     *
     * @param {Object} scriptContext
     * @param {string} scriptContext.type - The context in which the script is executed. It is one of the values from the scriptContext.InvocationType enum.
     * @Since 2015.2
     */
    function execute(context) {
    	var invoices=[];
    	var contactSearchObj = search.create({
							   type: "contact",
							   filters:
							   [
							   ],
							   columns:
							   [
								  "internalid"
							   ]
							});
				var pagedData = contactSearchObj.runPaged();
				pagedData.pageRanges.forEach(function (pageRange){
					var mypage = pagedData.fetch({index: pageRange.index});
					mypage.data.forEach(function(result){
							   // .run().each has a limit of 4,000 results
							   try{
									var deletedrecordid = record.delete({
									   type: record.Type.CONTACT,
									   id: result.getValue('internalid')
									});
								//	log.debug("ID sent and Deleted ", ' delted ' + deletedrecordid);
									}
								catch(e)
									{
										log.error(" Error for Contact ID " + result.getValue('internalid')+' '+e.message);
									}
							});
    
				});
    }
    
   
    return {
        execute: execute
    };
    
});
