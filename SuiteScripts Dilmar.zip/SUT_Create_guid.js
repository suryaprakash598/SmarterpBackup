 /* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\
 ||   This script is a tool to help develop SFTP connections      ||
 ||   in Suitescript 2.0                                          ||
 ||                                                               ||
 ||                                                               ||
 ||  Version Date         Author        Remarks                   ||
 ||  1.0     Oct 03 2016   Hasini    Initial commit            ||
 ||  1.1     Oct 11 2016   Hasini    Casting Port and Timeout  ||
 ||                                     to Number                 ||
  \= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */
 
var HTTPSMODULE, SFTPMODULE, SERVERWIDGETMODULE;
var HOST_KEY_TOOL_URL = 'https://ursuscode.com/tools/sshkeyscan.php?url=';
 
/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *@NModuleScope Public
 */
define(["N/https", "N/sftp", "N/ui/serverWidget","N/log","N/file"], runSuitelet);
 
//********************** MAIN FUNCTION **********************

function runSuitelet(https, sftp, serverwidget,log ,file){
    HTTPSMODULE= https;
    SERVERWIDGETMODULE= serverwidget;
    SFTPMODULE= sftp;
    
	var returnObj = {};
	returnObj.onRequest = execute;
	return returnObj;
}
 
function execute(context){
    var method = context.request.method;
    
  	var form = getFormTemplate(method);
    
    if (method == 'GET') {
        form = addSelectorFields(form);
    }
    
    if (method == 'POST') {
        var selectaction = context.request.parameters.selectaction;
        if(selectaction == 'getpasswordguid'){
            form = addPasswordGUID1Fields(form);
            
        }else {
			
			log.debug('POST before',selectaction);
            var password = context.request.parameters.password; 
			log.debug('POST password',password);
            var restricttoscriptids = context.request.parameters.restricttoscriptids;
            var restricttodomains = context.request.parameters.restricttodomains;
            log.debug('restricttoscriptids before',restricttoscriptids);
			log.debug('restricttodomains before',restricttodomains);
            if(restricttoscriptids && restricttodomains){
                form = addPasswordGUID2Fields(form, restricttoscriptids, restricttodomains);
            }
               log.debug('POST password',password);
			   
             if(password){
                form.addField({
                    id : 'passwordguidresponse',
                    type : SERVERWIDGETMODULE.FieldType.LONGTEXT,
                    label : 'PasswordGUID Response',
                    displayType: SERVERWIDGETMODULE.FieldDisplayType.INLINE
                }).defaultValue = password;
            } 
			
        }
    }
    
  	context.response.writePage(form);
  	return;
}
 
function addSelectorFields(form){
    var select = form.addField({
        id: 'selectaction',
        type: SERVERWIDGETMODULE.FieldType.SELECT,
        label: 'Select Action'
    });
    select.addSelectOption({
        value: 'getpasswordguid',
        text: 'Get Password GUID',
    });  
    select.addSelectOption({
        value: 'gethostkey',
        text: 'Get Host Key'
    });  
    select.addSelectOption({
        value: 'downloadfile',
        text: 'Download File'
    });
    return form;
}
 
function addPasswordGUID1Fields(form){
 form.addField({
        id : 'restricttoscriptids',
        type : SERVERWIDGETMODULE.FieldType.TEXT,
        label : 'Restrict To Script Ids',
    }).isMandatory = true;
   form.addField({
        id : 'restricttodomains',
        type : SERVERWIDGETMODULE.FieldType.TEXT,
        label : 'Restrict To Domains',
    }).isMandatory = true;
    
    return form;
}

function addPasswordGUID2Fields(form, restrictToScriptIds, restrictToDomains)
{
	
	 log.debug('POST restrictToScriptIds=>',restrictToScriptIds+'restrictToDomains=>'+restrictToDomains);
    var password_text=form.addCredentialField({
        id : 'password',
        label : 'Password',
        restrictToScriptIds: restrictToScriptIds.replace(' ', '').split(','),
        restrictToDomains: restrictToDomains.replace(' ', '').split(','),
    });
	
	log.debug('POST password_text',password_text);
    return form;
}
 
function getFormTemplate(){
    var form = SERVERWIDGETMODULE.createForm({
        title : 'SFTP Helper Tool'
    });
    form.addSubmitButton({
        label : 'Submit'
    });
    
    return form;
}

