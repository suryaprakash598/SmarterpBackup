	/**
	 * @NApiVersion 2.x
	 * @NScriptType ScheduledScript
	 *@NAmdConfig  ./JsLibraryConfig.json

	Owner			Date 			Modifications
	Surya			23/06/2021		custbody_dil_so_shell_sales_order_num filter changes from "is" to "contains"
	 */
	define(['N/search', 'N/file', 'N/record', 'underscore', 'SuiteScripts/RecurlyLib', 'N/email'],

	    function (search, file, record, underscore, RECURLY_MODULE, email) {

	    //Load saved search
	    function execute(scriptContext) {
	        try {

	            var orderIds = [];
	            var files = searchFiles();
	            for (var f = 0; f < files.length; f++) {
	                var csvFile = file.load({
	                    id: files[f]
	                });
	                var dataArr = RECURLY_MODULE.csvToArr(csvFile.getContents());
	                //log.debug('dataArr',dataArr);

	                var shellInvoiceNumber = dataArr[1][1];
	                var shellsalesorder = dataArr[1][2]; //'0254141452';//
	                var salesorderNumber = dataArr[1][46];
	                log.debug('shellsalesorder', shellsalesorder);
	                //log.debug('salesorderNumber',salesorderNumber);
	                var soid = searchShellSalesOrder(shellsalesorder);
	                log.debug('soid', soid);
					/* if(soid=='')
					{
						shellsalesorder = shellsalesorder.replace(/^0+/, '');
						soid = searchShellSalesOrder(shellsalesorder);
					} */
	                //return true;
	                if (soid) {
	                    var invoiceData = searchSO(soid);
	                    log.debug('invoiceData', invoiceData);
	                    var recId = '';
	                    var soObj = '';
	                    var docNumber = '';
	                    if (Object.keys(invoiceData).length) {

	                        record.submitFields({
	                            type: 'invoice',
	                            id: invoiceData.invoiceID,
	                            values: {
	                                custbody_shell_invoice_number: shellInvoiceNumber
	                            },
	                            options: {
	                                enableSourcing: !1,
	                                ignoreMandatoryFields: !0
	                            }
	                        });
	                        orderIds.push({
	                            'fileid': files[f],
	                            'shellInvoiceNumber': shellInvoiceNumber,
	                            'shellsalesorder': shellsalesorder,
	                            'salesorderNumber': salesorderNumber,
	                            'tranid': invoiceData.tranid,
	                            'invoiceID': invoiceData.invoiceID
	                        })
	                        if (orderIds.length) {
	                            createCustomRecord(orderIds);
	                            sendEmail(orderIds);
	                        }
	                    }

	                }
	            }
	        } catch (e) {
	            log.debug('error', e.toString());
	        }
	    }
	    function searchSO(soid) {
	        try {
	            var invoiceSearchObj = search.create({
	                type: "invoice",
	                filters:
	                [
	                    ["type", "anyof", "CustInvc"],
	                    "AND",
	                    ["createdfrom", "anyof", soid],
	                    "AND",
	                    ["mainline", "is", "T"]
	                ],
	                columns:
	                [
	                    "internalid",
	                    "tranid",
	                    "statusref"
	                ]
	            });
	            var searchResultCount = invoiceSearchObj.runPaged().count;
	            var invoiceObj = {};
	            invoiceSearchObj.run().each(function (result) {
	                // .run().each has a limit of 4,000 results
	                invoiceObj.invoiceID = result.getValue({
	                    name: 'internalid'
	                });
	                invoiceObj.tranid = result.getValue({
	                    name: 'tranid'
	                });
	                invoiceObj.status = result.getValue({
	                    name: 'statusref'
	                });
	                return true;
	            });
	            return invoiceObj;
	        } catch (e) {
	            log.debug('Error in SearchSO', e.toString());
	        }
	    }
	    function searchFiles() {
	        try {
	            var fileSearchObj = search.create({
	                type: "file",
	                filters:
	                [
	                    ["folder", "anyof", "1247"]
	                ],
	                columns:
	                [
	                    "internalid"
	                ]
	            });
	            var searchResultCount = fileSearchObj.runPaged().count;
	            //log.debug("fileSearchObj result count",searchResultCount);
	            var arr = [];
	            fileSearchObj.run().each(function (result) {
	                // .run().each has a limit of 4,000 results
	                arr.push(result.getValue({
	                        name: 'internalid'
	                    }));
	                return true;
	            });
	            return arr;
	        } catch (e) {
	            log.debug('error in searchFiles', e, toString());
	        }
	    }
	    function searchShellSalesOrder(shellsalesorder) {
	        try {
	            log.debug('shellsalesorder', shellsalesorder);
	            var salesorderSearchObj = search.create({
	                type: "salesorder",
	                filters:
	                [
	                    ["type", "anyof", "SalesOrd"],
	                    "AND",
	                    ["custbody_dil_so_shell_sales_order_num", "contains", shellsalesorder],
	                    "AND",
	                    ["mainline", "is", "T"]
	                    //,"AND",["status","anyof","SalesOrd:G"] //Sales Order:Billed //,"SalesOrd:E" Sales Order:Pending Billing/Partially Fulfilled
	                ],
	                columns:
	                [
	                    "internalid"
	                ]
	            });
	            var searchResultCount = salesorderSearchObj.runPaged().count;
	            //log.debug("salesorderSearchObj result count",searchResultCount);
	            var soid = '';
	            salesorderSearchObj.run().each(function (result) {
	                // .run().each has a limit of 4,000 results
	                soid = result.getValue({
	                    name: 'internalid'
	                });
	                return true;
	            });
	            return soid;
	        } catch (e) {
	            log.debug('error in searchShellSalesOrder', e.toString());
	        }
	    }
	    function createCustomRecord(arr) {
	        try {

	            //redirect.toSuitelet({scriptId:1909,deploymentId:1,parameters:{'fileid':1}});
	            log.debug('arr createCustomRecord', arr);
	            var customRecObj = record.create({
	                type: 'customrecord_edi_cfd_payment',
	                isDynamic: !0
	            });

	            for (var i = 0; i < arr.length; i++) {

	                customRecObj.setValue({
	                    fieldId: 'custrecord_cfd_document_number',
	                    value: arr[i].salesorderNumber
	                });
	                customRecObj.setValue({
	                    fieldId: 'custrecord_dil_shell_invoice_number',
	                    value: arr[i].shellInvoiceNumber
	                });
	                customRecObj.setValue({
	                    fieldId: 'custrecord_dil_shell_salesorder',
	                    value: arr[i].shellsalesorder
	                });
	                customRecObj.setValue({
	                    fieldId: 'custrecord_dil_shell_ns_invoice_number',
	                    value: arr[i].tranid
	                });
	            }
	            var id = customRecObj.save();
	            for (var i = 0; i < arr.length; i++) {
	                record.attach({
	                    record: {
	                        type: 'file',
	                        id: arr[i].fileid,
	                    },
	                    to: {
	                        type: 'customrecord_edi_cfd_payment',
	                        id: id
	                    }
	                })
	            }
	        } catch (e) {
	            log.debug('error', e.toString());
	        }

	    }
	    function sendEmail(arr) {
	        try {
	            var senderId = -5;
	            log.debug('arr sendEmail', arr);
	            var recipientId = ['amber@dilmar.com'];
	            var subject = 'EDI CFD Files';
	            var body = 'Hi, EDI CFD processed files';
	            body += '<table><tr><th>Document Number</th><th>File</th></tr>';
	            var ids = moveFilesToProcessed(arr);
	            /* for (var i = 0; i < arr.length; i++) {
	            body += '<tr>';
	            body += '<td>' + arr[i].tranid + '</td><td>' + ids[i].fileid + '</td>';
	            body += '</tr>';
	            }
	            body += '</table>';
	            email.send({
	            author: senderId,
	            recipients: recipientId,
	            cc: cclist,
	            bcc: bcclist,
	            subject: subject,
	            body: body
	            }); */

	        } catch (e) {
	            log.debug('error', e.toString());
	        }
	    }
	    function moveFilesToProcessed(fileArr) {
	        try {
	            var arr = [];
	            for (var i = 0; i < fileArr.length; i++) {
	                var proceefile = file.load({
	                    id: fileArr[i].fileid
	                });
	                if (proceefile.fileType == 'CSV') {
	                    var newFileName = 'Processed_' + proceefile.name;
	                    proceefile.name = newFileName;
	                    proceefile.folder = 1248;
	                    //submit the file so that the new file name would be saved
	                    var id = proceefile.save();
	                    arr.push(id);
	                }
	            }
	            return arr;

	        } catch (e) {
	            log.debug('Error', e.toString())
	        }
	    }

	    return {
	        execute: execute
	    };

	});