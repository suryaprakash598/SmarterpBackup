/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/format', 'N/record','N/ui/dialog','N/runtime','N/render','N/file','N/email'],
/**
 * @param {format} format
 * @param {record} record
 */
function(format, record,dialog,runtime,render,file,email) {


   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(context) {
    	
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(context) {
    	if (context.type !== context.UserEventType.CREATE)
            return;
    	var newRecord = context.newRecord;
    	var custArray = [];
    	var scriptObj = runtime.getCurrentScript();
		var folderid =scriptObj.getParameter({name: 'custscript_dil_tran_pdf_folder'}); 
        var email_author = scriptObj.getParameter({name: 'custscript_dil_payment_email_author'});
		var attachment;
		 var objRecord = record.load({
             type: record.Type.EMAIL_TEMPLATE, 
             id: 15,
             isDynamic: true
        		 });
		 var email_body = objRecord.getValue({
              fieldId: 'content'
          });
		 var email_sub = objRecord.getValue({
			 fieldId:'subject'
		 })
		 
    	var deposit_acct = newRecord.getValue({
    		fieldId: 'custrecord_dil_bulk_pay_deposit_to_acct'
    		})
    	var posting_period = newRecord.getValue({
    		fieldId: 'custrecord_dil_bulk_pay_posting_period'
    	})
    	
    	var payCount = newRecord.getLineCount({
			sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id'
		});
	  
		for (var i = 0; i < payCount; i++){
			
				
				var applied =  newRecord.getSublistValue({
					sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					fieldId: 'custrecord_dil_bulk_pay_apply_dtl',
					line: i
				});
				if (applied){
					var custid = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_cust_dtl',
						line: i
					});
				var custpos = custArray.indexOf(custid);
				if (custpos == -1){custArray.push(custid)};
				};
		}
		log.debug('array length',custArray.length);
		custArray.forEach(function(result){
			var total_payment =0;
			log.debug('customerid',result);
			var selected_custid = result;
			 var dataarray=[];	
			for (var j = 0; j < payCount; j++){
				 var tranData = new Object(); 
					
				var for_custid = newRecord.getSublistValue({
					sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					fieldId: 'custrecord_dil_bulk_pay_cust_dtl',
					line: j
				});
				var to_apply = newRecord.getSublistValue({
					sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
					fieldId: 'custrecord_dil_bulk_pay_apply_dtl',
					line: j
				});
				if (for_custid == selected_custid && to_apply){
					
					var invid = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_refno_dtl',
						line: j
					});
					var paydt = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_paydt_dtl',
						line: j
					});
					var payamt = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_pymnt_amt_dtl',
						line: j
					});
					var pymntmethod = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_buik_pay_pymnt_method_dtl',
						line: j
					});
					var custemail = newRecord.getSublistValue({
						sublistId: 'recmachcustrecord_dil_bulk_pay_hdr_id',
						fieldId: 'custrecord_dil_bulk_pay_cust_email_dtl',
						line: j
					});
					total_payment = total_payment + payamt;
					tranData["invid"] = invid;
					tranData["paydt"] = format.parse({value:paydt, type: format.Type.DATE});
					tranData["payamt"]=payamt;
					tranData["total_pay"]=total_payment;
					tranData["pay_method"]=pymntmethod;
					tranData["emailaddress"]=custemail;
					dataarray.push(tranData);
					   log.debug('tran data array inv id',invid + pymntmethod);

				}
			}
			log.debug('dataarray length',dataarray.length);
			var pymntRecord = record.create({
				type : record.Type.CUSTOMER_PAYMENT,
				isDynamic: true,
				});
				pymntRecord.setValue('customer',selected_custid);
				pymntRecord.setValue('undepfunds','F');
				pymntRecord.setValue('account', deposit_acct);
				pymntRecord.setValue('trandate', dataarray[0].paydt);
				pymntRecord.setValue('postingperiod', posting_period);
                pymntRecord.setValue('paymentmethod',dataarray[0].pay_method);
          log.debug('payment method',dataarray[0].pay_method);
			var invcount = pymntRecord.getLineCount({
				sublistId: 'apply'
			})
			log.debug('invoice count in payment record',invcount);
			dataarray.sort();
			for (k = 0 ; k < dataarray.length; k++)
				{
				   log.debug('data array inv id',dataarray[k].invid);
					
				 for (inv = 0; inv < invcount; inv++)
					 {
					   var invinternalid = pymntRecord.getSublistValue({
						   sublistId: 'apply',
						   fieldId: 'refnum',
						   line: inv
					   });
					   log.debug('invoice internal id and data array inv id',invinternalid +' '+dataarray[k].invid);
					   if (dataarray[k].invid == invinternalid)
						   {
						   pymntRecord.selectLine({
							   sublistId: 'apply',
							   line: inv});
						   
						   
						   pymntRecord.setCurrentSublistValue({
						    	sublistId:'apply',
						    	fieldId: 'apply',
						    	value: true
						    });
						    pymntRecord.setCurrentSublistValue({
						    	sublistId: 'apply',
						    	fieldId: 'amount',
						    	value: dataarray[k].payamt
						    });
						  /*  pymntRecord.setCurrentSublistValue({
						    	sublistId: 'apply',
						    	fieldId: 'paymentmethod',
						    	value: dataarray[k].pay_method
						    })*/
						    
						    
						    log.debug('invoice internal id',invinternalid);
						    break; 
						   }
					 
					 }
				 
				}
			 //pymntRecord.setValue('payment',dataarray[k].total_pay);
				
			var payrecid = pymntRecord.save();
			var today_date = new Date();
			var year =0, month=0, day = 0;
			year = today_date.getFullYear();
			month = today_date.getMonth() + 1;
			month = (month < 10) ? "0".concat(month) : month.toString();
			day = today_date.getDate();
			day = (day < 10) ? "0".concat(day) : day.toString();
			var datestring = year +month.toString() +day.toString();
			var pdf_file_name = payrecid +"_"+ datestring;
		
       
			try{
				var transactionFile = render.transaction({
				entityId: payrecid,
				printMode: render.PrintMode.PDF,
				//formId: custom_form
				});
			}catch(e)
			{
				log.error(' render error',e.toString())
			}
			try{
					var fileObj = file.create({
								name: pdf_file_name,
								fileType: file.Type.PDF,
								contents: transactionFile.getContents(),
								folder: folderid
							});

					var pdfFileId = fileObj.save();
					log.debug( 'pdffile' , pdfFileId + ' saved');
				}catch(e)
				{
					log.error(' render error',e.toString())
				}
			try{
				    attachment = file.load({
					id: pdfFileId
					});
				}catch(e)
					{log.error('File Attachment Error ',e.toString());}
				 
				try{
						log.debug('send email','coming in sending email'+email_sub + ' '+ dataarray[0].emailaddress);
						email.sendBulk({
							 author: email_author,
							 recipients: dataarray[0].emailaddress, 
							 subject: email_sub,
							 body: email_body,
							 attachments: [attachment],
							// replyTo: return_email,
							 relatedRecords : {
							 transactionId: payrecid }
							});
					}
					catch (e)
						{
							log.error('Invalid/No Email address Error ',e.toString());
								email.send({
									 author: email_author,
									 recipients: 'credit@dilmar.com', //default email address to send for any improper email addresses,
									 subject: email_sub + 'Error while sending email',
									// replyTo: return_email,
									 body: email_body + '<br\/>'+e.toString(),
									 attachments: [attachment]
								});			
						}

		})
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
    
});
