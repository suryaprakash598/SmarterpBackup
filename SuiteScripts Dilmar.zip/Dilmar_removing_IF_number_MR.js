/**
 * @NApiVersion 2.0
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/email', 'N/record', 'N/search', 'N/config', 'N/runtime', 'N/file','N/render','N/format','N/task'],
/**
 * @param {email} email
 * @param {record} record
 * @param {search} search
 * @param {config} config
 * @param {runtime} runtime
 */
function(email, record, search, CONFIG, runtime, file,render,format,task) {
   
    
    function getInputData() {
    	var salesorderSearchObj = search.create({
   type: "salesorder",
   filters:
   [
      ["type","anyof","SalesOrd"], 
      "AND", 
      ["status","noneof","SalesOrd:B","SalesOrd:H","SalesOrd:F"], 
      "AND", 
      ["custcol_first_itemfulfilment","noneof","@NONE@"], 
      "AND", 
      ["quantitybilled","equalto","0"], 
      "AND", 
      ["quantitypicked","equalto","0"]
   ],
   columns:
   [
      search.createColumn({name: "internalid", label: "Internal ID",summary: "GROUP"})
      
   ]
});
var searchResultCount = salesorderSearchObj.runPaged().count;
var so_id=[];
log.debug("salesorderSearchObj result count",searchResultCount);
salesorderSearchObj.run().each(function(result){
	var internalid = result.getValue({
            name: "internalid",
            summary: "GROUP"
        })
   // .run().each has a limit of 4,000 results
   so_id.push(internalid);
   return true;
});
return so_id;
    }

    
    function map(context) {
		try{
		var so_id = context.value;
		log.debug('so id',so_id);
		var saleOrder = record.load({
                    type: 'salesorder',
                    id: so_id,
                    isDynamic: false,
                });
				var lineCount = saleOrder.getLineCount({
    sublistId: 'item'
});
log.debug('lineCount',lineCount);
//for each line set the "itemreceive" field to true
for (var i = 0; i < lineCount; i++) {
	
  var quantity_billed=saleOrder.getSublistValue({
      sublistId: 'item',
      fieldId: 'quantitybilled',
	  line: i
  });
 
var quantity_picked=saleOrder.getSublistValue({
      sublistId: 'item',
      fieldId: 'quantitypicked',
	  line: i
  });
  
  var first_fulfilment=saleOrder.getSublistValue({
      sublistId: 'item',
      fieldId: 'custcol_first_itemfulfilment',
	  line: i
  });
	 
  if((quantity_billed==0||!quantity_billed)&&(quantity_picked==0||!quantity_picked)&&first_fulfilment){
	  log.debug('quantity_billed',quantity_billed);
	  log.debug('quantity_picked',quantity_picked);
	  log.debug('first_fulfilment',first_fulfilment);
	 lineNumber=saleOrder.setSublistValue({
      sublistId: 'item',
      fieldId: 'custcol_first_itemfulfilment',
	  line: i,
	  value:null
  });
  }
    }
	var id=saleOrder.save();
	log.debug('after saving id',id)
    }
	catch(e){
		log.debug('error',e)
	}
	}

    
    function reduce(context) {

    }

    function summarize(summary) {
			 
    }

    return {
        getInputData: getInputData,
        map: map,
        //reduce: reduce,
        //summarize: summarize
    };
    
});
