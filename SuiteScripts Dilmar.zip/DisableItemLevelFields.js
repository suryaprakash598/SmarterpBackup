/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/runtime'],

function(runtime) {
    
  	function disablefields(recordid)
	{
      try{
		var itemsublist = recordid.getSublist({sublistId:'item'});
		var price = itemsublist.getColumn({fieldId: 'price'});
		var taxcode = itemsublist.getColumn({fieldId: 'taxcode'});
        var quantity = itemsublist.getColumn({fieldId: 'quantity'});
        var requestdate = itemsublist.getColumn({fieldId: 'requesteddate'});
         var billaddresslist = recordid.getField('billaddresslist');
         var location_hdr = recordid.getField('location');
        var description = itemsublist.getColumn({fieldId: 'description'});
         var istaxable = itemsublist.getColumn({fieldId: 'istaxable'});
         var productline = itemsublist.getColumn({fieldId: 'class'});
         var units = itemsublist.getColumn({fieldId: 'units'});
         var salesrep = recordid.getField({fieldId:'salesrep'});
        var opportunity_fld = recordid.getField({fieldId:'opportunity'});
        log.debug('opportunity field visible',opportunity_fld.isVisible);
        if (opportunity_fld.isVisible)
        {   var opportunity_val = recordid.getValue('opportunity');
            log.debug('opportunity_val',opportunity_val);
        	if (opportunity_val.length > 0)
				price.isDisabled = true;
        };
        salesrep.isDisabled = true;
		taxcode.isDisabled = true;
        description.isDisabled = true;
        location_hdr.isDisabled = true;
    //    istaxable.isDisabled = true;
        productline.isDisabled = true;
        units.isDisabled = true;
        billaddresslist.isDisabled = true;
       // if (requestdate.isVisible) {requestdate.isVisible = false;}
       
      } catch(e)
        {
          log.error('error while defaulting',e.toString());
        }
	}

    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(context) {
    	var recordid = context.currentRecord;
		var userObj = runtime.getCurrentUser();	
			var userRole = userObj.role;
      try{
			if (userRole === 1086 || userRole === 1087 || userRole === 1099)
			{	
              	var billaddresslist = recordid.getField('billaddresslist');
				var saleseffectivedate = recordid.getField('saleseffectivedate');
			    var itemsublist = recordid.getSublist({sublistId:'item'});
				var price = itemsublist.getColumn({fieldId: 'price'});
				var taxcode = itemsublist.getColumn({fieldId: 'taxcode'});
				var quantity = itemsublist.getColumn({fieldId: 'quantity'});
				var salesrep = recordid.getField('salesrep');
            	 var requestdate = itemsublist.getColumn({fieldId: 'requesteddate'});
         	var billaddresslist = recordid.getField('billaddresslist');
         	var location_hdr = recordid.getField('location');
        	var description = itemsublist.getColumn({fieldId: 'description'});
         	var istaxable = itemsublist.getColumn({fieldId: 'istaxable'});
         	var productline = itemsublist.getColumn({fieldId: 'class'});
         	var units = itemsublist.getColumn({fieldId: 'units'});
       		var amount = itemsublist.getColumn({fieldId: 'amount'});
              var createdfrom = recordid.getField('createdfrom');
                var rectype = recordid.type;
             log.debug('rectype',rectype);
             // price.isDisabled = true; 
              taxcode.isDisabled = true;
              salesrep.isDisabled = true;
              taxcode.isDisabled = true;
              description.isDisabled = true;
           
          //    istaxable.isDisabled = true;
              productline.isDisabled = true;
              units.isDisabled = true;
			  amount.isDisabled = true;
			 if (billaddresslist !== null) billaddresslist.isDisabled = true;
             if (saleseffectivedate !== null)	saleseffectivedate.isDisabled = true;
              
              if (createdfrom !== null)
                {
                 var source = recordid.getValue({fieldId:'createdfrom'});
                  if (source.length > 0)
                       location_hdr.isDisabled = true;
                  else
                       location_hdr.isDisabled = false;
                }
			 //if (salesrep.isVisible)	salesrep.isDisabled = true;
            
              if (rectype != 'returnauthorization')
			{	var shipcarrier = recordid.getField('shipcarrier');
				//var opportunity = recordid.getField('opportunity');
              if (shipcarrier.isVisible) shipcarrier.isDisabled = true;
			  //if (opportunity.isVisible)	opportunity.isDisabled = true;
            }
			
			}
      }catch(e)
        { log.error('error',e.toString());}
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(context) {

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(context) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(context) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(context) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(context) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(context) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(context) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(context) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(context) {

    }

    return {
        pageInit: pageInit,
    /*    fieldChanged: fieldChanged,
        postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,
        saveRecord: saveRecord */
    };
    
});
