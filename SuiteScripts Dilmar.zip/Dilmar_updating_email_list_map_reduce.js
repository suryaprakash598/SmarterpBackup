/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/redirect','N/search'],

function(record, redirect, search) {
   
    /**
     * Marks the beginning of the Map/Reduce process and generates input data.
     *
     * @typedef {Object} ObjectRef
     * @property {number} id - Internal ID of the record instance
     * @property {string} type - Record type id
     *
     * @return {Array|Object|Search|RecordRef} inputSummary
     * @since 2015.1
     */
    function getInputData() {
    	var invoiceSearchObj = search.create({
   type: "invoice",
   filters:
   [
      ["type","anyof","CustInvc"], 
      "AND", 
      [["formulatext: {messages.isemailed}","isempty",""],"OR",["custbody_dil_invoicemanuallysent","is","T"]], 
      "AND", 
      ["mainline","is","T"], 
      "AND", 
      ["customer.custentity_dil_customer_nation_yn","is","F"], 
      "AND", 
      ["status","anyof","CustInvc:A"], 
      "AND", 
      ["terms","noneof","19"],
	  "AND", 
      ["datecreated","onorafter","9/16/2021 12:00 am"], 
      "AND", 
      ["custbody_email_list_updated","is","F"]
   ],
   columns:
   [
     
      search.createColumn({
         name: "internalid",
         summary: "GROUP",
         label: "Internal ID"
      }),
      search.createColumn({
         name: "tranid",
         summary: "GROUP",
         label: "Document Number"
      })
      
   ]
});
var arr=[];
var searchResultCount = invoiceSearchObj.runPaged().count;
log.debug("invoiceSearchObj result count",searchResultCount);
invoiceSearchObj.run().each(function(result){
   // .run().each has a limit of 4,000 results
   var invoice_id = result.getValue({
            name: "internalid",
            summary: "GROUP"
        })
	arr.push(invoice_id);
   return true;
});
return arr;
    }

    /**
     * Executes when the map entry point is triggered and applies to each key/value pair.
     *
     * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
     * @since 2015.1
     */
    function map(context) {
		var rec_id = context.value;
    	try{
    	log.debug('Record ID', rec_id);
				var invoice =record.load({
 type: record.Type.INVOICE,
 id: rec_id
 })
 var entity=invoice.getValue({fieldId:'entity'});
 var email=findEmailList(entity);
 var email_list = email.toString();
 log.debug(entity,email_list);
 var setting_emails = invoice.setValue({
					fieldId: 'custbody_dil_emaillist',
					value:email_list
				});
	var setting_native_email_field = invoice.setValue({
					fieldId: 'email',
					value:email_list
				});
var email_list_updated	=invoice.setValue({
	fieldId: 'custbody_email_list_updated',
					value:true
});		
 
 var id=invoice.save({enableSourcing: true, ignoreMandatoryFields: true});
    	log.debug('invoice',id);
    }
	catch(e){
		log.debug('error',rec_id)
	}
	}
	
	
	// Search for the contacts associated with Customers and Vendors
function findEmailList(entity){
  	var emails = [];
			var contactSearchObj = search.create({
			   type: "contact",
			   filters:
			   [
				  ["isinactive","is","F"], 
				  "AND", 
				  ["email","isnotempty",""], 
                 "AND",
                 ["custentity_dil_contact_inv_notify","is","T"],
				  "AND", 
				  ["company.internalid","anyof",entity]
			   ],
			   columns:
			   [
				  search.createColumn({
				  name: "email"})
				  
			   ]
			});
		
			 var curr_emailaddress,all_emailaddresses;
			contactSearchObj.run().each(function(result){
               if (emails.length <= 10)
              {
                 curr_emailaddress = result.getValue("email");
                 var existing_email = emails.indexOf(curr_emailaddress);
                 if (existing_email == -1)
                    { 
                      all_emailaddresses = all_emailaddresses+curr_emailaddress+";";
                      if (all_emailaddresses.length <= 254)
                      {emails.push(result.getValue("email"));}
                    }
              }
			    return true;
			});
			return emails;
	}
   
   
    /**
     * Executes when the reduce entry point is triggered and applies to each group.
     *
     * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
     * @since 2015.1
     */
    function reduce(context) {

    }


    /**
     * Executes when the summarize entry point is triggered and applies to the result set.
     *
     * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
     * @since 2015.1
     */
    function summarize(summary) {

    }

    return {
        getInputData: getInputData,
        map: map,
        //reduce: reduce,
        //summarize: summarize
    };
    
});
