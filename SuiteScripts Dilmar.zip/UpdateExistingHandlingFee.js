/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/record',],
/**
 * @param {format} format
 * @param {record} record
 */
function(search, record) {

function execute(scriptContext) {
			var invoiceSearchObj = search.create({
                                     type: "invoice",
                                     filters:
                                     [
                                        ["type","anyof","CustInvc"], 
                                        "AND", 
                                        ["custbody_dil_is_national_customer","is","T"], 
                                        "AND", 
                                        ["mainline","is","T"], 
                                        "AND", 
                                        ["status","anyof","CustInvc:A"], 
                                        "AND", 
                                        ["taxline","is","F"], 
                                        "AND", 
                                        ["shipping","is","F"], 
                                        "AND", 
                                        ["cogs","is","F"], 
                                        "AND", 
                                        ["externalid","anyof","@NONE@"]
                                     ],
                                     columns:
                                     [
                                        "internalid",
                                        "tranid",
                                        "entity",
                                        "item",
                                        "amount"
                                     ]
                                  });
                                  
			var searchResultCount = invoiceSearchObj.runPaged().count;
			log.debug("invoiceSearchObj result count",searchResultCount);
			invoiceSearchObj.run().each(function(result){
               try{
			   var objRecord = record.load({
					type : record.Type.INVOICE,
					id: result.getValue('internalid'),
					isDynamic: true
				});
             	objRecord.setValue({
					fieldId: 'memo',
					value: ' ',
					ignoreFieldChange: true
				});
				objRecord.save();
               }catch(e)
                 {
                   log.error('error',e.toString());
                 }
            
			   return true;
			});
}
return {
	execute : execute
}
});