/*******************************************************************************
{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType ScheduledScript
 *
 ******************************************************************************/

define(['N/runtime', 'N/task', 'N/record', 'N/search', 'N/log'], function(
  /** @type {import('N/runtime')} **/ runtime,
  /** @type {import('N/task')}    **/ task,
  /** @type {import('N/record')}  **/ record,
  /** @type {import('N/search')}  **/ search,
  /** @type {import('N/log')}     **/ log
) {

  /**
   * context.type
   *
   * @type {import('N/types').EntryPoints.Scheduled.execute}
   */
  function execute(context) {
    // no return value
		 var arr= [
	117468
	
	
	
	
]
for(var i=0;i<arr.length;i++)
{
	try{
		log.debug(arr[i],'07/05/2021')
		record.submitFields({type:'itemfulfillment',id:arr[i],values:{trandate:'07/05/2021'}});
	}catch(e)
	{
		log.debug('error',e.toString());
	}
}
  }
function convertDate(oldDate)
{
	var a =oldDate;
	log.debug('oldDate',oldDate);
	var d = new Date(a);
	log.debug('d',d);
	var date = (d.getMonth()+1)+'/'+d.getDate()+'/'+d.getFullYear();
	log.debug('date',date);
	return date;
}
  return {
    'execute': execute
  };

});
