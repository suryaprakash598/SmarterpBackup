/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 *@NAmdConfig  ./JsLibraryConfig.json
 
 Owner			Date		Description
 Surya			24/05/2021	Location limited to 5 characters
 Surya			24/05/2021	sales rep and created by limited to 2 characters
 Surya			24/05/2021	Removed decimals on Onhand Qty
 Surya			26/05/2021	Capture Salesrep code from New field Sales rep code
 Surya			15/09/2021	Date created to Date in filter
 */
 define(['N/search', 'N/file', 'underscore','N/encode', 'N/record', 'N/email','SuiteScripts/SFTPConnectionEstablish'],

 function (search, file, underscore, encode, record, email,_SFTPObj) {

 //Load saved search
 function execute(scriptContext) {
     var _mcInvDetail = savedSearchInvoiceDetail(); 
	  var textFile = '';
     for(var i=0;i<_mcInvDetail.length;i++)
	 {
		textFile+= headerRecord(_mcInvDetail[i]);
	 }
	// log.debug('textFile',textFile);
	 var fileObj = file.create({
                 name: 'invoiceDetail'+new Date(),
                 fileType: file.Type.PLAINTEXT,
                 contents: textFile,
                 description: '',
                 encoding: file.Encoding.UTF8,
                 folder: 1250//1086
             });

             //Save the CSV file
             var fileId = fileObj.save()
			 var connectionObj =  _SFTPObj.executeSFTP();
	log.debug('connectionObj',connectionObj);
	var fileData = file.load({id:fileId});
			 if(connectionObj)
			 {
				 connectionObj.upload({
					directory: '/',
					filename: 'invoiceDetail.txt',
					file: fileData,
					replaceExisting: false
					}); 
			 }
 }
 function savedSearchInvoiceDetail() {
     try {
         var arr = [];
          var invoiceSearchObj = search.create({
			   type: "invoice",
			   filters:
			   [
				  ["type","anyof","CustInvc"], 
				   "AND", 
				 ["trandate","within","thismonth"],  
				 // ["trandate","within","6/01/2021","9/17/2021"], 
				  "AND", 
				  ["item.custitem_dilmar_brand","anyof","52"], 
				  "AND", 
				  ["mainline","is","F"], 
				  "AND", 
				  ["taxline","is","F"], 
				  "AND", 
				  ["shipping","is","F"], 
				  "AND", 
				  ["cogs","is","F"]
			   ],
			   columns:
			   [
				 "location",
				  "tranid",
				  "item",
				  search.createColumn({
					 name: "vendorname",
					 join: "item"
				  }),
				  search.createColumn({
					 name: "quantity",
					 join: "appliedToTransaction",
					 label: "Quantity"
				  }),
				  search.createColumn({
					 name: "salesrep",
					 join: "customer" 
				  }),
				  search.createColumn({
					 name: "custrecord_5826_loc_branch_id",
					 join: "location" 
				  }),
				  "quantity",
				  "rate",
				  "createdby"
			   ]
			});
			 
		var searchResultCount = invoiceSearchObj.runPaged().count;
		 invoiceSearchObj.run().each(function(result){
            // .run().each has a limit of 4,000 results
            var obj ={};
            obj.location = result.getText({name:'location'});
            obj.locationCode = result.getValue({  name: "custrecord_5826_loc_branch_id",  join: "location"  });
            obj.docNumber = result.getValue({name:'tranid'});
            obj.salesrep = result.getText({name:'salesrep',join: "customer"});
            obj.salesrepId = result.getValue({name:'salesrep',join: "customer"});
			if(obj.salesrepId){
				var salesrepCode = search.lookupFields({type:'employee',id:obj.salesrepId,columns:['custentity_salesrep_code']});
				obj.salesrep_code = salesrepCode.custentity_salesrep_code;	
			}else{
				obj.salesrep_code='';
			} 
            obj.quantity = result.getValue({name:'quantity'});
            obj.rate = result.getValue({name:'rate'});
            obj.partnumber = result.getText({ name: "item" });
			obj.createdby = result.getText({ name: "createdby" });
			obj.qtyOrdered = result.getValue({name: "quantity", join: "appliedToTransaction"});

            arr.push(obj);
            return true;
         });
         return arr;
     } catch (e) {
         log.debug('Error in savedSearchList', e.toString());
     }
 }
  
 function headerRecord(data) {
	 log.debug('_data',data);
     var tempString = '';
	var _data =  Object.keys(data);
	 var time = '000000';
     if (_data.length) {
		 //LocationID , InvoiceNumber,PartNumber, VendorCode,
		 //CounterPersonID,SalesPersonID,QuantityOrdered,QuantityShipped,UnitPrice
		var vendorcode='MOT';
		 var SalesPersonID=data.salesrep;
		 var createdBy=data.createdby;
		 var QuantityOrdered='';
		/* if(data.location)
		{ */
	 createdBy = createdBy.match(/.{1,2}/g)[0]||'';
	 //SalesPersonID = SalesPersonID!=''?SalesPersonID.match(/.{1,2}/g)[0]:'';
	var locationName = data.locationCode;
		  //locationName = locationName.match(/.{1,5}/g)[0]||'';
         tempString +=  locationName + "\t" +
						data.docNumber + "\t" +
						data. partnumber+ "\t" +
						vendorcode + "\t" +
						 createdBy+ "\t" + 
						data.salesrep_code + "\t" + 
						 (data.qtyOrdered|0) + "\t" + 
						 (data.quantity|0) + "\t" + 
						data.rate+ "\r\n";
		// }
     }
     return tempString;
 }
 function formatDate(date) {
	 if(date)
	 {
		 var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

		if (month.length < 2) 
			month = '0' + month;
		if (day.length < 2) 
			day = '0' + day;

		return [year, month, day].join('');
	 }else{
		 return '        ';
	 }
    
}
 
  function units() {
     var obj = {
         'Bulk': 'GAL',
         '1 Gal': 'GAL',
         'Carton': 'CT',
         'Case': 'CT',
         'Drum': 'EA',
         'Each': 'EA',
         'Ecobox': 'CT',
         'Keg': 'EA',
         'Pail': 'EA',
         'Tote': 'EA'
     };
     return obj;
 }
 
 return {
     execute: execute
 };

});