/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record', 'N/search'],
/**
 * @param{record} record
 * @param{search} search
 */
function(record, search) {

    const TRANSACTION_BODY = {};
    TRANSACTION_BODY.ADJ_LOCATION = 'adjlocation';

    const TRANSACTION_LINE = {};
    TRANSACTION_LINE.INVENTORY_LIST = 'inventory';
    TRANSACTION_LINE.LOCATION = 'location';
    TRANSACTION_LINE.ITEM = 'item';
    TRANSACTION_LINE.UNITCOST = 'unitcost';

    const ITEM = {};
    ITEM.LOCATION_LIST = 'locations';
    ITEM.AVERAGECOSTMLI = 'averagecostmli';
    ITEM.LOCATION = 'location';
    ITEM.AVERAGECOST = 'averagecost';
    ITEM.COST = 'cost';
    ITEM.LASTPURCHASEPRICE = 'lastpurchaseprice';

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {
        if(scriptContext.type === scriptContext.UserEventType.CREATE) {
            var currRec = scriptContext.newRecord;
            var recordId = currRec.id;
            if(CreatedFromInventoryCount(recordId)) {
                var invAdjustment = record.load({
                    type: record.Type.INVENTORY_ADJUSTMENT,
                    id: recordId,
                    isDynamic: true
                });

                var lineCount = invAdjustment.getLineCount({
                    sublistId: TRANSACTION_LINE.INVENTORY_LIST
                });

                if(lineCount > 0) {
                    for(var line = 0; line < lineCount; line++) {
                        invAdjustment.selectLine({
                            sublistId : TRANSACTION_LINE.INVENTORY_LIST,
                            line: line
                        })
                        var lineUnitCost = invAdjustment.getCurrentSublistValue({
                            sublistId : TRANSACTION_LINE.INVENTORY_LIST,
                            fieldId : TRANSACTION_LINE.UNITCOST
                        }) || '';

                        if(!lineUnitCost) {
                            var lineItem = invAdjustment.getCurrentSublistValue({
                                sublistId : TRANSACTION_LINE.INVENTORY_LIST,
                                fieldId : TRANSACTION_LINE.ITEM
                            }) || '';

                            var lineLocation = invAdjustment.getCurrentSublistValue({
                                sublistId : TRANSACTION_LINE.INVENTORY_LIST,
                                fieldId : TRANSACTION_LINE.LOCATION
                            }) || '';

                            if(lineItem) {
                                var newUnitCost = GetItemCost(lineItem, lineLocation);
                                if (newUnitCost) {
                                    invAdjustment.setCurrentSublistValue({
                                        sublistId: TRANSACTION_LINE.INVENTORY_LIST,
                                        fieldId: TRANSACTION_LINE.UNITCOST,
                                        value: newUnitCost
                                    })

                                    invAdjustment.commitLine({
                                        sublistId: TRANSACTION_LINE.INVENTORY_LIST
                                    })
                                }
                            }
                        }
                    }
                }

                invAdjustment.save({
                    enableSourcing : false,
                    ignoreMandatoryFields : true
                })
            }
        }
    }
    
    function CreatedFromInventoryCount(recordId) {
        var searchObj = search.create({
            type: search.Type.INVENTORY_COUNT,
            filters:
            [
                ["mainline", search.Operator.IS, "T"],
                "AND",
                ["applyingtransaction", search.Operator.ANYOF, recordId]
            ],
            columns:
            [
                search.createColumn({name: "tranid"}),
                search.createColumn({name: "applyingtransaction"})
            ]
        });
        var searchResultCount = searchObj.runPaged().count;
        return searchResultCount > 0;
    }

    function GetItemCost(item, location) {
        var itemAverageCost = '';

        var itemRec = record.load({
            type : record.Type.INVENTORY_ITEM,
            id : item,
            isDynamic : true
        });

        var locationLineCount = itemRec.getLineCount({
            sublistId: ITEM.LOCATION_LIST
        });

        if(locationLineCount) {
            for(var locationLine = 0; locationLine < locationLineCount; locationLine++) {
                var lineLocation = itemRec.getSublistValue({
                    sublistId: ITEM.LOCATION_LIST,
                    fieldId: ITEM.LOCATION,
                    line: locationLine
                }) || '';

                if(lineLocation === location) {
                    itemAverageCost = itemRec.getSublistValue({
                        sublistId: ITEM.LOCATION_LIST,
                        fieldId: ITEM.AVERAGECOSTMLI,
                        line: locationLine
                    })
                    break;
                }
            }
        }

        if(!itemAverageCost) {
            // get body level average cost
            itemAverageCost = itemRec.getValue({
                fieldId : ITEM.AVERAGECOST
            }) || '';

            if(!itemAverageCost) {
                // get body level purchase price
                itemAverageCost = itemRec.getValue({
                    fieldId: ITEM.COST
                }) || '';

                if(!itemAverageCost) {
                    // get body level last purchase price
                    itemAverageCost = itemRec.getValue({
                        fieldId : ITEM.LASTPURCHASEPRICE
                    }) || '';
                }
            }
        }

        return itemAverageCost;
    }

    return {
        // beforeLoad: beforeLoad,
        // beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
    
});
