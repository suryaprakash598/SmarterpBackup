/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/search'],
/**
 * @param {record} record
 */
function(record,search) {
   
    /**
     * Definition of the Scheduled script trigger point.
     *
     * @param {Object} scriptContext
     * @param {string} scriptContext.type - The context in which the script is executed. It is one of the values from the scriptContext.InvocationType enum.
     * @Since 2015.2
     */
    function getInputData() {
    
    	var customerSearchObj = search.create({
							   type: "customer",
							   filters:
							   [
							   ],
							   columns:
							   [
								  "internalid"
							   ]
							});
		return customerSearchObj;
	}
			/*	var pagedData = contactSearchObj.runPaged();
				pagedData.pageRanges.forEach(function (pageRange){
					var mypage = pagedData.fetch({index: pageRange.index});
					mypage.data.forEach(function(result){*/
							   // .run().each has a limit of 4,000 result
function map(context) {
    	try{
    	var searchresult = JSON.parse(context.value);
    	var alreadyProcessed = false;
    	var customerid = searchresult.values.internalid.value;
		var companyid = searchresult.values.company.value;
		//log.debug('contactid found: ',contactid);
		context.write({
        	        	key: companyid,
        	        	value: contactid
		});
		}catch(e)
		{ log.error ('error getting details in map section',contactid+' '+companyid+' '+e.toString());
		}
}
    
	
 function reduce(context) {
	var row = JSON.parse(context.values[0]);
      try{
					var custrecordid = record.load({
										type: record.Type.CUSTOMER,
									   id: row.id
									});
								//	log.debug("ID sent and Deleted ", ' delted ' + deletedrecordid);
					var numLines = custrecordid.getLineCount({
										sublistId: 'itempricing'
									});
					log.debug('numLines',numLines);
        if (numLines > 0)
			{		for (var i=numLines; i=0; i--)
					{custrecordid.removeLine({
									sublistId: 'itempricing',
									line: i
								});
                     custrecordid.commitLine({sublistId: 'itempricing'});
					}
					var custid = custrecordid.save();
					log.debug('customerid SAVED ',custid);
				}
      }
				catch(e)
				{
				log.error(" Error for Customer ID " + custid+' '+e.toString());
				}
		
    
 }
   
    return {
        getInputData: getInputData,
      //  map: map,
        reduce: reduce,
    };
    
});
