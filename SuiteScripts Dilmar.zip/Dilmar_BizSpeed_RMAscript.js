	/**
	 * @NApiVersion 2.x
	 * @NScriptType UserEventScript
	 * @NModuleScope SameAccount
	 */
	 
	define(['N/record', 'N/search', 'N/https'],

	    function (record, search, https) {

	    /**
	     * Function definition to be triggered before record is loaded.
	     *
	     * @param {Object} scriptContext
	     * @param {Record} scriptContext.newRecord - New record
	     * @param {string} scriptContext.type - Trigger type
	     * @param {Form} scriptContext.form - Current form
	     * @Since 2015.2
	     */
	    function beforeLoad(scriptContext) {}

	    /**
	     * Function definition to be triggered before record is loaded.
	     *
	     * @param {Object} scriptContext
	     * @param {Record} scriptContext.newRecord - New record
	     * @param {Record} scriptContext.oldRecord - Old record
	     * @param {string} scriptContext.type - Trigger type
	     * @Since 2015.2
	     */
	    function beforeSubmit(scriptContext) {}

	    /**
	     * Function definition to be triggered before record is loaded.
	     *
	     * @param {Object} scriptContext
	     * @param {Record} scriptContext.newRecord - New record
	     * @param {Record} scriptContext.oldRecord - Old record
	     * @param {string} scriptContext.type - Trigger type
	     * @Since 2015.2
	     */
	    function afterSubmit(scriptContext) {
	        try {

	            var type = scriptContext.newRecord.type;
	            var recid = scriptContext.newRecord.id;
				var objrecord = record.load({type:type,id:recid,isDynamic:!0});
	            var customer = objrecord.getText({
	                fieldId: 'entity'
	            });
	            var orderNumber = objrecord.getValue({
	                fieldId: 'tranid'
	            });
				 
				var is_bizspeed_req_sent = objrecord.getValue({
	                fieldId: 'custbody_is_bizspeed_req_sent'
	            });
				 
				log.debug('!is_bizspeed_req_sent',!is_bizspeed_req_sent);
	            var itemCount = objrecord.getLineCount({
	                sublistId: 'item'
	            });
				if(true ) //&&shipmethod==2
				{
					var _RMData = returnauthorizationData(recid);
					log.debug('_RMData', _RMData);
					var _orderData = objectMaking(_RMData, orderNumber, customer)
						var orderData = {
						"msg": {
							"module": "SS2.MobileHub.Classes.SyncMobileHelpers.api3PLexternal",
							"opcode": "AddUpdateOrdersWithoutTrips",
							"status": null,
							"messageData": {
								"Orders": _orderData
							},
							"authToken": {
								"UserName": "netsuite_api",
								"Password": "sWWHpW5viOwP",
								"CompanyCode": "dilmar",
								"CryptoKey": null,
								"OrgRefId": "00000000-0000-0000-0000-000000000000",
								"UserRefId": "00000000-0000-0000-0000-000000000000"
							},
							"clockTimeInUTC": "2018-06-29T18:24:42.0977793Z"
						}
					};

	            var createProduct = postOrderData(orderData);
				var bizstatusObj = JSON.parse(createProduct.body);
				var bizstatus = bizstatusObj.d.status;
				if(bizstatus=="OK")
				{
					//record.submitFields({type:type,id:recid,values:{custbody_is_bizspeed_req_sent:true},options:{enableSourcing:!1,ignoreMandatoryFields:!0}});
				}
				}
	            
	        } catch (e) {
	            log.debug('Error in Main', e.toString());
	        }
	    } //function close


	    function postOrderData(OrderData) {
	        try {
	            log.debug('orderData', OrderData);
	            var _bizspeed_url = 'https://mh-est.goroam.com/SyncMobileSuiteJSON.asmx/BrokerMessageJSON';

	            var headersbizspeed = {
	                'content-type': 'application/json'
	            };
	            var response = https.request({
	                method: https.Method.POST,
	                url: _bizspeed_url,
	                body: JSON.stringify(OrderData),
	                headers: headersbizspeed
	            });
	            log.debug('OrderData response', response)
	            return response;

	        } catch (e) {
	            log.debug('Error in postOrderData', e.toString());
	        }
	    }
	    function returnauthorizationData(id) {
	        try {
	            var returnauthorizationSearchObj = search.create({
				   type: "returnauthorization",
				   filters:
				   [
					  ["type","anyof","RtnAuth"], 
					  "AND", 
					  // ["numbertext","haskeywords","RMA03"], 
					   ["internalid","anyof",id],
					  "AND", 
					  ["mainline","is","F"], 
					  "AND", 
					  ["taxline","is","F"], 
					  "AND", 
					  ["shipping","is","F"], 
					  "AND", 
					  ["cogs","is","F"]
				   ],
				   columns:
				   [
					  "tranid",
					  "createdfrom",
					  "memomain",
					  "entity",
					  "trandate",
      				  "shipaddress1",
	                  "shipaddress2",
	                  "shipcity",
	                  "shipstate",
	                  "shipzip",
					  "billaddressee",
	                  "billaddress1",
	                  "billaddress2",
	                  "billcity",
	                  "billstate",
	                  "billzip",
					  "location",
					  "item",
					  search.createColumn({
						 name: "displayname",
						 join: "item"
					  }),
					  search.createColumn({
	                        name: "internalid",
	                        join: "shippingAddress"
	                  }),
					  search.createColumn({
	                        name: "internalid",
	                        join: "billingAddress"
	                   }),
					   search.createColumn({
						 name: "custentity1",
						 join: "customer" 
					  }),
					  "unit",
					  "linesequencenumber",
					  "quantity",
					  "rate"
				   ]
				});
				var searchResultCount = returnauthorizationSearchObj.runPaged().count;
				log.debug("returnauthorizationSearchObj result count",searchResultCount);
				    
	            var arr = [];
	            var bodyData = {};
	            var counter = 0;
				returnauthorizationSearchObj.run().each(function(result){
	                var lineData = {};
	                if (counter == 0) {
	                    bodyData.createdfrom = result.getValue({
	                        name: 'createdfrom'
	                    });
						bodyData.memomain = result.getValue({
	                        name: 'memomain'
	                    });
						bodyData.createdfromText = result.getText({
	                        name: 'createdfrom'
	                    });
	                    bodyData.docnumber = result.getValue({
	                        name: 'tranid'
	                    });
	                    bodyData.customer = result.getValue({
	                        name: 'entity'
	                    }); 
						bodyData.location = result.getText({
	                        name: 'location'
	                    });
						bodyData.trandate = result.getValue({
	                        name: 'trandate'
	                    }); 
	                    bodyData.shipaddress1 = result.getValue({
	                        name: 'shipaddress1'
	                    });
	                    bodyData.shipaddress2 = result.getValue({
	                        name: 'shipaddress2'
	                    });
	                    bodyData.shipcity = result.getValue({
	                        name: 'shipcity'
	                    });
	                    bodyData.shipstate = result.getValue({
	                        name: 'shipstate'
	                    });
	                    bodyData.shipzip = result.getValue({
	                        name: 'shipzip'
	                    });
	                    bodyData.billaddressee = result.getValue({
	                        name: 'billaddressee'
	                    });
	                    bodyData.billaddress1 = result.getValue({
	                        name: 'billaddress1'
	                    });
	                    bodyData.billaddress2 = result.getValue({
	                        name: 'billaddress2'
	                    });
	                    bodyData.billcity = result.getValue({
	                        name: 'billcity'
	                    });
	                    bodyData.billstate = result.getValue({
	                        name: 'billstate'
	                    });
	                    bodyData.billzip = result.getValue({
	                        name: 'billzip'
	                    });
	                    bodyData.otherrefnum = result.getValue({
	                        name: 'otherrefnum'
	                    });
	                    
	                    bodyData.shipId = result.getValue({
	                        name: "internalid",
	                        join: "shippingAddress"
	                    });
	                    bodyData.billId = result.getValue({
	                        name: "internalid",
	                        join: "billingAddress"
	                    });
						bodyData.customerType = result.getValue( {
							 name: "custentity1",
							 join: "customer"
						  });
	                    arr.push(bodyData);
	                    counter++;
	                }
	                lineData.item = result.getValue({
	                    name: 'item'
	                });
	                lineData.itemDesc = result.getText({
	                    name: 'item'
	                });
					lineData.itemSalesDesc = result.getValue({
						 name: "displayname",
						 join: "item"
					  });
	                lineData.rate = result.getValue({
	                    name: 'rate'
	                });
	                lineData.unit = result.getValue({
	                    name: 'unit'
	                });
	                lineData.linesequencenumber = result.getValue({
	                    name: 'linesequencenumber'
	                });
	                lineData.quantity = result.getValue({
	                    name: 'quantity'
	                });
	                
	                arr.push(lineData);
	                return true;
	            });
	            return arr;
	        } catch (e) {
	            log.debug('Error in returnauthorizationSearchObj', e.toString());
	        }
	    }
	    function objectMaking(_RMData,orderNumber, customer,data) {
	        try {
	            var arr = [];
               
					   if(_RMData.length)
					   {
						   var obj = {
								"startTimeUtcString": new Date().toISOString(),
								"endTimeUtcString": new Date().toISOString(),
								"tripCode": null,
								"orderNo": orderNumber,
								"orderType": 'c',
								"instructions":_RMData[0].memomain ,
								"customerName": customer,
								"accountNo": _RMData[0].shipId,
								"alternateOrdNumber": '',
								"stopId": null,
								"parentAcctNo": "133073",
								"shipAddress1": _RMData[0].shipaddress1,
								"shipAddress2": _RMData[0].shipaddress2,
								"shipCity": _RMData[0].shipcity,
								"shipState":_RMData[0].shipstate,
								"shipZip": _RMData[0].shipzip,
								"billName": _RMData[0].billaddressee,
								"billingAddress1": _RMData[0].billaddress1,
								"billingAddress2":_RMData[0].billaddress2,
								"billCity": _RMData[0].billcity,
								"billState": _RMData[0].billstate,
								"billZip": _RMData[0].billzip,
								"customerLatitude": 0,
								"customerLongitude": 0,
								"isRequiredCod": false,
								"Eta": new Date(),
								"Etd": minutesToAdd(new Date()),
								"Timezone": null,
								"email": null,
								"phone": "",
								"releaseNo": '',
								"contact": "Shell",
								"customerType":  _RMData[0].customerType,
								"servicedByDepotID": _RMData[0].location
						   };
								var lineAr = [];
							for (var i = 1; i < _RMData.length; i++) {
							   var lineObj = {
										"orderNo": orderNumber,
										"itemID": _RMData[i].itemDesc,
										"itemDescription": _RMData[i].itemSalesDesc,
										"UOM":'',
										"VendorName": null,
										"lineNum": '',
										"customerItemID": _RMData[i].itemDesc,
										"customerItemDescription":_RMData[i].itemSalesDesc,
										"itemGroupName": null,
										"itemSubGroupName": null,
										"orderQty": _RMData[i].quantity,
										"taxRate": 0,
										"itemPrice": 0,
										"actionId": 0,
										"lineNotes": ""
									};
								lineAr.push(lineObj);	
							}
							obj.Details=lineAr;
							 arr.push(obj);
					   }
	                 
	            return arr;

	        } catch (e) {
	            log.debug('Error in object Making', e.toString());
	        }
	    }
	    function loadItemFulfillment(id)
		{
			try{
				 
			}catch(e)
			{
				log.debug('Error in loadItemFulfillment', e.toString());
			}
		}
		function minutesToAdd(date)
		{
			log.debug('date',date);
			var _date = date;
			var d = new Date(_date);
			log.debug('d',d);
			d.setMinutes(30); //390//6:30 hrs 
			return d;
		}
		return {
	        //  beforeLoad: beforeLoad,
	        //  beforeSubmit: beforeSubmit,
	        afterSubmit: afterSubmit
	    };

	});
