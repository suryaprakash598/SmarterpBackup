/*******************************************************************************
{{ScriptHeader}} *
 * Company:                  {{Company}}
 * Author:                   {{Name}} - {{Email}}
 * File:                     {{ScriptFileName}}
 * Script:                   {{ScriptTitle}}
 * Script ID:                {{ScriptID}}
 * Version:                  1.0
 *
 * @NApiVersion 2.0
 * @NScriptType Restlet
 *
 ******************************************************************************/

define(['N/runtime', 'N/task', 'N/record', 'N/search', 'N/file','N/encode'], function(
  /** @type {import('N/runtime')} **/ runtime,
  /** @type {import('N/task')}    **/ task,
  /** @type {import('N/record')}  **/ record,
  /** @type {import('N/search')}  **/ search,
  /** @type {import('N/log')}     **/ file,
  /** @type {import('N/log')}     **/ encode
) {

  /**
   * @type {import('N/types').EntryPoints.RESTlet.delete_}
   */
  function onDelete(requestParams) {
    // return string or object data
    return '1';
  }

  /**
   * @type {import('N/types').EntryPoints.RESTlet.get}
   */
  function onGet(requestParams) {
    // return string or object data
    return '1';
  }

  /**
   * @type {import('N/types').EntryPoints.RESTlet.post}
   */
  function onPost(requestParams) {
    // return string or object data
	log.debug('requestParams',requestParams);
	 var keys = Object.keys(requestParams);
	 var scriptObj = runtime.getCurrentScript(); 
	
	var folder = 1086;
	var scriptid='';
	var deployid='';
	var obj = {};
	if(requestParams.filetype=='cfd')
	{ 
		folder = 1247;
		scriptid=scriptObj.getParameter({name: 'custscript_cfd_scriptid'}) ;
		deployid=scriptObj.getParameter({name: 'custscript_cfd_deployid'}) ;
		obj= {'custscript_cfd_file_id' : fileId};
	}else if(requestParams.filetype=='ocrm')
	{ 
		folder = 1243;
		scriptid=scriptObj.getParameter({name: 'custscript_ocrm_scriptid'});
		deployid=scriptObj.getParameter({name: 'custscript_ocrm_deployid'});
		obj= {'custscript_ocrm_file_id' : fileId};
	}else if(requestParams.filetype=='ntd')
	{ 
		folder = 1245;
		scriptid=scriptObj.getParameter({name: 'custscript_ntd_scriptid'}) ;
		deployid=scriptObj.getParameter({name: 'custscript_ntd_deployid'});
		obj= {'custscript_ntd_file_id' : fileId};
	}
	var base64tocsv = encode.convert({
            string: requestParams.filedata,
            inputEncoding: encode.Encoding.BASE_64,
            outputEncoding:encode.Encoding.UTF_8
        });
 
	 var fileObj = file.create({
                        //To make each file unique and avoid overwriting, append date on the title
                        name: requestParams.filename, //'chkp_' + month + "" + day + '.csv',
                        fileType: file.Type.CSV,
                        contents: base64tocsv,
                        description: 'This is a CSV file.',
                        encoding: file.Encoding.UTF8,
                        folder: folder
                    });


                    //Save the CSV file
                    var fileId = fileObj.save();
					
					// Create a scheduled script task
				var scheduledScript = task.create({
					taskType: task.TaskType.SCHEDULED_SCRIPT
				});
				scheduledScript.scriptId = scriptid;//'customscript_dil_edi_shell_cfd';
				scheduledScript.deploymentId = deployid;//'customdeploy_dil_edi_shell_cfd';
				scheduledScript.params = obj;
				scheduledScript.submit(); 
    return '1';
  }

  /**
   * @type {import('N/types').EntryPoints.RESTlet.put}
   */
  function onPut(requestParams) {
    // return string or object data
    return '1';
  }

  return {
    'delete': onDelete,
    'get':    onGet,
    'post':   onPost,
    'put':    onPut
  };

});