/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 * @NModuleScope SameAccount
 */
define(['N/ui/serverWidget', 'N/redirect', 'N/runtime', 'N/record', 'N/ui/message', 'N/search', 'N/url', 'N/format', 'N/ui/dialog', 'N/email', 'N/file', 'N/task'],

    function (serverWidget, redirect, runtime, record, message, search, url, format, dialog, email, file, task) {

    /**
     * Definition of the Scheduled script trigger point.
     *
     * @param {Object} scriptContext
     * @param {string} scriptContext.type - The context in which the script is executed. It is one of the values from the scriptContext.InvocationType enum.
     * @Since 2015.2
     */
    function execute(scriptContext) {

        var scriptObj = runtime.getCurrentScript();
        log.debug('Script parameter of custscript1:', '');
        var fileObj = file.load({
            id: scriptObj.getParameter({   name: 'custscript_file_id'    })
        });
        var contents = fileObj.getContents();
        var groupResult = JSON.parse(contents);

        var keys = Object.keys(groupResult);
        //journal creation
        var journal = record.create({
            type: record.Type.JOURNAL_ENTRY,
            isDynamic: true
        });

        //set the values in the required fields
        var l = groupResult[keys[0]];
        journal.setValue('subsidiary', l[0].subsidiary);
        log.debug('subsidiary', groupResult[keys[0]].subsidiary)
        //journal.setValue('trandate',dataSource[0].date);
        journal.setValue('approvalstatus', 1); //pending approval

        var total_creditamount = 0;
        var total_debitamount = 0;
        var invoice_internalid = [];
        var bill_internalid = [];
        for (var m = 0; m < keys.length; m++) {
            //creating invoice
            var rebateData = groupResult[keys[m]];
            for (var j = 0; j < rebateData.length; j++) {
                var data = {};
                data.creditamount = rebateData[j].creditamount;
                data.debitamount = rebateData[j].debitamount;
                //data.memo = rebateData[j].memo;
                data.internalid = rebateData[j].internalid;
                data.customer = rebateData[j].customer;
              data.type = rebateData[j].type;
             if(data.type=='Invoice'){
                 invoice_internalid.push(data.internalid)
             }
              else{
                   bill_internalid.push(data.internalid)
              }

                if (data.creditamount) {
                    total_creditamount = format.parse({
                        value: data.creditamount,
                        type: format.Type.FLOAT
                    }) + format.parse({
                        value: total_creditamount,
                        type: format.Type.FLOAT
                    });
                   
                   
                 
                } else if (data.debitamount) {
                    total_debitamount = format.parse({
                        value: data.debitamount,
                        type: format.Type.FLOAT
                    }) + format.parse({
                        value: total_debitamount,
                        type: format.Type.FLOAT
                    });

                   
                  
                }
            }
        }
        log.debug('total_debitamount', total_debitamount);
        log.debug('total_creditamount', total_creditamount);
		if(total_creditamount>0){
		journal.selectNewLine('line');
                    journal.setCurrentSublistValue('line', 'account',654);
                    journal.setCurrentSublistValue('line', 'debit', total_creditamount); //dataSource[i].creditamount);12232  costco 157
                    //journal.setCurrentSublistValue('line','memo',data.memo);
                    //journal.setCurrentSublistValue('line', 'entity', rebateData[j].customerid);
                    //Commits the currently selected line on a sublist.
                    journal.commitLine('line');
		}
		if(total_debitamount>0){
			 journal.selectNewLine('line');
                    //Set the value for the field in the currently selected line.
                    journal.setCurrentSublistValue('line', 'account',654);
                    journal.setCurrentSublistValue('line', 'credit', total_debitamount); // dataSource[i].creditamount);
                    //journal.setCurrentSublistValue('line','memo',data.memo);
                    //journal.setCurrentSublistValue('line', 'entity', rebateData[j].customerid);
                    //Commits the currently selected line on a sublist.
                    journal.commitLine('line');
		}

        var bank_acount = total_creditamount - total_debitamount;
        log.debug('bank_account', Math.abs(bank_acount));
        if (bank_acount > 0) {
            log.debug('bank debit amount', bank_acount)
            journal.selectNewLine('line');
            journal.setCurrentSublistValue('line', 'account', 265); //265	0121	SOUTH STATE //previous 254
            journal.setCurrentSublistValue('line', 'credit', Math.abs(bank_acount)); //dataSource[i].creditamount);12232  costco 157
            journal.setCurrentSublistValue('line', 'memo', 'Total collection debit(-)');
            // journal.setCurrentSublistValue('line','entity',157);
            //Commits the currently selected line on a sublist.
            journal.commitLine('line');

        } else if (bank_acount < 0) {
            log.debug('bank credit amount', bank_acount)
            journal.selectNewLine('line');
            journal.setCurrentSublistValue('line', 'account', 265);//265	0121	SOUTH STATE //previous 254
            journal.setCurrentSublistValue('line', 'debit', Math.abs(bank_acount)); //dataSource[i].creditamount);12232  costco 157
            journal.setCurrentSublistValue('line', 'memo', 'Total collection credit(+)');
            //journal.setCurrentSublistValue('line','entity',157);
            //Commits the currently selected line on a sublist.
            journal.commitLine('line');
        }
        //save the record.
        /* if(total_debitamount==total_creditamount){
        var recid=journal.save();
        log.debug(recid);
        }
        else{
        log.debug('total_debitamount',total_debitamount);
        log.debug('total_creditamount',total_creditamount);
        log.debug('amounts are not equal');
        } */
        var recid =journal.save();
        log.debug(recid);
        if (recid) {
            for (var m = 0; m < invoice_internalid.length; m++) {
              try{
                var objRecord3 = record.transform({
                    fromType: record.Type.INVOICE,
                    fromId: invoice_internalid[m],
                    toType: record.Type.CUSTOMER_PAYMENT,
                    isDynamic: true,
                });
				
                 objRecord3.setValue({
                    fieldId: 'paymentmethod',
                    value: 1
                });

				objRecord3.setValue({
                    fieldId: 'undepfunds',
                    value:"F"
                });
                objRecord3.setValue({
				fieldId: 'account',
                    value: 654
				});
				
                var rid3 = objRecord3.save({
                    ignoreMandatoryFields: true
                });
                log.debug('customer payment', rid3)

            }catch(e){
              log.debug('error customer paymnet',e)
            }
            }
          var vendor=scriptObj.getParameter({
                name: 'custscript_vendor'
            });
          try{
           var billPayment = record.create({
                type: record.Type.VENDOR_PAYMENT,
                isDynamic: false,
                defaultValues: {
                        entity:vendor
                    }
                });
				billPayment.setValue({
                    fieldId: 'account',
                    value: 654              }); 
               
               for (var m = 0; m < bill_internalid.length; m++) {
                var bill_lineid = billPayment.findSublistLineWithValue({
                    sublistId: 'apply',
                    fieldId: 'doc',
                    value: bill_internalid[m]
                });
                billPayment.setSublistValue({
                    sublistId: 'apply',
                    fieldId: 'apply',
                    line: bill_lineid,
                    value: true
                });
                //log.debug('bill_lineid', bill_lineid);
			   }

                var rid = billPayment.save({
                    ignoreMandatoryFields: true
                });
                log.debug('vendor payment', rid)
          /*  for (var m = 0; m < bill_internalid.length; m++) {
				var vendorBillPayment = record.transform({
										fromType: 'vendorbill',
										fromId: bill_internalid[m],
										toType:'vendorpayment'
										});
				 
				vendorBillPayment.setValue({
                    fieldId: 'account',
                    value: 654                }); 
               

                var rid = vendorBillPayment.save({
                    ignoreMandatoryFields: true
                });
                log.debug('vendor payment', rid)
            }*/

        }
          catch(e){
            log.debug('vendor payment error',e)
          }
        }

    }

    return {
        execute: execute
    };

});