//Validations
//Customer Search
//
jQuery(document).ready(function(e) {
	debugger;
	 
	var customerId = getUrlParameter("customer");
      
 
	var itemsArray  =fdata[0].split(',') ;
			  var html = "";
			  var data = itemsArray;
			  if (data.length > 0) {
			   for (var i = 0; i < data.length; i++) {
                    if (data[i]) {
						var item = data[i];
                        html += '<tr data-qnty="1" data-amt="0" data-desc="' + item + '" data-item-line="' + item + '"  data-displayname="' + item + '">';
                        html += '<td><input type="checkbox" name="All" value="itema"></td>';
                        html += '<td data-item="' + item + '">' + item + '</td>';
                        html += '<td data-desc1="' + item + '">' + item + '</td>';
                        html += '<td data-qty="0" class="quantity">';
                        html += '<input type="number" min="0" value="0" class="quantity-input" >';
                        html += '</td>';
                         html += '<td data-amount="0">$0</td>';
                        html += '</tr>';
                    }

                }
				
			  } 
				else {
						html += '<tr><td colspan="6">This customer does not have items</td></tr>';
						jQuery('.unmarkall,.markall,.additems').hide();
						jQuery('.over-loader,.loader-wrapper').hide();
					} 
			jQuery("#itemsData").append(html);
			jQuery('.over-loader,.loader-wrapper').hide();
			 
		 
			 
		
		
			 //add functionalities
			  jQuery(document).on('click', '.markall', function(e) {
				jQuery("input[name='All']").prop("checked", true);
				});
				
				//UnMark All
				jQuery(document).on('click', '.unmarkall', function(e) {
					jQuery("input[name='All']").prop("checked", false);
				});
				
					//Update Price
					jQuery(document).on('click', '.quantity-input', function(e) {
						var quantity = jQuery(this).val();
						var price = jQuery(this).closest('tr').find('[data-amount]').attr('data-amount');
						var amount = Number(quantity) * Number(price);
						amount = amount.toFixed(2);
						jQuery(this).closest('tr').find('[data-amount]').text('$' + amount);
					});
    //Add Item(s)


jQuery(document).on('click', '.additems', function(e) {
        var arr = [];
        debugger;
			jQuery("tbody tr").each(function(e) {
			var obj = {};
            obj.check = jQuery(this).find('input:checkbox').prop('checked');
            obj.item = jQuery(this).attr("data-item-line");
			obj.quantity = jQuery(this).find('.quantity .quantity-input').val();
            obj.amount = jQuery(this).attr("data-amt");
            obj.description = jQuery(this).attr("data-desc");
            obj.displayname = jQuery(this).attr("data-displayname");

            console.log('obj.check', obj.check);
            if (obj.check != false)
                arr.push(obj);
			});
        if (arr.length == 0) {
            jQuery('#error-modal').toggle();
            jQuery('#errMsg').html('Please select atleast one item');
        } else {
            jQuery('.over-loader,.loader-wrapper').show();
				setTimeout(function() {
                //Set Values			   
                for (var j = 0; j < arr.length; j++) {
					debugger;
				window.opener.nlapiSelectNewLineItem("item");
				window.opener.nlapiSetCurrentLineItemText("item", "item", arr[j].item, true, true);	//window.opener.nlapiSetCurrentLineItemValue("item", "item", arr[j].internalid, true, true);
				window.opener.nlapiSetCurrentLineItemValue("item", "quantity", arr[j].quantity);
                    window.opener.nlapiSetCurrentLineItemValue("item", "rate", 1);
                    window.opener.nlapiSetCurrentLineItemValue("item", "amount", (Number(arr[j].quantity) * Number(1)));
                    window.opener.nlapiCommitLineItem("item");
                }
                window.close();
           }, 500);

        }
    });
	//Model PopUp
	 jQuery("#error-modal .close-icon").click(function() {
        jQuery("#error-modal").hide();
    });

	
//Get Parameter
function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}
});


